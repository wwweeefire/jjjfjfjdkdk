//
//  currencyvc.h
//  digitalCurrency
//
//  Created by 111 on 8/1/2565 BE.
//  Copyright © 2565 BE BIZZAN. All rights reserved.
//

#import "BaseViewController.h"
//#import "BaseViewController.h"
#import "countryModel.h"
NS_ASSUME_NONNULL_BEGIN
typedef void (^ReturnValueBlock) (countryModel *model);
@interface currencyvc : BaseViewController

@property(nonatomic, copy) ReturnValueBlock returnValueBlock;
@end

NS_ASSUME_NONNULL_END
