//
//  currencyvc.m
//  digitalCurrency
//
//  Created by 111 on 8/1/2565 BE.
//  Copyright © 2565 BE BIZZAN. All rights reserved.
//

//
//  countryViewController.m
//  digitalCurrency
//
//  Created by sunliang on 2019/2/23.
//  Copyright © 2019年 BIZZAN. All rights reserved.
//

#import "currencyvc.h"
#import "LoginNetManager.h"
#import "countryModel.h"
#import "SelectCountryTableViewCell.h"
@interface currencyvc ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong)NSMutableArray *contentArr;

@property (nonatomic,strong)UITableView *tableView;
@end

@implementation currencyvc
- (NSMutableArray *)contentArr
{
    if (!_contentArr) {
        _contentArr = [NSMutableArray array];
    }
    return _contentArr;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title=LocalizationKey(@"selectCountry");
    [self getData];
    

      _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 50) style:UITableViewStyleGrouped];
      
      //设置数据源，注意必须实现对应的UITableViewDataSource协议
      _tableView.dataSource=self;
      

    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    //如果iOS的系统是11.0，会有这样一个宏定义“#define __IPHONE_11_0  110000”；如果系统版本低于11.0则没有这个宏定义
   #ifdef __IPHONE_11_0
   if ([self.tableView  respondsToSelector:@selector(setContentInsetAdjustmentBehavior:)]) {
       self.tableView .contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
   }
   #endif

    [self.view addSubview:_tableView];
    
    _tableView.frame = CGRectMake(0, kNaviBar_HEIGHT, kSCREEN_WIDTH, kSCREEN_HEIGHT - kNaviBar_HEIGHT - kTabBar_HEIGHT);
    
    [self.tableView registerNib:[UINib nibWithNibName:@"SelectCountryTableViewCell" bundle:nil] forCellReuseIdentifier:NSStringFromClass([SelectCountryTableViewCell class])];
    // Do any additional setup after loading the view from its nib.
}
#pragma mark-获取国家列表
-(void)getData{
    [EasyShowLodingView showLodingText:LocalizationKey(@"loading")];
    [LoginNetManager getcurrencyCompleteHandle:^(id resPonseObj, int code) {
    [EasyShowLodingView hidenLoding];
        if (code) {
            if ([resPonseObj[@"code"] integerValue] == 0) {
//                NSLog(@"--%@",resPonseObj);
                NSDictionary *countryArray=resPonseObj[@"data"];
//                for (int i=0; i<countryArray.count; i++) {
//
                    [self.contentArr addObjectsFromArray:countryArray.allKeys];
                
                [self.tableView reloadData];
            }else{
                [self.view makeToast:resPonseObj[MESSAGE] duration:1.5 position:CSToastPositionCenter];
            }
        }else{
            [self.view makeToast:LocalizationKey(@"noNetworkStatus") duration:1.5 position:CSToastPositionCenter];
        }
    }];

}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.contentArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    SelectCountryTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([SelectCountryTableViewCell class]) forIndexPath:indexPath];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
      NSString * yy =self.contentArr[indexPath.row];
    cell.enName.text = yy ;
//  cell.zhName.text = model.zhName;
    return cell;

}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 66;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    countryModel*model=self.contentArr[indexPath.row];
    self.returnValueBlock(model);
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
