//
//  SelectCountryTableViewCell.h
//  digitalCurrency
//
//  Created by iDog on 2019/4/27.
//  Copyright © 2019年 BIZZAN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SelectCountryTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *enName;
@property (weak, nonatomic) IBOutlet UILabel *zhName;

@end
