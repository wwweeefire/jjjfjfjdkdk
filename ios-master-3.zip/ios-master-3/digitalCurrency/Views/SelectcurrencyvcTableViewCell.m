//
//  SelectCountryTableViewCell.m
//  digitalCurrency
//
//  Created by iDog on 2019/4/27.
//  Copyright © 2019年 BIZZAN. All rights reserved.
//

#import "SelectcurrencyvcTableViewCell.h"

@implementation SelectcurrencyvcTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
