//
//  JXCategoryIndicatorParamsModel.m
//  JXCategoryView
//
//  Created by jiaxin on 2018/12/13.
//  Copyright © 2018 jiaxin. All rights reserved.
//

#import "JXCategoryIndicatorParamsModel.h"

@implementation JXCategoryIndicatorParamsModel

@end
