//
//  ZLGestureLockIndicator.h
//  GestureLockDemo
//
//  Created by ZL on 2019/4/5.
//  Copyright © 2019年 ZL. All rights reserved.
//  九宫格指示器 小图

#import <UIKit/UIKit.h>

@interface ZLGestureLockIndicator : UIView

- (void)setGesturePassword:(NSString *)gesturePassword;

@end
