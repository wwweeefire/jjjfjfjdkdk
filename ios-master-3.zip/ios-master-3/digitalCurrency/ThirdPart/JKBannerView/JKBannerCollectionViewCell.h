//
//  JKBannerCollectionViewCell.h
//
//  Created by 王冲 on 2019/9/8.
//  Copyright © 2019年 yangsq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JKBannerCollectionViewCell : UICollectionViewCell

@property (nonatomic,strong) UIImageView *imageView;

@end
