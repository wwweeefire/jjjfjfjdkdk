//
//  ZLAdvertViewController.h
//  ZLAdvertDemo
//
//  Created by zhangli on 2019/2/28.
//  Copyright © 2019年 YSMX. All rights reserved.
//  广告链接页

#import <UIKit/UIKit.h>

@interface ZLAdvertViewController : UIViewController

@property (nonatomic, copy) NSString *adUrl;

@end
