//
//  BaseModel.h
//  siLuBi
//
//  Created by sunliang on 2019/12/21.
//  Copyright © 2019年 BIZZAN. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BaseModel : NSObject

@end
