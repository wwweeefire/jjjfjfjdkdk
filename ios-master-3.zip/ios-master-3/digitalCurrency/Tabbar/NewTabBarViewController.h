//
//  NewTabBarViewController.h
//  digitalCurrency
//
//  Created by chan on 2021/1/6.
//  Copyright © 2021 BZEX. All rights reserved.
//

#import "RDVTabBarController.h"

NS_ASSUME_NONNULL_BEGIN

@interface NewTabBarViewController : RDVTabBarController

- (void)resettabarItemsTitle;

@end

NS_ASSUME_NONNULL_END
