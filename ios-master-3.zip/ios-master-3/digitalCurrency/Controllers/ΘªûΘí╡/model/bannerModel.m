//
//  bannerModel.m
//  digitalCurrency
//
//  Created by sunliang on 2019/3/6.
//  Copyright © 2019年 BIZZAN. All rights reserved.
//

#import "bannerModel.h"

@implementation bannerModel

@end
