//
//  Marketmodel.h
//  digitalCurrency
//
//  Created by startlink on 2019/7/4.
//  Copyright © 2019年 BIZZAN. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Marketmodel : NSObject
@property (nonatomic,copy)NSString *currentBonusETHBnous;
@property (nonatomic,copy)NSString *safetyAndAssoction;
@property (nonatomic,copy)NSString *yesDayCashDividensBonusETH;
@property (nonatomic,copy)NSString *yesDayMineAmountBHB;
@property (nonatomic,copy)NSString *bhbAmount;

@end
