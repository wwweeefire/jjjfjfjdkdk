//
//  ChatGroupMessageViewController.h
//  digitalCurrency
//
//  Created by iDog on 2019/4/16.
//  Copyright © 2019年 BIZZAN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChatGroupMessageViewController : BaseViewController

@end
