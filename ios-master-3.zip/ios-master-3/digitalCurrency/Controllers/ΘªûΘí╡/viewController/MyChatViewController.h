//
//  MyChat.h
//  digitalCurrency
//
//  Created by 邵贤军 on 2021/6/29.
//  Copyright © 2021 BIZZAN. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MyChatViewController : BaseViewController

@end

NS_ASSUME_NONNULL_END
