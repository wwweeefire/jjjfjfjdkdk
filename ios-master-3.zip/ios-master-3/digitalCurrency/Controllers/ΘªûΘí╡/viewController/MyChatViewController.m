//
//  MyChat.m
//  digitalCurrency
//
//  Created by 邵贤军 on 2021/6/29.
//  Copyright © 2021 BIZZAN. All rights reserved.
//

#import "MyChatViewController.h"
#import <WebKit/WebKit.h>

@implementation MyChatViewController


- (void)viewDidLoad{
    [super viewDidLoad];
    
    self.title = [[ChangeLanguage bundle] localizedStringForKey:@"myservice" value:nil table:@"English"];
    
    //在APP内部打开指定网页
    WKWebView *myWebView = [[WKWebView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
    NSURL *url = [NSURL URLWithString:@"https://www.baidu.com/"];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [myWebView loadRequest:request];
    [self.view addSubview:myWebView];
    
//    //在APP外部浏览器中打开指定网页（一般默认跳转苹果自带Safari浏览器）
//    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://www.baidu.com/"]];
    
}

@end
