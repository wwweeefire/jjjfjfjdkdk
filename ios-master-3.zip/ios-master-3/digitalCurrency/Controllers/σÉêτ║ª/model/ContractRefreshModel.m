//
//  ContractRefreshModel.m
//  digitalCurrency
//
//  Created by ios on 2020/10/7.
//  Copyright © 2020 BIZZAN. All rights reserved.
//

#import "ContractRefreshModel.h"

@implementation ContractRefreshModel


@end
