//
//  ConatractCurrentEntrustModel.m
//  digitalCurrency
//
//  Created by ios on 2020/10/8.
//  Copyright © 2020 BIZZAN. All rights reserved.
//

#import "ConatractCurrentEntrustModel.h"

@implementation ConatractCurrentEntrustModel

@end
