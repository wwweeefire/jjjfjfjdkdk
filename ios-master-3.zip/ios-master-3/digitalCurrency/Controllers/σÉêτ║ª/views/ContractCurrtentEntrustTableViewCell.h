//
//  ContractCurrtentEntrustTableViewCell.h
//  digitalCurrency
//
//  Created by ios on 2020/9/23.
//  Copyright © 2020 BIZZAN. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ContractCurrtentEntrustTableViewCell : UITableViewCell

@property (nonatomic, strong) UILabel *mtitilelabel;

@property (nonatomic, strong) UILabel *timelabel;

@property (nonatomic, strong) UIButton *revokebtn;

@property (nonatomic, strong) UILabel *entrustTypeStrlabel;

@property (nonatomic, strong) UILabel *triggerPricelabel;

@property (nonatomic, strong) UILabel *entrustPricelabel;

@property (nonatomic, strong) UILabel *dealPricelabel;

@property (nonatomic, strong) UILabel *depositPricelabel;

@property (nonatomic, strong) UILabel *entrustNumberlabel;





@property (nonatomic, strong) UILabel *entrustTypetiplabel;

@property (nonatomic, strong) UILabel *triggertiplabel;

@property (nonatomic, strong) UILabel *entrusttiplabel;

@property (nonatomic, strong) UILabel *dealtiplabel;

@property (nonatomic, strong) UILabel *deposittiplabel;

@property (nonatomic, strong) UILabel *entrustnumbertiplabel;


@end

NS_ASSUME_NONNULL_END
