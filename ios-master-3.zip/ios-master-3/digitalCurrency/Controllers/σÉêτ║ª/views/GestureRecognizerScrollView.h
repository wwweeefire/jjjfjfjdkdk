//
//  GestureRecognizerScrollView.h
//  digitalCurrency
//
//  Created by ios on 2020/9/23.
//  Copyright © 2020 BIZZAN. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface GestureRecognizerScrollView : UIScrollView

@end

NS_ASSUME_NONNULL_END
