//
//  ContractKlineChartView.m
//  digitalCurrency
//
//  Created by ios on 2020/9/22.
//  Copyright © 2020 BIZZAN. All rights reserved.
//

#import "ContractKlineChartView.h"
#import "KLineChartView.h"
#import "KLinePeriodView.h"
#import "KLineIndicatorsView.h"
#import "KLineVerticalIndicatorsView.h"
#import "UIColor+RGB.h"
#import "DataUtil.h"
#import "KLineStateManager.h"

@interface ContractKlineChartView ()

@end

@implementation ContractKlineChartView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
