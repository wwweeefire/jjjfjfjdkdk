//
//  ContractHistoryDetailViewController.h
//  digitalCurrency
//
//  Created by ios on 2020/9/24.
//  Copyright © 2020 BIZZAN. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ConatractCurrentEntrustModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface ContractHistoryDetailViewController : UIViewController

@property (nonatomic, strong) ConatractCurrentEntrustModel *model;

@end

NS_ASSUME_NONNULL_END
