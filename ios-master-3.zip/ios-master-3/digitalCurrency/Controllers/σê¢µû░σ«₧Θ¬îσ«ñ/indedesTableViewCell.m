//
//  indedesTableViewCell.m
//  digitalCurrency
//
//  Created by 111 on 26/1/2565 BE.
//  Copyright © 2565 BE BIZZAN. All rights reserved.
//

#import "indedesTableViewCell.h"

@implementation indedesTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
