//
//  inputnumberTableViewCell.m
//  digitalCurrency
//
//  Created by 111 on 28/1/2565 BE.
//  Copyright © 2565 BE BIZZAN. All rights reserved.
//

#import "inputnumberTableViewCell.h"

@implementation inputnumberTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    [self.numberfield addTarget:self action:@selector(textfieldAction:) forControlEvents:UIControlEventEditingChanged];
    // Initialization code
}
- (void)textfieldAction:(UITextField *)textField
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(textFieldTag:TextFieldString:)]) {
        [self.delegate textFieldTag:textField.tag  TextFieldString:textField.text];
    }
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)reloadconn{
    
    self.conn.constant = 0;
}
@end
