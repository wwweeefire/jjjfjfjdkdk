//
//  intwotextTableViewCell.h
//  digitalCurrency
//
//  Created by 111 on 28/1/2565 BE.
//  Copyright © 2565 BE BIZZAN. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface intwotextTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *toplabel;
@property (weak, nonatomic) IBOutlet UILabel *botomlabel;

@end

NS_ASSUME_NONNULL_END
