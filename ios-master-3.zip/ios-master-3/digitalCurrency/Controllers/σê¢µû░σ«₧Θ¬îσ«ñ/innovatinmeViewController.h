//
//  innovatinmeViewController.h
//  digitalCurrency
//
//  Created by 111 on 2/2/2565 BE.
//  Copyright © 2565 BE BIZZAN. All rights reserved.
//

#import "BaseViewController.h"
#import "JXCategoryView.h"
#import "JXCategoryListContainerView.h"
NS_ASSUME_NONNULL_BEGIN

@interface innovatinmeViewController : BaseViewController
<JXCategoryListContainerViewDelegate>

@property (nonatomic, strong) JXCategoryTitleView *categoryView;
@property (nonatomic, strong) JXCategoryListContainerView *listContainerView;
@property (nonatomic, strong) NSArray <NSString *> *titles;

@end

NS_ASSUME_NONNULL_END
