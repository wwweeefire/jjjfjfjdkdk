//
//  innvoatonmedesViewController.h
//  digitalCurrency
//
//  Created by 111 on 2/2/2565 BE.
//  Copyright © 2565 BE BIZZAN. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface innvoatonmedesViewController : BaseViewController

@end

NS_ASSUME_NONNULL_END
