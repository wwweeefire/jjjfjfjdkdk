//
//  invosdesmodel.m
//  digitalCurrency
//
//  Created by 111 on 2/2/2565 BE.
//  Copyright © 2565 BE BIZZAN. All rights reserved.
//

#import "invosdesmodel.h"

@implementation invosdesmodel

+(NSDictionary *)mj_replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}
@end
