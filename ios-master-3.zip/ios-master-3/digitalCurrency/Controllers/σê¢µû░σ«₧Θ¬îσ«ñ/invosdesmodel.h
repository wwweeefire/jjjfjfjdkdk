//
//  invosdesmodel.h
//  digitalCurrency
//
//  Created by 111 on 2/2/2565 BE.
//  Copyright © 2565 BE BIZZAN. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface invosdesmodel : NSObject
@property (nonatomic, copy) NSString *ID;
@property (nonatomic, copy) NSString *activityID;
@property (nonatomic, copy)   NSString *activityName;
@property (nonatomic, copy) NSString *memberID;
@property (nonatomic, copy) NSString *state;
@property (nonatomic, copy) NSString *type;
@property (nonatomic, copy) NSString *freezeAmount;
@property (nonatomic, copy) NSString *amount;
@property (nonatomic, copy) NSString *price;
@property (nonatomic, copy) NSString *turnover;
@property (nonatomic, copy)   NSString *coinSymbol;
@property (nonatomic, copy)   NSString *baseSymbol;
@property (nonatomic, copy)   NSString *createTime;
@end

NS_ASSUME_NONNULL_END
