//
//  invodesTableViewCell.h
//  digitalCurrency
//
//  Created by 111 on 2/2/2565 BE.
//  Copyright © 2565 BE BIZZAN. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface invodesTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *onetitle;
@property (weak, nonatomic) IBOutlet UILabel *onetext;
@property (weak, nonatomic) IBOutlet UILabel *twotitle;
@property (weak, nonatomic) IBOutlet UILabel *twotext;
@property (weak, nonatomic) IBOutlet UILabel *threetitle;
@property (weak, nonatomic) IBOutlet UILabel *threetext;
@property (weak, nonatomic) IBOutlet UILabel *fourtitle;
@property (weak, nonatomic) IBOutlet UILabel *fourtext;

@property (weak, nonatomic) IBOutlet UILabel *fivetitle;
@property (weak, nonatomic) IBOutlet UILabel *fivetext;
@property (weak, nonatomic) IBOutlet UILabel *sextitle;
@property (weak, nonatomic) IBOutlet UILabel *sextext;
@property (weak, nonatomic) IBOutlet UILabel *seventitle;
@property (weak, nonatomic) IBOutlet UILabel *seventext;
@property (weak, nonatomic) IBOutlet UILabel *eighttitle;
@property (weak, nonatomic) IBOutlet UILabel *eighttext;

@end

NS_ASSUME_NONNULL_END
