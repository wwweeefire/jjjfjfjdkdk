//
//  inovationHearderVIew.m
//  digitalCurrency
//
//  Created by 111 on 26/1/2565 BE.
//  Copyright © 2565 BE BIZZAN. All rights reserved.
//

#import "inovationHearderVIew.h"

#import "ZSDTCoreTextTools.h"


@interface inovationHearderVIew ()
<DTAttributedTextContentViewDelegate,DTLazyImageViewDelegate>
@property (strong, nonatomic)  UIImageView *ssssimageview;
@property (strong, nonatomic)  UILabel *title;
@property (strong, nonatomic)  UILabel *leftlable;
@property (strong, nonatomic)  DTAttributedLabel *attributedLabel;

@property (nonatomic,copy)NSString *html;

@property (strong, nonatomic)  UITableView *tab;
@property (nonatomic, assign) CGRect viewMaxRect;
@end
@implementation inovationHearderVIew



- (instancetype)init
{
    self = [super init];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        self.ssssimageview = [[UIImageView alloc] init];
  
        
        [self addSubview:self.ssssimageview];
        self.title = [[UILabel alloc] init];
  

        [self addSubview: self.title];
        
        _viewMaxRect =   CGRectMake(0, 100, ZSToolScreenWidth, CGFLOAT_HEIGHT_UNKNOWN);
        self.leftlable = [[UILabel alloc] init];
        

        [self addSubview: self.leftlable];
        
      
        [self addSubview: self.attributedLabel];
        
       
        
        [ self.ssssimageview  mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(@15);
         
            make.left.equalTo(@(15));
       
            make.height.equalTo(@70);
            make.width.equalTo(@124);
   
            
        }];
        
      

              [self.title  mas_makeConstraints:^(MASConstraintMaker *make) {
                  make.left.equalTo(self.ssssimageview.mas_right).offset(5);
                  make.top.equalTo(self.ssssimageview.mas_top);
                  make.height.equalTo(@30);
                  make.right.equalTo(@(-15));
                


              }];

              [ self.leftlable  mas_makeConstraints:^(MASConstraintMaker *make) {
                  make.left.equalTo(self.ssssimageview.mas_right).offset(5);
                  make.height.equalTo(@30);
                  make.right.equalTo(@(-15));
                  make.bottom.equalTo(self.ssssimageview.mas_bottom).offset(0);
              }];
        
    }
    return self;
}


//图片占位
- (UIView *)attributedTextContentView:(DTAttributedTextContentView *)attributedTextContentView viewForAttachment:(DTTextAttachment *)attachment frame:(CGRect)frame{
 
    
    if([attachment isKindOfClass:[DTImageTextAttachment class]]){
        NSString *imageURL = [NSString stringWithFormat:@"%@", attachment.contentURL];
        DTLazyImageView *imageView = [[DTLazyImageView alloc] initWithFrame:frame];
        imageView.delegate = self;
        imageView.contentMode = UIViewContentModeScaleAspectFit;
        imageView.image = [(DTImageTextAttachment *)attachment image];
        imageView.url = attachment.contentURL;
        
//
//        [imageView sd_setImageWithURL:[NSURL URLWithString:imageURL] placeholderImage:[UIImage imageNamed:@"noplaceholderImage.png"]];
        
     
        return imageView;
    }
    return nil;
}

-(void)relaod:(innovationdesoneModel*)model tab:(UITableView *)tableView{
   
    self.tab = tableView;
    self.title.text = model.title;
    self.leftlable.text = model.detail;
    self.html =model.content;


    [self.ssssimageview sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",IMAGEHOST,model.smallImageUrl]] placeholderImage:[UIImage imageNamed:@"noplaceholderImage.png"]];
    
    
    [self relodtabvie];

    
}

-(void)relodtabvie {
    
    CGSize textSize = [self getAttributedTextHeightHtml:self.html with_viewMaxRect:_viewMaxRect];
    self.attributedLabel.frame = CGRectMake(_viewMaxRect.origin.x, _viewMaxRect.origin.y, _viewMaxRect.size.width, textSize.height);
    self.attributedLabel.attributedString = [self getAttributedStringWithHtml:self.html];
    self.frame = CGRectMake(0, 0, SCREEN_WIDTH_S, 100 + textSize.height);
    [self.tab reloadData];
}


#pragma mark  Delegate：DTLazyImageViewDelegate
//懒加载获取图片大小
- (void)lazyImageView:(DTLazyImageView *)lazyImageView didChangeImageSize:(CGSize)size {
    NSURL *url = lazyImageView.url;
    CGSize imageSize = size;
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"contentURL == %@", url];
    BOOL didUpdate = NO;
    // update all attachments that match this URL (possibly multiple images with same size)
    for (DTTextAttachment *oneAttachment in [self.attributedLabel.layoutFrame textAttachmentsWithPredicate:pred])
    {
        // update attachments that have no original size, that also sets the display size
        if (CGSizeEqualToSize(oneAttachment.originalSize, CGSizeZero))
        {
            oneAttachment.originalSize = imageSize;
            [self configNoSizeImageView:url.absoluteString size:imageSize];
            didUpdate = YES;
        }
    }
    
    //    if (didUpdate)
    //    {
    //        self.attributedLabel.attributedTextContentView.layouter = nil;
    //        [self.attributedLabel relayoutText];
    //    }
}


//字符串中一些图片没有宽高，懒加载图片之后，在此方法中得到图片宽高
//这个把宽高替换原来的html,然后重新设置富文本
- (void)configNoSizeImageView:(NSString *)url size:(CGSize)size
{
    CGFloat imgSizeScale = size.height/size.width;
    CGFloat widthPx = _viewMaxRect.size.width;
    CGFloat heightPx = widthPx * imgSizeScale;
    
    NSString *imageInfo = [NSString stringWithFormat:@"_src=\"%@\"",url];
    NSString *sizeString = [NSString stringWithFormat:@" style=\"width:%.fpx; height:%.fpx;\"",widthPx,heightPx];
    NSString *newImageInfo = [NSString stringWithFormat:@"_src=\"%@\"%@",url,sizeString];
    
    if ([self.html containsString:imageInfo]) {
        NSString *newHtml = [self.html stringByReplacingOccurrencesOfString:imageInfo withString:newImageInfo];
        // reload newHtml
        
        self.html = newHtml;
        CGSize textSize = [self getAttributedTextHeightHtml:self.html with_viewMaxRect:_viewMaxRect];
        self.attributedLabel.frame = CGRectMake(_viewMaxRect.origin.x, _viewMaxRect.origin.y, _viewMaxRect.size.width, textSize.height);
        self.attributedLabel.attributedString = [self getAttributedStringWithHtml:self.html];
        //self.attributedLabel.attributedString = [self getAttributedStringWithHtml:@"<span style=\"color:#333;font-size:15px;\"><strong>砍价师服务介绍</strong></span>"];
        [self.attributedLabel relayoutText];
        [self relodtabvie];
    }
}

#pragma mark - private Methods
//使用HtmlString,和最大左右间距，计算视图的高度
- (CGSize)getAttributedTextHeightHtml:(NSString *)htmlString with_viewMaxRect:(CGRect)_viewMaxRect{
    //获取富文本
    NSAttributedString *attributedString =  [self getAttributedStringWithHtml:htmlString];
    //获取布局器
    DTCoreTextLayouter *layouter = [[DTCoreTextLayouter alloc] initWithAttributedString:attributedString];
    NSRange entireString = NSMakeRange(0, [attributedString length]);
    //获取Frame
    DTCoreTextLayoutFrame *layoutFrame = [layouter layoutFrameWithRect:_viewMaxRect range:entireString];
    //得到大小
    CGSize sizeNeeded = [layoutFrame frame].size;
    return sizeNeeded;
}

//Html->富文本NSAttributedString
- (NSAttributedString *)getAttributedStringWithHtml:(NSString *)htmlString{
    //获取富文本
    NSData *data = [htmlString dataUsingEncoding:NSUTF8StringEncoding];
    NSAttributedString *attributedString = [[NSAttributedString alloc] initWithHTMLData:data documentAttributes:NULL];
    return attributedString;
}

#pragma mark - Getter && Setter
//懒加载创建
- (DTAttributedLabel *)attributedLabel{
    if (_attributedLabel == nil) {
        _attributedLabel = [[DTAttributedLabel alloc] initWithFrame:CGRectZero];
        _attributedLabel.delegate = self;
        //        _attributedLabel.backgroundColor = [UIColor lightGrayColor];
    }
    return _attributedLabel;
}

@end
