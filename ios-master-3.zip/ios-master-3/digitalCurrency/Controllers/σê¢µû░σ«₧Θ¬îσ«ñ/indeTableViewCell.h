//
//  indeTableViewCell.h
//  digitalCurrency
//
//  Created by 111 on 26/1/2565 BE.
//  Copyright © 2565 BE BIZZAN. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface indeTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *ssssimageview;
@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UILabel *leftlable;
@property (weak, nonatomic) IBOutlet UILabel *allnumberTitle;
@property (weak, nonatomic) IBOutlet UILabel *number;
@property (weak, nonatomic) IBOutlet UILabel *allnumber;
@property (weak, nonatomic) IBOutlet UILabel *starttime;
@property (weak, nonatomic) IBOutlet UILabel *endtime;
@property (weak, nonatomic) IBOutlet UILabel *des;
@property (weak, nonatomic) IBOutlet UIButton *btn;

@property (weak, nonatomic) IBOutlet UIProgressView *progress;

@end

NS_ASSUME_NONNULL_END
