//
//  indataViewController.m
//  digitalCurrency
//
//  Created by 111 on 26/1/2565 BE.
//  Copyright © 2565 BE BIZZAN. All rights reserved.
//

#import "indataViewController.h"

#import "RDVTabBarController.h"
#import "ContractExchangeManager.h"
#import "innovationModel.h"
#import "indeTableViewCell.h"
#import "innovationdesViewController.h"
@interface indataViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, strong) UITableView *mytableView;

@property (nonatomic, strong) UILabel *noDatalabel;

@property (nonatomic, strong) NSMutableArray *dataArray;

@property (nonatomic, assign) NSInteger pageNo;



@end

@implementation indataViewController


- (void)viewWillAppear:(BOOL)animated {
//    [super viewWillAppear:animated];
    [[self rdv_tabBarController] setTabBarHidden:YES animated:YES];
}

- (void)viewWillDisappear:(BOOL)animated {
//    [super viewWillDisappear:animated];
    [[self rdv_tabBarController] setTabBarHidden:YES animated:YES];
}



- (UIView *)listView {
    return self.view;
}



- (NSMutableArray *)dataArray{
    
    if (!_dataArray) {
        _dataArray=[NSMutableArray array];
    }
    return _dataArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    
    _pageNo=1;
//    self.navigationItem.title=LocalizationKey(@"HistoricalCurrent");
    self.view.backgroundColor=mainColor;
    UITableView *tabelev=[[UITableView alloc]init];
    [tabelev  setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    tabelev.backgroundColor = ViewBackgroundColor;
    tabelev.delegate=self;
    tabelev.dataSource=self;
    
    [self.view addSubview:tabelev];
    if (@available(iOS 11.0, *)) {

        tabelev.estimatedRowHeight = 0;

        tabelev.estimatedSectionFooterHeight = 0;

        tabelev.estimatedSectionHeaderHeight=0;
        tabelev.contentInsetAdjustmentBehavior= UIScrollViewContentInsetAdjustmentNever;
    }
    _mytableView=tabelev;
    [self footRefreshWithScrollerView:tabelev];
    [self headRefreshWithScrollerView:tabelev];
    [_mytableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.mas_equalTo(0);
        make.top.mas_equalTo(1);
    }];
    
    [self.mytableView registerNib:[UINib nibWithNibName:@"indeTableViewCell" bundle:nil] forCellReuseIdentifier:@"indeTableViewCell"];
    
    
    [self getinovatiomContractParam:_contractCoinId PageNo:_pageNo isShowLoading:YES];
}

//MARK:--上拉加载
- (void)refreshFooterAction{
    [self.mytableView.mj_footer resetNoMoreData];;

    self.pageNo++;
    if (_contractCoinId) {
       
        [self getinovatiomContractParam:_contractCoinId PageNo:_pageNo isShowLoading:NO];
    }
    
}
//MARK:--下拉刷新
- (void)refreshHeaderAction{
    self.pageNo = 1;
    if (_contractCoinId) {
        [self getinovatiomContractParam:_contractCoinId PageNo:_pageNo isShowLoading:NO];
    }
}


#pragma mark - UITableViewDelegate,UITableViewDataSource
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    
    return _dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    indeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([indeTableViewCell class])];
      if (!cell) {
          cell = [[NSBundle mainBundle] loadNibNamed:@"indeTableViewCell" owner:nil options:nil][0];
      }
      cell.selectionStyle = UITableViewCellSelectionStyleNone;
    innovationModel *Model = _dataArray[indexPath.row];
    NSString *string  = [NSString stringWithFormat:@"%@%@",IMAGEHOST,Model.smallImageUrl];

    [cell.ssssimageview sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",IMAGEHOST,Model.smallImageUrl]] placeholderImage:[UIImage imageNamed:@"noplaceholderImage.png"]];
    cell.title.text = Model.title;
    cell.leftlable.text = LocalizationKey(@"schedule");
    cell.allnumberTitle.text = LocalizationKey(@"total_activity");
    
    cell.starttime.text =  [NSString stringWithFormat:@"%@: %@",LocalizationKey(@"startTime"),Model.startTime];
    cell.endtime.text =  [NSString stringWithFormat:@"%@: %@",LocalizationKey(@"endTime"),Model.endTime];
    cell.number.text=  [NSString stringWithFormat:@"%@%%",[self getprogress:Model]];
    
    cell.progress.progress =[self getprogress:Model].intValue/100.0;
    
    cell.allnumber.text = [NSString stringWithFormat:@"%@%@",Model.totalSupply,Model.unit];
    cell.des.text = Model.detail;
    cell.btn.tag = 100000+indexPath.row;
    [cell.btn addTarget:self action:@selector(pushdes:) forControlEvents:UIControlEventTouchUpInside];

  
    return  cell;
               

}
-(void)pushdes:(UIButton *)sender{
    int i = sender.tag -100000;
    
    
    innovationModel *Model = _dataArray[i];
    innovationdesViewController *walletVC = [innovationdesViewController new];
    walletVC.model =Model;

    walletVC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:walletVC animated:YES];
    
    
}

-(NSString *)getprogress:(innovationModel *)model{
    NSString *pro= @"0";
    if([model.type isEqualToString:@"3"]){
        
        if(model.step.intValue == 1){
                   pro = @"50";
               }else if(model.step.intValue  == 2){
                   pro = @"75";
               }else if(model.step.intValue  == 3){
                   pro = @"100";
               }else{
                   pro = @"0";
               }
    }else {
        
        
        pro = model.progress;
    }

        

    
    return pro;
}
                                                  
                                                  

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath*)indexPath{
    return 386;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

}


- (void)getinovatiomContractParam:(NSString *)coinid PageNo:(NSInteger)pageNo isShowLoading:(BOOL)isshow {
    
    NSMutableDictionary *mdict=[NSMutableDictionary dictionary];
    
    if (coinid) {
            [mdict setObject:coinid forKey:@"step"];
    }
    [mdict setObject:@(pageNo) forKey:@"pageNo"];
    [mdict setObject:@(10) forKey:@"pageSize"];
 
    if (isshow) {
            [EasyShowLodingView showLodingText:LocalizationKey(@"loading")];
    }
    [ContractExchangeManager getinovatiomContractParam:mdict CompleteHandle:^(id  _Nonnull resPonseObj, int code) {
        if (isshow) {
            [EasyShowLodingView hidenLoding];
        }
        
        if ([self.mytableView.mj_footer isRefreshing]) {
                   [self.mytableView.mj_footer endRefreshing];
               }
               if ([self.mytableView.mj_header isRefreshing]) {
                   [self.mytableView.mj_header endRefreshing];
               }
        if (code) {
                   if ([resPonseObj[@"code"] intValue] == 0) {
                       NSArray *data= [innovationModel mj_objectArrayWithKeyValuesArray:resPonseObj[@"data"][@"content"]];
                       
                       if (data.count==0) {
                           [self.mytableView.mj_footer endRefreshingWithNoMoreData];
                       }else{
                           if (_pageNo==1) {
                               if (self.dataArray.count!=0) {
                                   [self.dataArray removeAllObjects];
                               }
                           }
                        [self.dataArray addObjectsFromArray:data];
                                         
                       [self.mytableView reloadData];
                       [self loadNoData];
                           
                       }
                           
                        
                   }
                               
                   else if ([resPonseObj[@"code"] integerValue] ==4000){

                       [YLUserInfo logout];
                       [self.view makeToast:resPonseObj[MESSAGE] duration:1.5 position:CSToastPositionCenter];
                   }
                   else{
                       [self.view makeToast:resPonseObj[MESSAGE] duration:1.5 position:CSToastPositionCenter];
                   }
               }
               else{
                   [self.view makeToast:LocalizationKey(@"noNetworkStatus") duration:1.5 position:CSToastPositionCenter];
               }
        
    }];
    
    
}
- (void)loadNoData {
    
    if (self.dataArray.count==0) {
        self.mytableView.hidden=YES;
        self.noDatalabel.hidden=NO;
    }else{
        self.mytableView.hidden=NO;
        self.noDatalabel.hidden=YES;
    }
    
}

-(UILabel *)noDatalabel {
    
    if (!_noDatalabel) {
        _noDatalabel=[[UILabel alloc]init];
        _noDatalabel.textAlignment=NSTextAlignmentCenter;
       // _noDatalabel.backgroundColor=mainColor;
        _noDatalabel.font=[UIFont fontWithName:@"PingFangSC" size:14.0 * kWindowWHOne];
        _noDatalabel.text=LocalizationKey(@"noDada");
        _noDatalabel.textColor=AppTextColor_Level_3;
        [self.view addSubview:_noDatalabel];
        MJWeakSelf;
        [self.noDatalabel mas_makeConstraints:^(MASConstraintMaker *make) {
             make.centerX.equalTo(weakSelf.mytableView.mas_centerX).offset(0);
                            make.centerY.equalTo(weakSelf.mytableView.mas_centerY).offset(0);
            make.size.mas_equalTo(CGSizeMake(SCREEN_WIDTH_S,40));
        }];
    }
    return _noDatalabel;;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
