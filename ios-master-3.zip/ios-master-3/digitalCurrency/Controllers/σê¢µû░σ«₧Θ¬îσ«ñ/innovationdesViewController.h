//
//  innovationdesViewController.h
//  digitalCurrency
//
//  Created by 111 on 26/1/2565 BE.
//  Copyright © 2565 BE BIZZAN. All rights reserved.
//

#import "BaseViewController.h"
#import "innovationModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface innovationdesViewController : BaseViewController
@property (nonatomic, strong) innovationModel *model;
@end

NS_ASSUME_NONNULL_END
