//
//  innovationModel.m
//  digitalCurrency
//
//  Created by 111 on 26/1/2565 BE.
//  Copyright © 2565 BE BIZZAN. All rights reserved.
//

#import "innovationModel.h"

@implementation innovationModel


+(NSDictionary *)mj_replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}

@end


@implementation innovationdesoneModel


+(NSDictionary *)mj_replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}

@end




