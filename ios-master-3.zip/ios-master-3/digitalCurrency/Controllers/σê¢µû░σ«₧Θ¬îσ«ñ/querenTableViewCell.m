//
//  querenTableViewCell.m
//  digitalCurrency
//
//  Created by 111 on 28/1/2565 BE.
//  Copyright © 2565 BE BIZZAN. All rights reserved.
//

#import "querenTableViewCell.h"

@implementation querenTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    [self.pushBtn setTitle:    LocalizationKey(@"Get_involved_now") forState:UIControlStateNormal];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
