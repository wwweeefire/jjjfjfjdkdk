//
//  InnovationViewController.m
//  digitalCurrency
//
//  Created by 111 on 29/12/2564 BE.
//  Copyright © 2564 BE BIZZAN. All rights reserved.
//

#import "InnovationViewController.h"
#import "UIColor+Util.h"
#import "JXCategoryView.h"
#import "indataViewController.h"
#import "RDVTabBarController.h"
#import "innvoatonmedesViewController.h"
@interface InnovationViewController ()<JXCategoryViewDelegate>
@property (nonatomic, strong) NSArray <NSString *> *type;
@end

@implementation InnovationViewController



- (void)viewDidLoad {
    [super viewDidLoad];
//
//    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationItem.title = LocalizationKey(@"Innovation_Lab");


    self.listContainerView = [[JXCategoryListContainerView alloc] initWithType:JXCategoryListContainerType_ScrollView delegate:self];
//    self.listContainerView.initListPercent = 0.5;
    [self.view addSubview:self.listContainerView];
    self.type =@[@"-1", @"0",@"1",@"2",@"3"];

 
    
    self.titles = @[ LocalizationKey(@"all"),LocalizationKey(@"About_to_start"),LocalizationKey(@"openging"),LocalizationKey(@"Distributing"),LocalizationKey(@"completed")];
    self.categoryView = [[JXCategoryTitleView alloc] init];
    //优化关联listContainer，以后后续比如defaultSelectedIndex等属性，才能同步给listContainer
    self.categoryView.listContainer = self.listContainerView;
    self.categoryView.delegate = self;
    self.categoryView.titleColor  = [UIColor whiteColor];
    self.categoryView.titleSelectedColor = RGBOF(0xF0A70A);
    self.categoryView.titles = self.titles;
    self.categoryView.defaultSelectedIndex = 0;
    JXCategoryIndicatorLineView *lineView = [[JXCategoryIndicatorLineView alloc] init];
    self.categoryView.indicators = @[lineView];
    lineView.indicatorColor =    RGBOF(0xF0A70A);
    [self.view addSubview:self.categoryView];

    [self rightBarItemWithTitle:[[ChangeLanguage bundle] localizedStringForKey:@"Iaminvolved" value:nil table:@"English"]];

}


//MARK:--明细的点击事件
-(void)RighttouchEvent{
 
    innvoatonmedesViewController *vc = [[innvoatonmedesViewController alloc] init];
 

    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
    
    
    
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];

    self.navigationController.interactivePopGestureRecognizer.enabled = (self.categoryView.selectedIndex == 0);
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];

    self.categoryView.frame = CGRectMake(0, 0, self.view.bounds.size.width, 50);
    self.listContainerView.frame = CGRectMake(0, 50, self.view.bounds.size.width, self.view.bounds.size.height - 50);
}

/**
 重载数据源：比如从服务器获取新的数据、否则用户对分类进行了排序等
 */
- (void)reloadData {
    
    self.titles = @[ LocalizationKey(@"all"),LocalizationKey(@"About_to_start"),LocalizationKey(@"openging"),LocalizationKey(@"Distributing"),LocalizationKey(@"completed")];

    //重载之后默认回到0，你也可以指定一个index
    self.categoryView.defaultSelectedIndex = 1;
    self.categoryView.titles = self.titles;
    [self.categoryView reloadData];
}


- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [[self rdv_tabBarController] setTabBarHidden:YES animated:YES];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [[self rdv_tabBarController] setTabBarHidden:NO animated:YES];
}


#pragma mark - JXCategoryListContainerViewDelegate

- (NSInteger)numberOfListsInlistContainerView:(JXCategoryListContainerView *)listContainerView {
    return self.titles.count;
}

- (id<JXCategoryListContentViewDelegate>)listContainerView:(JXCategoryListContainerView *)listContainerView initListForIndex:(NSInteger)index {
    indataViewController *listVC = [[indataViewController alloc] init];
    

    listVC.contractCoinId = self.type[index];
    return listVC;
}



#pragma mark - JXCategoryViewDelegate

- (void)categoryView:(JXCategoryBaseView *)categoryView didSelectedItemAtIndex:(NSInteger)index {
    //侧滑手势处理
    self.navigationController.interactivePopGestureRecognizer.enabled = (index == 0);
}

@end
