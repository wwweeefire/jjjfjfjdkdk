//
//  inputnumberTableViewCell.h
//  digitalCurrency
//
//  Created by 111 on 28/1/2565 BE.
//  Copyright © 2565 BE BIZZAN. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@protocol inputnumberTableViewCellDelegate <NSObject>
- (void)textFieldTag:(NSInteger)index TextFieldString: (NSString *)textString;
@end
@interface inputnumberTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UITextField *numberfield;
@property (weak, nonatomic) IBOutlet UILabel *numbertype;
@property (weak, nonatomic) IBOutlet UILabel *banncenumber;
@property (weak, nonatomic) IBOutlet UILabel *banctext;
@property (weak, nonatomic) IBOutlet UILabel *locktext;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *conn;
@property (nonatomic,weak) id<inputnumberTableViewCellDelegate> delegate;
-(void)reloadconn;
@end

NS_ASSUME_NONNULL_END
