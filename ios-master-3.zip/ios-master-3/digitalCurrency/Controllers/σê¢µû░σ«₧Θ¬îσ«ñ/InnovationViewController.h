//
//  InnovationViewController.h
//  digitalCurrency
//
//  Created by 111 on 29/12/2564 BE.
//  Copyright © 2564 BE BIZZAN. All rights reserved.
//

#import "BaseViewController.h"
#import "JXCategoryView.h"
#import "JXCategoryListContainerView.h"
NS_ASSUME_NONNULL_BEGIN

@interface InnovationViewController : BaseViewController
<JXCategoryListContainerViewDelegate>

@property (nonatomic, strong) JXCategoryTitleView *categoryView;
@property (nonatomic, strong) JXCategoryListContainerView *listContainerView;
@property (nonatomic, strong) NSArray <NSString *> *titles;

@end

NS_ASSUME_NONNULL_END
