//
//  inovationHearderVIew.h
//  digitalCurrency
//
//  Created by 111 on 26/1/2565 BE.
//  Copyright © 2565 BE BIZZAN. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "innovationModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface inovationHearderVIew : UIView


-(void)relaod:(innovationdesoneModel*)model tab:(UITableView *)tableView;
@end

NS_ASSUME_NONNULL_END
