//
//  innvoatonmedesViewController.m
//  digitalCurrency
//
//  Created by 111 on 2/2/2565 BE.
//  Copyright © 2565 BE BIZZAN. All rights reserved.
//

#import "innvoatonmedesViewController.h"
#import "ContractExchangeManager.h"
#import "invodesTableViewCell.h"

#import "invosdesmodel.h"

@interface innvoatonmedesViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, strong) UITableView *mytableView;

@property (nonatomic, strong) UILabel *noDatalabel;

@property (nonatomic, strong) NSMutableArray *dataArray;

@property (nonatomic, assign) NSInteger pageNo;



@end

@implementation innvoatonmedesViewController


- (void)viewWillAppear:(BOOL)animated {
//    [super viewWillAppear:animated];
//    [[self rdv_tabBarController] setTabBarHidden:YES animated:YES];
}

- (void)viewWillDisappear:(BOOL)animated {
//    [super viewWillDisappear:animated];
//    [[self rdv_tabBarController] setTabBarHidden:YES animated:YES];
}



//- (UIView *)listView {
//    return self.view;
//}



- (NSMutableArray *)dataArray{
    
    if (!_dataArray) {
        _dataArray=[NSMutableArray array];
    }
    return _dataArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

   
    
    _pageNo=1;
   self.title=LocalizationKey(@"Iaminvolved");
    self.view.backgroundColor=mainColor;
    UITableView *tabelev=[[UITableView alloc]init];
    [tabelev  setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    tabelev.backgroundColor = ViewBackgroundColor;
    tabelev.delegate=self;
    tabelev.dataSource=self;
    
    [self.view addSubview:tabelev];
    if (@available(iOS 11.0, *)) {

        tabelev.estimatedRowHeight = 0;

        tabelev.estimatedSectionFooterHeight = 0;

        tabelev.estimatedSectionHeaderHeight=0;
        tabelev.contentInsetAdjustmentBehavior= UIScrollViewContentInsetAdjustmentNever;
    }
    _mytableView=tabelev;
    [self footRefreshWithScrollerView:tabelev];
    [self headRefreshWithScrollerView:tabelev];
    [_mytableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.mas_equalTo(0);
        make.top.mas_equalTo(1);
    }];
    
    [self.mytableView registerNib:[UINib nibWithNibName:@"invodesTableViewCell" bundle:nil] forCellReuseIdentifier:@"invodesTableViewCell"];
    
    
    [self getinovatiomContractParaPageNo:_pageNo isShowLoading:YES];
}

//MARK:--上拉加载
- (void)refreshFooterAction{
    [self.mytableView.mj_footer resetNoMoreData];;

    self.pageNo++;

       
        [self getinovatiomContractParaPageNo:_pageNo isShowLoading:NO];
    
    
}
//MARK:--下拉刷新
- (void)refreshHeaderAction{
    self.pageNo = 1;

        [self getinovatiomContractParaPageNo:_pageNo isShowLoading:NO];
    
}


#pragma mark - UITableViewDelegate,UITableViewDataSource
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    
    return _dataArray.count;
}




-(NSString *)getsta:(invosdesmodel *)model{
    NSString *pro= @"0";
  

            if(model.type.intValue  == 5){
                
                
                if(model.state.intValue == 1){
                     pro = @"未部署";
                 }else if(model.state.intValue  == 2){
                     pro = @"已部署";
                 }else if(model.state.intValue  == 3){
                     pro = @"已撤销";
                 }
     
               }else {
             
                   
                   
                   if(model.state.intValue == 1){
                        pro = @"待成交";
                    }else if(model.state.intValue  == 2){
                        pro = @"已成交";
                    }else if(model.state.intValue  == 3){
                        pro = @"已撤销";
                    }
               }
               


    return pro;
    
}
-(NSString *)gettype:(invosdesmodel *)model{
    NSString *pro= @"0";
  

              if(model.type.intValue == 1){
                   pro = @"首次上线(抢购)";
               }else if(model.type.intValue  == 2){
                   pro = @"首次上线(平分)";
               }else if(model.type.intValue  == 3){
                   pro = @"持仓瓜分";
               }else if(model.type.intValue  == 4){
                   pro = @"自由认购";
               }else if(model.type.intValue  == 5){
                   pro = @"云矿机认购";
               }else if(model.type.intValue  == 6){
                   pro = @"锁仓释放";
               }
               else{
                   pro = @"未知";
               }
   


    return pro;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    invodesTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([invodesTableViewCell class])];
      if (!cell) {
          cell = [[NSBundle mainBundle] loadNibNamed:@"invodesTableViewCell" owner:nil options:nil][0];
      }
    
      cell.selectionStyle = UITableViewCellSelectionStyleNone;
    invosdesmodel *model  = _dataArray[indexPath.row];
    
    

    cell.onetitle.text =LocalizationKey(@"nameac");
    cell.onetext.text = model.activityName;
    



    cell.twotitle.text =LocalizationKey(@"typeac");
    cell.twotext.text = [self gettype: model];
    
cell.threetitle.text = LocalizationKey(@"Subscriptionquantity");

    cell.threetext.text =[NSString stringWithFormat:@"%@",model.amount];

   
    
cell.fourtitle.text = LocalizationKey(@"participatingcurrency");
    cell.fourtext.text =[NSString stringWithFormat:@"%@",model.baseSymbol];
    
cell.fivetitle.text =LocalizationKey(@"Subscriptionunit");
    cell.fivetext.text =[NSString stringWithFormat:@"%@",model.coinSymbol];
    
    cell.sextitle.text =LocalizationKey(@"state");
    cell.sextext.text=[self getsta:model];
    
cell.seventitle.text =LocalizationKey(@"Turnover");
    cell.seventext.text =[NSString stringWithFormat:@"%@%@",model.turnover,model.baseSymbol];
    
    cell.eighttitle.text =LocalizationKey(@"createTime");
    cell.eighttext.text =[NSString stringWithFormat:@"%@",model.createTime];
    
    
  
  
    return  cell;
               

}

                                                 
                                                  

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath*)indexPath{
    return 214;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

}


- (void)getinovatiomContractParaPageNo:(NSInteger)pageNo isShowLoading:(BOOL)isshow {
    
    NSMutableDictionary *mdict=[NSMutableDictionary dictionary];
    
 
    [mdict setObject:@(pageNo) forKey:@"pageNo"];
    [mdict setObject:@(10) forKey:@"pageSize"];
 
    if (isshow) {
            [EasyShowLodingView showLodingText:LocalizationKey(@"loading")];
    }
    [ContractExchangeManager ucactivitygetmyorders:mdict CompleteHandle:^(id  _Nonnull resPonseObj, int code) {
        if (isshow) {
            [EasyShowLodingView hidenLoding];
        }
        
        if ([self.mytableView.mj_footer isRefreshing]) {
                   [self.mytableView.mj_footer endRefreshing];
               }
               if ([self.mytableView.mj_header isRefreshing]) {
                   [self.mytableView.mj_header endRefreshing];
               }
        if (code) {
                   if ([resPonseObj[@"code"] intValue] == 0) {
                       NSArray *data= [invosdesmodel mj_objectArrayWithKeyValuesArray:resPonseObj[@"data"][@"content"]];
                       
                       if (data.count==0) {
                           [self.mytableView.mj_footer endRefreshingWithNoMoreData];
                       }else{
                           if (_pageNo==1) {
                               if (self.dataArray.count!=0) {
                                   [self.dataArray removeAllObjects];
                               }
                           }
                        [self.dataArray addObjectsFromArray:data];
                                         
                       [self.mytableView reloadData];
                       [self loadNoData];
                           
                       }
                           
                        
                   }
                               
                   else if ([resPonseObj[@"code"] integerValue] ==4000){

                       [YLUserInfo logout];
                       [self.view makeToast:resPonseObj[MESSAGE] duration:1.5 position:CSToastPositionCenter];
                   }
                   else{
                       [self.view makeToast:resPonseObj[MESSAGE] duration:1.5 position:CSToastPositionCenter];
                   }
               }
               else{
                   [self.view makeToast:LocalizationKey(@"noNetworkStatus") duration:1.5 position:CSToastPositionCenter];
               }
        
    }];
    
    
}
- (void)loadNoData {
    
    if (self.dataArray.count==0) {
        self.mytableView.hidden=YES;
        self.noDatalabel.hidden=NO;
    }else{
        self.mytableView.hidden=NO;
        self.noDatalabel.hidden=YES;
    }
    
}

-(UILabel *)noDatalabel {
    
    if (!_noDatalabel) {
        _noDatalabel=[[UILabel alloc]init];
        _noDatalabel.textAlignment=NSTextAlignmentCenter;
       // _noDatalabel.backgroundColor=mainColor;
        _noDatalabel.font=[UIFont fontWithName:@"PingFangSC" size:14.0 * kWindowWHOne];
        _noDatalabel.text=LocalizationKey(@"noDada");
        _noDatalabel.textColor=AppTextColor_Level_3;
        [self.view addSubview:_noDatalabel];
        MJWeakSelf;
        [self.noDatalabel mas_makeConstraints:^(MASConstraintMaker *make) {
             make.centerX.equalTo(weakSelf.mytableView.mas_centerX).offset(0);
                            make.centerY.equalTo(weakSelf.mytableView.mas_centerY).offset(0);
            make.size.mas_equalTo(CGSizeMake(SCREEN_WIDTH_S,40));
        }];
    }
    return _noDatalabel;;
}


 
@end
