//
//  innovationdesViewController.m
//  digitalCurrency
//
//  Created by 111 on 26/1/2565 BE.
//  Copyright © 2565 BE BIZZAN. All rights reserved.
//

#import "innovationdesViewController.h"
#import "indedesTableViewCell.h"
#import "MineNetManager.h"
#import "querenTableViewCell.h"
#import <WebKit/WebKit.h>
#import "inovationHearderVIew.h"
#import "ContractExchangeManager.h"
#import "intwotextTableViewCell.h"
#import "inputnumberTableViewCell.h"

#import "WalletManageModel.h"
#import "inebuyTableViewCell.h"
#import "ykjTableViewCell.h"
#import "intwoTableViewCell.h"


#import "AccountSettingInfoModel.h"
#import "PopView.h"

#import "codephoneView.h"
#import "LoginNetManager.h"

@interface innovationdesViewController ()<UITableViewDelegate,UITableViewDataSource,inputnumberTableViewCellDelegate>
@property (nonatomic, strong) UITableView *mytableView;
@property (nonatomic, strong) NSMutableArray *assetTotalArr;
@property (nonatomic, copy) NSString *assetUSD;
@property (nonatomic, copy) NSString *assetCNY;
@property (nonatomic, strong) UILabel *noDatalabel;
@property(nonatomic,strong) AccountSettingInfoModel *accountInfo;
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, strong) inovationHearderVIew *hearview;
@property (nonatomic ,strong) codephoneView *loginView;
@property (nonatomic, assign) NSInteger pageNo;

@property (nonatomic, strong) NSArray <NSString *> *type;
@property (nonatomic, strong) innovationdesoneModel*desmodel;
@property (nonatomic, strong) NSArray <NSString *> *titles;

@property (nonatomic, strong)  NSString * text;
@property (nonatomic, strong)  NSString * codetext;
@end

@implementation innovationdesViewController

- (codephoneView *)loginView{
    if (_loginView == nil) {
        _loginView = [[NSBundle mainBundle] loadNibNamed:@"codephoneView" owner:nil options:nil].firstObject;
        
        _loginView.phonenumber.enabled = NO;
        _loginView.titeltetx.text = [[ChangeLanguage bundle] localizedStringForKey:@"messageCode" value:nil table:@"English"] ;
        
        _loginView.sendcode.titleLabel.text = [[ChangeLanguage bundle] localizedStringForKey:@"getVerifyCode" value:nil table:@"English"] ;
        
        
        _loginView.Surebtn.titleLabel.text = [[ChangeLanguage bundle] localizedStringForKey:@"confirm" value:nil table:@"English"] ;
        [_loginView.sendcode addTarget:self action:@selector(getcode) forControlEvents:UIControlEventTouchUpInside];
        
        
        [_loginView.Surebtn addTarget:self action:@selector(Surebtn) forControlEvents:UIControlEventTouchUpInside];
        [_loginView.codeptext addTarget:self action:@selector(textfieldAction:) forControlEvents:UIControlEventEditingChanged];
    }
    return _loginView;
}

-(void)Surebtn{
    
    
    if(self.codetext.length >0){
        
        [self getsuredata];
        
        
    }else {
        [self.view makeToast:[[ChangeLanguage bundle] localizedStringForKey:@"inputMessageCode" value:nil table:@"English"] duration:1.5 position:CSToastPositionCenter];
    }
}


-(void)getsuredata {
    
    
    

        [EasyShowLodingView showLodingText:[[ChangeLanguage bundle] localizedStringForKey:@"loading" value:nil table:@"English"]];
        NSMutableDictionary *mdict=[NSMutableDictionary dictionary];
        

                [mdict setObject:self.text forKey:@"amount"];
    [mdict setObject:self.model.type forKey:@"activityId"];
    
    [mdict setObject:self.accountInfo.mobilePhone forKey:@"aims"];
    
    [mdict setObject:self.codetext forKey:@"code"];

        [ContractExchangeManager activityattendtParam:mdict CompleteHandle:^(id  _Nonnull resPonseObj, int code) {
      
                [EasyShowLodingView hidenLoding];
            
        
            if (code) {
                       if ([resPonseObj[@"code"] intValue] == 0) {
                           
                           [self.navigationController popViewControllerAnimated:YES];
                         
                        
                       }
                                   
                       else if ([resPonseObj[@"code"] integerValue] ==4000){

                           [YLUserInfo logout];
//                           [ShowLoGinVC showLoginVc:self withTipMessage:resPonseObj[MESSAGE]];
                           [self.view makeToast:resPonseObj[MESSAGE] duration:1.5 position:CSToastPositionCenter];
                       }
                       else{
                           [self.view makeToast:resPonseObj[MESSAGE] duration:1.5 position:CSToastPositionCenter];
                       }
                   }
                   else{
                       [self.view makeToast:LocalizationKey(@"noNetworkStatus")  duration:1.5 position:CSToastPositionCenter];
                   }
            
        }];
        
        
    
}
-(void)getcode {
    
    
    
   
    
    [EasyShowLodingView showLodingText:LocalizationKey(@"loading")];
     __block NSMutableString *postResult = [[NSMutableString alloc] init];
   
     [postResult appendFormat:@"%@", [NSString stringWithFormat:@"account=%@",_loginView.phonenumber.text]];
     NSDictionary *headerFields = @{@"Content-Type":@"application/x-www-form-urlencoded;charset=UTF-8"};
     NSMutableURLRequest *secondaryRequest;
   
   
           secondaryRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",HOST,@"uc/mobile/activity/code"]] cachePolicy:NSURLRequestReloadIgnoringCacheData timeoutInterval:15.0];
    
     secondaryRequest.HTTPMethod = @"POST";
     secondaryRequest.allHTTPHeaderFields = headerFields;
     secondaryRequest.HTTPBody = [postResult dataUsingEncoding:NSUTF8StringEncoding];
     NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
     NSURLSession *session = [NSURLSession sessionWithConfiguration:config];
     NSURLSessionDataTask *task = [session dataTaskWithRequest:secondaryRequest completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
         dispatch_async(dispatch_get_main_queue(), ^{
             [EasyShowLodingView hidenLoding];
         });
     
         NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
         if (!error && httpResponse.statusCode == 200) {
             NSError *err;
             NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&err];
             if (!err) {
                 if ([dict[@"code"] integerValue] == 0) {
                     [self openCountdown];
                 }
                 else {

                     dispatch_async(dispatch_get_main_queue(), ^{
                         [APPLICATION.window makeToast:dict[@"message"] duration:1.5 position:CSToastPositionCenter];
                     });

                 }
             }
         }
     }];

     [task resume];

    
    
    
  
    
}


- (void)textfieldAction:(UITextField *)textField
{
    self.codetext = textField.text;
}

-(void)textFieldTag:(NSInteger)index TextFieldString:(NSString *)textString{
 
    self.text = textString;
}

// 开启倒计时效果
-(void)openCountdown{

    __block NSInteger time = 59; //倒计时时间
    
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_source_t _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
    
    dispatch_source_set_timer(_timer,dispatch_walltime(NULL, 0),1.0*NSEC_PER_SEC, 0); //每秒执行
    
    dispatch_source_set_event_handler(_timer, ^{
        NSString *str  = LocalizationKey(@"Resend");
        if(time <= 0){ //倒计时结束，关闭
     
            
            dispatch_source_cancel(_timer);
            dispatch_async(dispatch_get_main_queue(), ^{
                _loginView.sendcode.titleLabel.text =str;
                //设置按钮的样式
                [_loginView.sendcode setTitle:str forState:UIControlStateNormal];
                
              
               
                _loginView.sendcode.userInteractionEnabled = YES;
                _loginView.sendcode.backgroundColor  =RGBOF(0xFB8557) ;
            });

        }else{
            
            int seconds = time % 60;
            dispatch_async(dispatch_get_main_queue(), ^{
                _loginView.sendcode.titleLabel.text = [NSString stringWithFormat:@"%@(%.2d)",str, seconds];
                //设置按钮显示读秒效果
                [_loginView.sendcode setTitle:[NSString stringWithFormat:@"%@(%.2d)",str, seconds] forState:UIControlStateNormal];
//                [_loginView.sendcode setTitleColor: forState:UIControlStateNormal];
                _loginView.sendcode.backgroundColor  =RGBOF(0x979797);
                _loginView.sendcode.userInteractionEnabled = NO;
            });
            time--;
        }
    });
    dispatch_resume(_timer);
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.type =@[ @"0",@"1",@"2",@"3"];
    
    self.titles = @[ LocalizationKey(@"About_to_start"),LocalizationKey(@"openging"),LocalizationKey(@"Distributing"),LocalizationKey(@"completed")];
    self.hearview = [[inovationHearderVIew alloc] init];
    self.title = self.model.title;
    
    
//    self.navigationItem.title=LocalizationKey(@"HistoricalCurrent");
    self.view.backgroundColor=mainColor;
    UITableView *tabelev=[[UITableView alloc]init];
    [tabelev  setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    tabelev.backgroundColor = ViewBackgroundColor;
    tabelev.delegate=self;
    tabelev.dataSource=self;
    self.assetUSD = @"0";
    
    [self.view addSubview:tabelev];
    if (@available(iOS 11.0, *)) {

        tabelev.estimatedRowHeight = 0;

        tabelev.estimatedSectionFooterHeight = 0;

        tabelev.estimatedSectionHeaderHeight=0;
        tabelev.contentInsetAdjustmentBehavior= UIScrollViewContentInsetAdjustmentNever;
    }
    _mytableView=tabelev;
 
    [_mytableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.mas_equalTo(0);
        make.top.mas_equalTo(1);
    }];
    
    [self.mytableView registerNib:[UINib nibWithNibName:@"indedesTableViewCell" bundle:nil] forCellReuseIdentifier:@"indedesTableViewCell"];
    
    [self.mytableView registerNib:[UINib nibWithNibName:@"querenTableViewCell" bundle:nil] forCellReuseIdentifier:@"querenTableViewCell"];
    
    [self.mytableView registerNib:[UINib nibWithNibName:@"intwotextTableViewCell" bundle:nil] forCellReuseIdentifier:@"intwotextTableViewCell"];
    [self.mytableView registerNib:[UINib nibWithNibName:@"inputnumberTableViewCell" bundle:nil] forCellReuseIdentifier:@"inputnumberTableViewCell"];
    [self.mytableView registerNib:[UINib nibWithNibName:@"inebuyTableViewCell" bundle:nil] forCellReuseIdentifier:@"inebuyTableViewCell"];
    
    [self.mytableView registerNib:[UINib nibWithNibName:@"ykjTableViewCell" bundle:nil] forCellReuseIdentifier:@"ykjTableViewCell"];
    
    
    [self.mytableView registerNib:[UINib nibWithNibName:@"intwoTableViewCell" bundle:nil] forCellReuseIdentifier:@"intwoTableViewCell"];
    
    self.mytableView.tableHeaderView = self.hearview;
    [self getinovatiomContractParam];
    [self getTotalAssets];
    
  
}


- (void)getinovatiomContractParam {
    [EasyShowLodingView showLodingText:[[ChangeLanguage bundle] localizedStringForKey:@"loading" value:nil table:@"English"]];
    NSMutableDictionary *mdict=[NSMutableDictionary dictionary];
    

            [mdict setObject:self.model.ID forKey:@"id"];

    [ContractExchangeManager getinovatiomdesContractParam:mdict CompleteHandle:^(id  _Nonnull resPonseObj, int code) {
  
            [EasyShowLodingView hidenLoding];
        
    
        if (code) {
                   if ([resPonseObj[@"code"] intValue] == 0) {
                       
                      
                       self.desmodel  = [innovationdesoneModel mj_objectWithKeyValues:resPonseObj[@"data"]];
                       [self.hearview relaod:self.desmodel tab:self.mytableView];
                       
                       [self.mytableView reloadData];
                     
                    
                   }
                               
                   else if ([resPonseObj[@"code"] integerValue] ==4000){

                       [YLUserInfo logout];
                       [self.view makeToast:resPonseObj[MESSAGE] duration:1.5 position:CSToastPositionCenter];
                   }
                   else{
                       [self.view makeToast:resPonseObj[MESSAGE] duration:1.5 position:CSToastPositionCenter];
                   }
               }
               else{
                   [self.view makeToast:LocalizationKey(@"noNetworkStatus") duration:1.5 position:CSToastPositionCenter];
               }
        
    }];
    
    
}

-(void)getTotalAssets{
    //    [EasyShowLodingView showLodingText:[[ChangeLanguage bundle] localizedStringForKey:@"loading" value:nil table:@"English"]];
    [MineNetManager getMyWalletInfoForCompleteHandle:^(id resPonseObj, int code) {
        //        [EasyShowLodingView hidenLoding];
        if (code) {
            if ([resPonseObj[@"code"] integerValue] == 0) {
                [self.assetTotalArr removeAllObjects];
                NSArray *dataArr = [WalletManageModel mj_objectArrayWithKeyValuesArray:resPonseObj[@"data"]];
                double ass1 = 0.0;
                double ass2 = 0.0;
                for (WalletManageModel *walletModel in dataArr) {
                    if([walletModel.coin.unit isEqualToString:@"USDT"]){
                        double   balance   = [walletModel.balance doubleValue];
                        ass1  = balance;
                    }
                    
                    
               
                    
          
                }
                
                self.assetUSD = [NSString stringWithFormat:@"%.2f",ass1];
                [self.mytableView reloadData];
             
                 
            }else{
                [self.view makeToast:resPonseObj[MESSAGE] duration:1.5 position:CSToastPositionCenter];
            }
        }else{
            [self.view makeToast:[[ChangeLanguage bundle] localizedStringForKey:@"noNetworkStatus" value:nil table:@"English"] duration:1.5 position:CSToastPositionCenter];
        }
    }];
}


#pragma mark - UITableViewDelegate,UITableViewDataSource
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    
    if([self.model.type isEqualToString:@"2"]||[self.model.type isEqualToString:@"1"]){
        return self.desmodel != nil?2:0;
        
    }
    if([self.model.type isEqualToString:@"6"]){
        return self.desmodel != nil?5:0;
        
    } if([self.model.type isEqualToString:@"5"]){
        return self.desmodel != nil?4:0;
        
    }if([self.model.type isEqualToString:@"3"]){
        return self.desmodel != nil?5:0;
        
    }if([self.model.type isEqualToString:@"4"]){
        return self.desmodel != nil?4:0;
        
    }
    
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    if([self.model.type isEqualToString:@"2"]||[self.model.type isEqualToString:@"1"]){
        
        
        if (indexPath.row  == 0) {
            indedesTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([indedesTableViewCell class])];
              if (!cell) {
                  cell = [[NSBundle mainBundle] loadNibNamed:@"indedesTableViewCell" owner:nil options:nil][0];
              }
              cell.selectionStyle = UITableViewCellSelectionStyleNone;
      
                
                cell.titleview.text = LocalizationKey(@"Basic_Information");
                cell.jinduLabel.text= LocalizationKey(@"schedule");
                cell.allnumberTitle.text =LocalizationKey(@"total_activity");

                cell.number.text=  [NSString stringWithFormat:@"%@%%",[self getprogress:self.desmodel]];
                
                cell.progress.progress =[self getprogress:self.desmodel].intValue/100.0;
                

                
                cell.allnumber.text = [NSString stringWithFormat:@"%@%@",self.desmodel.totalSupply,self.desmodel.unit];
                cell.stylelabel.text =LocalizationKey(@"state");
                cell.styletext.text = self.titles[self.desmodel.step.intValue];
                cell.onetitle.text =LocalizationKey(@"Subscription_Type");
                cell.onetext.text = [self gettype:self.desmodel];
                
            
            
        
                cell.twotitle.text =LocalizationKey(@"total_activity");
                cell.twotext.text =[NSString stringWithFormat:@"%@%@",self.desmodel.totalSupply,self.desmodel.unit];
                
            cell.threetitle.text = LocalizationKey(@"Subscription_price");
            if(self.desmodel.price == nil){
                cell.threetext.text =[NSString stringWithFormat:@"%@%@",@"0",self.desmodel.acceptUnit];
            }else{
                cell.threetext.text =[NSString stringWithFormat:@"%@%@",self.desmodel.price,self.desmodel.acceptUnit];
                
            }
               
                
            cell.fourtitle.text = LocalizationKey(@"Active_currency");
                cell.fourtext.text =[NSString stringWithFormat:@"%@",self.desmodel.unit];
                
            cell.fivetitle.text =LocalizationKey(@"accepted_currency");
                cell.fivetext.text =[NSString stringWithFormat:@"%@%@",self.desmodel.totalSupply,self.desmodel.acceptUnit];
                
                cell.sextitle.text =LocalizationKey(@"Personal_purchase_limit");
                cell.sextext.text =[NSString stringWithFormat:@"%@",self.desmodel.limitTimes];
                
            cell.seventitle.text =LocalizationKey(@"Personal_purchase_number");
                cell.seventext.text =[NSString stringWithFormat:@"%@ ~%@",self.desmodel.minLimitAmout,self.desmodel.maxLimitAmout];
                
                cell.eighttitle.text =LocalizationKey(@"startTime");
                cell.eighttext.text =[NSString stringWithFormat:@"%@",self.desmodel.startTime];

                
                cell.ninetitle.text =LocalizationKey(@"endTime");
                cell.ninetext.text =[NSString stringWithFormat:@"%@",self.desmodel.endTime];

                
                
            
          
          
            return  cell;
        } else if      (indexPath.row  == 1) {
            querenTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([querenTableViewCell class])];
              if (!cell) {
                  cell = [[NSBundle mainBundle] loadNibNamed:@"querenTableViewCell" owner:nil options:nil][0];
              }
              cell.selectionStyle = UITableViewCellSelectionStyleNone;
            [cell.pushBtn addTarget:self action:@selector(cancleOrResetClicked) forControlEvents:UIControlEventTouchUpInside];
            
            cell.pushBtn.enabled = NO;
            cell.pushBtn.backgroundColor  =RGBOF(0x979797);
            return  cell;
            
        }
        
        
        
        
        
    }
    
    if([self.model.type isEqualToString:@"6"]){
        
        
        if (indexPath.row  == 0) {
            indedesTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([indedesTableViewCell class])];
              if (!cell) {
                  cell = [[NSBundle mainBundle] loadNibNamed:@"indedesTableViewCell" owner:nil options:nil][0];
              }
              cell.selectionStyle = UITableViewCellSelectionStyleNone;
            
          
                
                cell.titleview.text = LocalizationKey(@"Basic_Information");
                cell.jinduLabel.text= LocalizationKey(@"schedule");
                cell.allnumberTitle.text =LocalizationKey(@"total_activity");

                cell.number.text=  [NSString stringWithFormat:@"%@%%",[self getprogress:self.desmodel]];
                
                cell.progress.progress =[self getprogress:self.desmodel].intValue/100.0;
                

                
                cell.allnumber.text = [NSString stringWithFormat:@"%@%@",self.desmodel.totalSupply,self.desmodel.unit];
                cell.stylelabel.text =LocalizationKey(@"state");
                cell.styletext.text = self.titles[self.desmodel.step.intValue];
                cell.onetitle.text =LocalizationKey(@"Subscription_Type");
                cell.onetext.text = [self gettype:self.desmodel];
                
                
            cell.twotitle.text =LocalizationKey(@"release_type");
            if(self.desmodel.releaseType.intValue == 1) {
                
                cell.twotext.text =[NSString stringWithFormat:@"%@",LocalizationKey(@"proportional_release")];
            }else {
                
                cell.twotext.text =[NSString stringWithFormat:@"%@",LocalizationKey(@"equal_release")];
            }
                
            cell.threetitle.text =LocalizationKey(@"release_details");
                cell.threetext.text =[NSString stringWithFormat:@"%@%@",self.desmodel.lockedDays,LocalizationKey(@"period_release")];
                
            cell.fourtitle.text =LocalizationKey(@"lock-up_threshold");
                cell.fourtext.text =[NSString stringWithFormat:@"%@",self.desmodel.lockedFee];
                
            cell.fivetitle.text =LocalizationKey(@"release_multiple");
                cell.fivetext.text =[NSString stringWithFormat:@"%@%@",self.desmodel.priceScale,@""];
                
            cell.sextitle.text =LocalizationKey(@"total_activity");
              cell.sextext.text =[NSString stringWithFormat:@"%@ %@",self.desmodel.totalSupply,self.desmodel.unit];
                
            cell.seventitle.text =LocalizationKey(@"Position_required_currency");
                cell.seventext.text =[NSString stringWithFormat:@"%@",self.desmodel.acceptUnit];
                
            cell.eighttitle.text =LocalizationKey(@"Personal_purchase_limit");
            cell.eighttext.text =[NSString stringWithFormat:@"%@",self.desmodel.limitTimes];

                
            cell.ninetitle.text =LocalizationKey(@"Personal_purchase_number");
            cell.ninetext.text =[NSString stringWithFormat:@"%@ ~%@",self.desmodel.minLimitAmout,self.desmodel.maxLimitAmout];

                
                
            
          
          
            return  cell;
        } else if      (indexPath.row  == 1) {
            intwotextTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([intwotextTableViewCell class])];
              if (!cell) {
                  cell = [[NSBundle mainBundle] loadNibNamed:@"intwotextTableViewCell" owner:nil options:nil][0];
              }
            cell.toplabel.text =LocalizationKey(@"startTime");
            cell. botomlabel.text =[NSString stringWithFormat:@"%@",self.desmodel.startTime];

            
        
              cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return  cell;
            
        }
        else if      (indexPath.row  == 2) {
            intwotextTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([intwotextTableViewCell class])];
              if (!cell) {
                  cell = [[NSBundle mainBundle] loadNibNamed:@"intwotextTableViewCell" owner:nil options:nil][0];
              }
              cell.selectionStyle = UITableViewCellSelectionStyleNone;
            
            cell.toplabel.text =LocalizationKey(@"endTime");
            cell.botomlabel.text =[NSString stringWithFormat:@"%@",self.desmodel.endTime];
            return  cell;
            
        }if      (indexPath.row  == 3) {
            inputnumberTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([inputnumberTableViewCell class])];
              if (!cell) {
                  cell = [[NSBundle mainBundle] loadNibNamed:@"inputnumberTableViewCell" owner:nil options:nil][0];
              }
            cell.locktext.text =LocalizationKey(@"input_thelockup_amount");
            cell.banctext.text = LocalizationKey(@"my_available_balance");
            [cell reloadconn];
            cell.banncenumber.text = [NSString stringWithFormat:@"%@USDT",self.assetUSD];;
            cell.delegate = self;
              cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return  cell;
            
        }
        if      (indexPath.row  == 4) {
            querenTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([querenTableViewCell class])];
              if (!cell) {
                  cell = [[NSBundle mainBundle] loadNibNamed:@"querenTableViewCell" owner:nil options:nil][0];
              }
              cell.selectionStyle = UITableViewCellSelectionStyleNone;
            [cell.pushBtn addTarget:self action:@selector(cancleOrResetClicked) forControlEvents:UIControlEventTouchUpInside];
            
            if([self.desmodel.step isEqualToString:@"3"]){
                cell.pushBtn.backgroundColor  =RGBOF(0x979797);
                cell.pushBtn.userInteractionEnabled = NO;
            }
     
            return  cell;
            
        }
        
        
        
    
        
        
        
        
    }
    
    if([self.model.type isEqualToString:@"5"]){
        
        
        if (indexPath.row  == 0) {
            indedesTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([indedesTableViewCell class])];
              if (!cell) {
                  cell = [[NSBundle mainBundle] loadNibNamed:@"indedesTableViewCell" owner:nil options:nil][0];
              }
              cell.selectionStyle = UITableViewCellSelectionStyleNone;
            
          
                
                
            cell.titleview.text = LocalizationKey(@"Basic_Information");
            cell.jinduLabel.text= LocalizationKey(@"schedule");
            cell.allnumberTitle.text =LocalizationKey(@"total_activity");

            cell.number.text=  [NSString stringWithFormat:@"%@%%",[self getprogress:self.desmodel]];
            
            cell.progress.progress =[self getprogress:self.desmodel].intValue/100.0;
            

            
            cell.allnumber.text = [NSString stringWithFormat:@"%@%@",self.desmodel.totalSupply,self.desmodel.unit];
            cell.stylelabel.text =LocalizationKey(@"state");
            cell.styletext.text = self.titles[self.desmodel.step.intValue];
            cell.onetitle.text =LocalizationKey(@"Subscription_Type");
            cell.onetext.text = [self gettype:self.desmodel];
            
            
            cell.twotitle.text =LocalizationKey(@"total_activity");
            cell.twotext.text =[NSString stringWithFormat:@"%@%@",self.desmodel.totalSupply,self.desmodel.unit];
            
            cell.threetitle.text = LocalizationKey(@"Subscription_price");
            cell.threetext.text =[NSString stringWithFormat:@"%@%@",self.desmodel.price,self.desmodel.acceptUnit];
            
            cell.fourtitle.text = LocalizationKey(@"Active_currency");
            cell.fourtext.text =[NSString stringWithFormat:@"%@",self.desmodel.unit];
            
            cell.fivetitle.text =LocalizationKey(@"accepted_currency");
            cell.fivetext.text =[NSString stringWithFormat:@"%@",self.desmodel.acceptUnit];
            
            cell.sextitle.text =LocalizationKey(@"Personal_purchase_limit");
            cell.sextext.text =[NSString stringWithFormat:@"%@",self.desmodel.limitTimes];
            
            cell.seventitle.text =LocalizationKey(@"Personal_purchase_number");
            cell.seventext.text =[NSString stringWithFormat:@"%@ ~%@",self.desmodel.minLimitAmout,self.desmodel.maxLimitAmout];
            
            cell.eighttitle.text =LocalizationKey(@"startTime");
            cell.eighttext.text =[NSString stringWithFormat:@"%@",self.desmodel.startTime];

            
            cell.ninetitle.text =LocalizationKey(@"endTime");
            cell.ninetext.text =[NSString stringWithFormat:@"%@",self.desmodel.endTime];

            
                
            
          
          
            return  cell;
        } else if      (indexPath.row  == 1) {
            ykjTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([ykjTableViewCell class])];
              if (!cell) {
                  cell = [[NSBundle mainBundle] loadNibNamed:@"ykjTableViewCell" owner:nil options:nil][0];
              }
            cell.canyulabel.text =LocalizationKey(@"Purchased_quantity");
            NSDecimalNumber *a = [NSDecimalNumber decimalNumberWithString:self.desmodel.totalSupply];
            NSDecimalNumber *b = [NSDecimalNumber decimalNumberWithString:self.desmodel.tradedAmount];
            cell.huodong.text = [NSString stringWithFormat:@"%@ %@",[self getdecimalNumberByRoundingAccordingToBehavior:b],self.desmodel.unit];
            
            


            
              
          
              NSDecimalNumber *subtract = [a decimalNumberBySubtracting:b];
           
            cell.canyulabelnumber.text=  LocalizationKey(@"The_remaining_amount");
            
            cell.huodongnumber.text=[NSString stringWithFormat:@"%@%@",[self getdecimalNumberByRoundingAccordingToBehavior:subtract],self.desmodel.unit];
          
              cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return  cell;
            
        } else if     (indexPath.row  == 2) {
            inputnumberTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([inputnumberTableViewCell class])];
              if (!cell) {
                  cell = [[NSBundle mainBundle] loadNibNamed:@"inputnumberTableViewCell" owner:nil options:nil][0];
              }
            cell.locktext.text = LocalizationKey(@"Enter_the_number_of_miners_to_buy");
            cell.banctext.text = LocalizationKey(@"my_available_balance");
            cell.numbertype.text = self.desmodel.unit;
//            [cell reloadconn];
            cell.delegate = self;
            cell.banncenumber.text = [NSString stringWithFormat:@"%@USDT",self.assetUSD];;
         
              cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return  cell;
            
        } else if      (indexPath.row  == 3) {
            querenTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([querenTableViewCell class])];
              if (!cell) {
                  cell = [[NSBundle mainBundle] loadNibNamed:@"querenTableViewCell" owner:nil options:nil][0];
              }
              cell.selectionStyle = UITableViewCellSelectionStyleNone;
            [cell.pushBtn addTarget:self action:@selector(cancleOrResetClicked) forControlEvents:UIControlEventTouchUpInside];
            if([self.desmodel.step isEqualToString:@"3"]){
                cell.pushBtn.backgroundColor  =RGBOF(0x979797);
                cell.pushBtn.userInteractionEnabled = NO;
            }
            return  cell;
            
        }
        
        
        
    
        
        
        
        
    }
    if([self.model.type isEqualToString:@"3"]){
        
        
        if (indexPath.row  == 0) {
            indedesTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([indedesTableViewCell class])];
              if (!cell) {
                  cell = [[NSBundle mainBundle] loadNibNamed:@"indedesTableViewCell" owner:nil options:nil][0];
              }
              cell.selectionStyle = UITableViewCellSelectionStyleNone;
            
          
                
                
            cell.titleview.text = LocalizationKey(@"Basic_Information");
            cell.jinduLabel.text= LocalizationKey(@"schedule");
            cell.allnumberTitle.text =LocalizationKey(@"total_activity");

            cell.number.text=  [NSString stringWithFormat:@"%@%%",[self getprogress:self.desmodel]];
            
            cell.progress.progress =[self getprogress:self.desmodel].intValue/100.0;
            

            
            cell.allnumber.text = [NSString stringWithFormat:@"%@%@",self.desmodel.totalSupply,self.desmodel.unit];
            cell.stylelabel.text =LocalizationKey(@"state");
            cell.styletext.text = self.titles[self.desmodel.step.intValue];
            cell.onetitle.text =LocalizationKey(@"Subscription_Type");
            cell.onetext.text = [self gettype:self.desmodel];
            
            
            cell.twotitle.text =LocalizationKey(@"total_activity");
            cell.twotext.text =[NSString stringWithFormat:@"%@%@",self.desmodel.totalSupply,self.desmodel.unit];
            
            cell.threetitle.text = LocalizationKey(@"Subscription_price");
            cell.threetext.text =[NSString stringWithFormat:@"%@%@",self.desmodel.price,self.desmodel.acceptUnit];
            
            cell.fourtitle.text = LocalizationKey(@"Active_currency");
            cell.fourtext.text =[NSString stringWithFormat:@"%@",self.desmodel.unit];
            
            cell.fivetitle.text =LocalizationKey(@"accepted_currency");
            cell.fivetext.text =[NSString stringWithFormat:@"%@%@",self.desmodel.totalSupply,self.desmodel.acceptUnit];
            
            cell.sextitle.text =LocalizationKey(@"Personal_purchase_limit");
            cell.sextext.text =[NSString stringWithFormat:@"%@",self.desmodel.limitTimes];
            
            cell.seventitle.text =LocalizationKey(@"Personal_purchase_number");
            cell.seventext.text =[NSString stringWithFormat:@"%@ ~%@",self.desmodel.minLimitAmout,self.desmodel.maxLimitAmout];
            
            cell.eighttitle.text =LocalizationKey(@"startTime");
            cell.eighttext.text =[NSString stringWithFormat:@"%@",self.desmodel.startTime];

            
            cell.ninetitle.text =LocalizationKey(@"endTime");
            cell.ninetext.text =[NSString stringWithFormat:@"%@",self.desmodel.endTime];

            
                
            
          
          
            return  cell;
        } else if      (indexPath.row  == 1) {
            inebuyTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([inebuyTableViewCell class])];
              if (!cell) {
                  cell = [[NSBundle mainBundle] loadNibNamed:@"inebuyTableViewCell" owner:nil options:nil][0];
              }
          

            
            cell.canyulabel.text = LocalizationKey(@"my_participating_positions");;
            cell.huodong.text= LocalizationKey(@"Activity_participation_total_position");
     
            NSDecimalNumber *a = [NSDecimalNumber decimalNumberWithString:self.desmodel.totalSupply];
            NSDecimalNumber *b = [NSDecimalNumber decimalNumberWithString:self.desmodel.freezeAmount];
            
       
            cell.canyulabelnumber.text = [NSString stringWithFormat:@"%@ %@",[self getdecimalNumberByRoundingAccordingToBehavior:b],self.desmodel.unit];
            
            if(self.desmodel.freezeAmount.doubleValue == 0){
                cell.shurnumber.text = [NSString stringWithFormat:@"%@0%@",LocalizationKey(@"My_current_position_can_be_divided_into_about"),self.desmodel.unit];
            }else {
                
                NSDecimalNumber *divide = [b decimalNumberByDividingBy:a];
                
                NSDecimalNumber *multiply = [divide decimalNumberByMultiplyingBy:a];
                
                
                cell.shurnumber.text = [NSString stringWithFormat:@"%@%@ %@",LocalizationKey(@"My_current_position_can_be_divided_into_about"),[self getdecimalNumberByRoundingAccordingToBehavior:multiply],self.desmodel.unit];
                
                
                
            }
            
     
            
            cell.huodongnumber.text=[NSString stringWithFormat:@"%@%@",[self getdecimalNumberByRoundingAccordingToBehavior:a],self.desmodel.unit];
            
        
              cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return  cell;
            
        } else if      (indexPath.row  == 2) {
            intwoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([intwoTableViewCell class])];
              if (!cell) {
                  cell = [[NSBundle mainBundle] loadNibNamed:@"intwoTableViewCell" owner:nil options:nil][0];
              }
            cell.des.text =LocalizationKey(@"Participatinginthetype");
              cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return  cell;
            
        }else if     (indexPath.row  == 3) {
            inputnumberTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([inputnumberTableViewCell class])];
              if (!cell) {
                  cell = [[NSBundle mainBundle] loadNibNamed:@"inputnumberTableViewCell" owner:nil options:nil][0];
              }
            cell.locktext.text = LocalizationKey(@"input_thelockup_amount");
            cell.banctext.text = LocalizationKey(@"my_available_balance");
//            [cell reloadconn];
            cell.delegate = self;
            cell.banncenumber.text = [NSString stringWithFormat:@"%@USDT",self.assetUSD];;
            cell.numbertype.text = self.desmodel.unit;
         
              cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return  cell;
            
        } else if      (indexPath.row  == 4) {
            querenTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([querenTableViewCell class])];
              if (!cell) {
                  cell = [[NSBundle mainBundle] loadNibNamed:@"querenTableViewCell" owner:nil options:nil][0];
              }
              cell.selectionStyle = UITableViewCellSelectionStyleNone;
            [cell.pushBtn addTarget:self action:@selector(cancleOrResetClicked) forControlEvents:UIControlEventTouchUpInside];
            if([self.desmodel.step isEqualToString:@"3"]){
                cell.pushBtn.backgroundColor  =RGBOF(0x979797);
                cell.pushBtn.userInteractionEnabled = NO;
            }
            return  cell;
            
        }
        
        
        
    
        
        
        
        
    }
    
    if([self.model.type isEqualToString:@"4"]){
        
        
        if (indexPath.row  == 0) {
            indedesTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([indedesTableViewCell class])];
              if (!cell) {
                  cell = [[NSBundle mainBundle] loadNibNamed:@"indedesTableViewCell" owner:nil options:nil][0];
              }
              cell.selectionStyle = UITableViewCellSelectionStyleNone;
            
          
                
                
            cell.titleview.text = LocalizationKey(@"Basic_Information");
            cell.jinduLabel.text= LocalizationKey(@"schedule");
            cell.allnumberTitle.text =LocalizationKey(@"total_activity");

            cell.number.text=  [NSString stringWithFormat:@"%@%%",[self getprogress:self.desmodel]];
            
            cell.progress.progress =[self getprogress:self.desmodel].intValue/100.0;
            

            
            cell.allnumber.text = [NSString stringWithFormat:@"%@%@",self.desmodel.totalSupply,self.desmodel.unit];
            cell.stylelabel.text =LocalizationKey(@"state");
            cell.styletext.text = self.titles[self.desmodel.step.intValue];
            cell.onetitle.text =LocalizationKey(@"Subscription_Type");
            cell.onetext.text = [self gettype:self.desmodel];
            
            
            cell.twotitle.text =LocalizationKey(@"total_activity");
            cell.twotext.text =[NSString stringWithFormat:@"%@%@",self.desmodel.totalSupply,self.desmodel.unit];
            
            cell.threetitle.text = LocalizationKey(@"Subscription_price");
            cell.threetext.text =[NSString stringWithFormat:@"%@%@",self.desmodel.price,self.desmodel.acceptUnit];
            
            cell.fourtitle.text =LocalizationKey(@"Active_currency");
            cell.fourtext.text =[NSString stringWithFormat:@"%@",self.desmodel.unit];
            
            cell.fivetitle.text =LocalizationKey(@"accepted_currency");
            cell.fivetext.text =[NSString stringWithFormat:@"%@",self.desmodel.acceptUnit];
            
            cell.sextitle.text =LocalizationKey(@"Personal_purchase_limit");
            cell.sextext.text =[NSString stringWithFormat:@"%@",self.desmodel.limitTimes];
            
            cell.seventitle.text =LocalizationKey(@"Personal_purchase_number");
            cell.seventext.text =[NSString stringWithFormat:@"%@ ~%@",self.desmodel.minLimitAmout,self.desmodel.maxLimitAmout];
            
            cell.eighttitle.text =LocalizationKey(@"startTime");
            cell.eighttext.text =[NSString stringWithFormat:@"%@",self.desmodel.startTime];

            
            cell.ninetitle.text =LocalizationKey(@"endTime");
            cell.ninetext.text =[NSString stringWithFormat:@"%@",self.desmodel.endTime];

            
                
            
          
          
            return  cell;
        } else if      (indexPath.row  == 1) {
            ykjTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([ykjTableViewCell class])];
              if (!cell) {
                  cell = [[NSBundle mainBundle] loadNibNamed:@"ykjTableViewCell" owner:nil options:nil][0];
              }
          

            cell.canyulabel.text = LocalizationKey(@"Purchased_quantity");
            NSDecimalNumber *a = [NSDecimalNumber decimalNumberWithString:self.desmodel.totalSupply];
            NSDecimalNumber *b = [NSDecimalNumber decimalNumberWithString:self.desmodel.tradedAmount];
            cell.huodong.text = [NSString stringWithFormat:@"%@ %@",[self getdecimalNumberByRoundingAccordingToBehavior:b],self.desmodel.unit];
            
            

     
            
              
          
              NSDecimalNumber *subtract = [a decimalNumberBySubtracting:b];
           
            cell.canyulabelnumber.text=   LocalizationKey(@"The_remaining_amount");
            
            cell.huodongnumber.text=[NSString stringWithFormat:@"%@%@",[self getdecimalNumberByRoundingAccordingToBehavior:subtract],self.desmodel.unit];
        
              cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return  cell;
            
        } else if     (indexPath.row  == 2) {
            inputnumberTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([inputnumberTableViewCell class])];
              if (!cell) {
                  cell = [[NSBundle mainBundle] loadNibNamed:@"inputnumberTableViewCell" owner:nil options:nil][0];
              }
            cell.locktext.text = LocalizationKey(@"The_remaining_amount");
            cell.banctext.text = LocalizationKey(@"Enter_exchange_amount");
            cell.delegate = self;
            cell.banncenumber.text = [NSString stringWithFormat:@"%@USDT",self.assetUSD];;
            cell.numbertype.text = self.desmodel.unit;
              cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return  cell;
            
        } else if      (indexPath.row  == 3) {
            querenTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([querenTableViewCell class])];
              if (!cell) {
                  cell = [[NSBundle mainBundle] loadNibNamed:@"querenTableViewCell" owner:nil options:nil][0];
              }
              cell.selectionStyle = UITableViewCellSelectionStyleNone;
            
        
            [cell.pushBtn addTarget:self action:@selector(cancleOrResetClicked) forControlEvents:UIControlEventTouchUpInside];
            
            if([self.desmodel.step isEqualToString:@"3"]){
                cell.pushBtn.backgroundColor  =RGBOF(0x979797);
                cell.pushBtn.userInteractionEnabled = NO;
            }
            return  cell;
            
        }
        
        
        
    
        
        
        
        
    }
  
    return  nil;

}

-(void)cancleOrResetClicked{
    if(self.text.length>    0){
        
       
        if( self.accountInfo !=nil){
            [self getAccountSettingStatus];
        }else {
            [self accountSettingData];
        }
        
        
    }else {
        [self.view makeToast:[[ChangeLanguage bundle] localizedStringForKey:@"inputSellNum" value:nil table:@"English"] duration:1.5 position:CSToastPositionCenter];
    }
    
   
}

-(void)getAccountSettingStatus{
    
    if(self.accountInfo.mobilePhone.length >5){
        
       NSString *str  = self.accountInfo.mobilePhone;
        
        self.loginView.center = self.view.center;
        self.loginView.backgroundColor = [UIColor whiteColor];
        _loginView.phonenumber.text = str ;
        PopView *popView = [PopView popSideContentView:self.loginView direct:PopViewDirection_SlideInCenter ];
        popView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.3];
        popView.clickOutHidden = NO;
        
    }else {
        
        [self.view makeToast:[[ChangeLanguage bundle] localizedStringForKey:@"noNetworkStatus" value:nil table:@"English"] duration:1.5 position:CSToastPositionCenter];
    }
  
}

//MARK:--账号设置的状态信息获取
-(void)accountSettingData{

    [EasyShowLodingView showLodingText:[[ChangeLanguage bundle] localizedStringForKey:@"loading" value:nil table:@"English"]];
    [MineNetManager accountSettingInfoForCompleteHandle:^(id resPonseObj, int code) {
        NSLog(@"resPonseObj ---- %@",resPonseObj);
        [EasyShowLodingView hidenLoding];
        if (code) {
            if ([resPonseObj[@"code"] integerValue] == 0) {

                self.accountInfo = [AccountSettingInfoModel mj_objectWithKeyValues:resPonseObj[@"data"]];

                [self getAccountSettingStatus];
            }else if ([resPonseObj[@"code"] integerValue]==4000){
               // [ShowLoGinVC showLoginVc:self withTipMessage:resPonseObj[MESSAGE]];
                [YLUserInfo logout];
                [self.view makeToast:resPonseObj[MESSAGE] duration:1.5 position:CSToastPositionCenter];
            }else{
                [self.view makeToast:resPonseObj[MESSAGE] duration:1.5 position:CSToastPositionCenter];
            }
        }else{
            [self.view makeToast:[[ChangeLanguage bundle] localizedStringForKey:@"noNetworkStatus" value:nil table:@"English"] duration:1.5 position:CSToastPositionCenter];
        }
    }];
}
-(NSString *)getprogress:(innovationdesoneModel *)model{
    NSString *pro= @"0";
    if([model.type isEqualToString:@"3"]){

        if(model.step.intValue == 1){
                   pro = @"50";
               }else if(model.step.intValue  == 2){
                   pro = @"75";
               }else if(model.step.intValue  == 3){
                   pro = @"100";
               }else{
                   pro = @"0";
               }
    }else {


        pro = model.progress;
    }




    return pro;
}

-(NSString *)getdecimalNumberByRoundingAccordingToBehavior:(NSDecimalNumber *)nummber {
    
    NSDecimalNumberHandler *roundUp = [NSDecimalNumberHandler
                                         decimalNumberHandlerWithRoundingMode:NSRoundDown
                                         scale:self.desmodel.amountScale.intValue
                                         raiseOnExactness:NO
                                         raiseOnOverflow:NO
                                         raiseOnUnderflow:NO
                                         raiseOnDivideByZero:YES];
    
    NSDecimalNumber *yy = [nummber decimalNumberByRoundingAccordingToBehavior:roundUp];
    
    return [NSString stringWithFormat:@"%@",yy];

    
}


-(NSString *)gettype:(innovationdesoneModel *)model{
    NSString *pro= @"0";
  

              if(model.type.intValue == 1){
                   pro = @"首次上线(抢购)";
               }else if(model.type.intValue  == 2){
                   pro = @"首次上线(平分)";
               }else if(model.type.intValue  == 3){
                   pro = @"持仓瓜分";
               }else if(model.type.intValue  == 4){
                   pro = @"自由认购";
               }else if(model.type.intValue  == 5){
                   pro = @"云矿机认购";
               }else if(model.type.intValue  == 6){
                   pro = @"锁仓释放";
               }
               else{
                   pro = @"未知";
               }
   


    return pro;
}
//
                                                  

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath*)indexPath{

    
    if([self.model.type isEqualToString:@"2"]||[self.model.type isEqualToString:@"1"]){
 
        if(indexPath.row == 0) {
            return 681;
        }else  if(indexPath.row == 1){
            return 64;
        }
        return 0;
    } if([self.model.type isEqualToString:@"6"]){
        
        if(indexPath.row == 0) {
            return 681;
        }else  if(indexPath.row == 1){
            return 60;
        }else  if(indexPath.row == 2){
            return 60;
        }
        else  if(indexPath.row == 3){
            return 86;
        }
        else  if(indexPath.row == 4){
            return 64;
        }
        
        return 0;
    }
    if([self.model.type isEqualToString:@"5"]){
       
       if(indexPath.row == 0) {
           return 681;
       }else  if(indexPath.row == 1){
           return 112;
       }else  if(indexPath.row == 2){
           return 86;
       }
       else  if(indexPath.row == 3){
           return 64;
       }
      
       
       return 0;
   } if([self.model.type isEqualToString:@"3"]){
       
       if(indexPath.row == 0) {
           return 681;
       }else  if(indexPath.row == 1){
           return 112;
       }else  if(indexPath.row == 2){
           return 49;
       }
       else  if(indexPath.row == 3){
           return 86;
       }
       else  if(indexPath.row == 4){
           return 64;
       }
       
       return 0;
   }
    if([self.model.type isEqualToString:@"4"]){
       
       if(indexPath.row == 0) {
           return 681;
       }else  if(indexPath.row == 1){
           return 112;
       }else  if(indexPath.row == 2){
           return 86;
       }
       else  if(indexPath.row == 3){
           return 64;
       }
      
       
       return 0;
   }
    
    return  0;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

}


    




/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
