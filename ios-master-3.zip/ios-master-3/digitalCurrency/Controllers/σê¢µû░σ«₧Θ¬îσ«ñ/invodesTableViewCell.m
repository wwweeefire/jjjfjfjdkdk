//
//  invodesTableViewCell.m
//  digitalCurrency
//
//  Created by 111 on 2/2/2565 BE.
//  Copyright © 2565 BE BIZZAN. All rights reserved.
//

#import "invodesTableViewCell.h"

@implementation invodesTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
