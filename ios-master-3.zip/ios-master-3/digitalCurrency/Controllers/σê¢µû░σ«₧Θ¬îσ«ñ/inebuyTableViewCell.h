//
//  inebuyTableViewCell.h
//  digitalCurrency
//
//  Created by 111 on 28/1/2565 BE.
//  Copyright © 2565 BE BIZZAN. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface inebuyTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *canyulabel;
@property (weak, nonatomic) IBOutlet UILabel *huodong;
@property (weak, nonatomic) IBOutlet UILabel *canyulabelnumber;
@property (weak, nonatomic) IBOutlet UILabel *huodongnumber;
@property (weak, nonatomic) IBOutlet UILabel *shurnumber;
@end

NS_ASSUME_NONNULL_END
