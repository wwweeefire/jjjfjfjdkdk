//
//  LoginViewController.h
//  digitalCurrency
//
//  Created by sunliang on 2019/1/29.
//  Copyright © 2019年 BIZZAN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController
@property(nonatomic,assign)int enterType;
@property (nonatomic, assign) BOOL pushOrPresent;
@end
