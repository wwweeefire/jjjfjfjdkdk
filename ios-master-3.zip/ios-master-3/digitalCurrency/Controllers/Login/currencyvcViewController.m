//
//  countryViewController.m
//  digitalCurrency
//
//  Created by sunliang on 2019/2/23.
//  Copyright © 2019年 BIZZAN. All rights reserved.
//

#import "currencyvcViewController.h"
#import "LoginNetManager.h"
#import "countryModel.h"
#import "SelectcurrencyvcTableViewCell.h"
@interface currencyvcViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong)NSMutableArray *contentArr;

@property (nonatomic,strong)NSDictionary*countryArray;
@end

@implementation currencyvcViewController
- (NSMutableArray *)contentArr
{
    if (!_contentArr) {
        _contentArr = [NSMutableArray array];
    }
    return _contentArr;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title=[[ChangeLanguage bundle] localizedStringForKey:@"currencyType" value:nil table:@"English"];
    [self getData];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.tableView registerNib:[UINib nibWithNibName:@"SelectcurrencyvcTableViewCell" bundle:nil] forCellReuseIdentifier:NSStringFromClass([SelectcurrencyvcTableViewCell class])];
    // Do any additional setup after loading the view from its nib.
}
#pragma mark-获取国家列表
-(void)getData{
    [EasyShowLodingView showLodingText:LocalizationKey(@"loading")];
    [LoginNetManager getcurrencyCompleteHandle:^(id resPonseObj, int code) {
    [EasyShowLodingView hidenLoding];
        if (code) {
            if ([resPonseObj[@"code"] integerValue] == 0) {
//                NSLog(@"--%@",resPonseObj);
             _countryArray=resPonseObj[@"data"];
                
                NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
              


                //把image归档为NSData
                [userDefault setObject:_countryArray forKey:@"currencyAll2"];
                [userDefault synchronize];

             
                    [self.contentArr addObjectsFromArray:_countryArray.allKeys];
              
                [self.tableView reloadData];
            }else{
                [self.view makeToast:resPonseObj[MESSAGE] duration:1.5 position:CSToastPositionCenter];
            }
        }else{
            [self.view makeToast:LocalizationKey(@"noNetworkStatus") duration:1.5 position:CSToastPositionCenter];
        }
    }];

}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.contentArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    SelectcurrencyvcTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([SelectcurrencyvcTableViewCell class]) forIndexPath:indexPath];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    NSString *vc=self.contentArr[indexPath.row];
    cell.enName.text = vc;



    return cell;

}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 66;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *vc=self.contentArr[indexPath.row];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
  

    [userDefault setObject:vc forKey:@"selectcurrencyAll2"];
    [userDefault synchronize];
    self.returnValueBlock(vc,_countryArray);
    AppDelegate.sharedAppDelegate.CNY = vc;
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
