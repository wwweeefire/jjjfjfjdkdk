//
//  PromoteFriendsModel.m
//  digitalCurrency
//
//  Created by iDog on 2019/5/7.
//  Copyright © 2019年 BIZZAN. All rights reserved.
//

#import "PromoteFriendsModel.h"

@implementation PromoteFriendsModel

@end
