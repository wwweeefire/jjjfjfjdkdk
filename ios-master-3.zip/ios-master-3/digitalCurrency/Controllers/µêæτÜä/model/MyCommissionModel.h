//
//  MyCommissionModel.h
//  digitalCurrency
//
//  Created by iDog on 2019/5/7.
//  Copyright © 2019年 BIZZAN. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyCommissionModel : NSObject
@property(nonatomic,copy)NSString *amount;
@property(nonatomic,copy)NSString *createTime;
@property(nonatomic,copy)NSString *remark;
@property(nonatomic,copy)NSString *symbol;
@end
