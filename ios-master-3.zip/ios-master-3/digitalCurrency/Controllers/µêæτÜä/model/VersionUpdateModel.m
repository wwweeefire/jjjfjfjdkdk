//
//  VersionUpdateModel.m
//  digitalCurrency
//
//  Created by iDog on 2019/5/7.
//  Copyright © 2019年 BIZZAN. All rights reserved.
//

#import "VersionUpdateModel.h"

@implementation VersionUpdateModel
+(NSDictionary *)mj_replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}
@end
