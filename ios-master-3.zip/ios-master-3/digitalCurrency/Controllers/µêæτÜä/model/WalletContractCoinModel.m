//
//  WalletContractCoinModel.m
//  digitalCurrency
//
//  Created by ios on 2020/10/9.
//  Copyright © 2020 BIZZAN. All rights reserved.
//

#import "WalletContractCoinModel.h"

@implementation WalletContractCoinModel

@end

@implementation WalletContractCoinInfo

@end
