//
//  TradeHistoryModel.h
//  digitalCurrency
//
//  Created by iDog on 2019/3/5.
//  Copyright © 2019年 BIZZAN. All rights reserved.
//

#import <Foundation/Foundation.h>

@class assetsourcemodel;
@protocol newassetsourcemodel <NSObject>



@end

@interface TradeHistoryModel : NSObject
@property(nonatomic,copy)NSString *_index;
@property(nonatomic,copy)NSString *_type;
@property(nonatomic,copy)NSString *_id;
@property(nonatomic,strong)assetsourcemodel *_source;


@end

@interface assetsourcemodel :NSObject
@property(nonatomic,copy)NSString *memberId;
@property(nonatomic,copy)NSString *symbol;
@property(nonatomic,copy)NSString *amount;
@property(nonatomic,copy)NSString *address;
@property(nonatomic,copy)NSString *flag;
@property(nonatomic,copy)NSString *createTime;
@property(nonatomic,copy)NSString *realFee;
@property(nonatomic,copy)NSString *fee;
@property(nonatomic,copy)NSString *ID;
@property(nonatomic,copy)NSString *type;
@property(nonatomic,copy)NSString *discountFee;

@end


@interface newassetsourcemodel :NSObject

//actualAmount = "0.01000000";
//address = TAskVvD9aGhPKsVgEjZounVUp3xo9ocyot;
//amount = 10000;
//balance = "0.02000000";
//createTime = "2021-12-28 21:50:44";
//id = 280606490026053;
//memberId = 8;
//memberName = 18686868686;
//payReason = "\U4ea4\U6613\U6210\U529f(U\U76fe)";
//payStatus = 1;
//symbol = TRCUSDT;
@property(nonatomic,copy)NSString *actualAmount;
@property(nonatomic,copy)NSString *address;
@property(nonatomic,copy)NSString *amount;
@property(nonatomic,copy)NSString *balance;
@property(nonatomic,copy)NSString *createTime;
@property(nonatomic,copy)NSString *memberId;
@property(nonatomic,copy)NSString *memberName;
@property(nonatomic,copy)NSString *payReason;
@property(nonatomic,copy)NSString *ID;
@property(nonatomic,copy)NSString *payStatus;
@property(nonatomic,copy)NSString *symbol;

@end
