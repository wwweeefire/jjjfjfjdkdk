//
//  AccountSettingInfoModel.m
//  digitalCurrency
//
//  Created by iDog on 2019/2/27.
//  Copyright © 2019年 BIZZAN. All rights reserved.
//

#import "AccountSettingInfoModel.h"

@implementation AccountSettingInfoModel
+(NSDictionary *)mj_replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}
@end
