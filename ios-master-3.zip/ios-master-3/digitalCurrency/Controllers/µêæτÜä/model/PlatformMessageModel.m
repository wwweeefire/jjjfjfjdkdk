//
//  PlatformMessageModel.m
//  digitalCurrency
//
//  Created by iDog on 2019/3/1.
//  Copyright © 2019年 BIZZAN. All rights reserved.
//

#import "PlatformMessageModel.h"

@implementation PlatformMessageModel

+(NSDictionary *)mj_replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}
@end
