//
//  GestureViewController.h
//  digitalCurrency
//
//  Created by sunliang on 2019/2/9.
//  Copyright © 2019年 BIZZAN. All rights reserved.
//

#import "BaseViewController.h"

@interface GestureViewController : BaseViewController

@end
