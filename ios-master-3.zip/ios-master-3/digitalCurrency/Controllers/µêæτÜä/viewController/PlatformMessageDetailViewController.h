//
//  PlatformMessageDetailViewController.h
//  digitalCurrency
//
//  Created by iDog on 2019/3/21.
//  Copyright © 2019年 BIZZAN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlatformMessageDetailViewController : BaseViewController
@property(nonatomic,copy)NSString *content;
@property(nonatomic,copy)NSString *navtitle;
@property(nonatomic,copy)NSString *ID;
@end
