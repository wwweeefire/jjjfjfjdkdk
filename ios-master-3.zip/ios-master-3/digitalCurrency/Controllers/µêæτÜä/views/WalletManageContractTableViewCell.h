//
//  WalletManageContractTableViewCell.h
//  digitalCurrency
//
//  Created by ios on 2020/10/9.
//  Copyright © 2020 BIZZAN. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface WalletManageContractTableViewCell : UITableViewCell

@property (nonatomic, strong) UILabel *mtitlelabel;

@property (nonatomic, strong) UILabel *onelabel;

@property (nonatomic, strong) UILabel *twolabel;

@property (nonatomic, strong) UILabel *threelabel;

@property (nonatomic, strong) UILabel *fourlabel;

@end

NS_ASSUME_NONNULL_END
