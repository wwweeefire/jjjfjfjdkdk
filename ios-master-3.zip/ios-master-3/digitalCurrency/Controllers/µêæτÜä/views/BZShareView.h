//
//  BZShareView.h
//  digitalCurrency
//
//  Created by Lanzz on 2021/1/14.
//  Copyright © 2021 BIZZAN. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BZShareView : UIView

+ (void)showWithUrl:(NSString *)url;

@end

NS_ASSUME_NONNULL_END
