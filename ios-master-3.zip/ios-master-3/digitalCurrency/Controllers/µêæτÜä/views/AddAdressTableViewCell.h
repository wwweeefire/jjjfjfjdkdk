//
//  AddAdressTableViewCell.h
//  digitalCurrency
//
//  Created by iDog on 2019/3/8.
//  Copyright © 2019年 BIZZAN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddAdressTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *addAdress;
@property (weak, nonatomic) IBOutlet UILabel *remark;

@end
