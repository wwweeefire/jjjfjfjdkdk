//
//  CurrencyexchangeTableViewCell.h
//  digitalCurrency
//
//  Created by startlink on 2019/8/6.
//  Copyright © 2019年 BIZZAN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CurrencyexchangeTableViewCell : UITableViewCell
@property (weak,nonatomic) IBOutlet UILabel *title1;
@property (weak,nonatomic) IBOutlet UILabel *title2;

@end
