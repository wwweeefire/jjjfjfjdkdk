//
//  ChangeAccountTableViewCell.m
//  digitalCurrency
//
//  Created by iDog on 2019/2/28.
//  Copyright © 2019年 BIZZAN. All rights reserved.
//

#import "ChangeAccountTableViewCell.h"

@implementation ChangeAccountTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
