//
//  AactionCollectionViewCell.h
//  digitalCurrency
//
//  Created by startlink on 2019/8/6.
//  Copyright © 2019年 BIZZAN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AactionCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *logimage;
@property (weak, nonatomic) IBOutlet UILabel *namelabel;

@end
