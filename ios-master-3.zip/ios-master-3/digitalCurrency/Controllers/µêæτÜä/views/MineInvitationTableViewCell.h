//
//  MineInvitationTableViewCell.h
//  digitalCurrency
//
//  Created by ios on 2020/9/25.
//  Copyright © 2020 BIZZAN. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MineInvitationTableViewCell : UITableViewCell



@property (nonatomic, strong) UILabel *mtitlelabel;

@property (nonatomic, strong) UIButton *myInvitationBtn;

@property (nonatomic, strong) UILabel *tiplabel1;

@property (nonatomic, strong) UILabel *titlelabel1;

@property (nonatomic, strong) UILabel *tiplabel2;

@property (nonatomic, strong) UILabel *titlelabel2;

@property (nonatomic, strong) UILabel *tiplabel3;

@property (nonatomic, strong) UILabel *titlelabel3;

@property (nonatomic, strong) UILabel *titlelbal4;

@property (nonatomic, strong) UILabel *tiplabel4;

@end

NS_ASSUME_NONNULL_END
