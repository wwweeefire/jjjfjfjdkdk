//
//  AddAdressTableViewCell.m
//  digitalCurrency
//
//  Created by iDog on 2019/3/8.
//  Copyright © 2019年 BIZZAN. All rights reserved.
//

#import "AddAdressTableViewCell.h"

@implementation AddAdressTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
