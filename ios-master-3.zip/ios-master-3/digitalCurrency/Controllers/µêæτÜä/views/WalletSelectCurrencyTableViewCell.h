//
//  WalletSelectCurrencyTableViewCell.h
//  digitalCurrency
//
//  Created by ios on 2020/10/9.
//  Copyright © 2020 BIZZAN. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface WalletSelectCurrencyTableViewCell : UITableViewCell

@property (nonatomic, strong) UILabel *mtitlelabel;

@end

NS_ASSUME_NONNULL_END
