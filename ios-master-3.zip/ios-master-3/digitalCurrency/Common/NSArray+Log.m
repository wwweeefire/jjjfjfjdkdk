//
//  NSArray+Log.m
//  ReadingClub
//
//  Created by qtkj on 16/9/1.
//  Copyright © 2016年 qtkj. All rights reserved.
//

#import "NSArray+Log.h"

#import <objc/runtime.h>

@implementation NSArray (Log)

- (NSString *)descriptionWithLocale:(id)locale
{
     NSMutableString *string = [NSMutableString string];

     // 开头有个[
     [string appendString:@"[\n"];

     // 遍历所有的元素
     [self enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
         [string appendFormat:@"\t%@,\n", obj];
     }];

     // 结尾有个]
     [string appendString:@"]"];

     // 查找最后一个逗号
     NSRange range = [string rangeOfString:@"," options:NSBackwardsSearch];
     if (range.location != NSNotFound)
     [string deleteCharactersInRange:range];
    
     return string;
}
+ (void)load{
    [super load];
    //---------------------- 不可变数组 objectAtIndex
    Method oldObjectAtIndex = class_getInstanceMethod(objc_getClass("__NSArrayI"), @selector(objectAtIndex:));
    Method newObjectAtIndex = class_getInstanceMethod(objc_getClass("__NSArrayI"), @selector(newObjectAtIndex:));
    method_exchangeImplementations(oldObjectAtIndex, newObjectAtIndex);
    //---------------------- 不可变数组 []
    Method oldMutableObjectAtIndex = class_getInstanceMethod(objc_getClass("__NSArrayI"), @selector(objectAtIndexedSubscript:));
    Method newMutableObjectAtIndex =  class_getInstanceMethod(objc_getClass("__NSArrayI"), @selector(newObjectAtIndexedSubscript:));
    method_exchangeImplementations(oldMutableObjectAtIndex, newMutableObjectAtIndex);
    
    //---------------------- 可变数组 objectAtIndex
    Method oldMObjectAtIndex = class_getInstanceMethod(objc_getClass("__NSArrayM"), @selector(objectAtIndex:));
    Method newMObjectAtIndex = class_getInstanceMethod(objc_getClass("__NSArrayM"), @selector(newMutableObjectAtIndex:));
    method_exchangeImplementations(oldMObjectAtIndex, newMObjectAtIndex);
    //---------------------- 可变数组 []
    Method oldMMutableObjectAtIndex = class_getInstanceMethod(objc_getClass("__NSArrayM"), @selector(objectAtIndexedSubscript:));
    Method newMMutableObjectAtIndex =  class_getInstanceMethod(objc_getClass("__NSArrayM"), @selector(newMutableObjectAtIndexedSubscript:));
    method_exchangeImplementations(oldMMutableObjectAtIndex, newMMutableObjectAtIndex);
}

// MARK: - 不可变数组 objectAtIndex
- (id)newObjectAtIndex:(NSUInteger)index{
    if (index > self.count - 1 || !self.count){
        @try {
            return [self newObjectAtIndex:index];
        } @catch (NSException *exception) {
            NSLog(@"\n\n------------不可变数组越界了");
            return nil;
        } @finally {
            
        }
    }
    else{
        return [self newObjectAtIndex:index];
    }
}
// MARK: - 不可变数组 []
- (id)newObjectAtIndexedSubscript:(NSUInteger)index{
    if (index > self.count - 1 || !self.count){
        @try {
            return [self newObjectAtIndexedSubscript:index];
        } @catch (NSException *exception) {
            NSLog(@"\n\n------------不可变数组越界了");
            return nil;
        } @finally {
        }
    }
    else{
        return [self newObjectAtIndexedSubscript:index];
    }
}
// MARK: - 可变数组 objectAtIndex
- (id)newMutableObjectAtIndex:(NSUInteger)index{
    if (index > self.count - 1 || !self.count){
        @try {
            return [self newMutableObjectAtIndex:index];
        } @catch (NSException *exception) {
            NSLog(@"\n\n------------可变数组越界了");
            return nil;
        } @finally {
            
        }
    }
    else{
        return [self newMutableObjectAtIndex:index];
    }
}
// MARK: - 可变数组 []
- (id)newMutableObjectAtIndexedSubscript:(NSUInteger)index{
    if (index > self.count - 1 || !self.count){
        @try {
            return [self newMutableObjectAtIndexedSubscript:index];
        } @catch (NSException *exception) {
            NSLog(@"\n\n------------可变数组越界了");
            return nil;
        } @finally {
        }
    }
    else{
        return [self newMutableObjectAtIndexedSubscript:index];
    }
}
@end
