//
//  ChangeLanguage.m
//  siLuBi
//
//  Created by sunliang on 2019/1/7.
//  Copyright © 2019年 BZEX. All rights reserved.
//

#import "ChangeLanguage.h"
//@import GT3Captcha;

@implementation LYLanguage

+ (LYLanguage*)creatName:(NSString *)name
              key:(NSString *)key
        bundleKey:(NSString *)bundleKey {
    LYLanguage *model = [LYLanguage new];
    model.name = name;
    model.key = key;
    model.bundleKey = bundleKey;
    return model;
}

@end

@implementation ChangeLanguage
static NSBundle *bundle = nil;
+ ( NSBundle * )bundle{

    return bundle;
}
//首次加载的时候先检测语言是否存在
+(void)initUserLanguage{

    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];

    NSString *currLanguage = [def valueForKey:LocalLanguageKey];

    if(!currLanguage){
        currLanguage = @"en";
//        NSArray *preferredLanguages = [NSLocale preferredLanguages];
//        currLanguage = preferredLanguages[0];
//        if ([currLanguage hasPrefix:@"en"]) {
//            currLanguage = @"en";
////            currLanguage = @"zh-Hans";
//        }else if ([currLanguage hasPrefix:@"zh"]) {
//            currLanguage = @"zh-Hans";
//        }else currLanguage = @"en";
        [def setValue:currLanguage forKey:LocalLanguageKey];
        [def synchronize];
    }

    //获取文件路径
    NSString *path = [[NSBundle mainBundle] pathForResource:currLanguage ofType:@"lproj"];
    bundle = [NSBundle bundleWithPath:path];//生成bundle
}

//获取当前语言
+(NSString *)userLanguage{

    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];

    NSString *language = [def valueForKey:LocalLanguageKey];

    

    return language;
}


// 设置语言
+(void)setUserlanguage:(NSString *)language{

    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *currLanguage = [userDefaults valueForKey:LocalLanguageKey];
    if ([currLanguage isEqualToString:language]) {
        return;
    }
    [userDefaults setValue:language forKey:LocalLanguageKey];
    [userDefaults synchronize];

    NSString *path = [[NSBundle mainBundle] pathForResource:language ofType:@"lproj" ];
    bundle = [NSBundle bundleWithPath:path];
}

+ (NSString *)networkLanguage {
  NSString *key =  [self userLanguage];
    for (LYLanguage*language in  self.languageList) {
        if ([language.bundleKey isEqualToString:key]) {
            return  language.key;
        }
    }
    return @"zh-Hans";
}

+ (NSArray *)languageList {
    
//      NSString *English = [[ChangeLanguage bundle] localizedStringForKey:@"English" value:nil table:@"English"];
//   NSString *simplifiedChinese = [[ChangeLanguage bundle] localizedStringForKey:@"simplifiedChinese" value:nil table:@"English"];
//
//    NSString *traditionalChinese = [[ChangeLanguage bundle] localizedStringForKey:@"traditionalChinese" value:nil table:@"English"];
//    NSString *Vietnamese = [[ChangeLanguage bundle] localizedStringForKey:@"Vietnamese" value:nil table:@"English"];
//
//    NSString *German  = [[ChangeLanguage bundle] localizedStringForKey:@"German" value:nil table:@"English"];
//    NSString *French = [[ChangeLanguage bundle] localizedStringForKey:@"French" value:nil table:@"English"];
//
//    NSString *Korean  = [[ChangeLanguage bundle] localizedStringForKey:@"Korean" value:nil table:@"English"];
//
//    NSString *Japanese = [[ChangeLanguage bundle] localizedStringForKey:@"Japanese" value:nil table:@"English"];
//    NSString *Thai  = [[ChangeLanguage bundle] localizedStringForKey:@"Thai" value:nil table:@"English"];
//    NSString *Turkish  = [[ChangeLanguage bundle] localizedStringForKey:@"Turkish" value:nil table:@"English"];
//
//
    
    return @[
        [LYLanguage creatName:@"English" key:@"en_US" bundleKey:@"en"],
        [LYLanguage creatName:@"简体中文" key:@"zh_CN" bundleKey:@"zh-Hans"],
        [LYLanguage creatName:@"繁体中文" key:@"zh_HK" bundleKey:@"zh-HK"],
   
        [LYLanguage creatName:@"Deutsch" key:@"de_DE" bundleKey:@"de"],
        [LYLanguage creatName:@"français" key:@"fr_FR" bundleKey:@"fr"],
        
        [LYLanguage creatName:@"한국인" key:@"ko_kO" bundleKey:@"ko"],
        [LYLanguage creatName:@"日本語" key:@"ja_JP" bundleKey:@"jp"],
        
        [LYLanguage creatName:@"ไทย" key:@"th_Th" bundleKey:@"th"],
        [LYLanguage creatName:@"Türkçe" key:@"tr_TR" bundleKey:@"tr"],
        [LYLanguage creatName:@"Tiếng Việt" key:@"vi_VN" bundleKey:@"vi"],//越南语

        
    ];
}

+ (NSTimeZone *)timeZone {
    NSString *current = [self userLanguage];
    NSString *name = @"America/Los_Angeles";
    if ([current isEqualToString: @"zh-Hans"]) {
        name = @"Asia/Shanghai";
    } else if ([current isEqualToString: @"en"]) {
        name = @"America/Los_Angeles";
    }else if ([current isEqualToString: @"zh-HK"]) {
        name = @"Asia/Hong_Kong";
    }else if ([current isEqualToString: @"ja"]) {
        name = @"Asia/Tokyo";
    }else if ([current isEqualToString: @"vi"]) {//越南语
        name = @"Asia/Hanoi";
    }
    return  [[NSTimeZone alloc] initWithName:name];
}


@end
