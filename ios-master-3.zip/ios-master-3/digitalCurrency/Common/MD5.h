//
//  MD5.h
//  digitalCurrency
//
//  Created by sunliang on 2019/4/4.
//  Copyright © 2019年 BIZZAN. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MD5 : NSObject
+(NSString *) md5: (NSString *) inPutText;
@end
