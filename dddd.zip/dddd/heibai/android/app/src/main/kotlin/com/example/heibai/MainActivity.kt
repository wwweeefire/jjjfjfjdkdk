package com.example.heibai

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
