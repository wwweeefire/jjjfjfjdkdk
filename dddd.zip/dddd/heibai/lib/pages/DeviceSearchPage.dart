import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:heibai/generated/l10n.dart';
// import 'package:heibai/pages/kchart/utils/date_format_util.dart';
// import 'package:monitor/common/style/style_custom.dart';
//
import 'package:heibai/net/api/Api.dart';
import 'package:heibai/net/api/app_api.dart';
import 'package:heibai/util/ThemeUtils.dart';
import 'package:heibai/util/DataUtils.dart';
import 'package:http/http.dart';
import '../Classes/model/searchmodel.dart';
import '../Classes/model/MCategoryList.dart';
import 'package:heibai/pages/userMsgRow.dart';
import 'package:heibai/pages/KChatPage.dart';

import '../Classes/model/homeListModel.dart';

class DeviceSearchPage extends StatefulWidget {
  // List<String> contents = [
  //   "mc20",
  //   "sony A6300系列",
  //   "sony a7",
  //   "sony 黑卡",
  //   "iphone xr",
  //   "'耐克'店铺",
  //   "mc20",
  //   "123",
  //   "321",
  // ];

  @override
  State<StatefulWidget> createState() {
    return _DeviceSearchPageState();
  }
}

class _DeviceSearchPageState extends State<DeviceSearchPage> {
  // List<MListElement> list = [];
  String searchValue = "";
  List<ListElement> Array = [];

  bool showseaching = false;
  bool sholoading = true;

  List<String> hisArray = [
    // "mc20",
    // "sony A6300系列",
    // "iphone xr",
    // "'耐克'店铺",
    // "mc20",
  ];
  TextEditingController _controller = new TextEditingController();

  @override
  void initState() {
    super.initState();
    _gethist();
  }

  _gethist() {
    DataUtils.getsearch().then((List<String> shisArray) {
      if (shisArray != null) {
        setState(() {
          hisArray = shisArray;
        });
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    double statusHeight = MediaQuery.of(context).padding.top;

    // _controller.text = searchValue;

    Widget search = Row(
      children: <Widget>[
        SizedBox(width: 6),
        Icon(Icons.search),
        SizedBox(width: 6),
        Expanded(
          flex: 1,
          child: TextField(
            // keyboardType: type,
            maxLines: 1,
            // controller: Controller,
            decoration: InputDecoration(
              hintText: S.current.SSBZGPJJ,
              border: InputBorder.none,
              hintStyle: TextStyle(
                fontSize: 12,
                color: ThemeUtils().currentColorTheme.textGaryColor,
              ),
            ),
            style: TextStyle(
              fontSize: 12,
              color: ThemeUtils().currentColorTheme.textWithdrawColor,
            ),
            onChanged: (value) {
              setState(() {
                searchValue = value;
              });
              // _controller.text = searchValue;
            },
            controller: _controller,
          ),
        ),
        searchValue != ""
            ? InkWell(
                onTap: () {
                  setState(() {
                    searchValue = "";
                  });
                },
                child: Icon(Icons.close, size: 14),
              )
            : Container(),
        SizedBox(width: 6),
        InkWell(
          onTap: () {
            setState(() {
              sholoading = false;
              showseaching = false;
            });
          },
          child: Text(
            "搜索",
            style: TextStyle(
              fontSize: 15,
              // fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.textWithdrawColor,
            ),
          ),
        ),
        SizedBox(width: 15),
      ],
    );

    Widget nw = new SizedBox(
      child: new Container(
        // padding: EdgeInsets.fromLTRB(10, 5, 5, 5),
        // margin: EdgeInsets.fromLTRB(15, 5, 15, 5),
        color: ThemeUtils().currentColorTheme.defaultColor,
        alignment: Alignment.center,
        child: search,
      ),
    );

    Widget allviebody = Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: true,
        // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
        title: nw,
        backgroundColor: ThemeUtils().currentColorTheme.contentBG,
        iconTheme: IconThemeData(
          color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
        ),
      ),
      // backgroundColor: themeColor,
      body: Container(
        color: ThemeUtils().currentColorTheme.contentBG,
        // padding: EdgeInsets.fromLTRB(16, 10, 16, 16),
        child: Column(
          children: <Widget>[
            // Row(
            //   children: <Widget>[
            //     Expanded(
            //       flex: 1,
            //       child: Container(
            //         height: 36,
            //         alignment: Alignment.center,
            //         decoration: BoxDecoration(
            //             // color: CustomColors.grey_swallow,
            //             borderRadius: BorderRadius.circular(36)),
            //         child: Text(""),
            //       ),
            //     ),
            //     SizedBox(width: 8),
            //   ],
            // ),
            SizedBox(
              height: 10,
            ),
            sholoading == true ? getHistoryWidget() : getSearchResultWidget()
          ],
        ),
      ),
    );

    return allviebody;
    // return Scaffold(
    //   body: Container(
    //     color: ThemeUtils().currentColorTheme.contentBG,
    //     padding: EdgeInsets.fromLTRB(16, statusHeight + 12, 16, 16),
    //     child: Column(
    //       children: <Widget>[
    //         Row(
    //           children: <Widget>[
    //             Expanded(
    //               flex: 1,
    //               child: Container(
    //                 height: 36,
    //                 alignment: Alignment.center,
    //                 decoration: BoxDecoration(
    //                     // color: CustomColors.grey_swallow,
    //                     borderRadius: BorderRadius.circular(36)),
    //                 child: Text(""),
    //               ),
    //             ),
    //             SizedBox(width: 8),

    //           ],
    //         ),
    //         SizedBox(
    //           height: 32,
    //         ),
    //         searchValue == "" ? getHistoryWidget() : getSearchResultWidget()
    //       ],
    //     ),
    //   ),
    // );
  }

  pushKChatPage(Product pro) async {
    // 打开登录页并处理登录成功的回调
    final result =
        await Navigator.of(context).push(MaterialPageRoute(builder: (context) {
      return KChatPage(
        title: pro.name,
        model: pro,
      );
    }));
  }

  Future<List<ListElement>> getdata() async {
    Map<String, dynamic> param = {};

    param["page"] = 1;
    param["pageSize"] = 100;
    param["name"] = searchValue;
    hisArray.add(searchValue);
    DataUtils.setsearch(hisArray);
    showseaching = true;

    // param["category"] = model.list[index].id;
    ResultData resultData =
        await AppApi.getInstance().get_product_page_list(context, true, param);
    if (resultData.isSuccess()) {
      // list.remove;

      Searchmodel model = searchmodelFromJson(resultData.dataJson);
      // nowmodel = model;
      // showLoading = false;
      return model.list;

      // setState(() {
      //   list = model.list;
      // });
    } else {
      List<ListElement> list = [];
      // setState(() {});
      return list;
      // JCHub.showmsg(resultData.msg, context);
    }
  }

  // Widget SearchResultWidget = getSearchResultWidget();

  ///搜索结果
  Widget getSearchResultWidget() {
    final mediaQueryData = MediaQuery.of(context);

// 2.获取宽度和高度
    final screenWidth = mediaQueryData.size.width;
    if (!showseaching) {
      getdata().then((List<ListElement> hisArray) {
        Array = hisArray;
        setState(() {});
      });
    }

    if (Array.length > 0) {
      return SingleChildScrollView(
          child: Column(
        children: List.generate(Array.length, (index) {
          ListElement item = Array[index];
          return InkWell(
            onTap: () {
              Product pro = Product(
                  weekendTrading: item.weekendTrading,
                  open: item.open.toDouble(),
                  price: item.price.toDouble(),
                  low: item.low.toDouble(),
                  high: item.high.toDouble(),
                  change: item.change.toDouble(),
                  id: item.id,
                  code: item.code,
                  name: item.name,
                  wave: item.wave,
                  vol: item.vol,
                  openTime: item.openTime);
              pushKChatPage(pro);
            },
            child: UserMsgRow(
                title: item.name,
                price: item.price.toString(),
                increase: item.change.toStringAsFixed(2)),
          );
        }),
      ));
    } else {
      return Container(
          width: screenWidth,
          child: Text(S.current.ZWSJ,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 12,
                // fontWeight: FontWeight.w900,
                color: ThemeUtils().currentColorTheme.textWithdrawColor,
              )));
    }
  }

  ///搜索历史
  Widget getHistoryWidget() {
    return Column(
      children: <Widget>[
        Container(
            padding: EdgeInsets.fromLTRB(16, 10, 16, 16),
            alignment: Alignment.centerLeft,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Text(
                  S.current.SSLS,
                  style: TextStyle(
                    fontSize: 15,
                    // fontWeight: FontWeight.w900,
                    color: ThemeUtils().currentColorTheme.textWithdrawColor,
                  ),
                ),
                InkWell(
                  onTap: showClearDialog,
                  child: Icon(Icons.delete_forever,
                      color: Colors.redAccent, size: 20),
                )
              ],
            )),
        SizedBox(
          height: 26,
        ),
        SingleChildScrollView(
          child: Wrap(
            spacing: 6,
            runSpacing: 6,
            children: List.generate(hisArray.length, (index) {
              return InkWell(
                onTap: () {
                  setState(() {
                    searchValue = hisArray[index];
                    _controller.text = searchValue;
                  });
                },
                child: Chip(
                  backgroundColor: ThemeUtils().currentColorTheme.contentBG,
                  label: Text(hisArray[index],
                      style: TextStyle(
                        fontSize: 12,
                        // fontWeight: FontWeight.w900,
                        color: ThemeUtils().currentColorTheme.textWithdrawColor,
                      )),
                ),
              );
            }),
          ),
        )
      ],
    );
  }

  showClearDialog() {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return CupertinoAlertDialog(
            title: Text(""),
            content: Text(S.current.QCLTJL),
            actions: <Widget>[
              CupertinoDialogAction(
                child: Text(S.current.DCQX),
                onPressed: () {
                  Navigator.pop(context);
                  //print("取消");
                },
              ),
              CupertinoDialogAction(
                child: Text(S.current.DQD),
                onPressed: () {
                  setState(() {
                    hisArray = [];
                    DataUtils.setsearch(hisArray);
                  });
                  Navigator.pop(context);
                },
              ),
            ],
          );
        });
  }
}
