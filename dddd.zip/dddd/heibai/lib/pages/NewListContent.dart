import 'package:flutter/material.dart';
import 'package:heibai/generated/l10n.dart';
import 'package:heibai/util/ThemeUtils.dart';
import 'dart:io';
import 'dart:convert';
import 'package:flutter/foundation.dart';
// import 'package:simp';
// import 'package:flutter_fai_webview/flutter_fai_webview.dart';
import 'package:webview_flutter/webview_flutter.dart';

class NewListContent extends StatefulWidget {
  final String htmlContent;

  NewListContent({Key key, this.htmlContent}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return NewListContentState();
  }
}

class NewListContentState extends State<NewListContent> {
  void initState() {
    super.initState();
    // Enable virtual display.
    if (Platform.isAndroid) WebView.platform = AndroidWebView();
  }
  // Widget build(BuildContext context) {

  //   return Scaffold(
  //       backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
  //       appBar: AppBar(
  //         backgroundColor: ThemeUtils().currentColorTheme.contentBG,
  //         title: Text("详情"),
  //       ),
  //       body: WebView(
  //       initialUrl: 'about:blank',
  //       onWebViewCreated: (WebViewController webViewController) {
  //         _controller = webViewController;
  //         _loadHtmlFromAssets();
  //       },;

  // }

  WebViewController _controller;

  @override
  Widget build(BuildContext context) {
    final mediaQueryData = MediaQuery.of(context);

// 2.获取宽度和高度
    final screenWidth = mediaQueryData.size.width;
    final screenHeight = mediaQueryData.size.height;

    final statusBarHeight = mediaQueryData.padding.top;
// 有刘海的屏幕:34 没有刘海的屏幕0
    double bottomHeight = 10.0;

    if (!kIsWeb) {
      bottomHeight = 10.0;
      if (Platform.isIOS) {
        bottomHeight = mediaQueryData.padding.bottom;
      }
    }
    return Scaffold(
        backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
        appBar: AppBar(
          backgroundColor: ThemeUtils().currentColorTheme.contentBG,
          title: ThemeUtils.sText(S.current.QXIANQING),
        ),
        body: Container(
          margin: EdgeInsets.only(bottom: bottomHeight),
          child: WebView(
            initialUrl: 'about:blank',
            onWebViewCreated: (WebViewController webViewController) {
              _controller = webViewController;
              _loadHtmlFromAssets();
            },
          ),
        ));
  }

  _loadHtmlFromAssets() async {
    Uri uri = new Uri.dataFromString(widget.htmlContent,
        mimeType: 'text/html', encoding: Encoding.getByName('utf-8'));

    _controller.loadUrl(uri.toString());
  }
}
