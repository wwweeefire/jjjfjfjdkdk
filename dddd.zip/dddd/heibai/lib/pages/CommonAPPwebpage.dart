import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:heibai/pages/kchart/utils/date_format_util.dart';
import 'package:heibai/util/ThemeUtils.dart';
import 'dart:io';
import 'dart:convert';
// import 'package:simp';
// import 'package:flutter_fai_webview/flutter_fai_webview.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';
import 'package:heibai/generated/l10n.dart';

class CommonAPPwebpage extends StatefulWidget {
  final String htmlContent;
  final String title;

  CommonAPPwebpage({Key key, this.htmlContent, this.title}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return NewListContentState();
  }
}

class NewListContentState extends State<CommonAPPwebpage> {
  FlutterWebviewPlugin flutterWebviewPlugin = FlutterWebviewPlugin();
  double lineProgress = 0.0;

  void initState() {
    super.initState();
    flutterWebviewPlugin.onProgressChanged.listen((progress) {
      print(progress);
      setState(() {
        lineProgress = progress;
      });
    });
  }

  @override
  void dispose() {
    flutterWebviewPlugin.dispose();
    super.dispose();
  }
  // Widget build(BuildContext context) {

  //   return Scaffold(
  //       backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
  //       appBar: AppBar(
  //         backgroundColor: ThemeUtils().currentColorTheme.contentBG,
  //         title: Text("详情"),
  //       ),
  //       body: WebView(
  //       initialUrl: 'about:blank',
  //       onWebViewCreated: (WebViewController webViewController) {
  //         _controller = webViewController;
  //         _loadHtmlFromAssets();
  //       },;

  // }

  //

  @override
  Widget build(BuildContext context) {
    final mediaQueryData = MediaQuery.of(context);

// 2.获取宽度和高度
    final screenWidth = mediaQueryData.size.width;
    final screenHeight = mediaQueryData.size.height;

    final statusBarHeight = mediaQueryData.padding.top;
// 有刘海的屏幕:34 没有刘海的屏幕0
    double bottomHeight = 0.0;

    if (!kIsWeb) {
      bottomHeight = 10.0;
      if (Platform.isIOS) {
        bottomHeight = mediaQueryData.padding.bottom;
      }
    }

    return WebviewScaffold(
      appBar: AppBar(
        backgroundColor: ThemeUtils().currentColorTheme.contentBG,
        title: ThemeUtils.sText(widget.title),
        bottom: PreferredSize(
          child: _progressBar(lineProgress, context),
          preferredSize: Size.fromHeight(3.0),
        ),
      ),
      url: widget.htmlContent,
    );
  }

  _progressBar(double progress, BuildContext context) {
    return LinearProgressIndicator(
      backgroundColor: Colors.white70.withOpacity(0),
      value: progress == 1.0 ? 0 : progress,
      valueColor: new AlwaysStoppedAnimation<Color>(Colors.blue),
    );
  }
}
