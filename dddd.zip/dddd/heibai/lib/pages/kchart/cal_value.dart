

class CalValue {

  int mStartIndex = 0, mStopIndex = 0;





}