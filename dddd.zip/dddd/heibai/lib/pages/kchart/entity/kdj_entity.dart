mixin KDJEntity {
  double k;
  double d;
  double j;
}
