mixin CandleEntity {
  double open;
  double high;
  double low;
  double close;
  double MA5Price;
  double MA10Price;
  double MA20Price;
  double MA30Price;
  double MA60Price;
//  上轨线
  double up;
//  中轨线
  double mb;
//  下轨线
  double dn;
}
