mixin VolumeEntity {
  double open;
  double close;
  double vol;
  double MA5Volume;
  double MA10Volume;
}
