mixin RSIEntity {
  /// RSI值
  double rsi;
  double rsiABSEma;
  double rsiMaxEma;
}
