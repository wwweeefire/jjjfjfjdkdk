mixin WREntity {
  /// %R值
  double r;

}
