void registerWebViewWebImplementation() {
  // No-op.
}
