import 'package:flutter/material.dart';
import 'package:heibai/Classes/model/config.dart';
import 'package:heibai/generated/l10n.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:heibai/util/ThemeUtils.dart';
import 'package:flutter/services.dart';
import 'package:heibai/Classes/JCHub/JCHub.dart';

class QrCodeImagePage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return QrCodeImagePageState();
  }
}

class QrCodeImagePageState extends State<QrCodeImagePage> {
  Widget build(BuildContext context) {
    // Widget ad = Container();
    // return ad;

    String code = ConfigManager().user.inviteCode.toString();
    Widget qrimag = Container(
      color: ThemeUtils().currentColorTheme.labelColorW,
      child: QrImage(
        data: code,
        version: QrVersions.auto,
        size: 221,
        gapless: false,
      ),
    );

    Widget ftext = Container(
      child: Text(
        S.current.DHYYQJR,
        style: TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );

    Widget inviteText = Container(
      child: Text(
        S.current.DYQM,
        style: TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );

    Widget inviteCodeText = Container(
      child: Text(
        code,
        style: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.labelColorY,
        ),
      ),
    );

    Widget inviteCodebtn = Container(
        child: new InkWell(
      onTap: () {
        Clipboard.setData(ClipboardData(text: S.current.DFZDJQB));
        JCHub.showmsg(S.current.YJFZCG, context);
      },
      child: new Container(
          height: 44,
          width: 120,
          // padding: EdgeInsets.fromLTRB(15, 15, 15, 15),
          // margin: EdgeInsets.fromLTRB(15, 5, 15, 5),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5),
              // color: ThemeUtils().currentColorTheme.labelColorY,
              // border: bo
              border: Border.all(
                  color: ThemeUtils().currentColorTheme.dateGaryColor,
                  width: 1)),
          alignment: Alignment.center,
          child: Text(
            S.current.FZYQM,
            // textAlign: TextAlign.center,
            style: TextStyle(
                // letterSpacing: 20,
                fontWeight: FontWeight.bold,
                fontSize: 12,
                color: ThemeUtils().currentColorTheme.textWithdrawColor),
          )),
    ));

    Widget bodyview = Container(
      alignment: Alignment.center,
      margin: EdgeInsets.fromLTRB(15, 37, 15, 0),
      color: ThemeUtils().currentColorTheme.contentBG,
      height: 458,
      child: Column(
        children: [
          SizedBox(
            height: 45,
          ),
          qrimag,
          SizedBox(
            height: 5,
          ),
          ftext,
          SizedBox(
            height: 11,
          ),
          inviteText,
          SizedBox(
            height: 11,
          ),
          inviteCodeText,
          SizedBox(
            height: 11,
          ),
          inviteCodebtn
        ],
      ),
    );

    Widget allviebody = Scaffold(
      backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
      body: bodyview,
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
        ),
        // 如果没有设置这项， 二级页面 会默认是返回箭头  ， 有侧边栏的页面默认有图标（用来打开侧边栏）
        // automaticallyImplyLeading: true,
        // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
        title: ThemeUtils.sText(S.current.invitefriends),
        centerTitle: true,
        //  actions: <Widget>[
        //     IconButton(
        //         icon: Icon(Icons.add_alarm),
        //         tooltip: 'Add Alarm',
        //         onPressed: () {
        //           // do nothing
        //         })
        //   ],   // 标题是否在居中

//          elevation: 0.1, // 导航栏Z轴的高度，默认是1  默认就是有高度 阴影的
        backgroundColor: ThemeUtils()
            .currentColorTheme
            .contentBG, // 导航栏的颜色  默认是 ThemeData 的颜色
//         flexibleSpace: FlexibleSpaceBar(title: Text("你号"),),//这个堆叠在工具栏上面  一般 appbar不用  主要用在 SliverAppBar上
//          brightness: Brightness.light, //状态栏的深度 有白色和黑色两种主题
//          titleSpacing: 10,//flexibleSpace 和 title 的距离  默认是重合的
//          toolbarOpacity: 0.5,// 导航栏透明度 默认是1 ，不包括flexibleSpace
//          bottomOpacity: 0.5,
      ),
    );
    return allviebody;
  }
}
