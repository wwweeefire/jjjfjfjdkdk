import 'package:flutter/material.dart';
import 'package:heibai/generated/l10n.dart';
import 'package:heibai/util/DataUtils.dart';
import 'package:heibai/util/ThemeUtils.dart';
import 'package:heibai/Classes/model/config.dart'; //咨询
import 'package:heibai/pages/MineinfoDataPage.dart';

import 'package:heibai/pages/Modifyloginpassword.dart';

import 'package:heibai/pages/Changepaymentpassword.dart';
import 'package:heibai/pages/web_socket_utility.dart';
import 'package:heibai/pages/login/loginView.dart';
import 'package:heibai/pages/seting/EPaymentmethod.dart';
import 'package:tapped/tapped.dart';
import 'package:heibai/net/api/Api.dart';
import 'package:heibai/net/api/app_api.dart';
import 'package:heibai/routers/navigator_util.dart';
import 'package:heibai/pages/localization_page.dart';
import 'package:heibai/pages/localthemepage.dart';

// import 'package:heibai/util/DataUtils.dart';
var titleTextStyle = TextStyle(
    fontSize: 12.0, color: ThemeUtils().currentColorTheme.labelColorG);
var rightArrowIcon = Image.asset(
  "images/wode/xyy@3x.png",
  width: 8,
  height: 14,
);

class SetingViewPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return SetingViewPageState();
  }
}

class SetingViewPageState extends State<SetingViewPage> {
  Config f = ConfigManager().config;
  var titleTextStyle = TextStyle(
      fontSize: 12.0, color: ThemeUtils().currentColorTheme.labelColorW);

  void post_logout() async {
    Map<String, dynamic> param = {};

    ResultData resultData =
        await AppApi.getInstance().post_logout(context, true, param);
    if (resultData.isSuccess()) {
      DataUtils.clearLoginInfo();
      NavigatorUtil.goToLoginRemovePage(context);
      WebSocketUtility().closeSocket();
    }
  }

  Widget build(BuildContext context) {
    var PositionBtn = Builder(builder: (ctx) {
      return CommonButton(
          text: S.current.LOGOUT,
          color: ThemeUtils().currentColorTheme.labelColorY,
          onTap: () {
            post_logout();
            FocusScope.of(context).requestFocus(FocusNode());
          });
    });
    Widget bodeView = Column(
      children: <Widget>[
        SizedBox(
          height: 10,
        ),
        itemView(
          title: S.current.GRXX,
          onTap: () async {
            final result = await Navigator.of(context)
                .push(MaterialPageRoute(builder: (context) {
              return MineinfoDataPage();
            }));
          },
        ),
        SizedBox(
          height: 10,
        ),
        itemView(
            title: S.current.SKFS,
            onTap: () async {
              final result = await Navigator.of(context)
                  .push(MaterialPageRoute(builder: (context) {
                return EPaymentmethod();
              }));
            }),
        SizedBox(
          height: 10,
        ),
        itemView(
          title: S.current.XGTXMM,
          onTap: () async {
            final result = await Navigator.of(context)
                .push(MaterialPageRoute(builder: (context) {
              return Changepaymentpassword();
            }));
          },
        ),
        SizedBox(
          height: 10,
        ),
        itemView(
          title: S.current.XGMM,
          onTap: () async {
            final result = await Navigator.of(context)
                .push(MaterialPageRoute(builder: (context) {
              return Modifyloginpassword();
            }));
          },
        ),
        SizedBox(
          height: 10,
        ),
        itemView(
          title: S.current.changeLanguage,
          des: DataUtils.getLanguage(),
          onTap: () async {
            final result = await Navigator.of(context)
                .push(MaterialPageRoute(builder: (context) {
              return LocalizetionPage();
            }));
          },
        ),
        SizedBox(
          height: 10,
        ),
        // itemView(
        //   title: Api.istest == true ? "主题" : "",
        //   onTap: () async {
        //     final result = await Navigator.of(context)
        //         .push(MaterialPageRoute(builder: (context) {
        //       return localthemepage();
        //     }));
        //   },
        // ),
        SizedBox(
          height: 10,
        ),
        PositionBtn
      ],
    );

    Widget allviebody = Scaffold(
      backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
      body: bodeView,
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
        ),
        // 如果没有设置这项， 二级页面 会默认是返回箭头  ， 有侧边栏的页面默认有图标（用来打开侧边栏）
        // automaticallyImplyLeading: true,
        // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
        title: ThemeUtils.sText(S.current.SETING),
        centerTitle: true,
        //  actions: <Widget>[
        //     IconButton(
        //         icon: Icon(Icons.add_alarm),
        //         tooltip: 'Add Alarm',
        //         onPressed: () {
        //           // do nothing
        //         })
        //   ],   // 标题是否在居中

        elevation: 0, // 导航栏Z轴的高度，默认是1  默认就是有高度 阴影的
        backgroundColor: ThemeUtils()
            .currentColorTheme
            .contentBG, // 导航栏的颜色  默认是 ThemeData 的颜色
//         flexibleSpace: FlexibleSpaceBar(title: Text("你号"),),//这个堆叠在工具栏上面  一般 appbar不用  主要用在 SliverAppBar上
//          brightness: Brightness.light, //状态栏的深度 有白色和黑色两种主题
//          titleSpacing: 10,//flexibleSpace 和 title 的距离  默认是重合的
//          toolbarOpacity: 0.5,// 导航栏透明度 默认是1 ，不包括flexibleSpace
//          bottomOpacity: 0.5,
      ),
    );
    return allviebody;
  }
}

class itemView extends StatelessWidget {
  final Function onTap;

  final String title;
  final String des;
  final String isColor;

  const itemView({
    Key key,
    this.onTap,
    this.title,
    this.des,
    this.isColor,
  }) : super(key: key);
  Widget build(BuildContext context) {
    Widget text;
    if (des == null && isColor == null) {
      text = Container(
          child: Text(
        '',
        style: titleTextStyle,
      ));
    } else {
      if (des != null) {
        text = Container(
            child: Text(
          des,
          style: titleTextStyle,
        ));
      } else {
        var oncolor;
        var downColor;
        if (isColor == "1") {
          oncolor = ThemeUtils().currentColorTheme.textRedColor;
          downColor = ThemeUtils().currentColorTheme.textgreenColor;
        } else {
          oncolor = ThemeUtils().currentColorTheme.textgreenColor;
          downColor = ThemeUtils().currentColorTheme.textRedColor;
        }

        text = Container(
          alignment: Alignment.center,
          child: RichText(
              text: TextSpan(
            text: '↑',
            style: TextStyle(color: oncolor, fontSize: 12),
            children: [
              TextSpan(
                text: '↓',
                style: TextStyle(color: downColor, fontSize: 12),
              ),
              // TextSpan(
              //   text: '元',
              //   style: TextStyle(color: ThemeUtils().currentColorTheme.textGaryColor, fontSize: 12),
              // )
            ],
          )),
        );
      }
    }

    Widget listItemContent = Container(
      color: ThemeUtils().currentColorTheme.contentBG,
      padding: const EdgeInsets.fromLTRB(10, 17.0, 10.0, 17.0),
      margin: EdgeInsets.symmetric(horizontal: 15, vertical: 0),
      child: Row(
        children: <Widget>[
          Container(
              child: Text(
            title,
            style: titleTextStyle,
          )),
          Expanded(
            child: Text(''), // 中间用Expanded控件
          ),
          text,
          Container(
            width: 10,
          ),
          rightArrowIcon
        ],
      ),
    );
    listItemContent = Tapped(
      child: listItemContent,
      onTap: onTap,
    );
    return listItemContent;
  }
}
