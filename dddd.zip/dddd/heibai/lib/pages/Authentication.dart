import 'package:flutter/material.dart';
import 'package:heibai/generated/l10n.dart';
import 'package:heibai/util/ThemeUtils.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:heibai/pages/login/loginView.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:tapped/tapped.dart';
import 'package:heibai/net/api/Api.dart';
import 'package:heibai/net/api/app_api.dart';
import 'dart:typed_data';
import 'package:heibai/Classes/JCHub/JCHub.dart';
import 'package:flutter/foundation.dart';

class Authentication extends StatefulWidget {
  // final ListElement model;
  // final double number;

  @override
  State<StatefulWidget> createState() {
    return Authenticationtate();
  }
}

class Authenticationtate extends State<Authentication> {
  List<XFile> _imageFileList = List.empty(growable: true); //存放选择的图片
  final ImagePicker _picker = ImagePicker();
  int maxFileCount = 1; //最大选择图片数量
  dynamic _pickImageError;
  // int _bigImageIndex = 0; //选中的需要放大的图片的下标
  // bool _bigImageVisibility = false; //是否显示预览大图
  String upurl;
  String bupurl;
  final usernameCtrl = TextEditingController(text: '');
  final sfzcardCtrl = TextEditingController(text: '');
  final phoneCtrl = TextEditingController(text: '');

  //获取当前展示的图的数量
  int getImageCount() {
    if (_imageFileList.length < maxFileCount) {
      return _imageFileList.length + 1;
    } else {
      return _imageFileList.length;
    }
  }

  List<XFile> _bimageFileList = List.empty(growable: true); //存放选择的图片

  int bmaxFileCount = 1; //最大选择图片数量

  //获取当前展示的图的数量
  int bgetImageCount() {
    if (_bimageFileList.length < maxFileCount) {
      return _bimageFileList.length + 1;
    } else {
      return _bimageFileList.length;
    }
  }

  void _onImageButtonPressed(ImageSource source,
      {BuildContext context,
      double maxHeight,
      double maxWidth,
      int imageQuality}) async {
    try {
      _imageFileList = List.empty(growable: true);
      final pickedFileList = await _picker.pickMultiImage(
        maxWidth: maxWidth,
        maxHeight: maxHeight,
        imageQuality: imageQuality,
      );
      setState(() {
        //pickedFileList.e
        if (_imageFileList.length < maxFileCount) {
          //小于最大数量
          if ((_imageFileList.length + (pickedFileList?.length ?? 0)) <=
              maxFileCount) {
            //加上新选中的不超过最大数量
            pickedFileList.forEach((element) {
              _imageFileList.add(element);
              uploadimga();
            });
          } else {
            //否则报错
            // Global.showCenterToast("超过可选最大数量!自动移除多余的图片");
            int avaliableCount = maxFileCount - _imageFileList.length;
            for (int i = 0; i < avaliableCount; i++) {
              _imageFileList.add(pickedFileList[i]);
            }
          }
        }
      });
    } catch (e) {
      setState(() {
        // Global.showCenterToast("$_pickImageError");//出现错误的话报错
        _pickImageError = e;
        JCHub.showmsg("$_pickImageError", context);
      });
    }
  }

  void _bonImageButtonPressed(ImageSource source,
      {BuildContext context,
      double maxHeight,
      double maxWidth,
      int imageQuality}) async {
    try {
      _bimageFileList = List.empty(growable: true);
      final pickedFileList = await _picker.pickMultiImage(
        maxWidth: maxWidth,
        maxHeight: maxHeight,
        imageQuality: imageQuality,
      );
      setState(() {
        //pickedFileList.e
        if (_bimageFileList.length < maxFileCount) {
          //小于最大数量
          if ((_bimageFileList.length + (pickedFileList?.length ?? 0)) <=
              maxFileCount) {
            //加上新选中的不超过最大数量
            pickedFileList.forEach((element) {
              _bimageFileList.add(element);
              buploadimga();
            });
          } else {
            //否则报错
            // Global.showCenterToast("超过可选最大数量!自动移除多余的图片");
            int avaliableCount = maxFileCount - _bimageFileList.length;
            for (int i = 0; i < avaliableCount; i++) {
              _bimageFileList.add(pickedFileList[i]);
            }
          }
        }
      });
    } catch (e) {
      setState(() {
        // Global.showCenterToast("$_pickImageError");//出现错误的话报错
        _pickImageError = e;
        JCHub.showmsg("$_pickImageError", context);
      });
    }
  }

  void uploadimga() async {
    List<int> byets = await _imageFileList[0].readAsBytes();
    ResultData resultData = await AppApi.getInstance()
        .uploadimage(context, File(_imageFileList[0].path), byets);
    if (resultData.isSuccess()) {
      // DataUtils.saveUserInfo(resultData.dataJson);
      // ConfigManager.
      upurl = resultData.data['file_path'];
      JCHub.showmsg(resultData.msg, context);
      // NavigatorUtil.goToHomeRemovePage(context);
    } else {
      JCHub.showmsg(resultData.msg, context);
    }
  }

  void buploadimga() async {
    List<int> byets = await _bimageFileList[0].readAsBytes();
    ResultData resultData = await AppApi.getInstance()
        .uploadimage(context, File(_bimageFileList[0].path), byets);
    if (resultData.isSuccess()) {
      // DataUtils.saveUserInfo(resultData.dataJson);
      // ConfigManager.
      bupurl = resultData.data['file_path'];
      JCHub.showmsg(resultData.msg, context);
      // NavigatorUtil.goToHomeRemovePage(context);
    } else {
      JCHub.showmsg(resultData.msg, context);
    }
  }

  void post_member_verified(params) async {
    // params["code"] = widget.model.code;

    ResultData resultData =
        await AppApi.getInstance().post_member_verified(context, true, params);
    if (resultData.isSuccess()) {
      JCHub.showmsg(S.current.Submittedsuccessfullywaitingforreview, context);
      Navigator.pop(context, "refresh");
    } else {
      JCHub.showmsg(resultData.msg, context);
    }
  }

  Widget build(BuildContext context) {
    var PositionBtn = Builder(builder: (ctx) {
      return CommonButton(
          text: S.current.submit,
          color: ThemeUtils().currentColorTheme.labelColorY,
          onTap: () {
            Map<String, dynamic> params = {};

            String username = usernameCtrl.text.trim();
            String bankcard = sfzcardCtrl.text.trim();

            String bankzname = phoneCtrl.text.trim();

            if (username.isEmpty || bankcard.isEmpty || bankzname.isEmpty) {
              JCHub.showmsg(S.current.QJCSJBNWK, context);
              return;
            }

            if (bupurl.isEmpty || upurl.isEmpty) {
              JCHub.showmsg(S.current.SFZZPBNWK, context);
              return;
            }

            params["frontend"] = upurl;
            params["backend"] = bupurl;

            params["mobile"] = bankzname;
            params["id_number"] = bankcard;
            params["real_name"] = username;
            post_member_verified(params);
            FocusScope.of(context).requestFocus(FocusNode());
          });
    });

    Widget name = Container(
        margin: EdgeInsets.only(left: 15, right: 15),
        child: authregTextField(
          icon: S.current.ZSXM,
          title: S.current.QSRZSXM,
          controller: usernameCtrl,
        ));

    Widget sfzid = Container(
        margin: EdgeInsets.only(left: 15, right: 15),
        child: authregTextField(
          icon: S.current.SFZH,
          title: S.current.QSRSFZH,
          controller: sfzcardCtrl,
        ));

    Widget phone = Container(
        margin: EdgeInsets.only(left: 15, right: 15),
        child: authregTextField(
          icon: S.of(context).SJH,
          title: S.current.QRRSJHM,
          controller: phoneCtrl,
        ));

    Widget toptext = Container(
      margin: EdgeInsets.only(left: 15, right: 15),
      height: 21,
      alignment: Alignment.centerLeft,
      child: Text(
        S.current.QSCSFZZFM,
        overflow: TextOverflow.ellipsis,
        maxLines: 1,
        style: TextStyle(
            color: ThemeUtils().currentColorTheme.textWithdkkkwColor,
            fontSize: 15),
        textAlign: TextAlign.left,
      ),
    );
    Widget bodyview = Column(
      children: <Widget>[
        SizedBox(
          height: 5,
        ),
        toptext,
        SizedBox(
          height: 5,
        ),
        Container(
          margin: EdgeInsets.only(left: 15, right: 15),
          child: DottedBorder(
              color: ThemeUtils().currentColorTheme.labelColorW,
              strokeWidth: 1,

              //手势包含添加按钮 实现点击进行选择图片
              child: Container(
                alignment: Alignment.center,
                child: topView(
                  image: _imageFileList.length > 0
                      ? kIsWeb == true
                          ? Image.network((_imageFileList[0].path))
                          : Image.file(File(_imageFileList[0].path),
                              fit: BoxFit.cover)
                      : Image.asset(
                          "images/wode/uplodatuox@3x.png",
                        ),
                  onTap: () => _onImageButtonPressed(
                    //执行打开相册
                    //
                    ImageSource.gallery,
                    context: context,
                    imageQuality: 40, //图片压缩
                  ),
                ),
              )),
        ),
        SizedBox(
          height: 20,
        ),
        Container(
          margin: EdgeInsets.only(left: 15, right: 15),
          child: DottedBorder(
            color: ThemeUtils().currentColorTheme.labelColorW,
            strokeWidth: 1,

            //手势包含添加按钮 实现点击进行选择图片
            child: buView(
              image: _bimageFileList.length > 0
                  ? kIsWeb == true
                      ? Image.network((_bimageFileList[0].path))
                      : Image.file(File(_bimageFileList[0].path),
                          fit: BoxFit.cover)
                  : Image.asset(
                      "images/wode/uplodbeimian@3x.png",
                    ),
              onTap: () => _bonImageButtonPressed(
                //执行打开相册
                //
                ImageSource.gallery,
                context: context,
                imageQuality: 40, //图片压缩
              ),
            ),
          ),
        ),
        SizedBox(
          height: 10,
        ),
        name,
        SizedBox(
          height: 5,
        ),
        sfzid,
        SizedBox(
          height: 5,
        ),
        phone,
        SizedBox(
          height: 5,
        ),
        PositionBtn,
      ],
    );

    Widget allviebody = Scaffold(
      backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
      resizeToAvoidBottomInset: false,
      body: Container(
        child: bodyview,
      ),
      appBar: AppBar(
        // 如果没有设置这项， 二级页面 会默认是返回箭头  ， 有侧边栏的页面默认有图标（用来打开侧边栏）
        // automaticallyImplyLeading: true,
        // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
        title: ThemeUtils.sText(S.current.Verified),
        centerTitle: true,
        iconTheme: IconThemeData(
          color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
        ),

        backgroundColor: ThemeUtils()
            .currentColorTheme
            .contentBG, // 导航栏的颜色  默认是 ThemeData 的颜色
      ),
    );
    return allviebody;
  }
}

class topView extends StatelessWidget {
  // final ListElement model;
  final Function onTap;
  final Image image;
  const topView({
    Key key,
    this.onTap,
    this.image,
    // this.model,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    var deviceData = MediaQuery.of(context); // 返回 MediaQueryData
    var width = deviceData.size.width - 150 - 40;
    // var image = new Image.asset('images/ic_nav_my_normal.png',height: 10 width,: 10);
    // var rightArrowIcon = Image.asset(
    //   "images/wode/xyy@3x.png",
    //   width: 8,
    //   height: 14,
    // );
    Widget rightimage = Container(
      height: 100,
      width: 150,
      // color: Colors.red,
      child: image == null ? Text("") : image,
    );

    Widget toptext = Container(
      height: 21,
      width: width,
      child: Text(
        S.current.XTM,
        overflow: TextOverflow.ellipsis,
        maxLines: 1,
        style: TextStyle(
            color: ThemeUtils().currentColorTheme.textWithdkkkwColor,
            fontSize: 15),
        textAlign: TextAlign.left,
      ),
    );
    Widget bottomtext = Container(
      height: 15,
      width: width,
      child: Text(
        S.current.QSCNDTXM,
        overflow: TextOverflow.ellipsis,
        maxLines: 1,
        style: TextStyle(
          color: ThemeUtils().currentColorTheme.textWithdDDrawColor,
          fontSize: 12,
        ),
      ),
    );

    Widget textView = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        SizedBox(
          height: 10,
        ),
        toptext,
        SizedBox(
          height: 20,
        ),
        bottomtext,
        // SizedBox(
        //   height: 12,
        // ),
      ],
    );
    Widget body = Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[
        textView,
        // Expanded(
        //   child: Text(''), // 中间用Expanded控件
        // ),
        rightimage
      ],
    );
    body = Tapped(
      child: body,
      onTap: onTap,
    );

    return Center(
      child: Container(
        // padding: EdgeInsets.all(10),

        height: 150,
        child: body,
        color: ThemeUtils().currentColorTheme.contentBG,
        // color: Colors.red,
      ),
    );
  }
}

class buView extends StatelessWidget {
  // final ListElement model;
  final Function onTap;
  final Image image;
  const buView({
    Key key,
    this.onTap,
    this.image,
    // this.model,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    var deviceData = MediaQuery.of(context); // 返回 MediaQueryData
    var width = deviceData.size.width - 150 - 40;
    // var image = new Image.asset('images/ic_nav_my_normal.png',height: 10 width,: 10);
    // var rightArrowIcon = Image.asset(
    //   "images/wode/xyy@3x.png",
    //   width: 8,
    //   height: 14,
    // );
    Widget rightimage = Container(
      height: 100,
      width: 150,
      // color: Colors.red,
      child: image == null ? Text("") : image,
    );

    Widget toptext = Container(
      height: 21,
      width: width,
      child: Text(
        S.current.DBM,
        overflow: TextOverflow.ellipsis,
        maxLines: 1,
        style: TextStyle(
            color: ThemeUtils().currentColorTheme.textWithdkkkwColor,
            fontSize: 15),
        textAlign: TextAlign.left,
      ),
    );
    Widget bottomtext = Container(
      height: 15,
      width: width,
      child: Text(
        S.current.QSSCNDBM,
        overflow: TextOverflow.ellipsis,
        maxLines: 1,
        style: TextStyle(
          color: ThemeUtils().currentColorTheme.textWithdDDrawColor,
          fontSize: 12,
        ),
      ),
    );

    ;
    Widget textView = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        SizedBox(
          height: 10,
        ),
        toptext,
        SizedBox(
          height: 20,
        ),
        bottomtext,
        // SizedBox(
        //   height: 12,
        // ),
      ],
    );
    Widget body = Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[
        textView,
        // Expanded(
        //   child: Text(''), // 中间用Expanded控件
        // ),
        rightimage
      ],
    );

    body = Tapped(
      child: body,
      onTap: onTap,
    );
    return Center(
      child: Container(
        // padding: EdgeInsets.all(10),

        height: 150,
        child: body,
        color: ThemeUtils().currentColorTheme.contentBG,
        // color: Colors.red,
      ),
    );
  }
}

class authregTextField extends StatelessWidget {
  final String icon;

  final String title;
  final Function onTap;
  final TextEditingController controller;

  const authregTextField(
      {Key key, this.icon, this.title, this.onTap, this.controller})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    var iconContainer = Container(
      // margin: EdgeInsets.all(),
      height: 20,
      width: 60,
      // decoration: BoxDecoration(
      //   color: ThemeUtils().currentColorTheme.labelColorW,
      //   borderRadius: BorderRadius.circular(2),
      //   gradient: LinearGradient(
      //     begin: Alignment.topLeft,
      //     end: Alignment.bottomCenter,
      //     colors: [
      //       color2,
      //       color!,
      //     ],
      //     stops: [0.1, 0.8],
      //   ),
      // ),
      child: Text(
        icon,
        style: TextStyle(
          fontSize: 13,
          color: ThemeUtils().currentColorTheme.labelColorW,
        ),
      ),
    );

    Widget body = Row(
      children: [
        iconContainer,
        new SizedBox(
          child: new Container(
            // margin: EdgeInsets.fromLTRB(15, 5, 15, 5),
            color: ThemeUtils().currentColorTheme.contentBG,
            width: MediaQuery.of(context).size.width - 150,
            // height: 30,
            padding: EdgeInsets.fromLTRB(10, 0, 0, 0),
            alignment: Alignment.center,
            child: TextField(
              controller: controller,
              // keyboardType: TextInputType.number,
              maxLines: 1,
              decoration: InputDecoration(
                hintText: title,
                border: InputBorder.none,
                hintStyle: TextStyle(
                  fontSize: 12,
                  color: ThemeUtils().currentColorTheme.textGaryColor,
                ),
              ),
              style: TextStyle(
                fontSize: 12,
                color: ThemeUtils().currentColorTheme.textWithdrawColor,
              ),
            ),
          ),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
      ],
    );

    // body = Tapped(
    //   child: body,
    //   onTap: onTap,
    // );
    return Container(
      child: Container(
        padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
        // margin: EdgeInsets.fromLTRB(15, 5, 15, 5),
        color: ThemeUtils().currentColorTheme.contentBG,
        height: 30,
        child: body,
      ),
    );
  }
}
