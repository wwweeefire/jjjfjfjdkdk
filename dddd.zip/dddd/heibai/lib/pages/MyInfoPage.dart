// import 'dart:math';
import 'package:heibai/main.dart';
import 'package:flutter/foundation.dart';
// ignore_for_file: duplicate_import
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:heibai/Classes/model/config.dart';
import 'package:heibai/Classes/model/level.dart';
import 'package:heibai/generated/l10n.dart';
import 'package:heibai/net/api/Api.dart';
// import 'package:heibai/pages/kchart/utils/date_format_util.dart';
import 'package:heibai/util/DataUtils.dart';
import 'package:heibai/util/ThemeUtils.dart';
import 'package:heibai/constants/Constants.dart';
import 'package:heibai/constants/events/LogoutEvent.dart';
import 'package:heibai/constants/events/LoginEvent.dart';
import 'package:heibai/constants/events/ChangeThemeEvent.dart';
import 'package:heibai/pages/login/loginView.dart';
import 'package:heibai/pages/Views/TopIconTextButton.dart';
// import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:heibai/Classes/model/UserInfo.dart';
import 'package:heibai/pages/Withdrawal/WithdrawalPlatformPage.dart';
import 'package:heibai/pages/Recharge/RechargePage.dart';
import 'package:heibai/pages/Balancebao/Balancebao.dart';
import 'package:heibai/pages/Qrcode/QrCodeImagePage.dart';

import 'package:heibai/pages/MineinfoDataPage.dart';
import 'package:heibai/pages/billallPage.dart';
import 'package:heibai/pages/HelpCenterMePage.dart';

// import 'package:heibai/generated/l10n.dart';

// import 'package:fluttertoast/fluttertoast.dart';
import 'package:heibai/pages/seting/SetingViewPage.dart';
import 'package:tapped/tapped.dart';
import '../util/DataUtils.dart';
import '../Classes/model/UserInfo.dart';
import 'package:heibai/net/api/app_api.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:heibai/pages/Rechargeallrecord.dart';
import 'package:heibai/pages/PositionallRecordListView.dart';
import 'package:heibai/pages/Withdrawalsallrecord.dart';
import 'package:heibai/pages/Authentication.dart';
import 'package:heibai/pages/NoticelistPage.dart';

import 'package:heibai/pages/HelpCenterPage.dart';
// ignore: unused_import
import 'package:heibai/generated/l10n.dart';

class MyInfoPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return MyInfoPageState();
  }
}

class MyInfoPageState extends State<MyInfoPage> with RouteAware {
  Color themeColor = ThemeUtils().currentColorTheme.currentColorTheme;
  Color contentBG = ThemeUtils().currentColorTheme.contentBG;
  static const double IMAGE_ICON_WIDTH = 22.0;
  static const double IMAGE_ICON_HIGHT = 17.0;
  static const double ARROW_ICON_WIDTH = 16.0;

  UserInfo user;
//

  // var titles = [];
  // var btitles = [];
//
  var titles = [
    S.current.Rechargerecord,
    S.current.Withdrawalsrecord,
    S.current.Orderhistory
  ];
  var btitles = [
    // S.current.invitefriends,
    S.current.HelpCenter,
    S.current.aboutus
  ];

  var imagePaths = [
    "images/wode/czjl@3x.png",
    "images/wode/xtjl@3x.png",
    "images/wode/lsdd@3x.png",
  ];
  var bimagePaths = [
    "images/wode/yqhy@3x.png",
    "images/wode/bzzx@3x.png",
    "images/wode/gywm@3x.png",
  ];
  var icons = [];
  var bicons = [];
  var userAvatar;
  var userName;
  var levelimage;

  var path;
  var titleTextStyle = TextStyle(
      fontSize: 12.0, color: ThemeUtils().currentColorTheme.labelColorW);
  var rightArrowIcon = Image.asset(
    "images/wode/xyy@3x.png",
    width: 8,
    height: 14,
  );

  MyInfoPageState() {
    for (int i = 0; i < imagePaths.length; i++) {
      icons.add(getIconImage(imagePaths[i]));
    }
    for (int i = 0; i < bimagePaths.length; i++) {
      bicons.add(getIconImage(bimagePaths[i]));
    }
  }

  @override
  void initState() {
    super.initState();
    _showUserInfo();

    Constants.eventBus.on<LogoutEvent>().listen((event) {
      // 收到退出登录的消息，刷新个人信息显示
      _showUserInfo();
    });
    Constants.eventBus.on<LoginEvent>().listen((event) {
      // 收到登录的消息，重新获取个人信息
      getUserInfo();
    });
    Constants.eventBus.on<ChangeThemeEvent>().listen((event) {
      setState(() {
        themeColor = event.color;
      });
    });
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    routeObserver.subscribe(this, ModalRoute.of(context));
  }

  @override
  void dispose() {
    super.dispose();
    routeObserver.unsubscribe(this);
  }

  @override
  void didPush() {
    final route = ModalRoute.of(context).settings.name;
  }

  @override
  void didPopNext() {
    final route = ModalRoute.of(context).settings.name;
    bool isBack = ModalRoute.of(context).isCurrent;
    if (isBack) {
      // 限于从其他页面返回到当前页面时执行，首次进入当前页面不执行
      // 注：此方法在iOS手势返回时，不执行此处
      getUserInfo();
    }
  }

  @override
  void didPushNext() {
    final route = ModalRoute.of(context).settings.name;
  }

  @override
  void didPop() {
    final route = ModalRoute.of(context).settings.name;
  }

  _showUserInfo() {
    DataUtils.getUserInfo().then((UserInfo userInfo) {
      if (userInfo != null) {
        // print(userInfo.username);
        // print(userInfo.avatar);
        getUserInfo();
        setState(() {
          user = userInfo;
          userAvatar = userInfo.avatar;
          userName = user.getusername();
          path = user.getis_real();
          // levelimage = user.getlevel();
        });
      } else {
        setState(() {
          userAvatar = null;
          userName = null;
          user = UserInfo();
          path = null;
          // levelimage = null;
        });
      }
    });
  }

  Widget getIconImage(path) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(0.0, 0.0, 10.0, 0.0),
      child:
          Image.asset(path, width: IMAGE_ICON_WIDTH, height: IMAGE_ICON_HIGHT),
    );
  }

  @override
  Widget build(BuildContext context) {
    titles = [
      S.of(context).Rechargerecord,
      S.of(context).Withdrawalsrecord,
      S.of(context).Orderhistory
    ];
    btitles = [
      // S.of(context).invitefriends,
      S.of(context).HelpCenter,
      S.of(context).aboutus
    ];
    Config f = ConfigManager().config;
    if (f != null) {
      if (f.base.showInviteCode == 1) {
        btitles = [
          S.current.invitefriends,
          S.current.HelpCenter,
          S.current.aboutus
        ];
      }
    }

    Widget rightbtn = InkWell(

        // color: Colors.red,
        onTap: () async {
          var s = user.isReal;

          if (user.isReal == 0 || user.isReal == 3) {
            final result = await Navigator.of(context)
                .push(MaterialPageRoute(builder: (context) {
              return Authentication();
            }));
            // result为"refresh"代表登录成功
            if (result != null && result == "refresh") {
              // 刷新用户信息
              getUserInfo();
            }
          }
        },
        child: Container(
          alignment: Alignment.centerRight,

          // padding: const EdgeInsets.fromLTRB(0.0, 0.0, 10.0, 0.0),
          width: 88,
          height: 31,

          child: path == null
              ? Text('')
              : Image.asset(
                  path,
                  // width: 104,
                  // height: 31,
                ),
        ));
    Widget topButtons = Container(
      padding: EdgeInsets.zero,
      // alignment: Alignment.bottomCenter,

      // margin: EdgeInsets.symmetric(horizontal: 15, vertical: 0),
      width: double.infinity,

      // color: ThemeUtils().currentColorTheme.contentBG,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          TopIconTextButton(
            title: S.of(context).recharge,
            icon: Image.asset('images/wode/recharge@3x.png',
                width: 20, height: 17),
            onTap: () async {
              final result = await Navigator.of(context)
                  .push(MaterialPageRoute(builder: (context) {
                return RechargePage();
              }));
            },
          ),
          TopIconTextButton(
            title: S.of(context).withdraw,
            icon: Image.asset('images/wode/withdraw@3x.png',
                width: 20, height: 17),
            onTap: () async {
              final result = await Navigator.of(context)
                  .push(MaterialPageRoute(builder: (context) {
                return WithdrawalPlatformPage();
              }));
            },
          ),
          TopIconTextButton(
            title: S.of(context).YueBao,
            icon:
                Image.asset('images/wode/yuebao@3x.png', width: 20, height: 17),
            onTap: () async {
              final result = await Navigator.of(context)
                  .push(MaterialPageRoute(builder: (context) {
                return Balancebao();
              }));
            },
          ),
          TopIconTextButton(
            title: S.of(context).bill,
            icon: Image.asset('images/wode/bill@3x.png', width: 20, height: 17),
            onTap: () async {
              final result = await Navigator.of(context)
                  .push(MaterialPageRoute(builder: (context) {
                return billallPage();
              }));
            },
          ),
        ],
      ),
    );

    Widget centertext = Container(
      height: 18,
      alignment: Alignment.centerLeft,
      child: Text(
        userName == null ? "" : S.current.ZJE + ": " + user.balance.toString(),
        textAlign: TextAlign.left,
        style: TextStyle(
          color: ThemeUtils().currentColorTheme.integralLabelTextColor,
          fontSize: 13,
        ),
      ),
    );

    double topwith = 130;
    if (userName != null) {
      double nowwith = StandardTextStyle.boundingTextSize(
                  userName,
                  TextStyle(
                      color: ThemeUtils().currentColorTheme.nameLabelTextColor,
                      fontSize: 18))
              .width +
          5;
      if (nowwith > topwith) {
        topwith = 130;
      } else {
        topwith = nowwith;
      }
    }
    Widget toptext = Row(
      children: [
        Container(
          height: 25,
          width: topwith,
          alignment: Alignment.centerLeft,
          child: Text(
            userName == null ? S.current.Clickontheavatartologin : userName,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
                color: ThemeUtils().currentColorTheme.nameLabelTextColor,
                fontSize: 18),
            textAlign: TextAlign.left,
          ),
        ),
        Container(
          alignment: Alignment.centerLeft,

          // padding: const EdgeInsets.fromLTRB(0.0, 0.0, 10.0, 0.0),
          width: 50,
          height: 30,

          child: levelimage == null
              ? Text('')
              : CachedNetworkImage(
                  imageUrl: ConfigManager().imageHost + levelimage,
                  fit: BoxFit.cover,
                  placeholder: (context, url) => Icon(Icons.error),
                  errorWidget: (context, url, error) => Icon(Icons.error),
                ),
        )
      ],
    );
    Widget bottomtext = Container(
      height: 19,
      alignment: Alignment.centerLeft,
      child: Text(
        userName == null
            ? ""
            : "ID:" +
                user.id.toString() +
                ' ' +
                S.current.Reputationpoints +
                user.score.toString(),
        textAlign: TextAlign.left,
        style: TextStyle(
          color: ThemeUtils().currentColorTheme.integralLabelTextColor,
          fontSize: 13,
        ),
      ),
    );
    Widget textView = Container(
      alignment: Alignment.centerLeft,
      // color: Colors.red,
      height: 90 + MediaQuery.of(context).padding.top,
      width: 200,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          kIsWeb == true
              ? SizedBox(
                  height: 10,
                )
              : SizedBox(
                  height: 30,
                ),
          toptext,
          SizedBox(
            height: 4,
          ),
          centertext,
          SizedBox(
            height: 4,
          ),
          bottomtext
        ],
      ),
    );

    Widget avatar = Container(
      height: 90 + MediaQuery.of(context).padding.top,
      margin: EdgeInsets.only(left: 15),
      padding: EdgeInsets.zero,
      alignment: Alignment.centerLeft,
      // color: contentBG,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          Tapped(
            child: userAvatar == null
                ? Container()
                : Container(
                    height: 72,
                    width: 72,
                    margin: EdgeInsets.only(bottom: 12),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(44),
                      // color: Colors.orange,
                      border: Border.all(
                        color: ThemeUtils().currentColorTheme.labelColorW,
                        width: 1,
                      ),
                    ),
                    child: ClipOval(
                      child: CachedNetworkImage(
                        imageUrl: ConfigManager().imageHost + userAvatar,
                        fit: BoxFit.cover,
                        placeholder: (context, url) => Image.asset(
                          "images/wode/yonghu@3x.png",
                          width: 72,
                          height: 72,
                        ),
                        errorWidget: (context, url, error) => Image.asset(
                          "images/wode/yonghu@3x.png",
                          width: 72,
                          height: 72,
                        ),
                      ),
                    ),
                  ),
            onTap: () async {
              final result = await Navigator.of(context)
                  .push(MaterialPageRoute(builder: (context) {
                return MineinfoDataPage();
              }));
            },
          ),
          Container(width: 10),
          textView,
          Expanded(
            child: Text(''), // 中间用Expanded控件
          ),
          Container(
            alignment: Alignment.centerRight,
            // color: Colors.red,
            child: rightbtn,
          )
        ],
      ),
    );

    var listView = ListView.builder(
      shrinkWrap: true, //解决无限高度问题
      physics: new NeverScrollableScrollPhysics(), //禁用滑动事件
      itemCount: titles.length * 2,
      itemBuilder: (context, i) => renderRow(i, false),
    );
    var blistView = ListView.builder(
      shrinkWrap: true, //解决无限高度问题
      physics: new NeverScrollableScrollPhysics(), //禁用滑动事件
      itemCount: btitles.length * 2,
      itemBuilder: (context, i) => renderRow(i, true),
    );

    Widget body = ListView(
      physics: BouncingScrollPhysics(
        parent: AlwaysScrollableScrollPhysics(),
      ),
      children: <Widget>[
        Container(height: 20),
        Container(
            // color: Colors.black,
            child: Column(
          children: <Widget>[
            // SizedBox(
            //   height: ,
            // ),
            avatar,
            Container(
              margin: EdgeInsets.symmetric(horizontal: 15, vertical: 0),
              decoration: BoxDecoration(
                color: contentBG,
                border: Border.all(color: contentBG),
                borderRadius: BorderRadius.circular(8),
              ),
              child: topButtons,
            )
          ],
        )),
        // 头像与关注
        // Stack(
        //   // alignment: Alignment.centerLeft,
        //   children: <Widget>[avatar, topButtons],
        // ),
        Container(
          color: ThemeUtils().currentColorTheme.defaultColor,
          child: Column(
            children: <Widget>[
              Container(
                padding: EdgeInsets.zero,
                margin: EdgeInsets.symmetric(horizontal: 15, vertical: 0),
                width: double.infinity,
                color: ThemeUtils().currentColorTheme.contentBG,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[],
                ),
              ),
              Container(
                height: 20,
                margin: EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  border: Border(
                    bottom: BorderSide(
                      color: ThemeUtils()
                          .currentColorTheme
                          .labelColorW
                          .withOpacity(0.1),
                    ),
                  ),
                ),
              ),
              listView,
              Container(
                height: 20,
                margin: EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  border: Border(
                    bottom: BorderSide(
                      color: ThemeUtils()
                          .currentColorTheme
                          .labelColorW
                          .withOpacity(0.1),
                    ),
                  ),
                ),
              ),
              blistView,
              Container(
                height: 10,
                margin: EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  border: Border(
                    bottom: BorderSide(
                      color: ThemeUtils()
                          .currentColorTheme
                          .labelColorW
                          .withOpacity(0.1),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
    Widget allviebodyView = Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          colors: ThemeUtils().currentColorTheme.kminetopColor,
        ),
      ),
      child: Stack(alignment: Alignment.topCenter, children: <Widget>[
        Container(
          margin: EdgeInsets.only(top: 240),
          height: double.infinity,
          width: double.infinity,
          color: themeColor,
        ),
        body,
      ]),
    );

    Widget allviebody = Scaffold(
      backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
      body: allviebodyView,
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
        ),
        // 如果没有设置这项， 二级页面 会默认是返回箭头  ， 有侧边栏的页面默认有图标（用来打开侧边栏）
        // automaticallyImplyLeading: true,
        // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
        // title: Text("出金"),
        centerTitle: true,
        actions: <Widget>[
          IconButton(
              icon: Image.asset(
                "images/wode/item_ sound@3x.png",
                width: 20,
                height: 20,
              ),

              // tooltip: 'Add Alarm',
              onPressed: () {
                final result = Navigator.of(context)
                    .push(MaterialPageRoute(builder: (context) {
                  return NoticelistPage();
                }));
                // do nothing
              }),
          IconButton(
              icon: Image.asset(
                "images/wode/item_seting@3x.png",
                width: 20,
                height: 20,
              ),
              // tooltip: 'Add Alarm',
              onPressed: () {
                final result = Navigator.of(context)
                    .push(MaterialPageRoute(builder: (context) {
                  return SetingViewPage();
                }));
                // do nothing
              }),
        ], // 标题是否在居中

        elevation: 0, // 导航栏Z轴的高度，默认是1  默认就是有高度 阴影的
        backgroundColor: ThemeUtils()
            .currentColorTheme
            .kminenavColor, // 导航栏的颜色  默认是 ThemeData 的颜色
//         flexibleSpace: FlexibleSpaceBar(title: Text("你号"),),//这个堆叠在工具栏上面  一般 appbar不用  主要用在 SliverAppBar上
//          brightness: Brightness.light, //状态栏的深度 有白色和黑色两种主题
//          titleSpacing: 10,//flexibleSpace 和 title 的距离  默认是重合的
//          toolbarOpacity: 0.5,// 导航栏透明度 默认是1 ，不包括flexibleSpace
//          bottomOpacity: 0.5,
      ),
    );
    return allviebody;
  }

  // 获取用户信息
  getUserInfo() async {
    try {
      ResultData resultData =
          await AppApi.getInstance().get_member_info(context, false);
      if (resultData.isSuccess()) {
        DataUtils.saveUserInfo(resultData.dataJson);

        UserInfo userInfo = userInfoFromJson(resultData.dataJson);
        user = userInfo;

        ConfigManager().user = user;

        // ConfigManager.
        setState(() {
          userAvatar = user.avatar;
          userName = user.getusername();
          user = user;
          path = user.getis_real();
          levelimage = user.getlevel();
        });
      } else {
        // setState(() {
        //   userAvatar = null;
        //   userName = null;
        //   user = UserInfo();
        //   path = null;
        //   levelimage = null;
        // });
      }
    } catch (e) {
      // setState(() {
      //   userAvatar = null;
      //   userName = null;
      //   user = UserInfo();
      //   path = null;
      //   levelimage = null;
      // });
    }
  }

  _login() async {
    // 打开登录页并处理登录成功的回调
    final result =
        await Navigator.of(context).push(MaterialPageRoute(builder: (context) {
      return LoginView();
    }));
    // result为"refresh"代表登录成功
    if (result != null && result == "refresh") {
      // 刷新用户信息
      getUserInfo();
      // 通知动弹页面刷新
      Constants.eventBus.fire(LoginEvent());
    }
    // navigator_util()

    // NavigatorUtil.goToLoginRemovePage(context);
  }

  _showUserInfoDetail() {}

  renderRow(i, bool isb) {
    --i;
    if (i.isOdd) {
      return Divider(
        height: 1.0,
      );
    }
    i = i ~/ 2;
    Widget nicon;
    String title;
    if (isb == true) {
      nicon = bicons[i];
      title = btitles[i];
    } else {
      nicon = icons[i];
      title = titles[i];
    }

    // }

    var listItemContent = Container(
      color: contentBG,
      padding: const EdgeInsets.fromLTRB(10, 17.0, 10.0, 17.0),
      margin: EdgeInsets.symmetric(horizontal: 15, vertical: 0),
      child: Row(
        children: <Widget>[
          nicon,
          Expanded(
              child: Text(
            title,
            style: titleTextStyle,
          )),
          rightArrowIcon
        ],
      ),
    );

    return InkWell(
      child: listItemContent,
      onTap: () {
        _handleListItemClick(i, isb);
//        Navigator
//            .of(context)
//            .push(MaterialPageRoute(builder: (context) => CommonWebPage(title: "Test", url: "https://my.oschina.net/u/815261/blog")));
      },
    );
  }

  _showLoginDialog() {
    showDialog(
        context: context,
        builder: (BuildContext ctx) {
          return AlertDialog(
            title: Text('提示'),
            content: Text('没有登录，现在去登录吗？'),
            actions: <Widget>[
              FlatButton(
                child: Text(
                  '取消',
                  style: TextStyle(color: Colors.red),
                ),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
              FlatButton(
                child: Text(
                  '确定',
                  style: TextStyle(color: Colors.blue),
                ),
                onPressed: () {
                  Navigator.of(context).pop();

                  //  NavigatorUtil.goToLoginRemovePage(context);
                  _login();
                },
              )
            ],
          );
        });
  }

  _handleListItemClick(int i, bool isb) async {
    // var titles = ["入金记录", "出金记录", "历史订单"];
    // var btitles = ["邀请好友", "帮助中心", "关于我们"];

    if (isb == true) {
      // nicon = bicons[i];
      // title = btitles[i];

      Config f = ConfigManager().config;
      if (f.base.showInviteCode == 1) {
        if (i == 0) {
          final result = await Navigator.of(context)
              .push(MaterialPageRoute(builder: (context) {
            return QrCodeImagePage();
          }));
        } else if (i == 2) {
          final result = await Navigator.of(context)
              .push(MaterialPageRoute(builder: (context) {
            return HelpCenterMePage();
          }));
        } else {
          final result = await Navigator.of(context)
              .push(MaterialPageRoute(builder: (context) {
            return HelpCenterPage();
          }));
        }
      } else {
        if (i == 1) {
          final result = await Navigator.of(context)
              .push(MaterialPageRoute(builder: (context) {
            return HelpCenterMePage();
          }));
        } else if (i == 0) {
          final result =
              Navigator.of(context).push(MaterialPageRoute(builder: (context) {
            return HelpCenterPage();
          }));
        }
      }
    } else {
      // nicon = icons[i];
      // title = titles[i];
      if (i == 0) {
        final result = await Navigator.of(context)
            .push(MaterialPageRoute(builder: (context) {
          return Rechargeallrecord();
        }));
      } else if (i == 2) {
        final result = await Navigator.of(context)
            .push(MaterialPageRoute(builder: (context) {
          return PositionallRecordListView();
        }));
      } else {
        final result = await Navigator.of(context)
            .push(MaterialPageRoute(builder: (context) {
          return Withdrawalsallrecord();
        }));
      }
    }
    // DataUtils.isLogin().then((isLogin) {
    //   if (!isLogin) {
    //     // 未登录
    //     _showLoginDialog();
    //   } else {
  }
}
