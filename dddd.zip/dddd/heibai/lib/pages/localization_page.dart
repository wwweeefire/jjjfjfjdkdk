import 'package:flutter/material.dart';
import 'package:heibai/generated/l10n.dart';
import 'package:heibai/util/DataUtils.dart';
import 'package:heibai/util/ThemeUtils.dart';
import 'package:heibai/Classes/model/config.dart'; //咨询

import 'package:heibai/pages/Withdrawal/Withdmethodadd.dart';
import 'package:tapped/tapped.dart';
import 'package:heibai/main.dart';
import 'package:heibai/routers/routes.dart';
import 'package:heibai/routers/navigator_util.dart';

var titleTextStyle = TextStyle(
    fontSize: 12.0, color: ThemeUtils().currentColorTheme.labelColorG);
var rightArrowIcon = Image.asset(
  "images/wode/xyy@3x.png",
  width: 8,
  height: 14,
);

class LocalizetionPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return LocalizetionPageState();
  }
}

class LocalizetionPageState extends State<LocalizetionPage> {
  Config f = ConfigManager().config;
  var lang = ConfigManager().config.lang;

  String userInfo = DataUtils.preferences.getString(DataUtils.SPchangeLanguage);
  var titleTextStyle = TextStyle(
      fontSize: 12.0, color: ThemeUtils().currentColorTheme.labelColorW);
  Widget build(BuildContext context) {
    var listView = ListView.builder(
      shrinkWrap: true, //解决无限高度问题
      physics: new NeverScrollableScrollPhysics(), //禁用滑动事件
      itemCount: lang.length,
      itemBuilder: (context, i) => renderRow(i),
    );

    Widget allviebody = Scaffold(
      backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
      body: listView,
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
        ),
        // 如果没有设置这项， 二级页面 会默认是返回箭头  ， 有侧边栏的页面默认有图标（用来打开侧边栏）
        // automaticallyImplyLeading: true,
        // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
        title: Text(
          S.of(context).changeLanguage,
        ),
        centerTitle: true,
        //  actions: <Widget>[
        //     IconButton(
        //         icon: Icon(Icons.add_alarm),
        //         tooltip: 'Add Alarm',
        //         onPressed: () {
        //           // do nothing
        //         })
        //   ],   // 标题是否在居中

        elevation: 0, // 导航栏Z轴的高度，默认是1  默认就是有高度 阴影的
        backgroundColor: ThemeUtils()
            .currentColorTheme
            .contentBG, // 导航栏的颜色  默认是 ThemeData 的颜色
//         flexibleSpace: FlexibleSpaceBar(title: Text("你号"),),//这个堆叠在工具栏上面  一般 appbar不用  主要用在 SliverAppBar上
//          brightness: Brightness.light, //状态栏的深度 有白色和黑色两种主题
//          titleSpacing: 10,//flexibleSpace 和 title 的距离  默认是重合的
//          toolbarOpacity: 0.5,// 导航栏透明度 默认是1 ，不包括flexibleSpace
//          bottomOpacity: 0.5,
      ),
    );
    return allviebody;
  }

  renderRow(i) {
    Lang model = lang[i];
    Widget item;
    if (model.code == "zh_cn") {
      item = itemView(
          title: '中文简体',
          isColor: userInfo == "zh" ? "1" : "0",
          onTap: () {
            // final result = Navigator.of(context)
            // .push(MaterialPageRoute(builder: (context) {
            // return Withdmethodadd();
            S.load(Locale('zh', 'CN'));
            DataUtils.changeLanguage("zh");
            ConfigManager().code = "zh";
            MyAppState.setting.changeLocale(Locale('zh', 'CN'));

            NavigatorUtil.goToHomeRemovePage(context);
            // }));
          });
    }

    if (model.code == "en") {
      item = itemView(
        title: 'English',
        isColor: userInfo == "en" ? "1" : "0",
        onTap: () {
          // final result = Navigator.of(context)
          // .push(MaterialPageRoute(builder: (context) {
          // return Withdmethodadd();
          DataUtils.changeLanguage("en");
          S.load(Locale('en', 'US'));

          ConfigManager().code = "en";

          MyAppState.setting.changeLocale(Locale('en', 'US'));
          NavigatorUtil.goToHomeRemovePage(context);
          // }));
        },
      );
    }
    if (model.code == "zh_hk") {
      item = itemView(
        title: '中文繁體',
        isColor: userInfo == "zh_hk" ? "1" : "0",
        onTap: () {
          // final result = Navigator.of(context)
          // .push(MaterialPageRoute(builder: (context) {
          // return Withdmethodadd();

          DataUtils.changeLanguage("zh_hk");
          ConfigManager().code = "zh_hk";
          S.load(Locale('zh', 'TW'));
          MyAppState.setting.changeLocale(Locale('zh', 'TW'));
          NavigatorUtil.goToHomeRemovePage(context);
          // }));
        },
      );
    }
    if (model.code == "ja_JP") {
      item = itemView(
        title: '日本語',
        isColor: userInfo == "ja_JP" ? "1" : "0",
        onTap: () {
          // final result = Navigator.of(context)
          // .push(MaterialPageRoute(builder: (context) {
          // return Withdmethodadd();

          DataUtils.changeLanguage("ja_JP");
          ConfigManager().code = "ja_JP";
          S.load(Locale('ja', 'JP'));
          MyAppState.setting.changeLocale(Locale('ja', 'JP'));
          NavigatorUtil.goToHomeRemovePage(context);
          // }));
        },
      );
    }
    if (model.code == "vi_VN") {
      item = itemView(
        title: 'Tiếng Việt',
        isColor: userInfo == "vi_VN" ? "1" : "0",
        onTap: () {
          // final result = Navigator.of(context)
          // .push(MaterialPageRoute(builder: (context) {
          // return Withdmethodadd();

          DataUtils.changeLanguage("vi_VN");
          ConfigManager().code = "vi_VN";
          S.load(Locale('vi', 'VN'));
          MyAppState.setting.changeLocale(Locale('vi', 'VN'));
          NavigatorUtil.goToHomeRemovePage(context);
          // }));
        },
      );
    }

    return Column(children: <Widget>[
      SizedBox(
        height: 10,
      ),
      item,
    ]);
  }
}

class itemView extends StatelessWidget {
  final Function onTap;

  final String title;
  final String des;
  final String isColor;

  const itemView({
    Key key,
    this.onTap,
    this.title,
    this.des,
    this.isColor,
  }) : super(key: key);
  Widget build(BuildContext context) {
    Widget text;

    if (isColor == "1") {
      text = Container(
          child: Image.asset(
        "images/wode/xz@3x.png",
        width: 13,
        height: 13,
      ));
    } else {
      text = Container(
          child: Image.asset(
        "images/wode/wxz@3x.png",
        width: 13,
        height: 13,
      ));
    }

    Widget listItemContent = Container(
      color: ThemeUtils().currentColorTheme.contentBG,
      padding: const EdgeInsets.fromLTRB(10, 17.0, 10.0, 17.0),
      margin: EdgeInsets.symmetric(horizontal: 15, vertical: 0),
      child: Row(
        children: <Widget>[
          Container(
              child: Text(
            title,
            style: titleTextStyle,
          )),
          Expanded(
            child: Text(''), // 中间用Expanded控件
          ),
          text,
          Container(
            width: 10,
          ),
          rightArrowIcon
        ],
      ),
    );

    listItemContent = Tapped(
      child: listItemContent,
      onTap: onTap,
    );
    return listItemContent;
  }
}
