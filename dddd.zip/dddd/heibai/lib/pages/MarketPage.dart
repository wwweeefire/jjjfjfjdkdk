import 'package:flutter/material.dart';
import 'package:heibai/generated/l10n.dart';
// TODO Implement this library.
import 'package:heibai/util/DataUtils.dart';
import 'package:heibai/util/ThemeUtils.dart';
// import 'package:flutter_search_bars/flutter_search_bars.dart';
import 'package:heibai/pages/Views/JcSerch.dart';
import 'package:heibai/net/api/Api.dart';
import 'package:heibai/net/api/app_api.dart';
// import '../Classes/model/BannerModel.dart';
import '../Classes/model/MCategory.dart';
import 'package:heibai/pages/MarketPageListView.dart';
import 'package:heibai/pages/MarketzPageListView.dart';
import 'package:heibai/pages/DeviceSearchPage.dart';

class MarketPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return MarketPageState();
  }
}

class MarketPageState extends State<MarketPage> {
  Widget build(BuildContext context) {
    Widget allviebody = Scaffold(
      backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
      body: MarkeForTabBarView(),
      appBar: AppBar(
        // 如果没有设置这项， 二级页面 会默认是返回箭头  ， 有侧边栏的页面默认有图标（用来打开侧边栏）
        // automaticallyImplyLeading: true,
        // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
        title: Container(
          width: 188,

          ///这里只是用于显示的搜索框不用做输入
          ///参数[heroTag]用于页面过渡动画tag
          ///参数clickCallBack为当前搜索框点击事件回调
          child: SearchStaticBar(
            heroTag: "searchStatidBar",
            hint: S.of(context).SSBZGPJJ,
            clickCallBack: () async {
              final result = await Navigator.of(context)
                  .push(MaterialPageRoute(builder: (context) {
                return DeviceSearchPage(
                    // title: pro.name,
                    // model: pro,
                    );
              }));
              // NavigatorUtils.pushPage(context, TestPage2());
            },
          ),
        ),

        // title: Text(S.current.tab_market),
        centerTitle: true,
        // actions: <Widget>[
        //   IconButton(
        //       icon: Icon(Icons.add_alarm),
        //       tooltip: 'Add Alarm',
        //       onPressed: () {
        //         final result = Navigator.of(context)
        //             .push(MaterialPageRoute(builder: (context) {
        //           return SetingViewPage();
        //         }));
        //         // do nothing
        //       })
        // ], // 标题是否在居中

        elevation: 0, // 导航栏Z轴的高度，默认是1  默认就是有高度 阴影的
        backgroundColor: ThemeUtils()
            .currentColorTheme
            .contentBG, // 导航栏的颜色  默认是 ThemeData 的颜色
//         flexibleSpace: FlexibleSpaceBar(title: Text("你号"),),//这个堆叠在工具栏上面  一般 appbar不用  主要用在 SliverAppBar上
//          brightness: Brightness.light, //状态栏的深度 有白色和黑色两种主题
//          titleSpacing: 10,//flexibleSpace 和 title 的距离  默认是重合的
//          toolbarOpacity: 0.5,// 导航栏透明度 默认是1 ，不包括flexibleSpace
//          bottomOpacity: 0.5,
      ),
    );
    return allviebody;
  }
}

class MarkeForTabBarView extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return MarkeForTabBarDemo();
  }
}

class MarkeForTabBarDemo extends State with SingleTickerProviderStateMixin {
  MCategory listmodel;
  bool loading = true;
  List<Tab> _tabs = <Tab>[];
  var _tabController;

  int _tabIndex = 0;
  var _body;
  var pages;

  @override
  void initState() {
    // _tabController = TabController(vsync: this, length: _tabs.length);
    super.initState();
    getBanner();
  }

  getBanner() async {
    try {
      ResultData resultData =
          await AppApi.getInstance().get_product_category(context, false);
      if (resultData.isSuccess()) {
        MCategory model = mCategoryFromJson(resultData.dataJson);
        // BannerModel model = homeListModelFromJson(resultData.dataJson);
        final List<Tab> nowtabs = [];
        ListElement one = ListElement(id: -1, name: S.of(context).ZX);
        var now = new Tab(text: one.name);
        nowtabs.add(now);
        for (ListElement item in model.list) {
          var name = item.name;
          var nowtab = new Tab(text: name);
          nowtabs.add(nowtab);
        }
        listmodel = model;
        listmodel.list.insert(0, one);
        // ConfigManager.
        setState(() {
          _tabs = nowtabs;
          _tabController = TabController(vsync: this, length: _tabs.length);
          loading = false;
        });
      } else {
        // user = UserInfo();
      }
    } catch (e) {
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {}

    if (loading == false) {
      pages = [];
      pages = Iterable.generate(_tabs.length).toList().map((index) {
        if (index == 0) {
          return Container(
              child: MarketzPageListView(
            model: listmodel,
            index: index,
          ));
        } else {
          return Container(
              child: MarketPageListView(
            model: listmodel,
            index: index,
          ));
        }
      }).toList();

      _body = IndexedStack(
        children: pages,
        index: _tabIndex,
      );
    }

    return _tabs.length == 0
        ? Center()
        : Scaffold(
            // drawer: _drawer(context),
            body: _body,
            appBar: TabBar(
              isScrollable: true,

              labelColor:
                  ThemeUtils().currentColorTheme.labelColorY, // 选中的Widget颜色
              indicatorColor: ThemeUtils().currentColorTheme.labelColorY,
              labelStyle: new TextStyle(
                  fontSize: 15.0), // 必须设置，设置 color 没用的，因为 labelColor 已经设置了
              unselectedLabelColor: ThemeUtils().currentColorTheme.labelColorW,
              unselectedLabelStyle: new TextStyle(
                  fontSize: 15.0), // 设置 color 没用的，因为unselectedLabelColor已经设置了
              controller: _tabController,
              // tabbar 必须设置 controller 否则报错
              indicatorSize: TabBarIndicatorSize.label,

              // 有 tab 和 label 两种
              tabs: _tabs,
              // currentIndex: _tabIndex,
              onTap: (index) {
                setState(() {
                  _tabIndex = index;
                });
              },
            ),
//          elevation: 0.1, // 导航栏Z轴的高度，默认是1  默认就是有高度 阴影的
            backgroundColor: ThemeUtils()
                .currentColorTheme
                .contentBG, // 导航栏的颜色  默认是 ThemeData 的颜色
//         flexibleSpace: FlexibleSpaceBar(title: Text("你号"),),//这个堆叠在工具栏上面
//          brightness: Brightness.light, //状态栏的深度 有白色和黑色两种主题
//          titleSpacing: 10,//flexibleSpace 和 title 的距离  默认是重合的
//          toolbarOpacity: 0.5,// 导航栏透明度 默认是1 ，不包括flexibleSpace
//          bottomOpacity: 0.5,
          );
    // TODO: implement build
  }
}
