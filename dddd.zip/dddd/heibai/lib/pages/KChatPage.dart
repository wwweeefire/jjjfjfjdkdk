import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:heibai/Classes/JCHub/JCHub.dart';
import 'package:heibai/Classes/model/config.dart';
import 'package:heibai/constants/events/changebuyEvent.dart';
import 'package:heibai/generated/l10n.dart';
import 'package:heibai/util/ThemeUtils.dart';
import 'kchart/flutter_kchart.dart';
import 'dart:convert';
import 'kchart/chart_style.dart';
import 'dart:io';
import 'package:heibai/pages/kchart/chart_style.dart';
import 'dart:async';
import 'package:heibai/pages/klinevc/kline_vertical_widget.dart';
import 'package:heibai/pages/klinevc/kline_data_controller.dart';
import 'package:heibai/net/api/Api.dart';
import 'package:heibai/net/api/app_api.dart';
import '../Classes/model/homeListModel.dart';
import '../Classes/model/productoption.dart';
import 'package:heibai/constants/events/LoginEvent.dart';
import 'package:heibai/constants/events/changeModel.dart';
import 'package:heibai/constants/events/changeNumber.dart';
import 'package:heibai/pages/login/loginView.dart';
import 'package:heibai/constants/Constants.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
// import 'package:flip_';
// import 'package:flip_panel/flip_panel.dart';
import '../Classes/model/NProduct.dart';
import 'package:heibai/pages/klinevc/flip_panel.dart';
import 'package:heibai/routers/Application.dart';
import 'package:heibai/routers/routes.dart';
import 'package:heibai/routers/navigator_util.dart';
import 'package:heibai/pages/web_socket_utility.dart';
import 'dart:math';
// import 'package:heibai/pages/klinevc/slide_direction.dart';
// import 'package:heibai/pages/klinevc/slide_countdown_clock.dart';

class KChatPage extends StatefulWidget {
  final String title;
  final Product model;
  const KChatPage({Key key, this.title, this.model}) : super(key: key);

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  @override
  KChatPageState createState() => KChatPageState(model: model);
}

class KChatPageState extends State<KChatPage> with TickerProviderStateMixin {
  List<KLineEntity> datas = [];
  bool showLoading = true;
  Product model;
  bool optional = false;
  Timer timer;
  KLineDataController dataController = KLineDataController();
  String path = "images/tabaricon/iocn_ccjl_no@3x.png";

  KChatPageState({Key key, this.model});
  // Function onMessage; // 接收消息回调
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getData(dataController.periodModel.period);
    get_product_optional();

    getdata();
    settimer();

    dataController.changePeriodClick = (KLinePeriodModel model) {
      getData(model.period);
    };
  }

  @override
  void dispose() {
    super.dispose();
    WebSocketUtility().removeListener(onMessage);
    timer.cancel();
  }

  void settimer() {
    final Duration duration = Duration(seconds: 15);

    timer = Timer.periodic(duration, (timer) {
      getddddData(dataController.periodModel.period);
    });
  }

  getdata() async {
    // WebSocketUtility().addListener((data) {
    //   print(data);
    // });

    WebSocketUtility().addListener(onMessage);
    // bool isf = true;
  }

  void onMessage(data) {
    NProduct ss = nProductFromJson(data);

    // print(data);
    chagemodel(ss);
  }

  _randomBit(int len, double intge) {
    String b = "1";
    for (int i = 0; i < len; i++) {
      b = b + "0";
    }
    int s = (intge * 2 * double.parse(b)).toInt();
    int u = (Random().nextInt(s));
    return (u - u / 2) / double.parse(b);
  }

  void chagemodel(NProduct smodel) {
    if (smodel.code == model.code) {
      Product oldmodel = model;
      Product newmodel;

      if (smodel.price == oldmodel.price) {
        String wave = oldmodel.wave.toString();
        List<String> wavelist = wave.split(".");
        int size = wavelist.last.length;
        double b = _randomBit(size, oldmodel.wave);

        String price = oldmodel.price.toString();

        List<String> s = price.split(".");
        int a = s.last.length;
        String rstr = b.toStringAsFixed(a);
        double r = double.parse(rstr);
        double newprices = model.price + r;

        String newpricesstr = newprices.toStringAsFixed(a);
        double newprice = double.parse(newpricesstr);
        String name = oldmodel.name;
        // print("kchatmagolaname" + "== $name" + "price =" + "$price");

        // print("kchatmagename" + "== $name" + "price =" + "$newprice");
        newmodel = Product(
          id: model.id,
          code: smodel.code,
          open: smodel.open,
          name: oldmodel.name,
          wave: oldmodel.wave,
          openTime: oldmodel.openTime,
          weekendTrading: oldmodel.weekendTrading,
          price: newprice,
          low: smodel.low,
          high: smodel.high,
          vol: smodel.vol,
          change: oldmodel.change + r / oldmodel.open,
        );
      } else {
        newmodel = Product(
          id: model.id,
          code: smodel.code,
          open: smodel.open,
          name: oldmodel.name,
          wave: oldmodel.wave,
          openTime: oldmodel.openTime,
          weekendTrading: oldmodel.weekendTrading,
          price: smodel.price,
          low: smodel.low,
          high: smodel.high,
          vol: smodel.vol,
          change: smodel.change,
        );
      }
      Constants.eventBus.fire(changeModel(newmodel));
      setStateIfMounted(() {
        model = newmodel;

        // datas = [];
        // showLoading = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final mediaQueryData = MediaQuery.of(context);
    YYDialog.init(context);

// 2.获取宽度和高度
    final screenWidth = mediaQueryData.size.width;
    final screenHeight = mediaQueryData.size.height;

    final statusBarHeight = mediaQueryData.padding.top;
// 有刘海的屏幕:34 没有刘海的屏幕0
    double bottomHeight = 10.0;

    if (!kIsWeb) {
      if (Platform.isIOS) {
        bottomHeight = mediaQueryData.padding.bottom;
      }
    }

    Widget topIncome = Container(
      alignment: Alignment.centerRight,
      child: RichText(
          text: TextSpan(
        text: S.current.DZG,
        style: TextStyle(
            color: ThemeUtils().currentColorTheme.textGaryColor, fontSize: 12),
        children: [
          TextSpan(
            text: '   ',
            style: TextStyle(color: Colors.red, fontSize: 12),
          ),
          TextSpan(
            text: model.high.toString(),
            style: TextStyle(
                color: ThemeUtils().currentColorTheme.labelColorW,
                fontSize: 12),
          )
        ],
      )),
    );

    Widget bdaIncome = Container(
      alignment: Alignment.centerRight,
      child: RichText(
          text: TextSpan(
        text: S.current.DZD,
        style: TextStyle(
            color: ThemeUtils().currentColorTheme.textGaryColor, fontSize: 12),
        children: [
          TextSpan(
            text: '   ',
            style: TextStyle(color: Colors.red, fontSize: 12),
          ),
          TextSpan(
            text: model.low.toString(),
            style: TextStyle(
                color: ThemeUtils().currentColorTheme.labelColorW,
                fontSize: 12),
          )
        ],
      )),
    );

    Widget lowIncome = Container(
      alignment: Alignment.centerRight,
      child: RichText(
          text: TextSpan(
        text: S.current.ESCJL,
        style: TextStyle(
            color: ThemeUtils().currentColorTheme.textGaryColor, fontSize: 12),
        children: [
          TextSpan(
            text: model.vol.toString(),
            style: TextStyle(color: Colors.red, fontSize: 12),
          ),
          TextSpan(
            text: '',
            style: TextStyle(
                color: ThemeUtils().currentColorTheme.labelColorW,
                fontSize: 12),
          )
        ],
      )),
    );

    Widget righttextView = Container(
      alignment: Alignment.centerRight,
      // color: Colors.red,
      padding: EdgeInsets.only(right: 10),
      width: screenWidth / 2 + 50,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          SizedBox(
            height: 14,
          ),
          topIncome,
          SizedBox(
            height: 4,
          ),
          bdaIncome,
          SizedBox(
            height: 4,
          ),
          lowIncome,
        ],
      ),
    );
    Widget priceText = Container(
        alignment: Alignment.centerLeft,
        padding: EdgeInsets.only(left: 10),
        child: Text(
          model.price.toString(),
          style: TextStyle(color: Colors.red, fontSize: 18),
        ));

    Widget pricenumberText = Container(
        alignment: Alignment.centerLeft,
        padding: EdgeInsets.only(left: 12),
        child: Text(
          model.change.toStringAsFixed(2) + '%',
          style: TextStyle(
              color: model.change > 0
                  ? ThemeUtils().currentColorTheme.numberRedColor
                  : ThemeUtils().currentColorTheme.textgreenColor,
              fontSize: 12),
        ));

    Widget lefttextView = Container(
      alignment: Alignment.centerLeft,
      // color: ThemeUtils().currentColorTheme.labelColorW,
      width: screenWidth / 2 - 50,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          SizedBox(
            height: 14,
          ),
          priceText,
          SizedBox(
            height: 2,
          ),
          pricenumberText,
        ],
      ),
    );
    Widget topviw = Container(
      padding: EdgeInsets.zero,
      // color: ThemeUtils().currentColorTheme.contentBG,
      height: 80,
      width: double.infinity,

      // color: ThemeUtils().currentColorTheme.contentBG,
      child: Row(
        // mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          lefttextView,
          Expanded(
            child: Text(''),
          ),
          righttextView,
        ],
      ),
    );

    var PositionBtn = Builder(builder: (ctx) {
      return CommonButton(
          text: S.current.CHIC,
          color: ThemeUtils().currentColorTheme.labelColorY,
          onTap: () {
            // 关闭键盘

            // 发送给webview，让webview登录后再取回token
            // autoLogin(username, password);
            NavigatorUtil.goBackrootUrl(context, 2);
          });
    });
    var pull = Builder(builder: (ctx) {
      return CommonButton(
          text: S.current.BUYZ,
          color: ThemeUtils().currentColorTheme.textgreenColor,
          onTap: () {
            YYPayDialogWithGravity(
                width: screenWidth - 50,
                gravity: Gravity.center,
                model: model,
                shell: 1,
                context: context,
                tap: (parmss) {
                  Navigator.pop(context);
                  if (parmss != null) {
                    YYCountdownDialogWithGravity(
                        width: screenWidth - 50,
                        gravity: Gravity.center,
                        model: model,
                        pams: parmss,
                        tap: () {
                          Navigator.pop(context);
                        });
                  }
                });
            // 关闭键盘

            // 发送给webview，让webview登录后再取回token
            // autoLogin(username, password);
          });
    });
    var shell = Builder(builder: (ctx) {
      return CommonButton(
          text: S.current.MD,
          color: ThemeUtils().currentColorTheme.textRedColor,
          onTap: () {
            YYPayDialogWithGravity(
                width: screenWidth - 50,
                gravity: Gravity.center,
                model: model,
                shell: 2,
                context: context,
                tap: (parmss) {
                  Navigator.pop(context);
                  if (parmss != null) {
                    YYCountdownDialogWithGravity(
                        width: screenWidth - 50,
                        gravity: Gravity.center,
                        model: model,
                        pams: parmss,
                        tap: () {
                          Navigator.pop(context);
                        });
                  }
                });
          });
    });
    var paddig = (screenWidth / 3 - 20) / 2;
    Widget bButtons = Container(
      padding: EdgeInsets.zero,
      color: ThemeUtils().currentColorTheme.contentBG,
      // alignment: Alignment.bottomCenter,
      height: 60,
      // margin: EdgeInsets.symmetric(horizontal: 15, vertical: 0),
      width: double.infinity,

      // color: ThemeUtils().currentColorTheme.contentBG,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Container(
            width: 10,
          ),
          Expanded(
            child: Container(
              height: 32,
              width: 80,
              child: PositionBtn,
            ),
          ),
          Container(
            width: paddig,
          ),
          Expanded(
            child: Container(
              height: 32,
              width: 80,
              child: pull,
            ),
          ),
          Container(
            width: paddig,
          ),
          Expanded(
            child: Container(
              height: 32,
              width: 80,
              child: shell,
            ),
          ),
          Container(
            width: 10,
          ),
        ],
      ),
    );

    Widget kine = Container(
      height: screenHeight - 80 - 80 - 40,
      child: KLineVerticalWidget(datas: datas, dataController: dataController),
    );

    Widget allbody = Container(
      // color: ThemeUtils().currentColorTheme.labelColorW,
      // color: ThemeUtils().currentColorTheme.contentBG,
      // color: Color(0xFF0B0E10),
      // color: ThemeUtils().currentColorTheme.contentBG,
      child: Column(
        children: <Widget>[
          topviw,
          kine,
        ],
      ),
    );

    return Scaffold(
      backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        actions: <Widget>[
          IconButton(
              icon: Image.asset(
                optional == true
                    ? "images/wode/yishoucang@3x.png"
                    : "images/wode/uyishoucang@3x.png",
                width: 20,
                height: 20,
              ),

              // tooltip: 'Add Alarm',
              onPressed: () {
                // setState(() {
                //   path = "images/tabaricon/iocn_ccjl_yes@3x.png";
                // });
                if (optional == false) {
                  post_member_optional_create();
                } else {
                  post_member_optional_remove();
                }

                // do nothing
              }),
        ],
        backgroundColor: ThemeUtils().currentColorTheme.contentBG,
        title: ThemeUtils.sText(widget.title),
      ),
      body: Stack(
        children: <Widget>[
          allbody,
          // Positioned(
          //   child: bButtons,
          //   top: 5,
          // ),
          Positioned(left: 0, right: 0, bottom: bottomHeight, child: bButtons)
        ],
      ),
    );
  }

  void get_product_optional() async {
    Map<String, dynamic> params = {};

    // params["code"] = widget.model.code;

    params["id"] = model.id;

    ResultData resultData =
        await AppApi.getInstance().get_product_optional(context, false, params);
    if (resultData.isSuccess()) {
      bool isf = resultData.data["optional"];

      setStateIfMounted(() {
        optional = isf;
      });
    }
  }

  void post_member_optional_remove() async {
    Map<String, dynamic> params = {};

    // params["code"] = widget.model.code;

    params["id"] = model.id;

    ResultData resultData = await AppApi.getInstance()
        .post_member_optional_remove(context, true, params);
    if (resultData.isSuccess()) {
      bool isf = false;

      setStateIfMounted(() {
        optional = isf;
      });
    }
  }

  void post_member_optional_create() async {
    Map<String, dynamic> params = {};

    // params["code"] = widget.model.code;

    params["pid"] = model.id;

    ResultData resultData = await AppApi.getInstance()
        .post_member_optional_create(context, true, params);
    if (resultData.isSuccess()) {
      bool isf = true;

      setStateIfMounted(() {
        optional = isf;
      });
    }
  }

  void setStateIfMounted(f) {
    if (mounted) setState(f);
  }

  void getddddData(String period) async {
    // setStateIfMounted(() {

    // });
    showLoading = true;
    Map<String, dynamic> params = {};

    params["code"] = model.code;

    params["interval"] = period;

    // datas = [];

    ResultData resultData =
        await AppApi.getInstance().get_product_kline(context, false, params);
    if (resultData.isSuccess()) {
      List list = resultData.data["list"];

      if (list != null) {
        if (list.length > 0) {
          datas = list
              .map((item) => KLineEntity.fromJson(item))
              .toList()
              .reversed
              .toList()
              .cast<KLineEntity>();
        }
      }

      if (datas.length > 0) {
        DataUtil.calculate(datas);
        showLoading = false;
        setStateIfMounted(() {});
      }

      // Future.delayed(Duration(seconds: 10), () {
      //   //  var rr KLineEntity()
      //   //         DataUtil.addLastData(datas,);
      // });
    } else {
      setStateIfMounted(() {});
      // user = UserInfo();
    }
  }

  void getData(String period) async {
    setStateIfMounted(() {
      datas = [];
      showLoading = true;
    });
    Map<String, dynamic> params = {};

    params["code"] = model.code;

    params["interval"] = period;

    ResultData resultData =
        await AppApi.getInstance().get_product_kline(context, true, params);
    if (resultData.isSuccess()) {
      List list = resultData.data["list"];

      if (list != null) {
        if (list.length > 0) {
          datas = list
              .map((item) => KLineEntity.fromJson(item))
              .toList()
              .reversed
              .toList()
              .cast<KLineEntity>();
        }
      }

      if (datas.length > 0) {
        DataUtil.calculate(datas);
        showLoading = false;
        setStateIfMounted(() {});
      }

      // Future.delayed(Duration(seconds: 10), () {
      //   //  var rr KLineEntity()
      //   //         DataUtil.addLastData(datas,);
      // });
    } else {
      setStateIfMounted(() {});
      // user = UserInfo();
    }
  }
}

YYDialog YYCountdownDialogWithGravity(
    {width, gravity, doubleButtonGravity, tap, model, shell, pams}) {
  YYDialog yyDialog = YYDialog().build()
    ..width = width
    ..gravity = gravity
    ..gravityAnimationEnable = true
    ..borderRadius = 4.0
    ..barrierDismissible = false
    // ..widget(RecordContextView(
    //   tap: tap,
    //   model: model,
    // ))
    ..widget(CountdownClockView(
      tap: tap,
      model: model,
      params: pams,
    ))
    ..barrierColor = Colors.black.withOpacity(.7)
    ..backgroundColor = ThemeUtils().currentColorTheme.contentBG

    // ..doubleButton(
    //   padding: EdgeInsets.only(top: 20.0),
    //   gravity: doubleButtonGravity ?? Gravity.right,
    //   text1: "DISAGREE",
    //   color1: Colors.deepPurpleAccent,
    //   fontSize1: 14.0,
    //   text2: "AGREE",
    //   color2: Colors.deepPurpleAccent,
    //   fontSize2: 14.0,
    // )
    ..show();
  return yyDialog;
}

YYDialog YYPayDialogWithGravity(
    {width,
    gravity,
    doubleButtonGravity,
    tap,
    model,
    shell,
    BuildContext context}) {
  YYDialog yyDialog = YYDialog().build()
    ..width = width
    ..gravity = gravity
    ..gravityAnimationEnable = true
    ..borderRadius = 4.0
    ..barrierDismissible = false
    ..widget(RecordContextView(
      tap: tap,
      model: model,
      shell: shell,
    ))
    // ..widget(CountdownClockPage())
    ..barrierColor = Colors.black.withOpacity(.7)
    ..backgroundColor = ThemeUtils().currentColorTheme.contentBG

    // ..doubleButton(
    //   padding: EdgeInsets.only(top: 20.0),
    //   gravity: doubleButtonGravity ?? Gravity.right,
    //   text1: "DISAGREE",
    //   color1: Colors.deepPurpleAccent,
    //   fontSize1: 14.0,
    //   text2: "AGREE",
    //   color2: Colors.deepPurpleAccent,
    //   fontSize2: 14.0,
    // )
    ..show();
  return yyDialog;
}

class CountdownClockView extends StatefulWidget {
  final Product model;
  final Function tap;
  final Map<String, dynamic> params;

  const CountdownClockView({
    Key key,
    this.model,
    this.tap,
    this.params,
  }) : super(key: key);
  @override
  State<StatefulWidget> createState() {
    // ignore: no_logic_in_create_state
    return CountdownClockViewState(model, tap);
  }
}

class CountdownClockViewState extends State<CountdownClockView> {
  Product model;
  Function tap;
  // RecordContextView({
  //   Key key,
  //   this.tap,
  //   this.model,
  // })
  CountdownClockViewState(this.model, this.tap);

//初始化
  final ValueNotifier<double> new_counter = ValueNotifier<double>(0.0);

  final ValueNotifier<int> newtime = ValueNotifier<int>(0);

  @override
  void dispose() {
    super.dispose();
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    new_counter.value = model.price;

    Constants.eventBus.on<changeModel>().listen((m) {
      // 收到登录的消息，重新获取个人信息
      new_counter.value = m.model.price;
      // setStateIfMounted(() {
      //   model = m.model;

      //   // datas = [];
      //   // showLoading = true;
      // });
    });
  }

  // var showLoading = true;
  @override
  Widget build(BuildContext context) {
    var amount = widget.params["amount"];

    var type = widget.params["type"];
    var interval = widget.params["interval"].toString();
    var ratio = widget.params["ratio"];
    var yqsy = widget.params["yqsy"];

    var index;

    var leftIconContainer = InkWell(
        // margin: EdgeInsets.all(6),
        // alignment: Alignment.centerRight,
        onTap: () {
          tap();
        },
        child: Container(
          alignment: Alignment.centerRight,
          child: Image.asset(
            "images/wode/gunabi@3x.png",
            width: 15,
            height: 15,
          ),
        ));
    Widget titletext = Container(
      alignment: Alignment.center,
      child: Text(
        model.name,
        style: TextStyle(
          fontSize: 16,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );
    Widget Expiredate = Container(
      alignment: Alignment.centerLeft,
      child: Text(
        S.current.DXJ,
        style: TextStyle(
          fontSize: 12,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );
    // Widget priceView = Container(
    //   alignment: Alignment.centerLeft,
    //   child: Text(
    //     model.price.toString(),
    //     style: TextStyle(
    //       fontSize: 30,
    //       // fontWeight: FontWeight.w900,
    //       color: ThemeUtils().currentColorTheme.numberRedColor,
    //     ),
    //   ),
    // );

    var priceView = ValueListenableBuilder(
      valueListenable: new_counter,
      builder: (BuildContext context, double value, Widget child) {
        return Container(
          alignment: Alignment.centerLeft,
          child: Text(
            '$value',
            style: TextStyle(
              fontSize: 30,
              // fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.numberRedColor,
            ),
          ),
        );
      },
    );

    // final String increase;
    // final String onther;
    Widget namenowitem = Container(
      alignment: Alignment.center,
      height: 30,
      child: buttonRow(
        title: S.current.DFX,
        price: S.current.DJR,
        increase: "",
        onther: S.current.YQSY,
      ),
    );
    Widget buttonitem = Container(
      alignment: Alignment.center,
      height: 30,
      child: buttonRow(
        title: type == 1 ? S.current.BUYZ : S.current.MD,
        price: amount.toString(),
        increase: '',
        onther: yqsy.toString(),
      ),
    );

    var PositionBtn = Builder(builder: (ctx) {
      return CommonButton(
          text: S.current.DGB,
          color: ThemeUtils().currentColorTheme.labelColorY,
          onTap: () {
            // 关闭键盘
            Navigator.pop(context);
            // 发送给webview，让webview登录后再取回token
            // autoLogin(username, password);
          });
    });

    int minutes = int.parse(interval);
    double m = minutes / 60;
    int min = m.toInt();

    Duration _duration = Duration(seconds: minutes);

    void popviw() {
      NavigatorUtil.goBackrootUrl(context, 2);
    }

    var datecolok = Container(
      alignment: Alignment.center,
      height: 50.0,
      // width: 30,
      // color: Colors.red,
      child: FlipClock.countdown(
        duration: Duration(
          minutes: min,
        ),
        digitColor: ThemeUtils().currentColorTheme.labelColorW,
        backgroundColor: ThemeUtils().currentColorTheme.labelColorY,
        digitSize: 30.0,
        height: 49,
        width: 30,
        borderRadius: const BorderRadius.all(Radius.circular(3.0)),
        onDone: () => popviw(),
      ),
    );

    // Widget datecolok = Container(
    //   alignment: Alignment.center,
    //   height: 50,
    //   child: Text(
    //     cucettime.toString() + "S",
    //     style: TextStyle(
    //       fontSize: 22,
    //       // fontWeight: FontWeight.w900,
    //       color: ThemeUtils().currentColorTheme.textWithdrawColor,
    //     ),
    //   ),
    // );
    Widget topview = ListView(
      children: <Widget>[
        SizedBox(
          height: 5,
        ),
        leftIconContainer,
        SizedBox(
          height: 5,
        ),
        titletext,
        SizedBox(
          height: 5,
        ),
        Expiredate,
        SizedBox(
          height: 5,
        ),
        priceView,
        SizedBox(
          height: 5,
        ),

        datecolok,
        SizedBox(
          height: 15,
        ),

        namenowitem,
        // SizedBox(
        //   height: 5,
        // ),
        buttonitem,
        SizedBox(
          height: 5,
        ),
        Container(
          margin: EdgeInsets.only(left: 20, right: 20),
          child: PositionBtn,
        ),

        // shellPriceText,
        // SizedBox(
        //   height: 5,
        // ),
        // shellAmounteText
      ],
    );
    return Container(
        padding: EdgeInsets.only(left: 20, right: 20),
        height: 320,
        child: topview);
  }
}

class RecordContextView extends StatefulWidget {
  final Product model;
  final Function tap;
  final int shell;
  final BuildContext context;

  const RecordContextView({
    Key key,
    this.model,
    this.tap,
    this.shell,
    this.context,
  }) : super(key: key);
  @override
  State<StatefulWidget> createState() {
    // ignore: no_logic_in_create_state
    return RecordContextViewState(model, tap);
  }
}

class RecordContextViewState extends State<RecordContextView> {
  Product model;
  Function tap;
  // RecordContextView({
  //   Key key,
  //   this.tap,
  //   this.model,
  // })
  RecordContextViewState(this.model, this.tap);
  var showLoading = true;
  var quick = 0;
  var ratio = 0;
  var cmoney = 0;

  Productoption nowmodel;
  final passwordCtrl = TextEditingController(text: '');
  @override
  Widget build(BuildContext context) {
    final mediaQueryData = MediaQuery.of(context);

// 2.获取宽度和高度
    final screenWidth = mediaQueryData.size.width;

    void getData(String period) async {
      // setState(() {
      //   showLoading = true;
      // });
      Map<String, dynamic> params = {};

      params["id"] = period;

      ResultData resultData =
          await AppApi.getInstance().get_product_option(context, false, params);
      if (resultData.isSuccess()) {
        // List list = resultData.data;
        Productoption model = productoptionFromJson(resultData.dataJson);
        nowmodel = model;
        showLoading = false;
        setState(() {
          showLoading = false;
          nowmodel = model;
        });
      } else {
        JCHub.showmsg(resultData.msg, context);

        Navigator.pop(context);
      }
    }

    // void calculate() {
    //   setState(() {});
    // }

    var topview;
    if (showLoading) {
      getData(model.id.toString());
    } else {
      var leftIconContainer = InkWell(
          // margin: EdgeInsets.all(6),
          // alignment: Alignment.centerRight,
          onTap: () {
            // tap();
            Navigator.pop(context);
          },
          child: Container(
            alignment: Alignment.centerRight,
            child: Image.asset(
              "images/wode/gunabi@3x.png",
              width: 15,
              height: 15,
            ),
          ));
      Widget titletext = Container(
        alignment: Alignment.center,
        child: Text(
          S.current.DDQR,
          style: TextStyle(
            fontSize: 16,
            // fontWeight: FontWeight.w900,
            color: ThemeUtils().currentColorTheme.textWithdrawColor,
          ),
        ),
      );
      Widget Expiredate = Container(
        alignment: Alignment.centerLeft,
        child: Text(
          S.current.DQSJ,
          style: TextStyle(
            fontSize: 12,
            // fontWeight: FontWeight.w900,
            color: ThemeUtils().currentColorTheme.textWithdrawColor,
          ),
        ),
      );

      Widget paylistvie = Container(
        alignment: Alignment.center,
        height: 65,
        child: payListView(
          model: nowmodel,
          tap: (index) {
            ratio = index;
            setState(() {
              ratio = index;
            });
          },
        ),
      );
      Widget investmentamount = Container(
        alignment: Alignment.centerLeft,
        child: Text(
          S.current.TZJE,
          style: TextStyle(
            fontSize: 12,
            // fontWeight: FontWeight.w900,
            color: ThemeUtils().currentColorTheme.textWithdrawColor,
          ),
        ),
      );

      Widget inpuBank = Container(
          width: 80,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5),
              // color: ThemeUtils().currentColorTheme.labelColorY,
              // border: bo
              border: Border.all(
                  color: ThemeUtils().currentColorTheme.labelColorW, width: 1)),
          child: Container(
            child: Container(
              padding: EdgeInsets.fromLTRB(5, 0, 5, 0),
              margin: EdgeInsets.fromLTRB(5, 0, 5, 0),
              alignment: Alignment.center,
              color: ThemeUtils().currentColorTheme.contentBG,
              //height: 40,
              child: new SizedBox(
                child: new Container(
                  height: 25,
                  color: ThemeUtils().currentColorTheme.contentBG,
                  // color: Colors.red,
                  alignment: Alignment.center,
                  child: TextField(
                    obscureText: false,
                    keyboardType: TextInputType.number,
                    maxLines: 1,
                    controller: passwordCtrl,
                    decoration: InputDecoration(
                      isCollapsed: true,
                      // contentPadding: EdgeInsets.all(0),
                      hintText: "其他金额",
                      border: InputBorder.none,
                      hintStyle: TextStyle(
                        fontSize: 12,
                        color: ThemeUtils().currentColorTheme.textGaryColor,
                      ),
                    ),
                    style: TextStyle(
                      fontSize: 12,
                      color: ThemeUtils().currentColorTheme.textWithdrawColor,
                    ),
                    onChanged: (value) {
                      Constants.eventBus.fire(changeNumber());

                      setState(() {
                        quick = -1;
                        if (value.isEmpty) {
                          cmoney = int.parse("0");
                        } else {
                          cmoney = int.parse(value);
                        }
                      });
                      // passwordCtrl.text = value.toString();
                    },
                  ),
                ),
              ),
            ),
          ));
      Widget paynumberlistvie = Row(
        children: [
          Container(
            alignment: Alignment.center,
            height: 65,
            width: screenWidth - 155 - 20,
            child: payNumberlistView(
              model: nowmodel,
              tap: (index) {
                quick = index;
                setState(() {
                  quick = index;

                  cmoney = nowmodel.quick[quick];

                  passwordCtrl.text = cmoney.toString();
                });
              },
            ),
          ),
          Expanded(
            child: Text(''), // 中间用Expanded控件
          ),
          inpuBank,
        ],
      );

      Widget money = Row(
        children: [
          Container(
            alignment: Alignment.centerLeft,
            width: screenWidth / 2 - 90,
            child: Text(
              S.current.DYE + "：" + ConfigManager().user.balance.toString(),
              textAlign: TextAlign.left,
              style: TextStyle(
                fontSize: 12,
                // fontWeight: FontWeight.w900,
                color: ThemeUtils().currentColorTheme.textWithdrawColor,
              ),
            ),
          ),
          // Expanded(
          //   child: Text(''), // 中间用Expanded控件
          // ),
          Container(
            alignment: Alignment.centerLeft,
            width: screenWidth / 2 - 90,
            child: Text(
              S.current.SXF + nowmodel.fee.toString() + "%",
              textAlign: TextAlign.left,
              style: TextStyle(
                fontSize: 12,
                // fontWeight: FontWeight.w900,
                color: ThemeUtils().currentColorTheme.textWithdrawColor,
              ),
            ),
          ),
        ],
      );
      //     final String price;
      // final String increase;
      // final String onther;
      Widget namenowitem = Container(
        alignment: Alignment.center,
        height: 30,
        child: buttonRow(
          title: S.current.DMC,
          price: S.current.DFX,
          increase: S.current.DXJ,
          onther: S.current.DJR,
        ),
      );
      Widget buttonitem = Container(
        alignment: Alignment.center,
        height: 30,
        child: buttonRow(
          title: model.name,
          price: widget.shell == 1 ? S.current.BUYZ : S.current.MD,
          increase: model.price.toString(),
          onther: cmoney.toString(),
        ),
      );

      void post_product_buy() async {
        // if (ConfigManager().user.balance <= 0) {
        //      JCHub.showmsg("余额不足请入金", context);
        //   return;
        // }
        if (cmoney.toDouble() <= 0) {
          JCHub.showmsg(S.current.Amountcannotbeempty, context);
          return;
        }
        Map<String, dynamic> params = {};

        params["amount"] = cmoney.toDouble();

        params["id"] = model.id;

        params["interval"] = nowmodel.interval[ratio];
        params["ratio"] = nowmodel.ratio[ratio];
        params["type"] = widget.shell;
        ResultData resultData =
            await AppApi.getInstance().post_product_buy(context, true, params);
        if (resultData.isSuccess()) {
          // Constants.eventBus.fire(LoginEvent());
          // Navigator.pop(context);
          params["yqsy"] =
              (nowmodel.ratio[ratio] * cmoney.toDouble() / 100).toString();
          Constants.eventBus.fire(changebuyEvent());
          Constants.eventBus.fire(LoginEvent());

          tap(params);
        } else {
          JCHub.showmsg(resultData.msg, context);
        }
      }

      var PositionBtn = Builder(builder: (ctx) {
        return CommonButton(
            text: S.current.DJC,
            color: ThemeUtils().currentColorTheme.labelColorY,
            onTap: () {
              // 关闭键盘

              // 发送给webview，让webview登录后再取回token
              // autoLogin(username, password);
              FocusScope.of(context).requestFocus(FocusNode());
              post_product_buy();
            });
      });

      Widget lowIncome = Container(
        alignment: Alignment.center,
        height: 15,
        child: Text(
          S.current.DYQSY +
              (nowmodel.ratio[ratio] * cmoney.toDouble() / 100).toString(),
          style: TextStyle(
            fontSize: 12,
            // fontWeight: FontWeight.w900,
            color: ThemeUtils().currentColorTheme.textWithdrawColor,
          ),
        ),
      );

      topview = Column(
        children: <Widget>[
          SizedBox(
            height: 5,
          ),
          leftIconContainer,
          SizedBox(
            height: 5,
          ),
          titletext,
          SizedBox(
            height: 5,
          ),
          Expiredate,
          SizedBox(
            height: 5,
          ),
          paylistvie,
          SizedBox(
            height: 5,
          ),
          investmentamount,
          SizedBox(
            height: 5,
          ),
          paynumberlistvie,
          SizedBox(
            height: 5,
          ),
          money,
          SizedBox(
            height: 5,
          ),
          namenowitem,
          // SizedBox(
          //   height: 5,
          // ),
          buttonitem,
          SizedBox(
            height: 5,
          ),
          Container(
            margin: EdgeInsets.only(left: 20, right: 20),
            child: PositionBtn,
          ),
          SizedBox(
            height: 18,
          ),
          lowIncome,
          SizedBox(
            height: 14,
          ),
          // shellPriceText,
          // SizedBox(
          //   height: 5,
          // ),
          // shellAmounteText
        ],
      );
    }

    return Container(
        padding: EdgeInsets.only(left: 20, right: 20),
        height: 443,
        child: showLoading == true
            ? Offstage(
                offstage: !showLoading,
                child: Container(
                    width: double.infinity,
                    height: 443,
                    alignment: Alignment.center,
                    child: CircularProgressIndicator()),
              )
            : topview);
  }
}

class payListRow extends StatefulWidget {
  final Productoption model;
  final Function tap;
  final int index;
  final int isselect;

  const payListRow({Key key, this.model, this.index, this.tap, this.isselect})
      : super(key: key);
  @override
  State<StatefulWidget> createState() {
    // ignore: no_logic_in_create_state
    return payListRowState();
  }
}

class payListRowState extends State<payListRow> {
  @override
  Widget build(BuildContext context) {
    bool isselect = widget.index == widget.isselect ? true : false;
    int index = widget.index;
    Widget titleText = Container(
        alignment: Alignment.center,
        height: 15,
        child: Text(
          S.current.JSSJ,
          style: TextStyle(
              color: ThemeUtils().currentColorTheme.textGaryColor,
              fontSize: 12),
        ));

    Widget timeText = Container(
        alignment: Alignment.center,
        // padding: EdgeInsets.only(left: 9),
        height: 15,
        child: Text(
          widget.model.interval[index].toString() + "s",
          style: TextStyle(
              color: ThemeUtils().currentColorTheme.labelColorY, fontSize: 12),
        ));

    Widget incomeText = Container(
        alignment: Alignment.center,
        // padding: EdgeInsets.only(left: 10),
        height: 15,
        child: Text(
          S.current.DSY + widget.model.ratio[index].toString() + "%",
          style: TextStyle(
              color: ThemeUtils().currentColorTheme.labelColorY, fontSize: 12),
        ));

    Widget lefttextView = InkWell(
      onTap: () {
        // reload();
        widget.tap(index);
      },
      child: Container(
        alignment: Alignment.centerLeft,

        // width: screenWidth / 2,
        margin: EdgeInsets.only(left: 5, right: 5),

        decoration: isselect == false
            ? BoxDecoration(
                borderRadius: BorderRadius.circular(6),
                color: ThemeUtils().currentColorTheme.viewgaryBG,

                ///边框颜色、宽
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(6),
                color: ThemeUtils().currentColorTheme.viewgaryBG,

                ///圆角
                border: Border.all(
                    color: ThemeUtils().currentColorTheme.labelColorY, width: 1)

                ///边框颜色、宽
                ),
        height: 70,
        width: 70,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            SizedBox(
              height: 5,
            ),
            titleText,
            SizedBox(
              height: 2,
            ),
            timeText,
            SizedBox(
              height: 2,
            ),
            incomeText,
          ],
        ),
      ),
    );

    return Container(
      child: Container(
        // color: ThemeUtils().currentColorTheme.contentBG,
        width: 70,
        child: lefttextView,
      ),
    );
  }
}

class payListView extends StatefulWidget {
  final Productoption model;
  final Function tap;
  final int index;

  const payListView({Key key, this.model, this.index, this.tap})
      : super(key: key);
  @override
  State<StatefulWidget> createState() {
    return HomeListViewState(model, index, tap);
  }
}

class HomeListViewState extends State<payListView> {
  final Productoption model;
  final Function tap;
  final int index;

  HomeListViewState(this.model, this.index, this.tap);
  var select = 0;
  Widget build(BuildContext context) {
    var listView = ListView.builder(
      shrinkWrap: true, //解决无限高度问题
      // physics: new NeverScrollableScrollPhysics(), //禁用滑动事件
      itemCount: model.interval.length,
      scrollDirection: Axis.horizontal,
      itemBuilder: (context, i) => renderRow(i),
    );

    Widget body = Container(
      // height: 65,
      // color: ThemeUtils().currentColorTheme.viewgaryBG,
      child: listView,
    );
    return body;
  }

  void relod(int period) async {
    select = period;
    setState(() {
      select = period;
    });
  }

  renderRow(i) {
    // Product pro = model.category[index].product[i];
    if (i == 0) {
      return payListRow(
        model: model,
        tap: (index) {
          select = index;

          tap(index);
          relod(i);
        },
        index: i,
        isselect: select,
      );
    }

    var rowitem = payListRow(
      model: model,
      tap: (index) {
        select = index;
        tap(index);
        relod(i);
      },
      index: i,
      isselect: select,
    );

    return rowitem;
  }
}

class payNumberRow extends StatelessWidget {
  final Productoption model;
  final Function tap;
  final int index;
  final int isselect;

  const payNumberRow({Key key, this.model, this.index, this.tap, this.isselect})
      : super(key: key);
  Widget build(BuildContext context) {
    var text =
        model.quick[index].toString() + ConfigManager().config.base.symbolFlag;
    ;
    bool select = index == isselect ? true : false;
    // int index = widget.index;
    Widget titleText = Container(
        alignment: Alignment.center,
        decoration: select == false
            ? BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                color: ThemeUtils().currentColorTheme.viewgaryBG,

                ///边框颜色、宽
              )
            : BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                color: ThemeUtils().currentColorTheme.viewgaryBG,

                ///圆角
                border: Border.all(
                    color: ThemeUtils().currentColorTheme.labelColorY, width: 1)

                ///边框颜色、宽
                ),
        height: 30,
        width: StandardTextStyle.boundingTextSize(
                    text,
                    TextStyle(
                        color: ThemeUtils().currentColorTheme.textGaryColor,
                        fontSize: 12))
                .width +
            25,
        child: Text(
          text,
          maxLines: 1,
          style: TextStyle(
              color: ThemeUtils().currentColorTheme.textGaryColor,
              fontSize: 12),
        ));

    Widget lefttextView = InkWell(
      onTap: () {
        // reload();
        tap(index);
      },
      child: Container(
        alignment: Alignment.centerLeft,

        // width: screenWidth / 2,
        margin: EdgeInsets.only(left: 5, right: 5),

        height: 30,
        width: StandardTextStyle.boundingTextSize(
                    text,
                    TextStyle(
                        color: ThemeUtils().currentColorTheme.textGaryColor,
                        fontSize: 12))
                .width +
            15,
        child: titleText,
      ),
    );

    return Container(
      child: Container(
        // color: ThemeUtils().currentColorTheme.contentBG,
        // width: 70,
        child: lefttextView,
      ),
    );
  }
}

class payNumberlistView extends StatefulWidget {
  final Productoption model;
  final Function tap;
  final int index;

  const payNumberlistView({Key key, this.model, this.index, this.tap})
      : super(key: key);
  @override
  State<StatefulWidget> createState() {
    return payNumberlistViewState(model, index, tap);
  }
}

class payNumberlistViewState extends State<payNumberlistView> {
  final Productoption model;
  final Function tap;
  final int index;

  payNumberlistViewState(this.model, this.index, this.tap);
  var select = -1;

  @override
  void initState() {
    super.initState();
    Constants.eventBus.on<changeNumber>().listen((event) {
      relod(-1);
      // 收到退出登录的消息，刷新个人信息显示
    });
  }

  Widget build(BuildContext context) {
    var listView = ListView.builder(
      shrinkWrap: true, //解决无限高度问题
      // physics: new NeverScrollableScrollPhysics(), //禁用滑动事件
      itemCount: model.quick.length,
      scrollDirection: Axis.horizontal,
      itemBuilder: (context, i) => renderRow(i),
    );

    Widget body = Container(
      height: 55,
      // color: ThemeUtils().currentColorTheme.viewgaryBG,
      child: listView,
    );
    return body;
  }

  void relod(int period) async {
    select = period;
    setState(() {
      select = period;
    });
  }

  renderRow(i) {
    // Product pro = model.category[index].product[i];
    if (i == 0) {
      return payNumberRow(
        model: model,
        tap: (index) {
          select = index;
          tap(index);
          relod(index);
        },
        index: i,
        isselect: select,
      );
    }

    var rowitem = payNumberRow(
      model: model,
      tap: (index) {
        select = index;
        tap(index);
        relod(index);
      },
      index: i,
      isselect: select,
    );

    return rowitem;
  }
}

class buttonRow extends StatelessWidget {
  final String title;
  final String price;
  final String increase;
  final String onther;
  const buttonRow({
    Key key,
    this.title,
    this.price,
    this.increase,
    this.onther,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var list = <Widget>[
      Flex(
        direction: Axis.horizontal,
        children: <Widget>[
          Expanded(
            flex: 1,
            child: Container(
              // padding: EdgeInsets.zero,
              height: 30,
              // color: Colors.red,
              margin: EdgeInsets.symmetric(horizontal: 15, vertical: 0),
              alignment: Alignment.center,
              child: Text(
                title ?? '商品名称',
                style: TextStyle(
                  color: ThemeUtils().currentColorTheme.textWithdrawColor,
                  fontSize: 12,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ),
          Expanded(
            flex: 1,
            child: Container(
              // padding: EdgeInsets.zero,
              height: 30,
              alignment: Alignment.center,
              // color: Colors.yellow,
              child: Text(
                price ?? '最新净值',
                style: TextStyle(
                  color: ThemeUtils().currentColorTheme.textWithdrawColor,
                  fontSize: 12,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ),
          Expanded(
            flex: 1,
            child: Container(
              // padding: EdgeInsets.zero,
              height: 30,
              alignment: Alignment.center,
              // color: Colors.yellow,
              child: Text(
                onther ?? '最新净值',
                style: TextStyle(
                  color: ThemeUtils().currentColorTheme.textWithdrawColor,
                  fontSize: 12,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ),
          Expanded(
            flex: 1,
            child: Container(
              alignment: Alignment.center,
              // padding: EdgeInsets.zero,
              height: 30,

              child: Text(
                increase ?? '跌涨幅',
                style: TextStyle(
                  color: ThemeUtils().currentColorTheme.textWithdrawColor,
                  fontSize: 12,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ),
        ],
      ),
    ];
    var info = Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: list,
    );

    return Container(
      child: Container(
        // padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        child: Row(
          children: <Widget>[
            Expanded(child: info),
          ],
        ),
      ),
    );
  }
}

class inpuBankNumberWiget extends StatelessWidget {
  final String title;
  final TextInputType type;
  final int hight;
  final TextEditingController Controller;

  final bool ishow;

  const inpuBankNumberWiget(
      {Key key,
      this.title,
      this.hight,
      this.Controller,
      this.ishow = false,
      this.type = TextInputType.text})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    int he = hight;
    if (he == null) {
      he = 50;
    }

    return Container(
      child: Container(
        padding: EdgeInsets.fromLTRB(5, 0, 5, 0),
        margin: EdgeInsets.fromLTRB(5, 0, 5, 0),
        alignment: Alignment.center,
        color: ThemeUtils().currentColorTheme.contentBG,
        //height: 40,
        child: new SizedBox(
          child: new Container(
            height: 25,
            color: ThemeUtils().currentColorTheme.contentBG,
            alignment: Alignment.center,
            child: TextField(
              obscureText: ishow,
              keyboardType: type,
              maxLines: 1,
              controller: Controller,
              decoration: InputDecoration(
                hintText: title,
                border: InputBorder.none,
                hintStyle: TextStyle(
                  fontSize: 12,
                  color: ThemeUtils().currentColorTheme.textGaryColor,
                ),
              ),
              style: TextStyle(
                fontSize: 12,
                color: ThemeUtils().currentColorTheme.textWithdrawColor,
              ),
            ),
          ),
        ),
      ),
    );
    // TODO: implement build
  }
}
