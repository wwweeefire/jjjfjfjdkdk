// ignore_for_file: unused_import
import 'dart:io';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:heibai/Classes/model/config.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../Classes/model/UserInfo.dart';
// import 'package:heibai/pages/kchart/utils/date_format_util.dart';
import 'package:heibai/util/ThemeUtils.dart';
// TODO Implement this library.
import 'package:heibai/pages/localization_page.dart';
import 'package:heibai/generated/l10n.dart';
import 'package:heibai/pages/WhomePageList.dart';
import 'package:tapped/tapped.dart';
import 'package:card_swiper/card_swiper.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:heibai/pages/Views/TopIconTextButton.dart';
import '../Classes/model/BannerModel.dart';
import 'package:heibai/net/api/Api.dart';
import 'package:heibai/net/api/app_api.dart';
import 'package:heibai/pages/Recharge/RechargePage.dart';
import 'package:heibai/pages/Balancebao/Balancebao.dart';
import 'package:heibai/pages/Withdrawal/WithdrawalPlatformPage.dart';
import 'package:heibai/pages/CommonWebPage.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:heibai/pages/CommonAPPwebpage.dart';
import 'package:heibai/pages/announcementpage.dart';
import 'package:flutter_widget_from_html_core/flutter_widget_from_html_core.dart';
import 'package:heibai/pages/web_socket_utility.dart';
import '../Classes/model/NProduct.dart';
import 'package:heibai/util/DataUtils.dart';
import 'package:marquee/marquee.dart';
import 'package:webviewx/webviewx.dart';
import 'package:text_scroll/text_scroll.dart';

class HomePage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return HomePageState();
  }
}

class HomePageState extends State<HomePage> {
  bool loading = true;

  BannerModel Banner;

  @override
  void initState() {
    YYDialog.init(context);
    // _tabController = TabController(vsync: this, length: _tabs.length);
    super.initState();
  }

  void _showslog(BuildContext context, BannerModel Banner) {
    final mediaQueryData = MediaQuery.of(context);

// 2.获取宽度和高度
    final screenWidth = mediaQueryData.size.width;

    final screenhe = mediaQueryData.size.height;
    YYAlertDialogWithGravity(
      width: screenWidth * 0.8,
      hight: screenhe * 0.6,
      gravity: Gravity.center,
      model: Banner,
    );
  }

  getBanner() async {
    if (kIsWeb) {
      try {
        ResultData resultData =
            await AppApi.getInstance().get_index(context, false);
        if (resultData.isSuccess()) {
          BannerModel model = bannerModelFromJson(resultData.dataJson);
          // ConfigManager.
          setState(() {
            Banner = model;
            loading = false;
          });
          if (model != null) {
            if (model.notice.pop != null) {
              if (ConfigManager().isshown) {
                _showslog(context, model);
              }
            }
          }
        } else {
          // user = UserInfo();
        }
      } catch (e) {
        setState(() {
          Banner = null;
          loading = false;
        });
      }
    } else {
      try {
        ResultData resultData =
            await AppApi.getInstance().get_index(context, true);
        if (resultData.isSuccess()) {
          BannerModel model = bannerModelFromJson(resultData.dataJson);
          // ConfigManager.
          setState(() {
            Banner = model;
            loading = false;
          });
          if (model != null) {
            if (model.notice.pop != null) {
              if (ConfigManager().isshown) {
                _showslog(context, model);
              }
            }
          }
        } else {
          // user = UserInfo();
        }
      } catch (e) {
        setState(() {
          Banner = null;
          loading = false;
        });
      }
    }
  }

  Widget build(BuildContext context) {
    // 获取用户信息

    Widget topAnnouncement = Container(
      color: ThemeUtils().currentColorTheme.contentBG,
      margin: EdgeInsets.symmetric(horizontal: 15, vertical: 0),
      height: 38,
      child: new topheadAnnouncement(
        title: Banner == null
            ? ""
            : Banner.notice.roll == null
                ? ""
                : Banner.notice.roll.intro,
        onTap: () async {
          final result = await Navigator.of(context)
              .push(MaterialPageRoute(builder: (context) {
            return announcementpage();
          }));
        },
      ),
    );

    Widget topButtons = Container(
      padding: EdgeInsets.zero,
      margin: EdgeInsets.symmetric(horizontal: 15, vertical: 0),
      width: double.infinity,
      color: ThemeUtils().currentColorTheme.contentBG,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          TopIconTextButton(
            title: S.current.recharge,
            icon: Image.asset('images/wode/recharge@3x.png'),
            onTap: () async {
              final result = await Navigator.of(context)
                  .push(MaterialPageRoute(builder: (context) {
                return RechargePage();
              }));
            },
          ),
          TopIconTextButton(
            title: S.current.withdraw,
            icon: Image.asset('images/wode/withdraw@3x.png'),
            onTap: () async {
              final result = await Navigator.of(context)
                  .push(MaterialPageRoute(builder: (context) {
                return WithdrawalPlatformPage();
              }));
            },
          ),
          TopIconTextButton(
            title: S.current.YueBao,
            icon: Image.asset('images/wode/yuebao@3x.png'),
            onTap: () async {
              final result = await Navigator.of(context)
                  .push(MaterialPageRoute(builder: (context) {
                return Balancebao();
              }));
            },
          ),
          TopIconTextButton(
            title: S.current.KF,
            icon: Image.asset('images/wode/homekf@3x.png'),
            onTap: () async {
              var kfid = ConfigManager().config.kf[0].id;

              var userid = ConfigManager().user.id;
              if (kIsWeb) {
                var baidu = ConfigManager().config.kf[0].link;

                final result = await Navigator.of(context)
                    .push(MaterialPageRoute(builder: (context) {
                  return CommonWebPage(
                    htmlContent: baidu + "?id=$kfid&uid=$userid",
                    title: S.current.KF,
                  );
                }));
              } else {
                var baidu = ConfigManager().config.kf[0].link;

                final result = await Navigator.of(context)
                    .push(MaterialPageRoute(builder: (context) {
                  return CommonAPPwebpage(
                    htmlContent: baidu + "?id=$kfid&uid=$userid",
                    title: S.current.KF,
                  );
                }));
              }
            },
          ),
        ],
      ),
    );

    Widget ad = Container(
      margin: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
      height: 140,
      // color: ThemeUtils().currentColorTheme.labelColorW,
      child: ClipRRect(
        // borderRadius: BorderRadius.circular(6),
        // ignore: unnecessary_new
        child: Banner == null
            ? Text("")
            : Banner.banner.length > 0
                ? new Swiper(
                    itemBuilder: (BuildContext context, int index) {
                      var url;
                      if (Banner.banner.length > 0) {
                        url = Banner.banner[index].image;
                      }

                      return InkWell(
                        child: CachedNetworkImage(
                          imageUrl: ConfigManager().imageHost + url,
                          fit: BoxFit.cover,
                          placeholder: (context, url) => Image.asset(
                            "images/wode/noimage.png",
                          ),
                          errorWidget: (context, url, error) => Image.asset(
                            "images/wode/noimage.png",
                          ),
                        ),
                        onTap: () async {
                          var baidu = "https://www.google.com/";
                          // if (Banner.banner[index].link.length > 10) {
                          baidu = Banner.banner[index].link;
                          // }

                          if (kIsWeb) {
                            final result = await Navigator.of(context)
                                .push(MaterialPageRoute(builder: (context) {
                              return CommonWebPage(
                                htmlContent: baidu,
                                title: S.current.QWANGYE,
                              );
                            }));
                          } else {
                            final result = await Navigator.of(context)
                                .push(MaterialPageRoute(builder: (context) {
                              return CommonAPPwebpage(
                                htmlContent: baidu,
                                title: S.current.QWANGYE,
                              );
                            }));
                          }
                        },
                      );
                    },
                    indicatorLayout: PageIndicatorLayout.COLOR,
                    autoplay: true,
                    itemCount: Banner == null ? 0 : Banner.banner.length,
                    pagination: SwiperPagination(),
                    control: new SwiperPagination())
                : Text(""),
      ),
    );

    Widget tabarview = Container(
      margin: EdgeInsets.symmetric(horizontal: 0, vertical: 10),
      // padding: EdgeInsets.zero,
      // height: 456,
      height: 475,
      child: homeTabBarView(),
    );
    Widget palyview = Container(
      color: ThemeUtils().currentColorTheme.contentBG,
      margin: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
      padding: EdgeInsets.zero,
      child: homePayView(
        onTap: () async {
          final result = await Navigator.of(context)
              .push(MaterialPageRoute(builder: (context) {
            return RechargePage();
          }));
        },
      ),
    );
    Widget body = Container(
      child: Column(
        children: <Widget>[
          ad,
          topAnnouncement,
          topButtons,
          palyview,
        ],
      ),
    );

    var loadingView;
    if (loading) {
      getBanner();

      // getConnect();

      loadingView = Center(
          child: Container(
              padding: const EdgeInsets.fromLTRB(0, 30, 0, 0),
              // color: ThemeUtils().currentColorTheme.contentBG,
              child: Text(
                "loading...",
                style: TextStyle(
                  fontSize: 20,
                  // fontWeight: FontWeight.w900,
                  color: ThemeUtils().currentColorTheme.textGaryColor,
                ),
              )));
    } else {
      loadingView = Center();
    }

    Widget allbody = Container(
      // color: ThemeUtils().currentColorTheme.labelColorW,
      // color: ThemeUtils().currentColorTheme.contentBG,
      // color: Color(0xFF0B0E10),
      color: ThemeUtils().currentColorTheme.contentBG,
      child: ListView(
        children: <Widget>[body, tabarview],
      ),
    );

    String userInfo =
        DataUtils.preferences.getString(DataUtils.SPchangeLanguage);

    if (userInfo == null) {
      userInfo = "zh";
    }
    ;
    Widget allviebody = Scaffold(
      backgroundColor: ThemeUtils().currentColorTheme.contentBG,
      body: loading == true ? loadingView : allbody,
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
        ),
        // 如果没有设置这项， 二级页面 会默认是返回箭头  ， 有侧边栏的页面默认有图标（用来打开侧边栏）
        automaticallyImplyLeading: true,
        // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
        title: ThemeUtils.sText(S.current.tab_home),
        centerTitle: true,
        // 标题是否在居中
        actions: <Widget>[
          IconButton(
              icon: Image.asset(
                "images/flag/" + userInfo + ".png",
                width: 20,
                height: 20,
              ),

              // tooltip: 'Add Alarm',
              onPressed: () async {
                final result = await Navigator.of(context)
                    .push(MaterialPageRoute(builder: (context) {
                  return LocalizetionPage();
                }));
                // final result = Navigator.of(context)
                //     .push(MaterialPageRoute(builder: (context) {
                //   return NoticelistPage();
                // }));
                // do nothing
              }),
        ],

//          elevation: 0.1, // 导航栏Z轴的高度，默认是1  默认就是有高度 阴影的
        backgroundColor: ThemeUtils()
            .currentColorTheme
            .contentBG, // 导航栏的颜色  默认是 ThemeData 的颜色
//         flexibleSpace: FlexibleSpaceBar(title: Text("你号"),),//这个堆叠在工具栏上面  一般 appbar不用  主要用在 SliverAppBar上
//          brightness: Brightness.light, //状态栏的深度 有白色和黑色两种主题
//          titleSpacing: 10,//flexibleSpace 和 title 的距离  默认是重合的
//          toolbarOpacity: 0.5,// 导航栏透明度 默认是1 ，不包括flexibleSpace
//          bottomOpacity: 0.5,
      ),
    );

    return allviebody;
  }
}

class topheadAnnouncement extends StatelessWidget {
  final String title;
  final String url;
  final Function onTap;
  const topheadAnnouncement({
    Key key,
    this.title,
    this.onTap,
    this.url,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final mediaQueryData = MediaQuery.of(context);
    // YYDialog.init(context);

// 2.获取宽度和高度
    final screenWidth = mediaQueryData.size.width;
    // ignore: unnecessary_new
    var image = new Image.asset('images/wode/homenotice@3x.png');

    Widget ad = Container(
      height: 16,
      width: 18,
      child: image,
    );

    double textwidth = StandardTextStyle.boundingTextSize(
            title,
            TextStyle(
                color: ThemeUtils().currentColorTheme.textGaryColor,
                fontSize: 12))
        .width;

    double textviewwidth = screenWidth - 20 - 30 - 20 - 50;
    Widget Ctext = Container(
        width: textviewwidth,
        child: textviewwidth > textwidth
            ? Text(
                title,
                maxLines: 1,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                  color: ThemeUtils().currentColorTheme.labelColorW,
                ),
              )
            : TextScroll(
                title,
                mode: TextScrollMode.endless,
                velocity: Velocity(pixelsPerSecond: Offset(50, 0)),
                style: TextStyle(
                  fontSize: 12,
                  color: ThemeUtils().currentColorTheme.labelColorW,
                ),
                textAlign: TextAlign.left,
              ));

    // Widget Ctext = Container(
    //     width: textviewwidth,
    //     child: Marquee(
    //       text: title + " ",
    //       velocity: 18.0,
    //       style: TextStyle(
    //         fontSize: 12,
    //         color: ThemeUtils().currentColorTheme.labelColorW,
    //       ),
    //     ));

    Widget rightbtn = Container(
      alignment: Alignment.centerRight,
      height: 15,
      width: 30,
      child: Text(
        S.current.GD + '>',
        style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w900,
            color: ThemeUtils().currentColorTheme.labelColorY),
      ),
    );

    Widget line = Divider(
      height: 1.0,
      indent: 0.0,
      color: ThemeUtils().currentColorTheme.lineColor,
    );

    rightbtn = Tapped(
      child: rightbtn,
      onTap: onTap,
    );

    Widget body = Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[
        ad,
        Container(width: 4),
        Ctext,
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        rightbtn,
        Container(width: 9),
      ],
    );
    // body = Tapped(
    //   child: body,
    // );

    Widget topview = Column(
      children: <Widget>[
        SizedBox(
          height: 10,
        ),
        body,
        SizedBox(
          height: 9,
        ),
        line
      ],
    );
    return Container(
      child: Container(
        height: 44,
        child: topview,
      ),
    );
  }
}

class homePayView extends StatelessWidget {
  final Function onTap;
  const homePayView({
    Key key,
    this.onTap,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    var image = new Image.asset('images/wode/kjzf@3x.png');
    Widget ad = Container(height: 25, width: 25, child: image);
    Widget rightimage = Container(
      height: 23,
      width: 35,
      child: new Image.asset('images/wode/shouye_icon_you@3x.png'),
    );

    Widget toptext = Container(
      height: 20,
      child: Text(
        S.current.KJCZ,
        style: TextStyle(
            color: ThemeUtils().currentColorTheme.textWithdkkkwColor,
            fontSize: 12),
        textAlign: TextAlign.left,
      ),
    );
    Widget bottomtext = Container(
      height: 20,
      child: Text(
        S.current.ZCYHKMORE,
        style: TextStyle(
          color: ThemeUtils().currentColorTheme.textWithdDDrawColor,
          fontSize: 12,
        ),
      ),
    );

    Widget textView = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        SizedBox(
          height: 4,
        ),
        toptext,
        bottomtext
      ],
    );

    Widget body = Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[
        ad,
        Container(width: 10),
        textView,
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        rightimage
      ],
    );
    body = Tapped(
      child: body,
      onTap: onTap,
    );

    return Center(
      child: Container(
        height: 44,
        child: body,
      ),
    );
  }
}

YYDialog YYAlertDialogWithGravity(
    {width, gravity, doubleButtonGravity, model, hight}) {
  YYDialog yyDialog = YYDialog().build()
    ..width = width
    ..gravity = gravity
    ..gravityAnimationEnable = true
    ..borderRadius = 4.0
    ..barrierDismissible = false
    ..widget(nCenterdespage(
      h: hight,
      width: width,
      sbanner: model,
    ))
    ..backgroundColor = ThemeUtils().currentColorTheme.contentBG

    // ..doubleButton(
    //   padding: EdgeInsets.only(top: 20.0),
    //   gravity: doubleButtonGravity ?? Gravity.right,
    //   text1: "DISAGREE",
    //   color1: Colors.deepPurpleAccent,
    //   fontSize1: 14.0,
    //   text2: "AGREE",
    //   color2: Colors.deepPurpleAccent,
    //   fontSize2: 14.0,
    // )
    ..show();
  return yyDialog;
}

class nCenterdespage extends StatefulWidget {
  final BannerModel sbanner;
  final double width;
  final double h;
  const nCenterdespage({
    Key key,
    this.sbanner,
    this.width,
    this.h,
  }) : super(key: key);
  @override
  State<StatefulWidget> createState() {
    return nCenterdespageState();
  }
}

class nCenterdespageState extends State<nCenterdespage> {
  void initState() {
    super.initState();
    // Enable virtual display.
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    void showSnackBar(String content, BuildContext context) {
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(
          SnackBar(
            content: Text(content),
            duration: const Duration(seconds: 1),
          ),
        );
    }

    var leftIconContainer = InkWell(
        // margin: EdgeInsets.all(6),
        // alignment: Alignment.centerRight,
        onTap: () {
          // webviewController.dispose();
          Navigator.pop(context);
        },
        child: Container(
          alignment: Alignment.centerRight,
          child: Image.asset(
            "images/wode/gunabi@3x.png",
            width: 15,
            height: 15,
          ),
        ));

    Widget buildRichTextView() {
      return Container(
        height: widget.h - 125,
        width: widget.width,
        child: ListView(
          padding: EdgeInsets.only(top: 0),
          children: [
            Container(
                child: HtmlWidget(
              widget.sbanner.notice.pop.content,
              textStyle: TextStyle(
                  color: ThemeUtils().currentColorTheme.labelColorW,
                  fontSize: 15),
            )

                //golobalTextStyle: TextStyle(color: ThemeUtils().currentColorTheme.labelColorW, fontSize: 15)),
                ),
          ],
        ),
      );
    }

    Widget titletext = Container(
      alignment: Alignment.centerLeft,
      child: Text(
        widget.sbanner.notice.pop.title,
        style: TextStyle(
          fontSize: 18,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );
    var Time = DateTime.fromMillisecondsSinceEpoch(
        widget.sbanner.notice.pop.createTime * 1000);

    // var Time = DateTime.fromMillisecondsSinceEpoch(model.createTime * 1000);
    var aTime = Time.toLocal().toString().substring(0, 16);

    Widget Expiredate = Container(
      alignment: Alignment.centerLeft,
      child: Text(
        aTime.toString(),
        style: TextStyle(
          fontSize: 12,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );
    Widget content = Container(
      alignment: Alignment.center,
      // color: ThemeUtils().currentColorTheme.labelColorW,
      child: buildRichTextView(),
    );
    Widget topview = Container(
        // margin: EdgeInsets.all(15),
        padding: EdgeInsets.all(15),
        // color: ThemeUtils().currentColorTheme.contentBG,
        child: Column(children: <Widget>[
          SizedBox(
            height: 5,
          ),
          leftIconContainer,
          SizedBox(
            height: 5,
          ),
          titletext,
          SizedBox(
            height: 5,
          ),
          Expiredate,
          SizedBox(
            height: 15,
          ),
          content,
          SizedBox(
            height: 5,
          ),
        ]));

    return Container(
        // margin: EdgeInsets.only(bottom: 0),
        height: widget.h,
        child: Container(
          // color: ,

          child: Container(
            child: topview,
          ),
        ));
  }
}
