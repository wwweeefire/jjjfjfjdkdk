import 'package:flutter/material.dart';
import 'package:heibai/util/ThemeUtils.dart';
import 'dart:io';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'dart:convert';
import '../Classes/model/Noticelistmodel.dart';
import 'package:tapped/tapped.dart'; //咨询
import 'package:heibai/pages/CommonWebPage.dart';
import 'package:heibai/Classes/model/config.dart';
import 'package:heibai/generated/l10n.dart';
import 'package:webviewx/webviewx.dart';
import 'package:flutter_widget_from_html_core/flutter_widget_from_html_core.dart';
// import 'package:webviewx/webviewx.dart';
// import 'dart:html';
// import 'dart:ui' as ui;
// // import 'package:simp';
// // import 'package:flutter_fai_webview/flutter_fai_webview.dart';
// import 'package:webview_flutter/webview_flutter.dart';

class NoticelistPagedes extends StatefulWidget {
  final String htmlContent;
  final ListElement model;

  NoticelistPagedes({Key key, this.htmlContent, this.model}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return HelpCenterdespageState();
  }
}

class HelpCenterdespageState extends State<NoticelistPagedes> {
  WebViewXController webviewController;
  void initState() {
    super.initState();
  }

  Size get screenSize => MediaQuery.of(context).size;
  @override
  void dispose() {
    super.dispose();
    webviewController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    void showSnackBar(String content, BuildContext context) {
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(
          SnackBar(
            content: Text(content),
            duration: const Duration(seconds: 1),
          ),
        );
    }

    double h = StandardTextStyle.boundingTextSize(
            widget.model.title,
            TextStyle(
                color: ThemeUtils().currentColorTheme.textGaryColor,
                fontSize: 26))
        .height;
    Widget _buildWebViewX() {
      return WebViewX(
        key: const ValueKey('webviewx'),
        initialContent: widget.model.content,
        initialSourceType: SourceType.html,
        height: screenSize.height - 136 - h - 47,
        width: screenSize.width - 16,
        onWebViewCreated: (controller) => webviewController = controller,
        onPageStarted: (src) =>
            debugPrint('A new page has started loading: $src\n'),
        onPageFinished: (src) =>
            debugPrint('The page has finished loading: $src\n'),
        dartCallBacks: {
          DartCallback(
            name: 'TestDartCallback',
            callBack: (msg) => showSnackBar(msg.toString(), context),
          )
        },
        jsContent: const {
          EmbeddedJsContent(
            js: "document.getElementsByTagName('body')[0].style.webkitTextFillColor= 'white'",
          ),
        },
        webSpecificParams: const WebSpecificParams(
          printDebugInfo: true,
        ),
        mobileSpecificParams: const MobileSpecificParams(
          androidEnableHybridComposition: true,
        ),
        navigationDelegate: (navigation) {
          debugPrint(navigation.content.sourceType.toString());
          return NavigationDecision.navigate;
        },
      );
    }

    Widget titletext = Container(
      alignment: Alignment.centerLeft,
      child: Text(
        widget.model.title,
        maxLines: 2,
        style: TextStyle(
          fontSize: 18,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );
    var Time =
        DateTime.fromMillisecondsSinceEpoch(widget.model.createTime * 1000);

    // var Time = DateTime.fromMillisecondsSinceEpoch(model.createTime * 1000);
    var aTime = Time.toLocal().toString().substring(0, 16);

    Widget Expiredate = Container(
      alignment: Alignment.centerLeft,
      child: Text(
        aTime.toString(),
        style: TextStyle(
          fontSize: 12,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );

    Widget buildRichTextView() {
      return Container(
        height: screenSize.height - 136 - h - 55,
        width: screenSize.width - 16,
        child: ListView(
          children: [
            Container(
                child: HtmlWidget(
              widget.model.content,
              textStyle: TextStyle(
                  color: ThemeUtils().currentColorTheme.labelColorW,
                  fontSize: 15),
            )

                //golobalTextStyle: TextStyle(color: ThemeUtils().currentColorTheme.labelColorW, fontSize: 15)),
                ),
          ],
        ),
      );
    }

    Widget content = Container(
      alignment: Alignment.center,
      // color: ThemeUtils().currentColorTheme.labelColorW,
      child: buildRichTextView(),
    );
    Widget topview = Container(
        // margin: EdgeInsets.all(15),
        padding: EdgeInsets.all(15),
        // color: ThemeUtils().currentColorTheme.contentBG,
        child: Column(children: <Widget>[
          SizedBox(
            height: 5,
          ),
          titletext,
          SizedBox(
            height: 5,
          ),
          Expiredate,
          SizedBox(
            height: 15,
          ),
          content,
          SizedBox(
            height: 5,
          ),
        ]));

    return Scaffold(
      backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
        ),
        backgroundColor: ThemeUtils().currentColorTheme.contentBG,
        title: ThemeUtils.sText(widget.model.title),
      ),
      body: Container(
        // margin: EdgeInsets.only(bottom: 0),
        child: Container(
          // color: ,
          child: Center(
            child: Container(
              child: topview,
            ),
          ),
        ),
      ),
    );
  }
}
