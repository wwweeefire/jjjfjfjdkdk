import 'dart:math';
import 'package:flutter/widgets.dart';
import 'package:heibai/Classes/JCHub/JCHub.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:heibai/Classes/model/BankDes.dart';
import 'package:heibai/Classes/model/UserInfo.dart';
// import 'package:heibai/pages/kchart/utils/date_format_util.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:heibai/util/ThemeUtils.dart';
import 'package:heibai/pages/Views/iconTextIcon.dart';
import 'package:flutter_multi_formatter/flutter_multi_formatter.dart';
import 'package:heibai/net/api/Api.dart';
import 'package:heibai/net/api/app_api.dart';
import 'package:heibai/Classes/model/Rechargemethod.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:heibai/pages/userMsgRow.dart';
import 'dart:io';
import 'package:heibai/pages/login/loginView.dart';
// import 'package:heibai/pages/Withdrawal/WithdDataInfo.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:heibai/Classes/model/config.dart';
import 'package:heibai/Classes/model/USDTModel.dart';
import 'package:material_segmented_control/material_segmented_control.dart';
import 'package:heibai/Classes/model/thirdParty.dart';
import 'package:heibai/Classes/model/zfbParty.dart';
import 'package:heibai/Classes/model/rkfModel.dart';
import 'package:heibai/generated/l10n.dart';
// flutter_advanced_segment
// import 'package:dotte';
import 'dart:typed_data';
import 'package:heibai/pages/CommonWebPage.dart';
import 'package:heibai/pages/CommonAPPwebpage.dart';
import 'package:heibai/pages/Views/TopIconTextButton.dart';
import 'package:flutter/foundation.dart';
import 'package:heibai/constants/Constants.dart';
import 'package:heibai/constants/events/LoginEvent.dart';

class RechargePageDes extends StatefulWidget {
  final ListElement model;
  final String number;

  const RechargePageDes({Key key, this.model, this.number}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return RechargePageDestate();
  }
}

class RechargePageDestate extends State<RechargePageDes> {
  List<BankDes> banklist = [];
  List<UsdtModel> usdtmodel = [];
  List<ZfbParty> zfbParty = [];
  List<ThirdParty> thirdParty = [];
  List<RkfModel> rkfModel = [];
  bool showloading = true;
  void get_recharge_method_info() async {
    Map<String, dynamic> param = {};
    param['code'] = widget.model.code;
    ResultData resultData = await AppApi.getInstance()
        .get_recharge_method_info(context, true, param);
    if (resultData.isSuccess()) {
      if (widget.model.code == 'kf') {
        rkfModel = rkfModelFromJson(resultData.dataJson);
      } else if (widget.model.code == 'bank') {
        banklist = bankDesFromJson(resultData.dataJson);
      } else if (widget.model.code == 'usdt') {
        usdtmodel = usdtModelFromJson(resultData.dataJson);
      } else if (widget.model.code == 'payment') {
        thirdParty = thirdPartyFromJson(resultData.dataJson);
      } else if (widget.model.code == 'alipay') {
        zfbParty = zfbPartyFromJson(resultData.dataJson);
      }

      setState(() {
        showloading = false;
      });
    }
  }

  Widget build(BuildContext context) {
    if (showloading) {
      get_recharge_method_info();
    }

    if (showloading) {
      return Text("");
    } else {
      if (widget.model.code == 'bank') {
        return bankCardpaMent(
          banklist: banklist,
          namemodel: widget.model,
          number: widget.number,
        );
      } else if (widget.model.code == 'usdt') {
        return usdtpayMent(
          model: usdtmodel,
          namemodel: widget.model,
          number: widget.number,
        );
      } else if (widget.model.code == 'payment') {
        return thirdPartylPlatformPage(
          model: thirdParty,
          namemodel: widget.model,
          number: widget.number,
        );
      } else if (widget.model.code == 'alipay') {
        return zfbCardpaMent(
          model: zfbParty,
          namemodel: widget.model,
          number: widget.number,
        );
      } else if (widget.model.code == 'kf') {
        return RkfModelPage(
          model: rkfModel,
          namemodel: widget.model,
          number: widget.number,
        );
      }
    }
  }
}

class bankCardpaMent extends StatefulWidget {
  final List<BankDes> banklist;
  final ListElement namemodel;
  final String number;

  const bankCardpaMent({Key key, this.banklist, this.number, this.namemodel})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return bankCardpaMenttate();
  }
}

class bankCardpaMenttate extends State<bankCardpaMent> {
  String _title;
  String upurl;
  final passwordCtrl = TextEditingController(text: '');
  List<XFile> _imageFileList = List.empty(growable: true); //存放选择的图片
  final ImagePicker _picker = ImagePicker();
  int maxFileCount = 1; //最大选择图片数量
  dynamic _pickImageError;
  int _bigImageIndex = 0; //选中的需要放大的图片的下标
  bool _bigImageVisibility = false; //是否显示预览大图

  //获取当前展示的图的数量
  int getImageCount() {
    if (_imageFileList.length < maxFileCount) {
      return _imageFileList.length + 1;
    } else {
      return _imageFileList.length;
    }
  }

  Widget _handlePreview() {
    return _previewImages();
  }

  Widget _previewImages() {
    //没选满
    if (_imageFileList.length > 0) {
      //需要展示的图片
      return Stack(
        //层叠布局 图片上面要有一个删除的框
        alignment: Alignment.center,

        children: [
          Positioned(
              top: 0.0,
              left: 0.0,
              right: 0.0,
              bottom: 0.0,
              child: GestureDetector(
                child: kIsWeb == true
                    ? Image.network((_imageFileList[0].path))
                    : Image.file(File(_imageFileList[0].path),
                        fit: BoxFit.cover),
                onTap: () => showBigImage(0),
              )),
          Positioned(
            top: 0.0,
            right: 0.0,
            width: 20,
            height: 20,
            child: GestureDetector(
              child: SizedBox(
                child: Image.asset('images/recharge/guanb@3x.png'),
              ),
              onTap: () => _removeImage(0),
            ),
          ),
        ],
      );
      //return Image.file(File(_imageFileList[index].path),fit:BoxFit.cover ,) ;
    } else {
      //显示添加符号

      return kIsWeb == true
          ? DottedBorder(
              color: ThemeUtils().currentColorTheme.labelColorW,
              strokeWidth: 1,
              // dashPattern: [8, 4],
              //手势包含添加按钮 实现点击进行选择图片
              child: InkWell(
                  onTap: () => _onImageButtonPressed(
                        //执行打开相册
                        ImageSource.gallery,
                        context: context,
                        imageQuality: 40, //图片压缩
                      ),
                  child: Container(
                    alignment: Alignment.center,
                    child: Image.asset('images/recharge/gemra.png',
                        width: 30, height: 30),
                  )))
          : DottedBorder(
              color: ThemeUtils().currentColorTheme.labelColorW,
              strokeWidth: 1,
              // dashPattern: [8, 4],
              //手势包含添加按钮 实现点击进行选择图片
              child: Container(
                // color: Colors.red,

                padding: EdgeInsets.only(top: 10, bottom: 1),
                // margin: EdgeInsets.only(top: 0, bottom: 40),
                alignment: Alignment.center,
                child: TopIconTextButton(
                  title: S.current.uploadcertificate,
                  icon: Image.asset('images/recharge/gemra.png',
                      width: 30, height: 30),
                  onTap: () => _onImageButtonPressed(
                    //执行打开相册
                    ImageSource.gallery,
                    context: context,
                    imageQuality: 40, //图片压缩
                  ),
                ),
              ));
    }
  }

  void _onImageButtonPressed(ImageSource source,
      {BuildContext context,
      double maxHeight,
      double maxWidth,
      int imageQuality}) async {
    try {
      final pickedFileList = await _picker.pickMultiImage(
        maxWidth: maxWidth,
        maxHeight: maxHeight,
        imageQuality: imageQuality,
      );
      setState(() {
        //pickedFileList.e
        if (_imageFileList.length < maxFileCount) {
          //小于最大数量
          if ((_imageFileList.length + (pickedFileList?.length ?? 0)) <=
              maxFileCount) {
            //加上新选中的不超过最大数量
            pickedFileList.forEach((element) {
              _imageFileList.add(element);
              uploadimga();
            });
          } else {
            //否则报错
            // Global.showCenterToast("超过可选最大数量!自动移除多余的图片");
            int avaliableCount = maxFileCount - _imageFileList.length;
            for (int i = 0; i < avaliableCount; i++) {
              _imageFileList.add(pickedFileList[i]);
            }
          }
        }
      });
    } catch (e) {
      setState(() {
        // Global.showCenterToast("$_pickImageError");//出现错误的话报错
        _pickImageError = e;

        JCHub.showmsg("$_pickImageError", context);
      });
    }
  }

  void uploadimga() async {
    List<int> byets = await _imageFileList[0].readAsBytes();
    ResultData resultData = await AppApi.getInstance()
        .uploadimage(context, File(_imageFileList[0].path), byets);
    if (resultData.isSuccess()) {
      // DataUtils.saveUserInfo(resultData.dataJson);
      // ConfigManager.
      upurl = resultData.data['file_path'];
      JCHub.showmsg(resultData.msg, context);
      // NavigatorUtil.goToHomeRemovePage(context);
    } else {
      JCHub.showmsg(resultData.msg, context);
    }
  }

  //移除图片
  void _removeImage(int index) {
    setState(() {
      _imageFileList.removeAt(index);
      upurl = '';
    });
  }

  //通过双击小图的时候获取当前需要放大预览的图的下标
  void showBigImage(int index) {
    setState(() {
      _bigImageIndex = index;
      _bigImageVisibility = true;
    });
  }

  //通过大图的双击事件 隐藏大图
  void hiddenBigImage() {
    setState(() {
      _bigImageVisibility = false;
    });
  }

  //展示大图
  Widget displayBigImage() {
    if (_imageFileList.length > _bigImageIndex) {
      return Image.file(File(_imageFileList[_bigImageIndex].path),
          fit: BoxFit.fill);
    } else {
      return null;
    }
  }

  Widget build(BuildContext context) {
    _title = widget.namemodel.name;
    if (widget.banklist.length > 0) {
      BankDes model = widget.banklist.first;
      Widget titletext = Container(
        alignment: Alignment.centerLeft,
        child: Text(
          S.current.bankcardinformation,
          style: TextStyle(
            fontSize: 15,
            // fontWeight: FontWeight.w900,
            color: ThemeUtils().currentColorTheme.textWithdrawColor,
          ),
        ),
      );
      Widget name = Container(
        alignment: Alignment.centerLeft,
        child: Text(
          S.current.PayeeName + model.realName,
          style: TextStyle(
            fontSize: 12,
            // fontWeight: FontWeight.w900,
            color: ThemeUtils().currentColorTheme.textWithdrawColor,
          ),
        ),
      );

      Widget bankname = Container(
        // color: Colors.red,
        alignment: Alignment.centerLeft,
        child: Text(
          S.current.bankcardname + model.bankName,
          style: TextStyle(
            fontSize: 12,
            // fontWeight: FontWeight.w900,
            color: ThemeUtils().currentColorTheme.textWithdrawColor,
          ),
        ),
      );

// 银行卡卡号：6212 8888 8888
      Widget banknumbername = Container(
        alignment: Alignment.centerLeft,
        child: Text(
          S.current.Bankcardnumber + model.cardNumber,
          style: TextStyle(
            fontSize: 12,
            // fontWeight: FontWeight.w900,
            color: ThemeUtils().currentColorTheme.textWithdrawColor,
          ),
        ),
      );

      Widget topview = Column(
        children: <Widget>[
          SizedBox(
            height: 10,
          ),
          titletext,
          SizedBox(
            height: 5,
          ),
          name,
          SizedBox(
            height: 5,
          ),
          bankname,
          SizedBox(
            height: 5,
          ),
          banknumbername,
          SizedBox(
            height: 5,
          ),

          //   height: 5,
          // ),

          SizedBox(
            height: 10,
          ),

          // shellPriceText,
          // SizedBox(
          //   height: 5,
          // ),
          // shellAmounteText
        ],
      );

      Widget btitle = Container(
        alignment: Alignment.centerLeft,
        margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
        child: Text(
          S.current.Uploadtransfervoucher,
          style: TextStyle(
            fontSize: 15,
            // fontWeight: FontWeight.w900,
            color: ThemeUtils().currentColorTheme.textWithdrawColor,
          ),
        ),
      );
      Widget inpuBank = inpuBankNumberWiget(
        title: S.current.Pleaseenterthecardnumber,
        // hight: 40,
        type: TextInputType.number,
        Controller: passwordCtrl,
      );

      Widget photo = Container(
        alignment: Alignment.centerLeft,
        child: SizedBox(
          height: 100,
          width: 100,
          child: _handlePreview(),
        ),
      );

      var PositionBtn = Builder(builder: (ctx) {
        return CommonButton(
            text: S.current.submit,
            color: ThemeUtils().currentColorTheme.labelColorY,
            onTap: () {
              Map<String, dynamic> params = {};

              // if (ncountry != null) {
              //   params["country"] = ncountry.code;
              // }

              params["amount"] = double.parse(widget.number);

              params["method"] = widget.namemodel.id;
              if (upurl.length > 0) {
                params["voucher"] = upurl;
              }

              String username = passwordCtrl.text.trim();
              params["from"] = username;

              params["to"] = model.id;

              pushcomit(context, params);
              // 关闭键盘
              FocusScope.of(context).requestFocus(FocusNode());
            });
      });

      Widget bview = Column(
        children: <Widget>[
          SizedBox(
            height: 10,
          ),
          btitle,
          SizedBox(
            height: 5,
          ),
          inpuBank,
          SizedBox(
            height: 10,
          ),
          photo,
          SizedBox(
            height: 10,
          ),
          PositionBtn,
          SizedBox(
            height: 10,
          ),
        ],
      );
      // final String increase;
      // final String onther;
      Widget bodyviw = Column(
        children: [
          Container(
            color: ThemeUtils().currentColorTheme.contentBG,
            padding: EdgeInsets.only(left: 15),
            margin: EdgeInsets.fromLTRB(20, 20, 20, 20),
            child: topview,
          ),
          Container(
            color: ThemeUtils().currentColorTheme.contentBG,
            padding: EdgeInsets.only(left: 15, right: 15),
            margin: EdgeInsets.fromLTRB(20, 20, 20, 20),
            child: bview,
          ),
        ],
      );

      Widget allviebody = Scaffold(
        backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
        resizeToAvoidBottomInset: false,
        body: bodyviw,
        appBar: AppBar(
          // 如果没有设置这项， 二级页面 会默认是返回箭头  ， 有侧边栏的页面默认有图标（用来打开侧边栏）
          // automaticallyImplyLeading: true,
          // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
          title: Text(_title),
          centerTitle: true,

          backgroundColor: ThemeUtils()
              .currentColorTheme
              .contentBG, // 导航栏的颜色  默认是 ThemeData 的颜色
        ),
      );
      return allviebody;
    } else {
      Widget allviebody = Scaffold(
        backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
        resizeToAvoidBottomInset: false,
        body: Container(),
        appBar: AppBar(
          iconTheme: IconThemeData(
            color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
          ),
          // 如果没有设置这项， 二级页面 会默认是返回箭头  ， 有侧边栏的页面默认有图标（用来打开侧边栏）
          // automaticallyImplyLeading: true,
          // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
          title: ThemeUtils.sText(_title),
          centerTitle: true,

          backgroundColor: ThemeUtils()
              .currentColorTheme
              .contentBG, // 导航栏的颜色  默认是 ThemeData 的颜色
        ),
      );
      return allviebody;
    }
  }
}

class zfbCardpaMent extends StatefulWidget {
  final ListElement namemodel;
  final String number;
  final List<ZfbParty> model;

  const zfbCardpaMent({Key key, this.model, this.number, this.namemodel})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return zfbCardpaMentate();
  }
}

class zfbCardpaMentate extends State<zfbCardpaMent> {
  String _title = "";
  List<XFile> _imageFileList = List.empty(growable: true); //存放选择的图片
  final ImagePicker _picker = ImagePicker();
  int maxFileCount = 1; //最大选择图片数量
  dynamic _pickImageError;
  String upurl;
  int _bigImageIndex = 0; //选中的需要放大的图片的下标
  bool _bigImageVisibility = false; //是否显示预览大图
  final passwordCtrl = TextEditingController(text: '');
  //获取当前展示的图的数量
  int getImageCount() {
    if (_imageFileList.length < maxFileCount) {
      return _imageFileList.length + 1;
    } else {
      return _imageFileList.length;
    }
  }

  Widget _handlePreview() {
    return _previewImages();
  }

  Widget _previewImages() {
    //没选满
    if (_imageFileList.length > 0) {
      //需要展示的图片
      return Stack(
        //层叠布局 图片上面要有一个删除的框
        alignment: Alignment.center,

        children: [
          Positioned(
              top: 0.0,
              left: 0.0,
              right: 0.0,
              bottom: 0.0,
              child: GestureDetector(
                child: kIsWeb == true
                    ? Image.network((_imageFileList[0].path))
                    : Image.file(File(_imageFileList[0].path),
                        fit: BoxFit.cover),
                onTap: () => showBigImage(0),
              )),
          Positioned(
            top: 0.0,
            right: 0.0,
            width: 20,
            height: 20,
            child: GestureDetector(
              child: SizedBox(
                child: Image.asset('images/recharge/guanb@3x.png'),
              ),
              onTap: () => _removeImage(0),
            ),
          ),
        ],
      );
      //return Image.file(File(_imageFileList[index].path),fit:BoxFit.cover ,) ;
    } else {
      //显示添加符号

      return kIsWeb == true
          ? DottedBorder(
              color: ThemeUtils().currentColorTheme.labelColorW,
              strokeWidth: 1,
              // dashPattern: [8, 4],
              //手势包含添加按钮 实现点击进行选择图片
              child: InkWell(
                  onTap: () => _onImageButtonPressed(
                        //执行打开相册
                        ImageSource.gallery,
                        context: context,
                        imageQuality: 40, //图片压缩
                      ),
                  child: Container(
                    alignment: Alignment.center,
                    child: Image.asset('images/recharge/gemra.png',
                        width: 30, height: 30),
                  )))
          : DottedBorder(
              color: ThemeUtils().currentColorTheme.labelColorW,
              strokeWidth: 1,
              // dashPattern: [8, 4],
              //手势包含添加按钮 实现点击进行选择图片
              child: Container(
                // color: Colors.red,

                padding: EdgeInsets.only(top: 10, bottom: 1),
                // margin: EdgeInsets.only(top: 0, bottom: 40),
                alignment: Alignment.center,
                child: TopIconTextButton(
                  title: S.current.uploadcertificate,
                  icon: Image.asset('images/recharge/gemra.png',
                      width: 30, height: 30),
                  onTap: () => _onImageButtonPressed(
                    //执行打开相册
                    ImageSource.gallery,
                    context: context,
                    imageQuality: 40, //图片压缩
                  ),
                ),
              ));
    }
  }

  void _onImageButtonPressed(ImageSource source,
      {BuildContext context,
      double maxHeight,
      double maxWidth,
      int imageQuality}) async {
    try {
      final pickedFileList = await _picker.pickMultiImage(
        maxWidth: maxWidth,
        maxHeight: maxHeight,
        imageQuality: imageQuality,
      );
      setState(() {
        //pickedFileList.e
        if (_imageFileList.length < maxFileCount) {
          //小于最大数量
          if ((_imageFileList.length + (pickedFileList?.length ?? 0)) <=
              maxFileCount) {
            //加上新选中的不超过最大数量
            pickedFileList.forEach((element) {
              _imageFileList.add(element);
              uploadimga();
            });
          } else {
            //否则报错
            // Global.showCenterToast("超过可选最大数量!自动移除多余的图片");
            int avaliableCount = maxFileCount - _imageFileList.length;
            for (int i = 0; i < avaliableCount; i++) {
              _imageFileList.add(pickedFileList[i]);
            }
          }
        }
      });
    } catch (e) {
      setState(() {
        // Global.showCenterToast("$_pickImageError");//出现错误的话报错
        _pickImageError = e;
        JCHub.showmsg("$_pickImageError", context);
      });
    }
  }

  void uploadimga() async {
    List<int> byets = await _imageFileList[0].readAsBytes();
    ResultData resultData = await AppApi.getInstance()
        .uploadimage(context, File(_imageFileList[0].path), byets);
    if (resultData.isSuccess()) {
      // DataUtils.saveUserInfo(resultData.dataJson);
      // ConfigManager.
      upurl = resultData.data['file_path'];
      JCHub.showmsg(resultData.msg, context);
      // NavigatorUtil.goToHomeRemovePage(context);
    } else {
      JCHub.showmsg(resultData.msg, context);
    }
  }

  //移除图片
  void _removeImage(int index) {
    setState(() {
      _imageFileList.removeAt(index);
      upurl = '';
    });
  }

  //通过双击小图的时候获取当前需要放大预览的图的下标
  void showBigImage(int index) {
    setState(() {
      _bigImageIndex = index;
      _bigImageVisibility = true;
    });
  }

  //通过大图的双击事件 隐藏大图
  void hiddenBigImage() {
    setState(() {
      _bigImageVisibility = false;
    });
  }

  //展示大图
  Widget displayBigImage() {
    if (_imageFileList.length > _bigImageIndex) {
      return Image.file(File(_imageFileList[_bigImageIndex].path),
          fit: BoxFit.fill);
    } else {
      return null;
    }
  }

  Widget build(BuildContext context) {
    _title = widget.namemodel.name;
    ZfbParty zfbmodel = widget.model.first;
    Widget titletext = Container(
      alignment: Alignment.centerLeft,
      child: Text(
        S.current.Alipaynformation,
        style: TextStyle(
          fontSize: 15,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );
    Widget name = Container(
      alignment: Alignment.centerLeft,
      child: Text(
        S.current.PayeeName + zfbmodel.realName,
        style: TextStyle(
          fontSize: 12,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );

// 银行卡卡号：6212 8888 8888
    Widget bankname = Container(
      alignment: Alignment.centerLeft,
      child: Text(
        S.current.Alipayaccount + zfbmodel.account,
        style: TextStyle(
          fontSize: 12,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );
    Widget banknumbername = Container(
      alignment: Alignment.centerLeft,
      child: Text(
        S.current.Alipayreceiptcode,
        style: TextStyle(
          fontSize: 12,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );

    Widget qrimag = Container(
      color: ThemeUtils().currentColorTheme.labelColorW,
      alignment: Alignment.center,
      height: 150,
      width: 150,
      child: CachedNetworkImage(
        imageUrl: "++",
        placeholder: (context, url) => Image.asset(
          "images/recharge/bankPay@3x.png",
        ),
        errorWidget: (context, url, error) => Image.asset(
          "images/recharge/bankPay@3x.png",
        ),
      ),
    );

    Widget ftext = Container(
      alignment: Alignment.center,
      child: Text(
        "",
        style: TextStyle(
          fontSize: 13,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );
    Widget topview = Column(
      children: <Widget>[
        SizedBox(
          height: 5,
        ),
        titletext,
        SizedBox(
          height: 5,
        ),
        name,
        SizedBox(
          height: 5,
        ),
        bankname,
        SizedBox(
          height: 5,
        ),
        banknumbername,
        SizedBox(
          height: 5,
        ),
        qrimag,
        //   height: 5,
        // ),

        SizedBox(
          height: 5,
        ),
        ftext,
        SizedBox(
          height: 5,
        ),
        // shellPriceText,
        // SizedBox(
        //   height: 5,
        // ),
        // shellAmounteText
      ],
    );

    Widget btitle = Container(
      alignment: Alignment.centerLeft,
      // margin: EdgeInsets.fromLTRB(15, 0, 0, 0),
      child: Text(
        S.current.Uploadtransfervoucher,
        style: TextStyle(
          fontSize: 15,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );
    Widget inpuBank = inpuBankNumberWiget(
      title: S.current.Pleaseenteraddress,
      hight: 40,
      Controller: passwordCtrl,
      type: TextInputType.text,
    );

    Widget photo = Container(
      alignment: Alignment.centerLeft,
      child: SizedBox(
        height: 100,
        width: 100,
        child: _handlePreview(),
      ),
    );

    var PositionBtn = Builder(builder: (ctx) {
      return CommonButton(
          text: S.current.submit,
          color: ThemeUtils().currentColorTheme.labelColorY,
          onTap: () {
            // 关闭键盘

            // 发送给webview，让webview登录后再取回token
            // autoLogin(username, password);

            Map<String, dynamic> params = {};

            // if (ncountry != null) {
            //   params["country"] = ncountry.code;
            // }

            params["amount"] = double.parse(widget.number);

            params["method"] = widget.namemodel.id;
            if (upurl.length > 0) {
              params["voucher"] = upurl;
            }

            String username = passwordCtrl.text.trim();
            params["from"] = username;

            params["to"] = zfbmodel.id;

            pushcomit(context, params);
            // 关闭键盘
            FocusScope.of(context).requestFocus(FocusNode());
          });
    });

    Widget bview = Column(
      children: <Widget>[
        SizedBox(
          height: 5,
        ),
        btitle,
        SizedBox(
          height: 5,
        ),
        inpuBank,
        SizedBox(
          height: 10,
        ),
        photo,
        SizedBox(
          height: 5,
        ),
        PositionBtn
      ],
    );
    // final String increase;
    // final String onther;
    Widget bodyviw = Column(
      children: [
        Container(
          color: ThemeUtils().currentColorTheme.contentBG,
          padding: EdgeInsets.only(left: 15),
          margin: EdgeInsets.fromLTRB(20, 20, 20, 20),
          child: topview,
        ),
        Container(
          color: ThemeUtils().currentColorTheme.contentBG,
          padding: EdgeInsets.only(left: 15, right: 15),
          margin: EdgeInsets.fromLTRB(20, 20, 20, 20),
          child: bview,
        ),
      ],
    );

    Widget allviebody = Scaffold(
      backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
      resizeToAvoidBottomInset: false,
      body: bodyviw,
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
        ),
        // 如果没有设置这项， 二级页面 会默认是返回箭头  ， 有侧边栏的页面默认有图标（用来打开侧边栏）
        // automaticallyImplyLeading: true,
        // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
        title: ThemeUtils.sText(_title),
        centerTitle: true,

        backgroundColor: ThemeUtils()
            .currentColorTheme
            .contentBG, // 导航栏的颜色  默认是 ThemeData 的颜色
      ),
    );
    return allviebody;
  }
}

class usdtpayMent extends StatefulWidget {
  final List<UsdtModel> model;
  final String number;
  final ListElement namemodel;

  const usdtpayMent({Key key, this.model, this.number, this.namemodel})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return usdtpayMentMentate();
  }
}

class usdtpayMentMentate extends State<usdtpayMent> {
  String upurl;
  final passwordCtrl = TextEditingController(text: '');
  String _title = "";
  List<XFile> _imageFileList = List.empty(growable: true); //存放选择的图片
  final ImagePicker _picker = ImagePicker();
  int maxFileCount = 1; //最大选择图片数量
  dynamic _pickImageError;
  int _bigImageIndex = 0; //选中的需要放大的图片的下标
  bool _bigImageVisibility = false; //是否显示预览大图

  //获取当前展示的图的数量
  int getImageCount() {
    if (_imageFileList.length < maxFileCount) {
      return _imageFileList.length + 1;
    } else {
      return _imageFileList.length;
    }
  }

  Widget _handlePreview() {
    return _previewImages();
  }

  Widget _previewImages() {
    //没选满
    if (_imageFileList.length > 0) {
      //需要展示的图片
      return Stack(
        //层叠布局 图片上面要有一个删除的框
        alignment: Alignment.center,

        children: [
          Positioned(
              top: 0.0,
              left: 0.0,
              right: 0.0,
              bottom: 0.0,
              child: GestureDetector(
                child: kIsWeb == true
                    ? Image.network((_imageFileList[0].path))
                    : Image.file(File(_imageFileList[0].path),
                        fit: BoxFit.cover),
                onTap: () => showBigImage(0),
              )),
          Positioned(
            top: 0.0,
            right: 0.0,
            width: 20,
            height: 20,
            child: GestureDetector(
              child: SizedBox(
                child: Image.asset('images/recharge/guanb@3x.png'),
              ),
              onTap: () => _removeImage(0),
            ),
          ),
        ],
      );
      //return Image.file(File(_imageFileList[index].path),fit:BoxFit.cover ,) ;
    } else {
      //显示添加符号

      return kIsWeb == true
          ? DottedBorder(
              color: ThemeUtils().currentColorTheme.labelColorW,
              strokeWidth: 1,
              // dashPattern: [8, 4],
              //手势包含添加按钮 实现点击进行选择图片
              child: InkWell(
                  onTap: () => _onImageButtonPressed(
                        //执行打开相册
                        ImageSource.gallery,
                        context: context,
                        imageQuality: 40, //图片压缩
                      ),
                  child: Container(
                    alignment: Alignment.center,
                    child: Image.asset('images/recharge/gemra.png',
                        width: 30, height: 30),
                  )))
          : DottedBorder(
              color: ThemeUtils().currentColorTheme.labelColorW,
              strokeWidth: 1,
              // dashPattern: [8, 4],
              //手势包含添加按钮 实现点击进行选择图片
              child: Container(
                // color: Colors.red,

                padding: EdgeInsets.only(top: 10, bottom: 1),
                // margin: EdgeInsets.only(top: 0, bottom: 40),
                alignment: Alignment.center,
                child: TopIconTextButton(
                  title: S.current.uploadcertificate,
                  icon: Image.asset('images/recharge/gemra.png',
                      width: 30, height: 30),
                  onTap: () => _onImageButtonPressed(
                    //执行打开相册
                    ImageSource.gallery,
                    context: context,
                    imageQuality: 40, //图片压缩
                  ),
                ),
              ));
    }
  }

  void _onImageButtonPressed(ImageSource source,
      {BuildContext context,
      double maxHeight,
      double maxWidth,
      int imageQuality}) async {
    try {
      final pickedFileList = await _picker.pickMultiImage(
        maxWidth: maxWidth,
        maxHeight: maxHeight,
        imageQuality: imageQuality,
      );
      setState(() {
        //pickedFileList.e
        if (_imageFileList.length < maxFileCount) {
          //小于最大数量
          if ((_imageFileList.length + (pickedFileList?.length ?? 0)) <=
              maxFileCount) {
            //加上新选中的不超过最大数量
            pickedFileList.forEach((element) {
              _imageFileList.add(element);
              uploadimga();
            });
          } else {
            //否则报错
            // Global.showCenterToast("超过可选最大数量!自动移除多余的图片");
            int avaliableCount = maxFileCount - _imageFileList.length;
            for (int i = 0; i < avaliableCount; i++) {
              _imageFileList.add(pickedFileList[i]);
            }
          }
        }
      });
    } catch (e) {
      setState(() {
        // Global.showCenterToast("$_pickImageError");//出现错误的话报错
        _pickImageError = e;
        JCHub.showmsg("$_pickImageError", context);
      });
    }
  }

  void uploadimga() async {
    List<int> byets = await _imageFileList[0].readAsBytes();
    ResultData resultData = await AppApi.getInstance()
        .uploadimage(context, File(_imageFileList[0].path), byets);
    if (resultData.isSuccess()) {
      // DataUtils.saveUserInfo(resultData.dataJson);
      // ConfigManager.
      upurl = resultData.data['file_path'];
      JCHub.showmsg(resultData.msg, context);
      // NavigatorUtil.goToHomeRemovePage(context);
    } else {
      JCHub.showmsg(resultData.msg, context);
    }
  }

  //移除图片
  void _removeImage(int index) {
    setState(() {
      _imageFileList.removeAt(index);
      upurl = '';
    });
  }

  //通过双击小图的时候获取当前需要放大预览的图的下标
  void showBigImage(int index) {
    setState(() {
      _bigImageIndex = index;
      _bigImageVisibility = true;
    });
  }

  //通过大图的双击事件 隐藏大图
  void hiddenBigImage() {
    setState(() {
      _bigImageVisibility = false;
    });
  }

  //展示大图
  Widget displayBigImage() {
    if (_imageFileList.length > _bigImageIndex) {
      return Image.file(File(_imageFileList[_bigImageIndex].path),
          fit: BoxFit.fill);
    } else {
      return null;
    }
  }

// Create a controller
  int _currentSelection = 0;
  Map<int, Widget> _children = {
    0: Container(alignment: Alignment.center, width: 60, child: Text('ERC')),
    1: Container(alignment: Alignment.center, width: 60, child: Text('TRC')),
  };
  Widget build(BuildContext context) {
    _title = widget.namemodel.name;
    UsdtModel usdt = widget.model[_currentSelection];

    // Create a controller

//...
    // Widget titletext =;

//
    Widget titletext = Container(
      // alignment: Alignment.centerLeft,
      // width: 200,
      // color: Colors.red,
      child: MaterialSegmentedControl(
        children: _children,
        selectionIndex: _currentSelection,
        borderColor: Colors.grey,
        selectedColor: ThemeUtils().currentColorTheme.labelColorY,
        unselectedColor: ThemeUtils().currentColorTheme.labelColorW,
        borderRadius: 1.0,
        onSegmentChosen: (value) {
          setState(() {
            _currentSelection = value;
          });
        },
      ),
    );
    Widget name = Container(
      alignment: Alignment.centerLeft,
      child: Text(
        S.current.USDTinformation,
        style: TextStyle(
          fontSize: 12,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );

// 银行卡卡号：6212 8888 8888
    Widget bankname = Container(
      alignment: Alignment.centerLeft,
      child: Text(
        S.current.USDTaddress + usdt.address,
        style: TextStyle(
          fontSize: 12,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );
    Widget banknumbername = Container(
      alignment: Alignment.centerLeft,
      child: Text(
        S.current.USDTcode,
        style: TextStyle(
          fontSize: 12,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );

    // Widget qrimag = Container(
    //   color: ThemeUtils().currentColorTheme.labelColorW,
    //   alignment: Alignment.center,
    //   height: 150,
    //   width: 150,
    //   child: CachedNetworkImage(
    //     imageUrl:  ConfigManager().imageHost + usdt.proto.toString(),
    //     placeholder: (context, url) => Image.asset(
    //       "images/recharge/bankPay@3x.png",
    //     ),
    //     errorWidget: (context, url, error) => Image.asset(
    //       "images/recharge/bankPay@3x.png",
    //     ),
    //   ),
    // );

    Widget qrimag = Container(
      color: ThemeUtils().currentColorTheme.labelColorW,
      child: QrImage(
        data: usdt.address,
        version: QrVersions.auto,
        size: 221,
        gapless: false,
      ),
    );

    Widget ftext = Container(
      alignment: Alignment.center,
      child: Text(
        "",
        style: TextStyle(
          fontSize: 13,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );
    Widget topview = Column(
      children: <Widget>[
        SizedBox(
          height: 10,
        ),
        titletext,
        SizedBox(
          height: 5,
        ),
        name,
        SizedBox(
          height: 5,
        ),
        bankname,
        SizedBox(
          height: 5,
        ),
        banknumbername,
        SizedBox(
          height: 5,
        ),
        qrimag,
        //   height: 5,
        // ),

        SizedBox(
          height: 5,
        ),
        ftext,
        SizedBox(
          height: 5,
        ),
        // shellPriceText,
        // SizedBox(
        //   height: 5,
        // ),
        // shellAmounteText
      ],
    );

    Widget btitle = Container(
      alignment: Alignment.centerLeft,
      // margin: EdgeInsets.fromLTRB(15, 0, 0, 0),
      child: Text(
        S.current.Uploadtransfervoucher,
        style: TextStyle(
          fontSize: 15,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );
    Widget inpuBank = inpuBankNumberWiget(
      title: S.current.Pleaseenteraddress,
      hight: 40,
      Controller: passwordCtrl,
      type: TextInputType.text,
    );

    Widget photo = Container(
      alignment: Alignment.centerLeft,
      child: SizedBox(
        height: 100,
        width: 100,
        child: _handlePreview(),
      ),
    );
    var PositionBtn = Builder(builder: (ctx) {
      return CommonButton(
          text: S.current.submit,
          color: ThemeUtils().currentColorTheme.labelColorY,
          onTap: () {
            // 关闭键盘

            // 发送给webview，让webview登录后再取回token
            // autoLogin(username, password);

            Map<String, dynamic> params = {};

            // if (ncountry != null) {
            //   params["country"] = ncountry.code;
            // }

            params["amount"] = double.parse(widget.number);

            params["method"] = widget.namemodel.id;
            if (upurl.length > 0) {
              params["voucher"] = upurl;
            }

            String username = passwordCtrl.text.trim();
            params["from"] = username;

            params["to"] = usdt.id;

            pushcomit(context, params);
            // 关闭键盘
            FocusScope.of(context).requestFocus(FocusNode());
          });
    });

    Widget bview = Column(
      children: <Widget>[
        SizedBox(
          height: 10,
        ),
        btitle,
        SizedBox(
          height: 5,
        ),
        inpuBank,
        SizedBox(
          height: 10,
        ),
        photo,
        SizedBox(
          height: 10,
        ),
        PositionBtn,
        SizedBox(
          height: 10,
        ),
      ],
    );
    // final String increase;
    // final String onther;
    Widget bodyviw = Column(
      children: [
        Container(
          padding: EdgeInsets.only(left: 15),
          color: ThemeUtils().currentColorTheme.contentBG,
          margin: EdgeInsets.fromLTRB(15, 20, 15, 20),
          child: topview,
        ),
        Container(
          color: ThemeUtils().currentColorTheme.contentBG,
          padding: EdgeInsets.only(left: 15),
          margin: EdgeInsets.fromLTRB(15, 10, 15, 20),
          child: bview,
        ),
      ],
    );

    Widget allviebody = Scaffold(
      backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
      resizeToAvoidBottomInset: false,
      body: ListView(
        children: [bodyviw],
      ),
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
        ),
        // 如果没有设置这项， 二级页面 会默认是返回箭头  ， 有侧边栏的页面默认有图标（用来打开侧边栏）
        // automaticallyImplyLeading: true,
        // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
        title: ThemeUtils.sText(_title),
        centerTitle: true,

        backgroundColor: ThemeUtils()
            .currentColorTheme
            .contentBG, // 导航栏的颜色  默认是 ThemeData 的颜色
      ),
    );
    return allviebody;
  }
}

pushcomit(BuildContext context, Map<String, dynamic> params) async {
  ResultData resultData =
      await AppApi.getInstance().post_recharge_create(context, true, params);
  if (resultData.isSuccess()) {
    //  DataUtils.saveUserInfo(resultData.dataJson);
    // ConfigManager.
    Constants.eventBus.fire(LoginEvent());
    Navigator.pop(context);
    JCHub.showmsg(S.current.Submittedsuccessfullywaitingforreview, context);
  } else {
    JCHub.showmsg(resultData.msg, context);
  }
}

class thirdPartylPlatformPage extends StatefulWidget {
  final List<ThirdParty> model;
  final String number;
  final ListElement namemodel;
  const thirdPartylPlatformPage(
      {Key key, this.model, this.number, this.namemodel})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return thirdPartylPlatformPageState();
  }
}

class thirdPartylPlatformPageState extends State<thirdPartylPlatformPage> {
  // Widget build(BuildContext context) {
  //
  //  Widget ad = Container();
  //   return ad;
  // }
  thirdPartypushcomit(BuildContext context, Map<String, dynamic> params) async {
    ResultData resultData =
        await AppApi.getInstance().post_recharge_create(context, true, params);
    if (resultData.isSuccess()) {
      //  DataUtils.saveUserInfo(resultData.dataJson);
      // ConfigManager.
      // Navigator.pop(context);
      Constants.eventBus.fire(LoginEvent());
      // JCHub.showmsg(S.current.Submittedsuccessfullywaitingforreview, context);
      var baidu = "https://www.google.com/";
      if (resultData.data != null) {
        baidu = resultData.data['url'];
        if (baidu == null) {
          baidu = "https://www.google.com/";
        }
      }

      if (kIsWeb) {
        final result = await Navigator.of(context)
            .push(MaterialPageRoute(builder: (context) {
          return CommonWebPage(
            htmlContent: baidu,
            title: widget.namemodel.name,
          );
        }));
      } else {
        final result = await Navigator.of(context)
            .push(MaterialPageRoute(builder: (context) {
          return CommonAPPwebpage(
            htmlContent: baidu,
            title: widget.namemodel.name,
          );
        }));
      }
    } else {
      JCHub.showmsg(resultData.msg, context);
    }
  }

  Widget build(BuildContext context) {
    var _title = widget.namemodel.name;
    renderRow(i) {
      // Product pro = model.category[index].product[i];
      ThirdParty m = widget.model[i];
      var titlename = m.name;
      var path = ConfigManager().imageHost + m.icon;

      var rowitem = iconTextIcon(
        onTap: () {
          // }));

          Map<String, dynamic> params = {};

          // if (ncountry != null) {
          //   params["country"] = ncountry.code;
          // }

          params["amount"] = double.parse(widget.number);

          params["method"] = widget.namemodel.id;
          // if (upurl.length > 0) {
          //   params["voucher"] = upurl;
          // // }

          // String username = ConfigManager().user.username;
          params["channel_id"] = m.id;

          params["to"] = m.id;

          thirdPartypushcomit(context, params);
        },
        icon: CachedNetworkImage(
          imageUrl: path,
          placeholder: (context, url) => Image.asset(
            "images/recharge/bankPay@3x.png",
          ),
          errorWidget: (context, url, error) => Image.asset(
            "images/recharge/bankPay@3x.png",
          ),
        ),
        title: titlename,
        rightImage: Image.asset(
          "images/wode/xyy@3x.png",
          width: 19,
          height: 13,
        ),
      );

      return rowitem;
    }

    var listView = ListView.builder(
      shrinkWrap: true, //解决无限高度问题
      // physics: new NeverScrollableScrollPhysics(), //禁用滑动事件
      itemCount: widget.model == null ? 0 : widget.model.length,
      scrollDirection: Axis.vertical,
      itemBuilder: (context, i) => renderRow(i),
    );

    Widget body = Container(
      child: listView,
    );

    Widget allviebody = Scaffold(
      backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
      body: body,
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
        ),
        // 如果没有设置这项， 二级页面 会默认是返回箭头  ， 有侧边栏的页面默认有图标（用来打开侧边栏）
        // automaticallyImplyLeading: true,
        // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
        title: ThemeUtils.sText(_title),
        centerTitle: true,
        //  actions: <Widget>[
        //     IconButton(
        //         icon: Icon(Icons.add_alarm),
        //         tooltip: 'Add Alarm',
        //         onPressed: () {
        //           // do nothing
        //         })
        //   ],   // 标题是否在居中

//          elevation: 0.1, // 导航栏Z轴的高度，默认是1  默认就是有高度 阴影的
        backgroundColor: ThemeUtils()
            .currentColorTheme
            .contentBG, // 导航栏的颜色  默认是 ThemeData 的颜色
//         flexibleSpace: FlexibleSpaceBar(title: Text("你号"),),//这个堆叠在工具栏上面  一般 appbar不用  主要用在 SliverAppBar上
//          brightness: Brightness.light, //状态栏的深度 有白色和黑色两种主题
//          titleSpacing: 10,//flexibleSpace 和 title 的距离  默认是重合的
//          toolbarOpacity: 0.5,// 导航栏透明度 默认是1 ，不包括flexibleSpace
//          bottomOpacity: 0.5,
      ),
    );
    return allviebody;
  }
}

class RkfModelPage extends StatefulWidget {
  final List<RkfModel> model;
  final String number;
  final ListElement namemodel;
  const RkfModelPage({Key key, this.model, this.number, this.namemodel})
      : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return RkfModelPageState(number);
  }
}

class RkfModelPageState extends State<RkfModelPage> {
  String number;

  RkfModelPageState(
    this.number,
  );
  // Widget build(BuildContext context) {
  //
  //  Widget ad = Container();
  //   return ad;
  // }
  // }
  kfpushcomit(
      BuildContext context, Map<String, dynamic> params, RkfModel m) async {
    ResultData resultData =
        await AppApi.getInstance().post_recharge_create(context, true, params);
    if (resultData.isSuccess()) {
      //  DataUtils.saveUserInfo(resultData.dataJson);
      // ConfigManager.
      // Navigator.pop(context);
      // JCHub.showmsg(S.current.Submittedsuccessfullywaitingforreview, context);
      var baidu = m.link;
      var kfid = m.id;
      number = '0';
      Constants.eventBus.fire(LoginEvent());
      var userid = ConfigManager().user.id;
      if (kIsWeb) {
        final result = await Navigator.of(context)
            .push(MaterialPageRoute(builder: (context) {
          return CommonWebPage(
            htmlContent: baidu + "?id=$kfid&uid=$userid",
            title: S.current.KF,
          );
        }));
      } else {
        final result = await Navigator.of(context)
            .push(MaterialPageRoute(builder: (context) {
          return CommonAPPwebpage(
            htmlContent: baidu + "?id=$kfid&uid=$userid",
            title: S.current.KF,
          );
        }));
      }
    } else {
      JCHub.showmsg(resultData.msg, context);
    }
  }

  Widget build(BuildContext context) {
    var _title = widget.namemodel.name;
    renderRow(i) {
      // Product pro = model.category[index].product[i];
      RkfModel m = widget.model[i];
      var titlename = m.name;
      // var path =  ConfigManager().imageHost + m.icon;

      var rowitem = iconTextIcon(
        onTap: () {
          if (number == "0") {
            Navigator.of(context).pop();
            return;
          }
          Map<String, dynamic> params = {};

          // if (ncountry != null) {
          //   params["country"] = ncountry.code;
          // }

          params["amount"] = double.parse(number);

          params["method"] = widget.namemodel.id;
          // if (upurl.length > 0) {
          //   params["voucher"] = upurl;
          // // }

          String username = ConfigManager().user.id.toString();
          params["channel_id"] = m.id;
          params["uid"] = username;

          params["to"] = m.id;

          // }));
          kfpushcomit(context, params, m);
        },
        icon: Image.asset(
          "images/recharge/kfczPay@3x.png",
        ),
        title: titlename,
        rightImage: Image.asset(
          "images/wode/xyy@3x.png",
          width: 19,
          height: 13,
        ),
      );

      return rowitem;
    }

    var listView = ListView.builder(
      shrinkWrap: true, //解决无限高度问题
      // physics: new NeverScrollableScrollPhysics(), //禁用滑动事件
      itemCount: widget.model == null ? 0 : widget.model.length,
      scrollDirection: Axis.vertical,
      itemBuilder: (context, i) => renderRow(i),
    );

    Widget body = Container(
      child: listView,
    );

    Widget allviebody = Scaffold(
      backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
      body: body,
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
        ),
        // 如果没有设置这项， 二级页面 会默认是返回箭头  ， 有侧边栏的页面默认有图标（用来打开侧边栏）
        // automaticallyImplyLeading: true,
        // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
        title: ThemeUtils.sText(_title),
        centerTitle: true,
        //  actions: <Widget>[
        //     IconButton(
        //         icon: Icon(Icons.add_alarm),
        //         tooltip: 'Add Alarm',
        //         onPressed: () {
        //           // do nothing
        //         })
        //   ],   // 标题是否在居中

//          elevation: 0.1, // 导航栏Z轴的高度，默认是1  默认就是有高度 阴影的
        backgroundColor: ThemeUtils()
            .currentColorTheme
            .contentBG, // 导航栏的颜色  默认是 ThemeData 的颜色
//         flexibleSpace: FlexibleSpaceBar(title: Text("你号"),),//这个堆叠在工具栏上面  一般 appbar不用  主要用在 SliverAppBar上
//          brightness: Brightness.light, //状态栏的深度 有白色和黑色两种主题
//          titleSpacing: 10,//flexibleSpace 和 title 的距离  默认是重合的
//          toolbarOpacity: 0.5,// 导航栏透明度 默认是1 ，不包括flexibleSpace
//          bottomOpacity: 0.5,
      ),
    );
    return allviebody;
  }
}

class inpuBankNumberWiget extends StatelessWidget {
  final String title;
  final TextInputType type;
  final int hight;
  final TextEditingController Controller;

  const inpuBankNumberWiget(
      {Key key, this.title, this.type, this.hight, this.Controller})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    int he = hight;
    if (he == null) {
      he = 50;
    }

    return Container(
      child: Container(
        padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
        // margin: EdgeInsets.fromLTRB(15, 5, 15, 5),
        color: ThemeUtils().currentColorTheme.defaultColor,
        height: 50,
        child: new SizedBox(
          child: new Container(
            height: he.toDouble(),
            color: ThemeUtils().currentColorTheme.defaultColor,
            alignment: Alignment.center,
            child: TextField(
              keyboardType: type,
              maxLines: 1,
              controller: Controller,
              decoration: InputDecoration(
                hintText: title,
                border: InputBorder.none,
                hintStyle: TextStyle(
                  fontSize: 12,
                  color: ThemeUtils().currentColorTheme.textGaryColor,
                ),
              ),
              style: TextStyle(
                fontSize: 12,
                color: ThemeUtils().currentColorTheme.textWithdrawColor,
              ),
            ),
          ),
        ),
      ),
    );
    // TODO: implement build
  }
}
