import 'dart:math';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:heibai/Classes/model/config.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'package:fluttertoast/fluttertoast.dart';

import 'package:heibai/util/ThemeUtils.dart';
import 'package:heibai/pages/Views/iconTextIcon.dart';
import 'package:flutter_multi_formatter/flutter_multi_formatter.dart';
import 'package:heibai/net/api/Api.dart';
import 'package:heibai/net/api/app_api.dart';
import 'package:heibai/Classes/model/Rechargemethod.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:heibai/pages/userMsgRow.dart';
import 'dart:io';
import 'package:heibai/pages/login/loginView.dart';
import 'package:heibai/Classes/JCHub/JCHub.dart';
import 'package:heibai/pages/Recharge/RechargePageDes.dart';
import 'package:heibai/generated/l10n.dart';

class RechargePage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return RechargePageState();
  }
}

class RechargePageState extends State<RechargePage> {
  var cureeindex = -1;
  bool showloading = true;
  Rechargemethod cmodel;
  TextEditingController _controller;

  var titlename;
  var idindex = 0;
  var path;
  var pathicon;

  void get_config() async {
    Map<String, dynamic> param = {};
    ResultData resultData =
        await AppApi.getInstance().get_recharge_method(context, true, param);
    if (resultData.isSuccess()) {
      Rechargemethod model = rechargemethodFromJson(resultData.dataJson);
      cmodel = model;

      showloading = false;
      ListElement m = model.list.first;
      titlename = m.name;
      path = m.icon;

      idindex = 0;
      setState(() {
        ListElement m = model.list.first;
        titlename = m.name;
        path = m.icon;
        showloading = false;

        if (m.code == 'kf') {
          pathicon = "images/recharge/kfczPay@3x.png";
        } else if (m.code == 'bank') {
          pathicon = "images/recharge/bankPay@3x.png";
        } else if (m.code == 'usdt') {
          pathicon = "images/recharge/USDTPay@3x.png";
        } else if (m.code == 'payment') {
          pathicon = "images/recharge/ThirdPay@3x.png";
        } else if (m.code == 'alipay') {
          pathicon = "images/recharge/zfbPay@3x.png";
        }
      });
    }
  }

  @override
  void initState() {
    super.initState();
    // get_config();
    setState(() {
      _controller = new TextEditingController(text: '');
    });
  }

  Widget build(BuildContext context) {
    YYDialog.init(context);
    if (showloading == true) {
      get_config();
    }
    final mediaQueryData = MediaQuery.of(context);

// 2.获取宽度和高度
    final screenWidth = mediaQueryData.size.width;
    final screenHeight = mediaQueryData.size.height;

    final statusBarHeight = mediaQueryData.padding.top;
// 有刘海的屏幕:34 没有刘海的屏幕0
    double bottomHeight = 10.0;

    if (!kIsWeb) {
      if (Platform.isIOS) {
        bottomHeight = mediaQueryData.padding.bottom;
      }
    }

    Widget textbody = showloading == true
        ? Container()
        : Container(
            margin: EdgeInsets.fromLTRB(15, 0, 15, 0),
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.only(left: 10),
            // height: 20,
            child: Text(
              S.current.Rechargemethod,
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w900,
                color: ThemeUtils().currentColorTheme.textWithdrawColor,
              ),
            ),
          );
    Widget titleview = showloading == true
        ? Container()
        : Container(
            child: iconTextIcon(
              onTap: () {
                FocusScope.of(context).requestFocus(FocusNode());
                YYPaylistDialogWithGravity(
                    gravity: Gravity.bottom,
                    width: 262 + bottomHeight,
                    model: cmodel,
                    tap: (indx) {
                      // if (indx > 0) {

                      setState(() {
                        ListElement m = cmodel.list[indx];
                        titlename = m.name;
                        idindex = indx;
                        path = m.icon;

                        if (m.code == 'kf') {
                          pathicon = "images/recharge/kfczPay@3x.png";
                        } else if (m.code == 'bank') {
                          pathicon = "images/recharge/bankPay@3x.png";
                        } else if (m.code == 'usdt') {
                          pathicon = "images/recharge/USDTPay@3x.png";
                        } else if (m.code == 'payment') {
                          pathicon = "images/recharge/ThirdPay@3x.png";
                        } else if (m.code == 'alipay') {
                          pathicon = "images/recharge/zfbPay@3x.png";
                        }
                      });
                      // }
                      Navigator.pop(context);
                    });
              },
              icon: CachedNetworkImage(
                imageUrl: path,
                fit: BoxFit.cover,
                placeholder: (context, url) => Image.asset(
                  pathicon,
                  width: 72,
                  height: 72,
                ),
                errorWidget: (context, url, error) => Image.asset(
                  pathicon,
                  width: 72,
                  height: 72,
                ),
              ),
              title: titlename,
              rightImage: Image.asset(
                "images/wode/xyy@3x.png",
                width: 19,
                height: 13,
              ),
            ),
          );
    Widget textbodyview = Container(
      margin: EdgeInsets.fromLTRB(15, 0, 15, 0),
      alignment: Alignment.centerLeft,
      padding: EdgeInsets.only(left: 10),
      // height: 20,
      child: Text(
        S.current.Rechargeamount,
        style: TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );

    Widget inputMoneyWiget = Container(
      padding: EdgeInsets.fromLTRB(10, 2, 8, 2),
      // decoration: BoxDecoration(
      //   borderRadius: BorderRadius.circular(30),
      //   color: ThemeUtils().currentColorTheme.labelColorW,
      // ),
      margin: EdgeInsets.fromLTRB(15, 0, 15, 0),
      color: ThemeUtils().currentColorTheme.contentBG,
      alignment: Alignment.center,
      child: TextFormField(
        controller: _controller,
        // initialValue: initstr,
        maxLines: 1,
        keyboardType: TextInputType.number,
        // inputFormatters: [
        //   PosInputFormatter(),
        // ],
        decoration: InputDecoration(
          hintText: ConfigManager().config.base.symbolFlag,
          hintStyle: TextStyle(
            fontSize: 24,
            color: ThemeUtils().currentColorTheme.textWithdrawColor,
          ),
          border: InputBorder.none,
        ),
        style: TextStyle(
          fontSize: 24,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );

    var loginBtn = Builder(builder: (ctx) {
      return CommonButton(
          text: S.current.recharge,
          color: ThemeUtils().currentColorTheme.labelColorY,
          onTap: () async {
            // String string = ConfigManager().config.funds.rechargeQuickAmount;
            // List<String> s = string.split(",");

            String money = _controller.text.trim();

            if (money.isEmpty) {
              JCHub.showmsg(S.current.Amountcannotbeempty, context);
              return;
            }

            ListElement list = cmodel.list[idindex];

            final result = await Navigator.of(context)
                .push(MaterialPageRoute(builder: (context) {
              return RechargePageDes(
                model: list,
                number: money,
              );
            }));

            // if (isOnLogin) return;
          });
    });
    Widget btnbuildGridView = Container(
      // height: 281,
      color: ThemeUtils().currentColorTheme.contentBG,
      margin: EdgeInsets.fromLTRB(15, 0, 15, 0),
      padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
      child: Column(
        children: [
          buildGridView(
            cureeindex,
            tap: (index) {
              String string = ConfigManager().config.funds.rechargeQuickAmount;
              List<String> s = string.split(",");
              String money = s[index];
              cureeindex = index;

              setState(() {
                cureeindex = index;
                _controller.text = money;
              });
            },
          ),
          SizedBox(
            height: 21,
          ),
          new SizedBox(
            child: loginBtn,
          )
        ],
      ),
    );
    Widget bodyview = Container(
      // margin: EdgeInsets.fromLTRB(15, 0, 15, 0),
      // alignment: Alignment.center,
      // margin: EdgeInsets.fromLTRB(15, 37, 15, 0),
      // color: ThemeUtils().currentColorTheme.contentBG,
      // height: 458,
      child: Column(
        children: [
          SizedBox(
            height: 11,
          ),
          textbody,
          SizedBox(
            height: 5,
          ),
          titleview,
          SizedBox(
            height: 11,
          ),
          textbodyview,
          SizedBox(
            height: 11,
          ),
          inputMoneyWiget,
          // SizedBox(
          //   height: 11,
          // ),
          btnbuildGridView,
        ],
      ),
    );

    Widget allviebody = Scaffold(
      backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
      body: bodyview,
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
        ),
        // 如果没有设置这项， 二级页面 会默认是返回箭头  ， 有侧边栏的页面默认有图标（用来打开侧边栏）
        // automaticallyImplyLeading: true,
        // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
        title: ThemeUtils.sText(S.current.Rechargemethod),
        centerTitle: true,
        //  actions: <Widget>[
        //     IconButton(
        //         icon: Icon(Icons.add_alarm),
        //         tooltip: 'Add Alarm',
        //         onPressed: () {
        //           // do nothing
        //         })
        //   ],   // 标题是否在居中

//          elevation: 0.1, // 导航栏Z轴的高度，默认是1  默认就是有高度 阴影的
        backgroundColor: ThemeUtils()
            .currentColorTheme
            .contentBG, // 导航栏的颜色  默认是 ThemeData 的颜色
//         flexibleSpace: FlexibleSpaceBar(title: Text("你号"),),//这个堆叠在工具栏上面  一般 appbar不用  主要用在 SliverAppBar上
//          brightness: Brightness.light, //状态栏的深度 有白色和黑色两种主题
//          titleSpacing: 10,//flexibleSpace 和 title 的距离  默认是重合的
//          toolbarOpacity: 0.5,// 导航栏透明度 默认是1 ，不包括flexibleSpace
//          bottomOpacity: 0.5,
      ),
    );
    return allviebody;
  }

  pushcomit(BuildContext context, Map<String, dynamic> params, ListElement list,
      String number) async {
    ResultData resultData =
        await AppApi.getInstance().post_recharge_create(context, true, params);
    if (resultData.isSuccess()) {
      //  DataUtils.saveUserInfo(resultData.dataJson);

      // ConfigManager.
      //  JCHub.showmsg(S.current.Submittedsuccessfullywaitingforreview, context);

      final result = await Navigator.of(context)
          .push(MaterialPageRoute(builder: (context) {
        return RechargePageDes(
          model: list,
          number: number,
        );
      }));
    } else {
      JCHub.showmsg(resultData.msg, context);
    }
  }

  ///创建GridView使用的子布局
  Widget buildListViewItemWidget(
    int index,
    tap,
    int cureeindex,
  ) {
    String string = ConfigManager().config.funds.rechargeQuickAmount;
    List<String> s = string.split(",");
    String money = s[index] + ConfigManager().config.base.symbolFlag;
    return InkWell(
        onTap: () {
          tap(index);
        },
        child: new Container(
          ///内容剧中
          alignment: Alignment.center,
          margin: EdgeInsets.only(left: 5, right: 5),

          ///根据角标来动态计算生成不同的背景颜色
          color: index == cureeindex
              ? ThemeUtils().currentColorTheme.labelColorY
              : ThemeUtils().currentColorTheme.viewgaryBG,
          child: new Text(
            money,
            style: TextStyle(
                color: index == cureeindex
                    ? ThemeUtils().currentColorTheme.labelColorW
                    : ThemeUtils().currentColorTheme.dateGaryColor,
                fontSize: 18),
          ),
        ));
  }

  List<Widget> buildListViewItemList(tap, int cureeindex) {
    String string = ConfigManager().config.funds.rechargeQuickAmount;
    List<String> s = string.split(",");

    List<Widget> list = [];

    ///模拟的8条数据
    for (int i = 0; i < s.length; i++) {
      list.add(buildListViewItemWidget(i, tap, cureeindex));
    }
    return list;
  }

  ///GridView 的基本使用
  Widget buildGridView(cureeindex, {Function(dynamic index) tap}) {
    return GridView(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),

      ///子Item排列规则
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          //横轴元素个数
          crossAxisCount: 3,
          //纵轴间距

          mainAxisSpacing: 10.0,
          //横轴间距
          crossAxisSpacing: 20.0,
          //子组件宽高长度比例
          childAspectRatio: 2.3),

      ///GridView中使用的子Widegt
      children: buildListViewItemList(tap, cureeindex),
    );
  }
}

YYDialog YYPaylistDialogWithGravity(
    {width, gravity, doubleButtonGravity, tap, model, shell}) {
  YYDialog yyDialog = YYDialog().build()
    // ..width = width
    ..height = width
    ..gravity = gravity
    ..gravityAnimationEnable = true
    // ..borderRadius = 4.0
    // ..barrierDismissible = false
    ..widget(rechargemethodView(
      tap: tap,
      model: model,
    ))
    // ..widget(CountdownClockPage())
    ..barrierColor = Colors.black.withOpacity(.7)
    ..backgroundColor = ThemeUtils().currentColorTheme.contentBG

    // ..doubleButton(
    //   padding: EdgeInsets.only(top: 20.0),
    //   gravity: doubleButtonGravity ?? Gravity.right,
    //   text1: "DISAGREE",
    //   color1: Colors.deepPurpleAccent,
    //   fontSize1: 14.0,
    //   text2: "AGREE",
    //   color2: Colors.deepPurpleAccent,
    //   fontSize2: 14.0,
    // )
    ..show();
  return yyDialog;
}

class rechargemethodView extends StatefulWidget {
  final Rechargemethod model;

  final Function tap;

  const rechargemethodView({
    Key key,
    this.model,
    this.tap,
  }) : super(key: key);
  @override
  State<StatefulWidget> createState() {
    // ignore: no_logic_in_create_state
    return rechargemethodViewState(model, tap);
  }
}

class rechargemethodViewState extends State<rechargemethodView> {
  Rechargemethod model;
  Function tap;
  rechargemethodViewState(this.model, this.tap);

  @override
  Widget build(BuildContext context) {
    var index;

    var leftIconContainer = InkWell(
        // margin: EdgeInsets.all(6),
        // alignment: Alignment.centerRight,
        onTap: () {
          Navigator.pop(context);
        },
        child: Container(
          margin: EdgeInsets.only(right: 10),
          alignment: Alignment.centerRight,
          child: Image.asset(
            "images/wode/gunabi@3x.png",
            width: 15,
            height: 15,
          ),
        ));
    Widget titletext = Container(
      // alignment: Alignment.center,
      margin: EdgeInsets.only(left: 10),
      child: Text(
        '入金方式',
        style: TextStyle(
          fontSize: 16,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );

    Widget body = Row(
      children: [
        titletext,
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        leftIconContainer,
      ],
    );

    Widget paynumberlistvie = Container(
      alignment: Alignment.topRight,
      // height: 176,
      // color: Colors.red,
      child: payListView(
        model: model,
        tap: (index) {
          tap(index);
        },
      ),
    );

    Widget topview = Column(
      children: <Widget>[
        SizedBox(
          height: 5,
        ),
        body,
        // SizedBox(
        //   height: 5,
        // ),
        // titletext,
        SizedBox(
          height: 10,
        ),
        paynumberlistvie,

        // shellPriceText,
        // SizedBox(
        //   height: 5,
        // ),
        // shellAmounteText
      ],
    );
    return Container(
      // padding: EdgeInsets.only(left: 20, right: 20),

      child: MediaQuery.removePadding(
        context: context,
        removeTop: true,
        child: topview,
      ),
    );
  }
}

class payListView extends StatefulWidget {
  final Rechargemethod model;
  final Function tap;
  final int index;

  const payListView({Key key, this.model, this.index, this.tap})
      : super(key: key);
  @override
  State<StatefulWidget> createState() {
    return HomeListViewState(model, index, tap);
  }
}

class HomeListViewState extends State<payListView> {
  final Rechargemethod model;
  final Function tap;
  final int index;

  HomeListViewState(this.model, this.index, this.tap);
  var select = 0;
  Widget build(BuildContext context) {
    var listView = ListView.builder(
      shrinkWrap: true, //解决无限高度问题
      // physics: new NeverScrollableScrollPhysics(), //禁用滑动事件
      itemCount: model.list.length,
      scrollDirection: Axis.vertical,
      itemBuilder: (context, i) => renderRow(i),
    );

    return listView;
  }

  renderRow(i) {
    // Product pro = model.category[index].product[i];
    ListElement m = model.list[i];
    String path;

    if (m.code == 'kf') {
      path = "images/recharge/kfczPay@3x.png";
    } else if (m.code == 'bank') {
      path = "images/recharge/bankPay@3x.png";
    } else if (m.code == 'usdt') {
      path = "images/recharge/USDTPay@3x.png";
    } else if (m.code == 'payment') {
      path = "images/recharge/ThirdPay@3x.png";
    } else if (m.code == 'alipay') {
      path = "images/recharge/zfbPay@3x.png";
    }

    var rowitem = payListRow(
      model: model,
      icon: CachedNetworkImage(
        imageUrl: ConfigManager().imageHost + m.icon,
        fit: BoxFit.cover,
        placeholder: (context, url) => Image.asset(
          path,
        ),
        errorWidget: (context, url, error) => Image.asset(
          path,
        ),
      ),
      title: m.name,
      rightImage: Image.asset(
        "images/wode/xyy@3x.png",
        width: 19,
        height: 13,
      ),
      tap: (index) {
        select = index;
        tap(index);
      },
      index: i,
      isselect: select,
    );

    return rowitem;
  }
}

class payListRow extends StatefulWidget {
  final Rechargemethod model;
  final Function tap;
  final int index;
  final int isselect;
  final Widget icon;
  final Image rightImage;
  final String title;
  final Function onTap;

  const payListRow(
      {Key key,
      this.model,
      this.index,
      this.tap,
      this.isselect,
      this.icon,
      this.rightImage,
      this.title,
      this.onTap})
      : super(key: key);
  @override
  State<StatefulWidget> createState() {
    // ignore: no_logic_in_create_state
    return payListRowState();
  }
}

class payListRowState extends State<payListRow> {
  @override
  Widget build(BuildContext context) {
    var iconContainer = Container(
      // margin: EdgeInsets.all(),
      height: 20,
      width: 20,

      child: widget.icon,
    );

    var leftIconContainer = Container(
      // margin: EdgeInsets.all(6),
      height: 13,
      width: 19,

      child: widget.rightImage,
    );

    Widget body = Row(
      children: [
        iconContainer,
        Container(
          alignment: Alignment.center,
          padding: EdgeInsets.only(left: 10),
          // height: 20,
          child: Text(
            widget.title,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.dateGaryColor,
            ),
          ),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        leftIconContainer,
      ],
    );

    body = InkWell(
      onTap: () {
        // reload();
        widget.tap(widget.index);
      },
      child: body,
    );
    return Container(
      child: Container(
        alignment: Alignment.centerLeft,
        margin: EdgeInsets.only(bottom: 1),
        padding: EdgeInsets.fromLTRB(15, 0, 0, 0),
        color: ThemeUtils().currentColorTheme.viewgaryBG,
        height: 44,
        child: body,
      ),
    );
  }
}
