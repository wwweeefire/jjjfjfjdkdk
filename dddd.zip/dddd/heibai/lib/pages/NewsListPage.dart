// TODO Implement this library .

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:heibai/constants/Constants.dart';
import 'package:heibai/constants/events/LogoutEvent.dart';
import 'package:heibai/constants/events/LoginEvent.dart';
import 'package:heibai/constants/events/ChangeThemeEvent.dart';
import 'package:heibai/generated/l10n.dart';
import 'package:heibai/util/DataUtils.dart';
import 'package:heibai/util/ThemeUtils.dart';
// TODO Implement this library.
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:heibai/Classes/model/config.dart';
import 'package:heibai/net/api/Api.dart';
import 'package:heibai/net/api/app_api.dart';
import 'package:heibai/Classes/JCHub/JCHub.dart';
import '../Classes/model/NewList.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:heibai/routers/navigator_util.dart';
import 'package:heibai/pages/NewListContent.dart';

class NewsListPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return NewsListPageState();
  }
}

class NewsListPageState extends State<NewsListPage> {
  Color themeColor = ThemeUtils().currentColorTheme.currentColorTheme;
  Color contentBG = ThemeUtils().currentColorTheme.contentBG;
  static const double IMAGE_ICON_WIDTH = 130.0;
  static const double IMAGE_ICON_HIGHT = 73.0;
  static const double ARROW_ICON_WIDTH = 16.0;
  // var listmodel;
  List<ListElement> list = [];
  RefreshController _refreshController =
      RefreshController(initialRefresh: false);

  bool showLoading = true;
  int page = 1;

  getdata() async {
    Map<String, dynamic> params = {};
    page = 1;
    params["page"] = page;
    params["pageSize"] = 10;

    ResultData resultData =
        await AppApi.getInstance().get_news_page_list(context, false, params);
    if (resultData.isSuccess()) {
      // List list = resultData.data;
      list.remove;
      NewListModel model = newListModelFromJson(resultData.dataJson);
      // nowmodel = model;
      // showLoading = false;
      list = model.list;

      setState(() {
        showLoading = false;
        // nowmodel = model;
        page++;
        list = model.list;
      });
    } else {
      JCHub.showmsg(resultData.msg, context);
      // tap();
    }
  }

  void _onRefresh() async {
    getdata();

    // if failed,use refreshFailed()
    _refreshController.refreshCompleted();
  }

  void _onLoading() async {
    // monitor network fetch
    // await Future.delayed(Duration(milliseconds: 1000));
    // if failed,use loadFailed(),if no data return,use LoadNodata()
    // items.add((items.length+1).toString());

    Map<String, dynamic> params = {};

    params["page"] = page;
    params["pageSize"] = 10;

    ResultData resultData =
        await AppApi.getInstance().get_news_page_list(context, true, params);
    if (resultData.isSuccess()) {
      // List list = resultData.data;

      NewListModel model = newListModelFromJson(resultData.dataJson);
      // nowmodel = model;
      // showLoading = false;
      //list.addAll(model.list);

      if (page < model.page.total) {
        page++;
        _refreshController.loadComplete();
      } else {
        _refreshController.loadNoData();
      }

      setState(() {
        // showLoading = false;
        // nowmodel = model;
        list.addAll(model.list);
        //  list.addAll(model.list);
      });
    } else {
      JCHub.showmsg(resultData.msg, context);
      _refreshController.loadComplete();
      // tap();
    }

    if (mounted) setState(() {});
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    if (showLoading) {
      getdata();
    }

    // getdata();
  }

  Widget build(BuildContext context) {
    var listView = ListView.builder(
      shrinkWrap: true, //解决无限高度问题
      // physics: new NeverScrollableScrollPhysics(), //禁用滑动事件
      itemCount: list.length * 2,
      itemBuilder: (context, i) => renderRow(i),
    );

    Widget allviebody = Scaffold(
      backgroundColor: themeColor,
      body: showLoading == true
          ? Text('')
          : SmartRefresher(
              header: WaterDropHeader(),
              footer: ClassicFooter(
                loadStyle: LoadStyle.ShowWhenLoading,
              ),
              enablePullDown: true,
              enablePullUp: true,
              // header: ClassicHeader(refreshStyle: RefreshStyle.Follow),
              // footer: tableHeader.footer,
              controller: _refreshController,
              onRefresh: _onRefresh,
              onLoading: _onLoading,
              child: listView,
            ),
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
        ),
        // 如果没有设置这项， 二级页面 会默认是返回箭头  ， 有侧边栏的页面默认有图标（用来打开侧边栏）
        automaticallyImplyLeading: true,
        // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
        title: ThemeUtils.sText(S.of(context).tab_consult),
        centerTitle: true,
        // 标题是否在居中

//          elevation: 0.1, // 导航栏Z轴的高度，默认是1  默认就是有高度 阴影的
        backgroundColor: ThemeUtils()
            .currentColorTheme
            .contentBG, // 导航栏的颜色  默认是 ThemeData 的颜色
//         flexibleSpace: FlexibleSpaceBar(title: Text("你号"),),//这个堆叠在工具栏上面  一般 appbar不用  主要用在 SliverAppBar上
//          brightness: Brightness.light, //状态栏的深度 有白色和黑色两种主题
//          titleSpacing: 10,//flexibleSpace 和 title 的距离  默认是重合的
//          toolbarOpacity: 0.5,// 导航栏透明度 默认是1 ，不包括flexibleSpace
//          bottomOpacity: 0.5,
      ),
    );

    return allviebody;
  }

  renderRow(i) {
    if (i == 0) {
    } else {}
    --i;
    if (i.isOdd) {
      return Divider(
        // color: ThemeUtils().currentColorTheme.lineColor,
        height: 1,
      );
    }
    i = i ~/ 2;

    // }
    ListElement model = list[i];
    return InkWell(
      child: itemlistView(
        model: model,
      ),
      onTap: () {
        _handleListItemClick(context, model.content);
//        Navigator
//            .of(context)
//            .push(MaterialPageRoute(builder: (context) => CommonWebPage(title: "Test", url: "https://my.oschina.net/u/815261/blog")));
      },
    );
  }
}

_handleListItemClick(context, htm) async {
  // pushKChatPage(Product pro) async {
  // // 打开登录页并处理登录成功的回调
  // final result =
  //     await Navigator.of(context).push(MaterialPageRoute(builder: (context) {
  //   return NewListContent(
  //     htmlContent: htm,
  //   );
  // }));
  NavigatorUtil.gowebhtmlPage(context, htm);
}

class itemlistView extends StatelessWidget {
  final ListElement model;
  final Function onTap;
  const itemlistView({
    Key key,
    this.onTap,
    this.model,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    var deviceData = MediaQuery.of(context); // 返回 MediaQueryData
    var width = deviceData.size.width - 130 - 40;
    // var image = new Image.asset('images/ic_nav_my_normal.png',height: 10 width,: 10);
    // var rightArrowIcon = Image.asset(
    //   "images/wode/xyy@3x.png",
    //   width: 8,
    //   height: 14,
    // );
    Widget rightimage = Container(
      height: 73,
      width: 130,
      // color: Colors.red,
      child: CachedNetworkImage(
        imageUrl: ConfigManager().imageHost + model.cover,
        fit: BoxFit.cover,
        placeholder: (context, url) => Image.asset(
          "images/wode/noimage.png",
          width: 130,
          height: 73,
        ),
        errorWidget: (context, url, error) => Image.asset(
          "images/wode/noimage.png",
          width: 72,
          height: 130,
        ),
      ),
    );

    Widget toptext = Container(
      height: 21,
      width: width,
      child: Text(
        model.title,
        overflow: TextOverflow.ellipsis,
        maxLines: 1,
        style: TextStyle(
            color: ThemeUtils().currentColorTheme.textWithdkkkwColor,
            fontSize: 15),
        textAlign: TextAlign.left,
      ),
    );
    Widget bottomtext = Container(
      height: 15,
      width: width,
      child: Text(
        model.intro,
        overflow: TextOverflow.ellipsis,
        maxLines: 1,
        style: TextStyle(
          color: ThemeUtils().currentColorTheme.textWithdDDrawColor,
          fontSize: 12,
        ),
      ),
    );

    ;
    Widget textView = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        SizedBox(
          height: 10,
        ),
        toptext,
        SizedBox(
          height: 20,
        ),
        bottomtext,
        // SizedBox(
        //   height: 12,
        // ),
      ],
    );
    Widget body = Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[
        textView,
        // Expanded(
        //   child: Text(''), // 中间用Expanded控件
        // ),
        rightimage
      ],
    );

    return Center(
      child: Container(
        padding: EdgeInsets.all(10),

        height: 93,
        child: body,
        color: ThemeUtils().currentColorTheme.contentBG,
        // color: Colors.red,
      ),
    );
  }
}
