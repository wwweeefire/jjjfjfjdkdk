import 'package:flutter/material.dart';
import 'package:heibai/pages/HomeListView.dart';
import 'package:heibai/util/ThemeUtils.dart';
import '../Classes/model/homeListModel.dart';
import 'package:heibai/net/api/Api.dart';
import 'package:heibai/net/api/app_api.dart';

class homeTabBarView extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return AppBarForTabBarDemo();
  }
}

class AppBarForTabBarDemo extends State with TickerProviderStateMixin {
  HomeListModel listmodel;
  bool loading = true;
  List<Tab> _tabs = <Tab>[];
  var _tabController;

  @override
  void initState() {
    // _tabController = TabController(vsync: this, length: _tabs.length);
    super.initState();
  }

  getBanner() async {
    ResultData resultData =
        await AppApi.getInstance().get_product_list(context, false);
    if (resultData.isSuccess()) {
      // homeListModel model = bannerModelFromJson(resultData.dataJson);
      HomeListModel model = homeListModelFromJson(resultData.dataJson);
      final List<Tab> nowtabs = [];
      for (Category item in model.category) {
        var name = item.name;
        var nowtab = new Tab(text: name);
        nowtabs.add(nowtab);
      }
      // ConfigManager.
      setState(() {
        listmodel = model;
        _tabs = nowtabs;
        _tabController = TabController(vsync: this, length: _tabs.length);
        loading = false;
      });
    } else {
      // user = UserInfo();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      getBanner();
    }

    return _tabs.length == 0
        ? Center()
        : Scaffold(
            // drawer: _drawer(context),
            body: new TabBarView(
              controller: _tabController,
              children: Iterable.generate(_tabs.length).toList().map((index) {
                return Container(
                    child: HomeListView(
                  model: listmodel,
                  index: index,
                ));
              }).toList(),
            ),
            appBar: TabBar(
              isScrollable: true,
              labelColor:
                  ThemeUtils().currentColorTheme.labelColorY, // 选中的Widget颜色
              indicatorColor: ThemeUtils().currentColorTheme.labelColorY,
              labelStyle: new TextStyle(
                  fontSize: 15.0), // 必须设置，设置 color 没用的，因为 labelColor 已经设置了
              unselectedLabelColor: ThemeUtils().currentColorTheme.labelColorW,
              unselectedLabelStyle: new TextStyle(
                  fontSize: 15.0), // 设置 color 没用的，因为unselectedLabelColor已经设置了
              controller: _tabController,
              // tabbar 必须设置 controller 否则报错
              indicatorSize: TabBarIndicatorSize.label,

              // 有 tab 和 label 两种
              tabs: _tabs,
            ),
//          elevation: 0.1, // 导航栏Z轴的高度，默认是1  默认就是有高度 阴影的
            backgroundColor: ThemeUtils()
                .currentColorTheme
                .contentBG, // 导航栏的颜色  默认是 ThemeData 的颜色
//         flexibleSpace: FlexibleSpaceBar(title: Text("你号"),),//这个堆叠在工具栏上面
//          brightness: Brightness.light, //状态栏的深度 有白色和黑色两种主题
//          titleSpacing: 10,//flexibleSpace 和 title 的距离  默认是重合的
//          toolbarOpacity: 0.5,// 导航栏透明度 默认是1 ，不包括flexibleSpace
//          bottomOpacity: 0.5,
          );
    // TODO: implement build
  }
}
