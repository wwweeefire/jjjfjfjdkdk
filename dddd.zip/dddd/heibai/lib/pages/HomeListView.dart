import 'package:flutter/material.dart';
import 'package:heibai/generated/l10n.dart';
import 'package:heibai/pages/userMsgRow.dart';
import 'package:heibai/pages/KChatPage.dart';

import 'package:heibai/util/ThemeUtils.dart';
import 'package:heibai/constants/Constants.dart';
import '../Classes/model/homeListModel.dart';
import 'package:heibai/pages/web_socket_utility.dart';
import '../Classes/model/NProduct.dart';
import 'dart:math';
import 'package:heibai/routers/routes.dart';
import 'package:heibai/routers/navigator_util.dart';
import 'package:heibai/constants/events/chageIndex.dart';

class HomeListView extends StatefulWidget {
  final HomeListModel model;

  final int index;

  const HomeListView({Key key, this.model, this.index}) : super(key: key);
  @override
  State<StatefulWidget> createState() {
    return HomeListViewState(model, index);
  }
}

class HomeListViewState extends State<HomeListView> {
  final HomeListModel model;

  final int index;
  List<Product> product = [];

  HomeListViewState(this.model, this.index);

  getdata() async {
    WebSocketUtility().addListener((data) {
      NProduct ss = nProductFromJson(data);

      //  print(data);
      chagemodel(ss);
    });
    // bool isf = true;
  }

  @override
  void initState() {
    // _tabController = TabController(vsync: this, length: _tabs.length);
    super.initState();

    if (model.category[index].product.length > 8) {
      for (var i = 0; i < 8; i++) {
        Product ss = model.category[index].product[i];
        product.add(ss);
      }
    } else {
      product = model.category[index].product;
    }
    getdata();
  }

  _randomBit(int len, double intge) {
    String b = "1";
    for (int i = 0; i < len; i++) {
      b = b + "0";
    }
    int s = (intge * 2 * double.parse(b)).toInt();
    int u = (Random().nextInt(s));
    return (u - u / 2) / double.parse(b);
  }

  void chagemodel(NProduct model) {
    var index = -1;

    for (var i = 0; i < product.length; i++) {
      String name = model.code;

      Product ss = product[i];
      String ssname = ss.code;
      String sssname = model.code;
      if (model.code == ss.code) {
        index = i;
      }
    }
    // int id;
    // String code;
    // String name;
    // double wave;
    // String openTime;
    // int weekendTrading;
    // double open;
    // double price;
    // double low;
    // double high;
    // double change;
    if (index >= 0) {
      Product newmodel;

      Product oldmodel = product[index];

      if (oldmodel.price == model.price) {
        String wave = oldmodel.wave.toString();
        List<String> wavelist = wave.split(".");
        int size = wavelist.last.length;
        double b = _randomBit(size, oldmodel.wave);

        // double b = (Random().nextInt(100) - 50) / 100.0;
        String price = oldmodel.price.toString();

        List<String> s = price.split(".");
        int a = s.last.length;
        String rstr = b.toStringAsFixed(a);
        double r = double.parse(rstr);
        double newprices = model.price + r;

        String newpricesstr = newprices.toStringAsFixed(a);
        double newprice = double.parse(newpricesstr);
        String name = oldmodel.name;

        // print("olaname" + "== $name" + "price =" + "$price");

        // print("name" + "== $name" + "price =" + "$newprice");
        newmodel = Product(
          id: oldmodel.id,
          code: model.code,
          open: model.open,
          name: oldmodel.name,
          wave: oldmodel.wave,
          openTime: oldmodel.openTime,
          weekendTrading: oldmodel.weekendTrading,
          price: newprice,
          low: model.low,
          high: model.high,
          change: oldmodel.change + r / oldmodel.open,
          vol: model.vol,
        );
      } else {
        newmodel = Product(
          id: oldmodel.id,
          code: model.code,
          open: model.open,
          name: oldmodel.name,
          wave: oldmodel.wave,
          openTime: oldmodel.openTime,
          weekendTrading: oldmodel.weekendTrading,
          price: model.price,
          low: model.low,
          high: model.high,
          change: model.change,
          vol: model.vol,
        );
      }

      setStateIfMounted(() {
        product.fillRange(index, index + 1, newmodel);
        // datas = [];
        // showLoading = true;
      });
    }
  }

  void setStateIfMounted(f) {
    if (mounted) setState(f);
  }

  Widget build(BuildContext context) {
    // product = model.category[index].product;

    var listView = ListView.builder(
      shrinkWrap: true, //解决无限高度问题
      physics: new NeverScrollableScrollPhysics(), //禁用滑动事件
      itemCount: product.length == 8 ? product.length + 2 : product.length + 1,
      itemBuilder: (context, i) => renderRow(i),
    );

    Widget body = Container(
      color: ThemeUtils().currentColorTheme.defaultColor,
      child: listView,
    );
    return body;
  }

  pushKChatPage(Product pro) async {
    // 打开登录页并处理登录成功的回调
    final result =
        await Navigator.of(context).push(MaterialPageRoute(builder: (context) {
      return KChatPage(
        title: pro.name,
        model: pro,
      );
    }));
  }

  renderRow(i) {
    if (i == 0) {
      return TitleMsgRow(
        title: S.current.SPMC,
        price: S.current.ZXJ,
        increase: S.current.ERZF,
      );
    }

    if (i < product.length + 1) {
      --i;
      Product pro = product[i];
      // if (i.isOdd) {}
      // i = i ~/ 2;

      var rowitem = UserMsgRow(
          title: pro.name,
          price: pro.price.toString(),
          increase: pro.change.toStringAsFixed(2));

      return InkWell(
        child: rowitem,
        onTap: () {
          pushKChatPage(pro);
        },
      );
    } else if (i == product.length + 1) {
      var rowitem = addWiget();

      return InkWell(
        child: rowitem,
        onTap: () {
          Constants.eventBus.fire(chageIndex(1));
        },
      );
    }
  }
}

class addWiget extends StatelessWidget {
  Widget build(BuildContext context) {
    final mediaQueryData = MediaQuery.of(context);

// 2.获取宽度和高度
    final screenWidth = mediaQueryData.size.width;
    var iconContainer = Container(
      // margin: EdgeInsets.all(),
      alignment: Alignment.center,
      height: 20,
      width: 0,

      child: Text(''),
    );

    Widget body = Row(
      children: [
        Container(
          width: screenWidth / 2 - 40,
        ),
        iconContainer,
        Container(
          alignment: Alignment.center,
          padding: EdgeInsets.only(left: 10),
          // height: 20,
          child: Text(
            S.current.CKGD,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.dateGaryColor,
            ),
          ),
        ),
      ],
    );

    return Container(
      child: Container(
        margin: EdgeInsets.only(bottom: 1),
        // margin: EdgeInsets.fromLTRB(15, 5, 15, 5),
        // color: ThemeUtils().currentColorTheme.viewgaryBG,
        height: 44,
        child: body,
      ),
    );
  }
}
