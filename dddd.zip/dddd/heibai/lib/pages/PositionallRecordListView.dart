import 'package:flutter/material.dart';
import 'package:heibai/pages/userMsgRow.dart';

import 'package:heibai/util/ThemeUtils.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:heibai/net/api/Api.dart';
import 'package:heibai/net/api/app_api.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import '../Classes/model/PositionRecordModel.dart';
import 'package:heibai/Classes/JCHub/JCHub.dart';
import 'package:heibai/generated/l10n.dart';
import 'package:heibai/constants/events/changebuyEvent.dart';
import 'package:heibai/constants/Constants.dart';
import 'dart:io';
import 'package:flutter/foundation.dart';

class PositionallRecordListView extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return PositionRecordoverListViewState();
  }
}

class PositionRecordoverListViewState extends State<PositionallRecordListView> {
  List<ListElement> list = [];
  bool showLoading = true;
  int page = 1;
  RefreshController _refreshController =
      RefreshController(initialRefresh: false);

  void get_order_page_list() async {
    Map<String, dynamic> params = {};

    params["page"] = 1;
    params["pageSize"] = 15;
    params["status"] = 1;

    ResultData resultData =
        await AppApi.getInstance().get_order_page_list(context, false, params);
    if (resultData.isSuccess()) {
      PositionRecordModel model =
          positionRecordModelFromJson(resultData.dataJson);
      list = model.list;
      page++;
      setState(() {
        if (list.length > 0) {
          showLoading = false;
        }
      });
    }
  }

  @override
  void initState() {
    super.initState();
    get_order_page_list();
    YYDialog.init(context);
    // Constants.eventBus.on<changebuyEvent>().listen((event) {
    //   // 收到登录的消息，重新获取个人信息
    //   get_order_page_list();
    // });
    //   if (SchedulerBinding.instance.schedulerPhase ==
    //   SchedulerPhase.persistentCallbacks) {
    // SchedulerBinding.instance.addPostFrameCallback((_) => onWidgetBuild());
  }

  Widget build(BuildContext context) {
    final mediaQueryData = MediaQuery.of(context);

// 2.获取宽度和高度
    final screenWidth = mediaQueryData.size.width;
    final screenHeight = mediaQueryData.size.height;

    final statusBarHeight = mediaQueryData.padding.top;
// 有刘海的屏幕:34 没有刘海的屏幕0
    double bottomHeight = 10.0;
    if (!kIsWeb) {
      bottomHeight = 10.0;
      if (Platform.isIOS) {
        bottomHeight = mediaQueryData.padding.bottom;
      }
    }
    Color themeColor = ThemeUtils().currentColorTheme.currentColorTheme;
    Color contentBG = ThemeUtils().currentColorTheme.contentBG;
    var listView = ListView.builder(
      // shrinkWrap: true, //解决无限高度问题
      // physics: new NeverScrollableScrollPhysics(), //禁用滑动事件
      itemCount: list.length,
      itemBuilder: (context, i) => renderRow(i, screenWidth),
    );

    Widget allviebody = Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
        ),
        automaticallyImplyLeading: true,
        // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
        title: ThemeUtils.sText(S.current.Orderhistory),
        backgroundColor: ThemeUtils().currentColorTheme.contentBG,
      ),
      backgroundColor: themeColor,
      body: Container(
          margin: EdgeInsets.only(bottom: bottomHeight),
          child: SmartRefresher(
            header: WaterDropHeader(),
            footer: ClassicFooter(
              loadStyle: LoadStyle.ShowWhenLoading,
            ),
            enablePullDown: true,
            enablePullUp: true,
            // header: ClassicHeader(refreshStyle: RefreshStyle.Follow),
            // footer: tableHeader.footer,
            controller: _refreshController,
            onRefresh: _onRefresh,
            onLoading: _onLoading,
            child: showLoading == true
                ? ListView(
                    children: [
                      Center(
                          child: Container(
                        child: Image.asset(
                          "images/wode/nulldata.png",
                        ),
                      ))
                    ],
                  )
                : listView,
          )),
    );

    return allviebody;
  }

  void _onRefresh() async {
    get_order_page_list();

    // if failed,use refreshFailed()
    _refreshController.refreshCompleted();
  }

  void _onLoading() async {
    Map<String, dynamic> params = {};

    params["page"] = page;
    params["pageSize"] = 15;
    params["status"] = 1;

    ResultData resultData =
        await AppApi.getInstance().get_order_page_list(context, false, params);
    if (resultData.isSuccess()) {
      // List list = resultData.data;
      PositionRecordModel model =
          positionRecordModelFromJson(resultData.dataJson);
      // nowmodel = model;
      // showLoading = false;
      // list.addAll(model.list);

      if (page < model.page.total) {
        page++;
        _refreshController.loadComplete();
      } else {
        _refreshController.loadNoData();
      }

      setState(() {
        // showLoading = false;
        // nowmodel = model;
        list.addAll(model.list);
        //  list.addAll(model.list);
      });
    } else {
      JCHub.showmsg(resultData.msg, context);
      _refreshController.loadComplete();
      // tap();
    }
    if (mounted) setState(() {});
  }

  renderRow(i, width) {
    ListElement item = list[i];

    var rowitem = pritemView(
      item: item,
    );

    return InkWell(
      child: rowitem,
      onTap: () {
        YYAlertDialogWithGravity(
            width: width - 30,
            gravity: Gravity.center,
            model: item,
            tap: () {
              Navigator.pop(context);
            });
      },
    );
  }
}

class pritemView extends StatelessWidget {
  final ListElement item;

  const pritemView({
    Key key,
    this.item,
  }) : super(key: key);
  Widget build(BuildContext context) {
    final mediaQueryData = MediaQuery.of(context);

// 2.获取宽度和高度
    final screenWidth = mediaQueryData.size.width;
    Widget nametext = Row(
      children: [
        Container(
          alignment: Alignment.centerLeft,
          width: screenWidth / 2 - 40,
          child: Text(
            item.productName,
            style: TextStyle(
              fontSize: 12,
              // fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.textWithdrawColor,
            ),
          ),
        ),
        // Expanded(
        //   child: Text(''), // 中间用Expanded控件
        // ),
        Container(
          alignment: Alignment.center,
          child: Text(
            item.chooseType == 1
                ? "↑" + S.current.BUYZ + "(" + item.payMoney.toString() + ")"
                : "↓" + S.current.MD + "(" + item.payMoney.toString() + ")",
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: item.chooseType == 1
                  ? ThemeUtils().currentColorTheme.numberRedColor
                  : ThemeUtils().currentColorTheme.textgreenColor,
            ),
          ),
        ),
      ],
    );
    // Widget titletext =

    Widget titletext = Row(
      children: [
        Container(
          alignment: Alignment.centerLeft,
          child: RichText(
              text: TextSpan(
            text: item.payPrice.toString() + "-",
            style: TextStyle(
                color: ThemeUtils().currentColorTheme.textGaryColor,
                fontSize: 12),
            children: [
              TextSpan(
                text: item.drawPrice.toString(),
                style: TextStyle(
                    color: item.drawMoney > 0
                        ? ThemeUtils().currentColorTheme.numberRedColor
                        : ThemeUtils().currentColorTheme.textgreenColor,
                    fontSize: 12),
              ),
            ],
          )),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        Container(
          // color: Colors.red,
          alignment: Alignment.center,
          child: Text(
            item.drawMoney.toString(),
            style: TextStyle(
              fontSize: 18,
              // fontWeight: FontWeight.w900,
              color: item.drawMoney > 0
                  ? ThemeUtils().currentColorTheme.numberRedColor
                  : ThemeUtils().currentColorTheme.textgreenColor,
            ),
          ),
        ),
      ],
    );
    // var aTime = DateTime.fromMillisecondsSinceEpoch(item.createTime);
    var Time = DateTime.fromMillisecondsSinceEpoch(item.createTime * 1000);
    var aTime = Time.toLocal().toString().substring(0, 16);
    var nTime = DateTime.fromMillisecondsSinceEpoch(item.drawTime * 1000);
    var naTime = nTime.toLocal().toString().substring(0, 16);
    Widget buyAmounteText = Row(
      children: [
        Container(
          alignment: Alignment.center,
          child: Text(
            aTime.toString(),
            style: TextStyle(
              fontSize: 12,
              // fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.labelColorW,
            ),
          ),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        Container(
          // color: Colors.red,
          padding: EdgeInsets.only(right: 10),
          alignment: Alignment.centerRight,
          child: Text(
            naTime.toString(),
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.dateGaryColor,
            ),
          ),
        ),
        // Expanded(
        //   child: Container(
        //     width: 15,
        //   ), // 中间用Expanded控件
        // ),
      ],
    );

    Widget topview = Column(
      children: <Widget>[
        SizedBox(
          height: 5,
        ),
        nametext,
        SizedBox(
          height: 5,
        ),
        titletext,
        SizedBox(
          height: 5,
        ),
        buyAmounteText,
        SizedBox(
          height: 5,
        ),
        Divider(
          color: ThemeUtils().currentColorTheme.lineColor,
          height: 1.0,
        )
      ],
    );

    return Container(
        padding: EdgeInsets.only(left: 20, right: 20),
        height: 85,
        child: topview);
  }
}

class ptoItmeRow extends StatelessWidget {
  final String title;
  final String price;
  final String increase;
  final String onther;
  final Function onTap;
  const ptoItmeRow(
      {Key key, this.title, this.price, this.increase, this.onther, this.onTap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    var list = <Widget>[
      Flex(
        direction: Axis.horizontal,
        children: <Widget>[
          Expanded(
            flex: 5,
            child: Container(
              // padding: EdgeInsets.zero,
              height: 45,
              // color: Colors.red,
              margin: EdgeInsets.symmetric(horizontal: 15, vertical: 0),
              alignment: Alignment.centerLeft,
              child: Text(
                title ?? '活动哈',
                style: TextStyle(
                  color: ThemeUtils().currentColorTheme.textWithdDDrawColor,
                  fontSize: 14,
                ),
                textAlign: TextAlign.left,
              ),
            ),
          ),
          Expanded(
            flex: 4,
            child: Container(
              // padding: EdgeInsets.zero,
              height: 45,
              alignment: Alignment.centerLeft,
              // color: Colors.yellow,
              child: Text(
                price ?? '1000000',
                style: TextStyle(
                  color: ThemeUtils().currentColorTheme.textWithdDDrawColor,
                  fontSize: 14,
                ),
                textAlign: TextAlign.left,
              ),
            ),
          ),
          Expanded(
            flex: 4,
            child: Container(
              alignment: Alignment.centerLeft,
              height: 45,
              child: Text(
                increase ?? '+150%',
                style: TextStyle(
                  color: ThemeUtils().currentColorTheme.textWithdDDrawColor,
                  fontSize: 14,
                ),
                textAlign: TextAlign.left,
              ),
            ),
          ),
          Expanded(
            flex: 3,
            child: Container(
              alignment: Alignment.centerRight,
              // padding: EdgeInsets.zero,
              padding: EdgeInsets.only(right: 15),
              height: 45,

              child: Text(
                onther ?? '明细',
                style: TextStyle(
                  color: ThemeUtils().currentColorTheme.textWithdDDrawColor,
                  fontSize: 14,
                ),
                textAlign: TextAlign.right,
              ),
            ),
          ),
        ],
      ),
    ];
    var info = Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: list,
    );

    return Container(
      child: info,
    );
  }
}

class ItemTitleRow extends StatelessWidget {
  final String title;
  final String price;
  final String increase;
  final String onther;
  const ItemTitleRow({
    Key key,
    this.title,
    this.price,
    this.increase,
    this.onther,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var list = <Widget>[
      Flex(
        direction: Axis.horizontal,
        children: <Widget>[
          Expanded(
            flex: 5,
            child: Container(
              // padding: EdgeInsets.zero,
              height: 30,
              // color: Colors.red,
              margin: EdgeInsets.symmetric(horizontal: 15, vertical: 0),
              alignment: Alignment.centerLeft,
              child: Text(
                title ?? '商品名称',
                style: TextStyle(
                  color: ThemeUtils().currentColorTheme.dateGaryColor,
                  fontSize: 12,
                ),
                textAlign: TextAlign.left,
              ),
            ),
          ),
          Expanded(
            flex: 4,
            child: Container(
              // padding: EdgeInsets.zero,
              height: 30,
              alignment: Alignment.centerLeft,
              // color: Colors.yellow,
              child: Text(
                price ?? '最新净值',
                style: TextStyle(
                  color: ThemeUtils().currentColorTheme.dateGaryColor,
                  fontSize: 12,
                ),
                textAlign: TextAlign.left,
              ),
            ),
          ),
          Expanded(
            flex: 4,
            child: Container(
              // padding: EdgeInsets.zero,
              height: 30,
              alignment: Alignment.centerLeft,
              // color: Colors.yellow,
              child: Text(
                onther ?? '最新净值',
                style: TextStyle(
                  color: ThemeUtils().currentColorTheme.dateGaryColor,
                  fontSize: 12,
                ),
                textAlign: TextAlign.left,
              ),
            ),
          ),
          Expanded(
            flex: 3,
            child: Container(
              alignment: Alignment.center,
              // padding: EdgeInsets.zero,
              height: 30,

              child: Text(
                increase ?? '跌涨幅',
                style: TextStyle(
                  color: ThemeUtils().currentColorTheme.dateGaryColor,
                  fontSize: 12,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ),
        ],
      ),
    ];
    var info = Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: list,
    );

    return Container(
      child: Container(
        // padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        child: Row(
          children: <Widget>[
            Expanded(child: info),
          ],
        ),
      ),
    );
  }
}

showdialog() {}

YYDialog YYAlertDialogWithGravity(
    {width, gravity, doubleButtonGravity, tap, model}) {
  YYDialog yyDialog = YYDialog().build()
    ..width = width
    ..gravity = gravity
    ..gravityAnimationEnable = true
    ..borderRadius = 4.0
    ..barrierDismissible = false
    ..widget(RecordContextView(
      tap: tap,
      model: model,
    ))
    ..backgroundColor = ThemeUtils().currentColorTheme.contentBG

    // ..doubleButton(
    //   padding: EdgeInsets.only(top: 20.0),
    //   gravity: doubleButtonGravity ?? Gravity.right,
    //   text1: "DISAGREE",
    //   color1: Colors.deepPurpleAccent,
    //   fontSize1: 14.0,
    //   text2: "AGREE",
    //   color2: Colors.deepPurpleAccent,
    //   fontSize2: 14.0,
    // )
    ..show();
  return yyDialog;
}

class RecordContextView extends StatelessWidget {
  final String title;
  final String price;
  final String increase;
  final String onther;
  final Function tap;
  final ListElement model;
  const RecordContextView({
    Key key,
    this.title,
    this.price,
    this.increase,
    this.onther,
    this.tap,
    this.model,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var leftIconContainer = InkWell(
        // margin: EdgeInsets.all(6),
        // alignment: Alignment.centerRight,
        onTap: () {
          tap();
        },
        child: Container(
          alignment: Alignment.centerRight,
          child: Image.asset(
            "images/wode/gunabi@3x.png",
            width: 15,
            height: 15,
          ),
        ));
    Widget titletext = Container(
      alignment: Alignment.center,
      child: Text(
        model.productName,
        style: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.labelColorW,
        ),
      ),
    );
    Widget nametext = Row(
      children: [
        Container(
          alignment: Alignment.center,
          child: Text(
            model.productName,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.labelColorW,
            ),
          ),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        Container(
          alignment: Alignment.center,
          child: Text(
            model.chooseType == 1
                ? "↑" + S.current.BUYZ + model.payMoney.toString()
                : "↓" + S.current.MD + model.payMoney.toString(),
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: model.chooseType == 1
                  ? ThemeUtils().currentColorTheme.numberRedColor
                  : ThemeUtils().currentColorTheme.textgreenColor,
            ),
          ),
        ),
      ],
    );
    Widget buyTitle = Container(
      alignment: Alignment.centerLeft,
      child: Text(
        S.current.DMRA,
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textgreenColor,
        ),
      ),
    );

    Widget buyPriceText = Row(
      children: [
        Container(
          alignment: Alignment.center,
          child: Text(
            S.current.DMRJG,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.textGaryColor,
            ),
          ),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        Container(
          alignment: Alignment.center,
          child: Text(
            model.payPrice.toString(),
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.numberRedColor,
            ),
          ),
        ),
      ],
    );
    var Time = DateTime.fromMillisecondsSinceEpoch(model.createTime * 1000);
    var aTime = Time.toLocal().toString().substring(0, 16);
    Widget buyDateText = Container(
      alignment: Alignment.centerLeft,
      child: Text(
        aTime.toString(),
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.dateGaryColor,
        ),
      ),
    );

// 投资金额
    Widget buyAmounteText = Row(
      children: [
        Container(
          alignment: Alignment.center,
          child: Text(
            S.current.TZJE,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.textGaryColor,
            ),
          ),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        Container(
          alignment: Alignment.center,
          child: Text(
            model.payMoney.toString(),
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.dateGaryColor,
            ),
          ),
        ),
      ],
    );

    Widget sellTitle = Container(
      alignment: Alignment.centerLeft,
      child: Text(
        S.current.DMCA,
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textgreenColor,
        ),
      ),
    );

    Widget shellPriceText = Row(
      children: [
        Container(
          alignment: Alignment.center,
          child: Text(
            S.current.DMCJG,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.textGaryColor,
            ),
          ),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        Container(
          alignment: Alignment.center,
          child: Text(
            model.drawPrice.toString(),
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.textgreenColor,
            ),
          ),
        ),
      ],
    );

    var sTime = DateTime.fromMillisecondsSinceEpoch(model.drawTime * 1000);
    var saTime = sTime.toLocal().toString().substring(0, 16);
    Widget shellDateText = Container(
      alignment: Alignment.centerLeft,
      child: Text(
        saTime.toString(),
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.dateGaryColor,
        ),
      ),
    );
// 投资金额
    Widget shellAmounteText = Row(
      children: [
        Container(
          alignment: Alignment.center,
          child: Text(
            S.current.DSY,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.textGaryColor,
            ),
          ),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        Container(
          alignment: Alignment.center,
          child: Text(
            model.drawMoney.toString(),
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.dateGaryColor,
            ),
          ),
        ),
      ],
    );

    Widget topview = Column(
      children: <Widget>[
        // SizedBox(
        //   height: 10,
        // ),
        leftIconContainer,
        SizedBox(
          height: 5,
        ),
        titletext,
        SizedBox(
          height: 13,
        ),
        nametext,
        SizedBox(
          height: 10,
        ),
        buyTitle,
        SizedBox(
          height: 5,
        ),
        buyDateText,
        SizedBox(
          height: 5,
        ),
        buyPriceText,
        SizedBox(
          height: 5,
        ),
        buyAmounteText,

        SizedBox(
          height: 20,
        ),
        sellTitle,
        SizedBox(
          height: 5,
        ),
        shellDateText,
        SizedBox(
          height: 5,
        ),
        shellPriceText,
        SizedBox(
          height: 5,
        ),
        shellAmounteText,
        SizedBox(
          height: 5,
        ),
      ],
    );
    return Container(
        padding: EdgeInsets.fromLTRB(40, 16, 30, 40), child: topview);
  }
}
