import 'package:flutter/material.dart';
import 'package:heibai/pages/userMsgRow.dart';
import 'dart:io';
import 'package:heibai/util/ThemeUtils.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:heibai/net/api/Api.dart';
import 'package:heibai/net/api/app_api.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
// import '../Classes/model/billModel.dart';
import '../Classes/model/helpListmodel.dart';
import 'package:heibai/pages/login/loginView.dart';
import 'package:heibai/pages/HelpCenterdespage.dart';
import 'package:heibai/Classes/model/config.dart';
import 'package:heibai/Classes/JCHub/JCHub.dart';
import 'package:flutter/foundation.dart';
import 'package:heibai/generated/l10n.dart';
import 'package:heibai/pages/CommonWebPage.dart';
import 'package:heibai/pages/CommonAPPwebpage.dart';

class HelpCenterPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return HelpCenterPageState();
  }
}

class HelpCenterPageState extends State<HelpCenterPage> {
  List<ListElement> list = [];
  bool showLoading = true;
  int page = 1;
  RefreshController _refreshController =
      RefreshController(initialRefresh: false);

  void get_help_list() async {
    Map<String, dynamic> params = {};

    // params["page"] = 1;
    // params["pageSize"] = 15;
    // params["status"] = 2;

    ResultData resultData =
        await AppApi.getInstance().get_help_list(context, false, params);
    if (resultData.isSuccess()) {
      HelpListmodel model = helpListmodelFromJson(resultData.dataJson);
      list = model.list;
      page++;
      setState(() {
        showLoading = false;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    get_help_list();
    //   if (SchedulerBinding.instance.schedulerPhase ==
    //   SchedulerPhase.persistentCallbacks) {
    // SchedulerBinding.instance.addPostFrameCallback((_) => onWidgetBuild());
  }

  Widget build(BuildContext context) {
    final mediaQueryData = MediaQuery.of(context);

// 2.获取宽度和高度
    final screenWidth = mediaQueryData.size.width;
    final screenHeight = mediaQueryData.size.height;

    final statusBarHeight = mediaQueryData.padding.top;
// 有刘海的屏幕:34 没有刘海的屏幕0
    double bottomHeight = 0.0;
    if (!kIsWeb) {
      bottomHeight = 10.0;
      if (Platform.isIOS) {
        bottomHeight = mediaQueryData.padding.bottom;
      }
    }

    Color themeColor = ThemeUtils().currentColorTheme.currentColorTheme;
    Color contentBG = ThemeUtils().currentColorTheme.contentBG;
    var listView = ListView.builder(
      // shrinkWrap: true, //解决无限高度问题
      // physics: new NeverScrollableScrollPhysics(), //禁用滑动事件
      itemCount: list.length,
      itemBuilder: (context, i) => renderRow(i),
    );

    var loginBtn = Builder(builder: (ctx) {
      return CommonButton(
          text: S.current.KF,
          color: ThemeUtils().currentColorTheme.contentBG,
          onTap: () async {
            var kfid = ConfigManager().config.kf[0].id;

            var userid = ConfigManager().user.id;
            var baidu = ConfigManager().config.kf[0].link;
            if (kIsWeb) {
              final result = await Navigator.of(context)
                  .push(MaterialPageRoute(builder: (context) {
                return CommonWebPage(
                  htmlContent: baidu + "?id=$kfid&uid=$userid",
                  title: S.current.KF,
                );
              }));
            } else {
              final result = await Navigator.of(context)
                  .push(MaterialPageRoute(builder: (context) {
                return CommonAPPwebpage(
                  htmlContent: baidu + "?id=$kfid&uid=$userid",
                  title: S.current.KF,
                );
              }));
            }
          });
    });

    var bodyviw = Stack(
      children: [
        listView,
        Positioned(left: 0, right: 0, bottom: bottomHeight, child: loginBtn)
      ],
    );

    Widget allviebody = Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
        ),
        automaticallyImplyLeading: true,
        // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
        title: ThemeUtils.sText(S.current.HelpCenter),
        backgroundColor: ThemeUtils().currentColorTheme.contentBG,
      ),
      backgroundColor: themeColor,
      body: showLoading == true
          ? Text('')
          : SmartRefresher(
              header: WaterDropHeader(),
              footer: ClassicFooter(
                loadStyle: LoadStyle.ShowWhenLoading,
              ),
              enablePullDown: true,
              enablePullUp: true,
              // header: ClassicHeader(refreshStyle: RefreshStyle.Follow),
              // footer: tableHeader.footer,
              controller: _refreshController,
              onRefresh: _onRefresh,
              onLoading: _onLoading,
              child: bodyviw,
            ),
    );

    return allviebody;
  }

  void _onRefresh() async {
    get_help_list();

    // if failed,use refreshFailed()
    _refreshController.refreshCompleted();
  }

  void _onLoading() async {
    // Map<String, dynamic> params = {};

    // // params["page"] = page;
    // // params["pageSize"] = 15;
    // // params["status"] = 2;

    // ResultData resultData =
    //     await AppApi.getInstance().get_help_list(context, false, params);
    // if (resultData.isSuccess()) {
    //   // List list = resultData.data;
    //   HelpListmodel model =
    //       helpListmodelFromJson(resultData.dataJson);
    //   // nowmodel = model;
    //   // showLoading = false;
    //   list.addAll(model.list);

    //   if (page < model.page.total) {
    //     page++;
    //     _refreshController.loadComplete();
    //   } else {
    //     _refreshController.loadNoData();
    //   }

    //   setState(() {
    //     // showLoading = false;
    //     // nowmodel = model;
    //     list.addAll(model.list);
    //     //  list.addAll(model.list);
    //   });
    // } else {
    //   JCHub.showmsg(resultData.msg, context);
    //   _refreshController.loadComplete();
    //   // tap();
    // }
    _refreshController.loadNoData();
    if (mounted) setState(() {});
  }

  renderRow(i) {
    ListElement item = list[i];

    var rowitem = biiemlistView(
      model: item,
    );

    return InkWell(
      child: rowitem,
      onTap: () async {
        final result = await Navigator.of(context)
            .push(MaterialPageRoute(builder: (context) {
          return HelpCenterdespage(
            model: item,
          );
        }));
      },
    );
  }
}

class biiemlistView extends StatelessWidget {
  final ListElement model;
  final Function onTap;
  const biiemlistView({
    Key key,
    this.onTap,
    this.model,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    var deviceData = MediaQuery.of(context); // 返回 MediaQueryData

    Widget toptext = Container(
      height: 21,
      width: 100,
      child: Text(
        model.title,
        overflow: TextOverflow.ellipsis,
        maxLines: 1,
        style: TextStyle(
            color: ThemeUtils().currentColorTheme.textWithdkkkwColor,
            fontSize: 15),
        textAlign: TextAlign.left,
      ),
    );

    Widget rtextView = Container(
      child: Image.asset(
        "images/wode/xyy@3x.png",
        width: 19,
        height: 13,
      ),
    );

    Widget body = Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[
        toptext,
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        rtextView,
        Divider(
          color: ThemeUtils().currentColorTheme.defaultColor,
          height: 1.0,
        )
      ],
    );

    return Center(
      child: Container(
        padding: EdgeInsets.only(left: 10, right: 10),

        height: 50,
        child: body,
        color: ThemeUtils().currentColorTheme.contentBG,
        // color: Colors.red,
      ),
    );
  }
}
