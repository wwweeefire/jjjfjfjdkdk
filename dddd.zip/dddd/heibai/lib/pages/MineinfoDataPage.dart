// ignore: file_names
// ignore: file_names
import 'package:flutter/material.dart';
import 'package:heibai/Classes/model/config.dart';
import 'dart:io';
import 'package:heibai/constants/Constants.dart';
import 'package:heibai/Classes/JCHub/JCHub.dart';
import 'package:heibai/generated/l10n.dart';
import 'package:heibai/util/ThemeUtils.dart';
import '../Classes/model/UserInfo.dart';
import 'package:heibai/net/api/Api.dart';
import 'package:heibai/net/api/app_api.dart';
import 'package:tapped/tapped.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:heibai/util/DataUtils.dart';
import 'package:heibai/pages/changephone.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/foundation.dart';
import 'dart:typed_data';
import 'package:heibai/constants/events/LoginEvent.dart';

class MineinfoDataPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return MineinfoDataPageState();
  }
}

class MineinfoDataPageState extends State<MineinfoDataPage> {
  List<XFile> _imageFileList = List.empty(growable: true); //存放选择的图片
  final ImagePicker _picker = ImagePicker();
  int maxFileCount = 1; //最大选择图片数量
  dynamic _pickImageError;
  // int _bigImageIndex = 0; //选中的需要放大的图片的下标
  // bool _bigImageVisibility = false; //是否显示预览大图
  String upurl;

  //获取当前展示的图的数量
  int getImageCount() {
    if (_imageFileList.length < maxFileCount) {
      return _imageFileList.length + 1;
    } else {
      return _imageFileList.length;
    }
  }

  void _onImageButtonPressed(ImageSource source,
      {BuildContext context,
      double maxHeight,
      double maxWidth,
      int imageQuality}) async {
    try {
      _imageFileList = List.empty(growable: true);
      final pickedFileList = await _picker.pickMultiImage(
        maxWidth: maxWidth,
        maxHeight: maxHeight,
        imageQuality: imageQuality,
      );
      setState(() {
        //pickedFileList.e
        if (_imageFileList.length < maxFileCount) {
          //小于最大数量
          if ((_imageFileList.length + (pickedFileList?.length ?? 0)) <=
              maxFileCount) {
            //加上新选中的不超过最大数量
            pickedFileList.forEach((element) {
              _imageFileList.add(element);
              uploadimga();
            });
          } else {
            //否则报错
            // Global.showCenterToast("超过可选最大数量!自动移除多余的图片");
            int avaliableCount = maxFileCount - _imageFileList.length;
            for (int i = 0; i < avaliableCount; i++) {
              _imageFileList.add(pickedFileList[i]);
            }
          }
        }
      });
    } catch (e) {
      setState(() {
        // Global.showCenterToast("$_pickImageError");//出现错误的话报错
        _pickImageError = e;
        JCHub.showmsg("$_pickImageError", context);
      });
    }
  }

  void post_member_update(params) async {
    // params["code"] = widget.model.code;

    ResultData resultData =
        await AppApi.getInstance().post_member_update(context, true, params);
    if (resultData.isSuccess()) {
      JCHub.showmsg(S.current.XGCG, context);
      // Navigator.pop(context, "refresh");
      _imageFileList.remove;
      upurl = '';
      getUserInfo();
      Constants.eventBus.fire(LoginEvent());
    }
  }

  void uploadimga() async {
    //  _imageFileList[0].readAsBytes();

    List<int> byets = await _imageFileList[0].readAsBytes();
    ResultData resultData = await AppApi.getInstance()
        .uploadimage(context, File(_imageFileList[0].path), byets);
    if (resultData.isSuccess()) {
      // DataUtils.saveUserInfo(resultData.dataJson);
      // ConfigManager.
      upurl = resultData.data['file_path'];

      Map<String, dynamic> params = {};
      // params["mobile"] = bankzname;
      // params["password_confirm"] = bankcard;
      params["avatar"] = upurl;
      post_member_update(params);
      // NavigatorUtil.goToHomeRemovePage(context);
    } else {
      JCHub.showmsg(resultData.msg, context);
    }
  }

  UserInfo user = ConfigManager().user;
  getUserInfo() async {
    try {
      ResultData resultData =
          await AppApi.getInstance().get_member_info(context, false);
      if (resultData.isSuccess()) {
        DataUtils.saveUserInfo(resultData.dataJson);

        UserInfo userInfo = userInfoFromJson(resultData.dataJson);
        user = userInfo;

        ConfigManager().user = user;

        // ConfigManager.
        setState(() {
          // userAvatar = user.avatar;
          // userName = user.username;
          user = user;
          // path = user.getis_real();
        });
      } else {
        // user = UserInfo();
      }
    } catch (e) {
      print(e);
    }
  }

  Widget build(BuildContext context) {
    // 投资金额
    Widget avatar = Row(
      children: [
        Container(
          alignment: Alignment.center,
          child: Text(
            S.current.TX,
            style: TextStyle(
              fontSize: 12,
              // fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.textGaryColor,
            ),
          ),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        Container(
          // margin: EdgeInsets.all(6),
          height: 40,
          width: 40,

          child: Tapped(
            child: Container(
              height: 40,
              width: 40,
              child: ClipOval(
                  child: _imageFileList.length > 0
                      ? kIsWeb == true
                          ? Image.network((_imageFileList[0].path))
                          : Image.file(File(_imageFileList[0].path),
                              fit: BoxFit.cover)
                      : CachedNetworkImage(
                          imageUrl: ConfigManager().imageHost + user.avatar,
                          fit: BoxFit.cover,
                          placeholder: (context, url) => Image.asset(
                            "images/wode/yonghu@3x.png",
                            width: 40,
                            height: 40,
                          ),
                          errorWidget: (context, url, error) => Image.asset(
                            "images/wode/yonghu@3x.png",
                            width: 40,
                            height: 40,
                          ),
                        )),
            ),
            onTap: () => _onImageButtonPressed(
              //执行打开相册
              //
              ImageSource.gallery,
              context: context,
              imageQuality: 40, //图片压缩
            ),
          ),
        ),
        Container(
          width: 5,
        ),
        Container(
          height: 13,
          width: 19,
          child: Image.asset(
            "images/wode/xyy@3x.png",
            width: 19,
            height: 13,
          ),
        )
      ],
    );

    Widget name = Row(
      children: [
        Container(
          alignment: Alignment.center,
          child: Text(
            S.current.MZ,
            style: TextStyle(
              fontSize: 12,
              // fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.textGaryColor,
            ),
          ),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        Container(
          alignment: Alignment.center,
          child: Text(
            user.getusername(),
            style: TextStyle(
              fontSize: 12,
              // fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.dateGaryColor,
            ),
          ),
        ),
        Container(
          width: 5,
        ),
        Container(
          height: 13,
          width: 19,
          child: Image.asset(
            "images/wode/xyy@3x.png",
            width: 19,
            height: 13,
          ),
        )
      ],
    );
    Widget grade = Row(
      children: [
        Container(
          alignment: Alignment.center,
          child: Text(
            S.current.DJ,
            style: TextStyle(
              fontSize: 12,
              // fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.textGaryColor,
            ),
          ),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        Container(
          alignment: Alignment.center,
          child: Text(
            user.getlevelname(),
            style: TextStyle(
              fontSize: 12,
              // fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.dateGaryColor,
            ),
          ),
        ),
        Container(
          width: 5,
        ),
        Container(
          height: 13,
          width: 19,
          child: Image.asset(
            "images/wode/xyy@3x.png",
            width: 19,
            height: 13,
          ),
        )
      ],
    );
    Widget phoneNumbe = Row(
      children: [
        Container(
          alignment: Alignment.center,
          child: Text(
            S.current.SJH,
            style: TextStyle(
              fontSize: 12,
              // fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.textGaryColor,
            ),
          ),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        Container(
          alignment: Alignment.center,
          child: Text(
            user.getphone(),
            style: TextStyle(
              fontSize: 12,
              // fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.dateGaryColor,
            ),
          ),
        ),
        Container(
          width: 5,
        ),
        Container(
          height: 13,
          width: 19,
          child: Image.asset(
            "images/wode/xyy@3x.png",
            width: 19,
            height: 13,
          ),
        )
      ],
    );

    Widget userId = Row(
      children: [
        Container(
          alignment: Alignment.center,
          child: Text(
            'ID',
            style: TextStyle(
              fontSize: 12,
              // fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.textGaryColor,
            ),
          ),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        Container(
          alignment: Alignment.center,
          child: Text(
            user.id.toString(),
            style: TextStyle(
              fontSize: 12,
              // fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.dateGaryColor,
            ),
          ),
        ),
      ],
    );

    Widget Creditscore = Row(
      children: [
        Container(
          alignment: Alignment.center,
          child: Text(
            S.current.Reputationpoints,
            style: TextStyle(
              fontSize: 12,
              // fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.textGaryColor,
            ),
          ),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        Container(
          alignment: Alignment.center,
          child: Text(
            user.score.toString(),
            style: TextStyle(
              fontSize: 12,
              // fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.dateGaryColor,
            ),
          ),
        ),
      ],
    );
    Widget topview = Column(children: <Widget>[
      SizedBox(
        height: 10,
      ),
      Container(
        color: ThemeUtils().currentColorTheme.contentBG,
        margin: EdgeInsets.fromLTRB(15, 0, 15, 0),
        padding: EdgeInsets.fromLTRB(15, 0, 10, 0),
        height: 50,
        child: avatar,
      ),
      SizedBox(
        height: 10,
      ),
      Container(
        color: ThemeUtils().currentColorTheme.contentBG,
        margin: EdgeInsets.fromLTRB(15, 0, 15, 0),
        padding: EdgeInsets.fromLTRB(15, 0, 10, 0),
        height: 50,
        child: name,
      ),
      SizedBox(
        height: 10,
      ),
      Container(
        color: ThemeUtils().currentColorTheme.contentBG,
        margin: EdgeInsets.fromLTRB(15, 0, 15, 0),
        padding: EdgeInsets.fromLTRB(15, 0, 10, 0),
        height: 50,
        child: grade,
      ),
      SizedBox(
        height: 10,
      ),
      Container(
        color: ThemeUtils().currentColorTheme.contentBG,
        margin: EdgeInsets.fromLTRB(15, 0, 15, 0),
        padding: EdgeInsets.fromLTRB(15, 0, 10, 0),
        height: 50,
        child: InkWell(
          child: phoneNumbe,
          onTap: () async {
            final result = await Navigator.of(context)
                .push(MaterialPageRoute(builder: (context) {
              return changephone();
            }));
            // result为"refresh"代表登录成功
            if (result != null && result == "refresh") {
              getUserInfo();
            }
          },
        ),
      ),
      SizedBox(
        height: 10,
      ),
      Container(
        color: ThemeUtils().currentColorTheme.contentBG,
        margin: EdgeInsets.fromLTRB(15, 0, 15, 0),
        padding: EdgeInsets.fromLTRB(15, 0, 10, 0),
        height: 50,
        child: userId,
      ),
      SizedBox(
        height: 10,
      ),
      Container(
        color: ThemeUtils().currentColorTheme.contentBG,
        height: 50,
        margin: EdgeInsets.fromLTRB(15, 0, 15, 0),
        padding: EdgeInsets.fromLTRB(15, 0, 10, 0),
        child: Creditscore,
      ),
      SizedBox(
        height: 5,
      ),
    ]);

    Widget allviebody = Scaffold(
      backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
      resizeToAvoidBottomInset: false,
      body: Container(

          // padding: EdgeInsets.fromLTRB(40, 16, 30, 40),
          child: topview),
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
        ),
        // 如果没有设置这项， 二级页面 会默认是返回箭头  ， 有侧边栏的页面默认有图标（用来打开侧边栏）
        // automaticallyImplyLeading: true,
        // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
        title: ThemeUtils.sText(S.current.GRXX),
        centerTitle: true,
        //  actions: <Widget>[
        //     IconButton(
        //         icon: Icon(Icons.add_alarm),
        //         tooltip: 'Add Alarm',
        //         onPressed: () {
        //           // do nothing
        //         })
        //   ],   // 标题是否在居中

        elevation: 0, // 导航栏Z轴的高度，默认是1  默认就是有高度 阴影的
        backgroundColor: ThemeUtils()
            .currentColorTheme
            .contentBG, // 导航栏的颜色  默认是 ThemeData 的颜色
//         flexibleSpace: FlexibleSpaceBar(title: Text("你号"),),//这个堆叠在工具栏上面  一般 appbar不用  主要用在 SliverAppBar上
//          brightness: Brightness.light, //状态栏的深度 有白色和黑色两种主题
//          titleSpacing: 10,//flexibleSpace 和 title 的距离  默认是重合的
//          toolbarOpacity: 0.5,// 导航栏透明度 默认是1 ，不包括flexibleSpace
//          bottomOpacity: 0.5,
      ),
    );

    return allviebody;
  }
}
