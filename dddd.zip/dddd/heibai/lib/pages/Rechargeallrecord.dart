import 'package:flutter/material.dart';
import 'package:heibai/pages/userMsgRow.dart';
import 'dart:convert';
import 'package:heibai/util/ThemeUtils.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:heibai/net/api/Api.dart';
import 'package:heibai/net/api/app_api.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
// import '../Classes/model/billModel.dart';
import '../Classes/model/RechargeallrecordModel.dart';
import 'dart:io';
// import 'dart:convert';
import 'package:heibai/Classes/JCHub/JCHub.dart';
import 'package:heibai/generated/l10n.dart';
import 'package:flutter/foundation.dart';

class Rechargeallrecord extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return RechargeallrecordState();
  }
}

class RechargeallrecordState extends State<Rechargeallrecord> {
  List<ListElement> list = [];
  bool showLoading = true;
  int page = 1;
  RefreshController _refreshController =
      RefreshController(initialRefresh: false);

  void get_recharge_page_list() async {
    Map<String, dynamic> params = {};

    params["page"] = 1;
    params["pageSize"] = 15;
    // params["status"] = 2;

    ResultData resultData = await AppApi.getInstance()
        .get_recharge_page_list(context, false, params);
    if (resultData.isSuccess()) {
      RechargeallrecordModel model =
          rechargeallrecordModelFromJson(resultData.dataJson);
      list = model.list;
      page++;
      setState(() {
        if (list.length > 0) {
          showLoading = false;
        }
      });
    }
  }

  @override
  void initState() {
    super.initState();
    get_recharge_page_list();
    //   if (SchedulerBinding.instance.schedulerPhase ==
    //   SchedulerPhase.persistentCallbacks) {
    // SchedulerBinding.instance.addPostFrameCallback((_) => onWidgetBuild());
  }

  Widget build(BuildContext context) {
    final mediaQueryData = MediaQuery.of(context);

// 2.获取宽度和高度
    final screenWidth = mediaQueryData.size.width;
    final screenHeight = mediaQueryData.size.height;

    final statusBarHeight = mediaQueryData.padding.top;
// 有刘海的屏幕:34 没有刘海的屏幕0
    double bottomHeight = 10.0;

    if (!kIsWeb) {
      bottomHeight = 10.0;
      if (Platform.isIOS) {
        bottomHeight = mediaQueryData.padding.bottom;
      }
    }

    Color themeColor = ThemeUtils().currentColorTheme.currentColorTheme;
    Color contentBG = ThemeUtils().currentColorTheme.contentBG;
    var listView = ListView.builder(
      // shrinkWrap: true, //解决无限高度问题
      // physics: new NeverScrollableScrollPhysics(), //禁用滑动事件
      itemCount: list.length,
      itemBuilder: (context, i) => renderRow(i),
    );

    Widget allviebody = Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
        ),
        automaticallyImplyLeading: true,
        // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
        title: ThemeUtils.sText(S.current.Rechargerecord),
        backgroundColor: ThemeUtils().currentColorTheme.contentBG,
      ),
      backgroundColor: themeColor,
      body: showLoading == true
          ? Center(
              child: Container(
              child: Image.asset(
                "images/wode/nulldata.png",
              ),
            ))
          : Container(
              margin: EdgeInsets.only(bottom: bottomHeight),
              child: SmartRefresher(
                header: WaterDropHeader(),
                footer: ClassicFooter(
                  loadStyle: LoadStyle.ShowWhenLoading,
                ),
                enablePullDown: true,
                enablePullUp: true,
                // header: ClassicHeader(refreshStyle: RefreshStyle.Follow),
                // footer: tableHeader.footer,
                controller: _refreshController,
                onRefresh: _onRefresh,
                onLoading: _onLoading,
                child: listView,
              ),
            ),
    );

    return allviebody;
  }

  void _onRefresh() async {
    get_recharge_page_list();

    // if failed,use refreshFailed()
    _refreshController.refreshCompleted();
  }

  void _onLoading() async {
    Map<String, dynamic> params = {};

    params["page"] = page;
    params["pageSize"] = 15;
    // params["status"] = 2;

    ResultData resultData = await AppApi.getInstance()
        .get_recharge_page_list(context, false, params);
    if (resultData.isSuccess()) {
      // List list = resultData.data;
      RechargeallrecordModel model =
          rechargeallrecordModelFromJson(resultData.dataJson);
      // nowmodel = model;
      // showLoading = false;
      // list.addAll(model.list);

      if (page < model.page.total) {
        page++;
        _refreshController.loadComplete();
      } else {
        _refreshController.loadNoData();
      }

      setState(() {
        // showLoading = false;
        // nowmodel = model;
        list.addAll(model.list);
        //  list.addAll(model.list);
      });
    } else {
      JCHub.showmsg(resultData.msg, context);
      _refreshController.loadComplete();
      // tap();
    }
    if (mounted) setState(() {});
  }

  renderRow(i) {
    ListElement item = list[i];

    var rowitem = biiemlistView(
      model: item,
    );

    return InkWell(
      child: rowitem,
      onTap: () {},
    );
  }
}

class biiemlistView extends StatelessWidget {
  final ListElement model;
  final Function onTap;
  const biiemlistView({
    Key key,
    this.onTap,
    this.model,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    var deviceData = MediaQuery.of(context); // 返回 MediaQueryData

    Widget toptext = Container(
      height: 21,
      width: 100,
      child: Text(
        model.typeName,
        overflow: TextOverflow.ellipsis,
        maxLines: 1,
        style: TextStyle(
            color: ThemeUtils().currentColorTheme.textWithdkkkwColor,
            fontSize: 15),
        textAlign: TextAlign.left,
      ),
    );
    var Time = DateTime.fromMillisecondsSinceEpoch(model.createTime * 1000);
    var aTime = Time.toLocal().toString().substring(0, 16);
    Widget bottomtext = Container(
      height: 15,
      width: 150,
      child: Text(
        aTime.toString(),
        overflow: TextOverflow.ellipsis,
        maxLines: 1,
        style: TextStyle(
          color: ThemeUtils().currentColorTheme.textWithdDDrawColor,
          fontSize: 12,
        ),
      ),
    );

    ;
    Widget textView = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        SizedBox(
          height: 5,
        ),
        toptext,
        SizedBox(
          height: 5,
        ),
        bottomtext,
        // SizedBox(
        //   height: 12,
        // ),
      ],
    );

    Widget rtoptext = Container(
      height: 21,
      width: 100,
      child: Text(
        model.amount.toString(),
        overflow: TextOverflow.ellipsis,
        maxLines: 1,
        style: TextStyle(
            color: ThemeUtils().currentColorTheme.textWithdkkkwColor,
            fontSize: 15),
        textAlign: TextAlign.right,
      ),
    );
    var bstr = "";
    Color textColor = ThemeUtils().currentColorTheme.textWithdDDrawColor;
    // 1 审核中 2审核成功 3审核失败
    if (model.status == 1) {
      bstr = S.current.SHZ;
    }
    if (model.status == 2) {
      bstr = S.current.SHCG;
      textColor = ThemeUtils().currentColorTheme.textgreenColor;
    }
    if (model.status == 3) {
      bstr = S.current.SHSB;
      textColor = ThemeUtils().currentColorTheme.numberRedColor;
    }
    Widget rbottomtext = Container(
      height: 15,
      width: 100,
      child: Text(
        bstr,
        overflow: TextOverflow.ellipsis,
        maxLines: 1,
        textAlign: TextAlign.right,
        style: TextStyle(
          color: textColor,
          fontSize: 12,
        ),
      ),
    );

    ;
    Widget rtextView = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        SizedBox(
          height: 5,
        ),
        rtoptext,
        SizedBox(
          height: 5,
        ),
        rbottomtext,
        SizedBox(
          height: 3,
        ),
      ],
    );

    Widget body = Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[
        textView,
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        rtextView,
      ],
    );

    Widget topview = Column(children: [
      body,
      Divider(
        color: ThemeUtils().currentColorTheme.lineColor,
        height: 1.0,
      )
    ]);
    return Center(
      child: Container(
        padding: EdgeInsets.only(left: 10, right: 10),

        height: 50,
        child: topview,
        color: ThemeUtils().currentColorTheme.contentBG,
        // color: Colors.red,
      ),
    );
  }
}
