import 'dart:async';
// import 'dart:html';
import 'package:flutter/foundation.dart';
import 'package:web_socket_channel/io.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:heibai/net/api/Api.dart';
import 'package:heibai/Classes/model/config.dart';

/// WebSocket地址

/// WebSocket状态
enum SocketStatus {
  SocketStatusConnected, // 已连接
  SocketStatusFailed, // 失败
  SocketStatusClosed, // 连接关闭
}

class WebSocketUtility {
  /// 单例对象
  static WebSocketUtility _socket;

  /// Listeners
  /// 监听事件对应处理函数
  ///
  ObserverList<Function> _listeners = new ObserverList<Function>();

  /// 内部构造方法，可避免外部暴露构造函数，进行实例化
  WebSocketUtility._();
  var id;

  /// 获取单例内部方法
  factory WebSocketUtility() {
    // 只能有一个实例
    if (_socket == null) {
      _socket = new WebSocketUtility._();
    }
    return _socket;
  }

  WebSocketChannel _webSocket; // WebSocket
  SocketStatus socketStatus; // socket状态
  Timer _heartBeat; // 心跳定时器
  num _heartTimes = 3000; // 心跳间隔(毫秒)
  num _reconnectCount = 5; // 重连次数，默认60次
  num _reconnectTimes = 0; // 重连计数器
  Timer _reconnectTimer; // 重连定时器
  Function onError; // 连接错误回调
  Function onOpen; // 连接开启回调
  Function onMessage; // 接收消息回调

  /// 初始化WebSocket
  void initWebSocket(
      {Function onOpen, Function onMessage, Function onError, String id}) {
    this.onOpen = onOpen;
    this.onMessage = onMessage;
    this.onError = onError;
    print('WebSocket连接成功');
    openSocket(id);
  }

  // void getWebSocket({Function onMessage}) {
  //   this.onMessage = onMessage;
  // }

  /// 开启WebSocket连接
  void openSocket(id) {
    closeSocket();

    String http = Api.SOCKET_URL;
    Uri url = Uri.parse(ConfigManager().scockHost + "?id=" + id);
    _webSocket = WebSocketChannel.connect(url);
    // print('WebSocket连接成功');
    // 连接成功，返回WebSocket实例
    socketStatus = SocketStatus.SocketStatusConnected;
    // 连接成功，重置重连计数器
    _reconnectTimes = 0;
    if (_reconnectTimer != null) {
      _reconnectTimer.cancel();
      _reconnectTimer = null;
    }
    onOpen();
    // 接收消息
    _webSocket.stream.listen((data) => webSocketOnMessage(data),
        onError: webSocketOnError, onDone: webSocketOnDone);
  }

  /// WebSocket接收消息回调
  webSocketOnMessage(data) {
    //  var dataJson = json.encode(data);

    onMessage(data);
    // print(data);

    _listeners.forEach((Function callback) {
      callback(data);
    });
  }

  /// WebSocket关闭连接回调
  webSocketOnDone() {
    // print('closed');
    reconnect();
  }

  ///
  /// 添加回调
  ///
  addListener(Function callback) {
    _listeners.add(callback);
  }

  removeListener(Function callback) {
    _listeners.remove(callback);
  }

  /// WebSocket连接错误回调
  webSocketOnError(e) {
    WebSocketChannelException ex = e;
    socketStatus = SocketStatus.SocketStatusFailed;
    onError(ex.message);
    closeSocket();
  }

  /// 初始化心跳
  void initHeartBeat() {
    destroyHeartBeat();
    _heartBeat =
        new Timer.periodic(Duration(milliseconds: _heartTimes), (timer) {
      sentHeart();
    });
  }

  /// 心跳
  void sentHeart() {
    sendMessage('{"module": "HEART_CHECK", "message": "请求心跳"}');
  }

  /// 销毁心跳
  void destroyHeartBeat() {
    if (_heartBeat != null) {
      _heartBeat.cancel();
      _heartBeat = null;
    }
  }

  /// 关闭WebSocket
  void closeSocket() {
    if (_webSocket != null) {
      print('WebSocket连接关闭');
      _webSocket.sink.close();
      destroyHeartBeat();
      socketStatus = SocketStatus.SocketStatusClosed;
    }
  }

  void scloseSocket() {
    if (_webSocket != null) {
      print('WebSocket连接关闭');
      _webSocket.sink.close();
      destroyHeartBeat();
      socketStatus = SocketStatus.SocketStatusClosed;
    }
  }

  /// 发送WebSocket消息
  void sendMessage(message) {
    if (_webSocket != null) {
      switch (socketStatus) {
        case SocketStatus.SocketStatusConnected:
          // print('发送中：' + message);
          _webSocket.sink.add(message);
          break;
        case SocketStatus.SocketStatusClosed:
          print('连接已关闭');
          break;
        case SocketStatus.SocketStatusFailed:
          // print('发送失败');
          break;
        default:
          break;
      }
    }
  }

  /// 重连机制
  void reconnect() {
    if (_reconnectTimes < _reconnectCount) {
      _reconnectTimes++;
      _reconnectTimer =
          new Timer.periodic(Duration(milliseconds: _heartTimes), (timer) {
        openSocket(id);
      });
    } else {
      if (_reconnectTimer != null) {
        // print('重连次数超过最大次数');
        _reconnectTimer.cancel();
        _reconnectTimer = null;
      }
      return;
    }
  }
}
