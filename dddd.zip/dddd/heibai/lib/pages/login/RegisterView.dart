// ignore_for_file: unused_import

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:heibai/util/DataUtils.dart';
import 'package:heibai/net/api/Api.dart';
import 'package:heibai/net/api/app_api.dart';
import 'package:heibai/routers/navigator_util.dart';
import 'package:heibai/util/ThemeUtils.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:heibai/Classes/model/config.dart';
import 'package:tapped/tapped.dart'; //咨询
import 'package:heibai/generated/l10n.dart';
import 'package:heibai/pages/login/loginView.dart';
import 'package:heibai/pages/login/country_picker.dart';
import 'package:heibai/pages/login/country.dart';
import 'package:heibai/pages/login/country_listview.dart';
import 'package:heibai/pages/login/countries_json.dart';
import 'dart:convert';
import 'package:heibai/pages/login/countryView.dart';
import 'package:heibai/routers/Application.dart';
import 'package:heibai/routers/routes.dart';

import 'package:heibai/Classes/JCHub/JCHub.dart';

class RegisterView extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return RegisterViewState();
  }
}

class RegisterViewState extends State<RegisterView> {
  // final ValueNotifier<int> new_counter = ValueNotifier<int>(0);

  Config f = ConfigManager().config;
  Country country = Country.fromJson(countryCodes[0]);
  bool loading = true;

  // final usernameCtrl = TextEditingController(text: '');
  final phoneCtrl = TextEditingController(text: '');
  // final phoneCodeCtrl = TextEditingController(text: '');
  final passwordCtrl = TextEditingController(text: '');
  final twopasswordCtrl = TextEditingController(text: '');
  final wpasswordCtrl = TextEditingController(text: '');
  final referralCodeCtrl = TextEditingController(text: '');

  // 标记当前页面是否是我们自定义的回调页面
  // bool isLoadingCallbackPage = false;
  // 是否正在注册
  bool isOnLogin = false;
  List<Map<dynamic, dynamic>> ncountryCodes = [];
  var Widgets = <Widget>[];

  Country ncountry;
// ValueNotifier是ValueListenableBuilder 需要传入的ValueListenable<T> 抽象类的实现 . 接收一个泛型.
  final ValueNotifier<String> new_counter =
      ValueNotifier<String>(S.current.DXZGJDQ);
  @override
  void initState() {
    super.initState();
  }

  Widget _builderWithValue(BuildContext context, String value, Widget child) {
    return regText(
      onTap: () async {
        // get_country();
        // c.launch(context);
        final result = await Navigator.of(context)
            .push(MaterialPageRoute(builder: (context) {
          return countryView(
            onSelected: (country) {
              ncountry = country;
              new_counter.value = ncountry.zh_name + '+' + ncountry.code;
            },
          );
        }));
      },
      des: '$value',
      title: S.current.GJDQ,
      icon: Image.asset(
        "images/wode/xyy@3x.png",
        width: 19,
        height: 13,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Config f = ConfigManager().config;
    // TODO: implement build

    // void fromJson(Map<dynamic, dynamic> countryData) {
    //   // newcountryCodes = countryData['list'];i
    //   var yt = countryCodes;
    //   var tncountryCodes = countryData.putIfAbsent("list", () => (2)); //存在
    //   ncountryCodes = countryData.putIfAbsent("list", () => (2)); //存在
    //   // print(result);

    //   var k = ncountryCodes;
    // }

    void regrequest(Map<String, dynamic> params, BuildContext context) async {
      ResultData resultData =
          await AppApi.getInstance().regrequest(context, true, params);
      if (resultData.isSuccess()) {
        DataUtils.saveUserInfo(resultData.dataJson);
        // ConfigManager.

        NavigatorUtil.goToHomeRemovePage(context);
      } else {
        JCHub.showmsg(resultData.msg, context);
        // setState(() {
        //   isOnLogin = false;
        // });
      }
    }

    void regbtnon(BuildContext context) {
      // setState(() {
      //   isOnLogin = true;
      // });
      String username = phoneCtrl.text.trim();
      String password = passwordCtrl.text.trim();
      String twopassword = twopasswordCtrl.text.trim();
      String wpassword = wpasswordCtrl.text.trim();
      // String phoneCode = phoneCodeCtrl.text.trim();
      String referralCode = referralCodeCtrl.text.trim();
      String msg;

      if (username.isEmpty) {
        if (f != null) {
          if (f.base.mobileRegister == 1) {
            msg = S.current.SJHBNWK;
            JCHub.showmsg(msg, context);
            return;
          } else {
            msg = S.current.YHMBNWK;
            JCHub.showmsg(msg, context);
            return;
          }
        }
      }
      if (password.isEmpty) {
        msg = S.current.MMBNWK;
        JCHub.showmsg(msg, context);
        return;
      }
      if (twopassword.isEmpty) {
        msg = S.current.QRMMBNWK;
        JCHub.showmsg(msg, context);
        return;
      }
      if (twopassword.isEmpty) {
        msg = S.current.TXMMBNWK;
        JCHub.showmsg(msg, context);
        return;
      }

      if (f != null) {
        if (f.base.mobileRegister == 1) {
          if (country == null) {
            msg = S.current.DQXZQH;
            ;
            JCHub.showmsg(msg, context);
            return;
          }
        }
      }

      Map<String, dynamic> params = {};
      if (country != null) {
        params["country"] = country.code;
      }

      if (referralCode.length > 0) {
        params["invite_code"] = referralCode;
      }
      params["password"] = password;
      params["re_password"] = password;
      params["username"] = username;
      params["withdraw_password"] = wpassword;

      regrequest(params, context);
      // headers["lang"] = "1";
      FocusScope.of(context).requestFocus(FocusNode());
    }

    var loginBtn = Builder(builder: (ctx) {
      return CommonButton(
          text: S.current.XZC,
          color: ThemeUtils().currentColorTheme.labelColorY,
          onTap: () {
            // if (isOnLogin) return;
            regbtnon(ctx);
          });
    });
    if (!isOnLogin) {
      Widgets.add(SizedBox(
        height: 10,
      ));
      // Widgets.add(regTextField(
      //   icon: "姓名",
      //   title: "请填写真实姓名",
      //   controller: usernameCtrl,
      // ));
      // Widgets.add(SizedBox(
      //   height: 3,
      // ));
      if (f != null) {
        if (f.base.mobileRegister == 1) {
          Widgets.add(ValueListenableBuilder<String>(
            builder: _builderWithValue,
            valueListenable: new_counter,
          ));
          Widgets.add(SizedBox(
            height: 3,
          ));
          Widgets.add(regTextField(
            icon: S.current.SJH,
            title: S.current.ZWNDDLZH,
            controller: phoneCtrl,
            type: TextInputType.number,
          ));
        } else {
          Widgets.add(regTextField(
            icon: S.current.DYHM,
            title: S.current.ZWNDDLZH,
            controller: phoneCtrl,
            type: TextInputType.text,
          ));
        }
      }

      Widgets.add(SizedBox(
        height: 3,
      ));
      Widgets.add(regTextField(
        icon: S.current.MM,
        title: S.current.QSRMM,
        controller: passwordCtrl,
        isshow: true,
      ));
      Widgets.add(SizedBox(
        height: 3,
      ));
      Widgets.add(regTextField(
        icon: S.current.QRMM,
        title: S.current.QSRMM,
        controller: twopasswordCtrl,
        isshow: true,
      ));
      Widgets.add(SizedBox(
        height: 3,
      ));
      Widgets.add(regTextField(
        icon: S.current.THXM,
        title: S.current.SQSRTXMM,
        controller: wpasswordCtrl,
        type: TextInputType.number,
        isshow: true,
      ));
      Widgets.add(SizedBox(
        height: 3,
      ));

      if (f != null) {
        if (f.base.showInviteCode == 1) {
          Widgets.add(regTextField(
            icon: S.current.TJM,
            title: S.current.QTXTJM,
            controller: referralCodeCtrl,
          ));
        }
      }

      Widgets.add(SizedBox(
        height: 58,
      ));
      Widgets.add(loginBtn);
    }

    var loadingView;
    if (isOnLogin) {
      loadingView = Center(
          child: Padding(
        padding: const EdgeInsets.fromLTRB(0, 30, 0, 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            // CupertinoActivityIndicator(),
            // Text("注册中，请稍等...")
          ],
        ),
      ));
    } else {
      loadingView = Center();
    }

    Widgets.add(Expanded(
        child: Column(
      children: <Widget>[
        Expanded(child: loadingView),
      ],
    )));
    Widget tbody = Container(
      padding: const EdgeInsets.all(28),
      child: Column(
        children: Widgets,
      ),
    );
    Widget allviebody = Scaffold(
      backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
      resizeToAvoidBottomInset: false,
      body: tbody,
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
        ),
        // 如果没有设置这项， 二级页面 会默认是返回箭头  ， 有侧边栏的页面默认有图标（用来打开侧边栏）
        // automaticallyImplyLeading: true,
        // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
        title: ThemeUtils.sText(S.current.XZC),
        centerTitle: true,
        //  actions: <Widget>[
        //     IconButton(
        //         icon: Icon(Icons.add_alarm),
        //         tooltip: 'Add Alarm',
        //         onPressed: () {
        //           // do nothing
        //         })
        //   ],   // 标题是否在居中

        elevation: 0, // 导航栏Z轴的高度，默认是1  默认就是有高度 阴影的
        backgroundColor: ThemeUtils()
            .currentColorTheme
            .contentBG, // 导航栏的颜色  默认是 ThemeData 的颜色
//         flexibleSpace: FlexibleSpaceBar(title: Text("你号"),),//这个堆叠在工具栏上面  一般 appbar不用  主要用在 SliverAppBar上
//          brightness: Brightness.light, //状态栏的深度 有白色和黑色两种主题
//          titleSpacing: 10,//flexibleSpace 和 title 的距离  默认是重合的
//          toolbarOpacity: 0.5,// 导航栏透明度 默认是1 ，不包括flexibleSpace
//          bottomOpacity: 0.5,
      ),
    );

    return allviebody;
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties.add(DiagnosticsProperty<Country>('country', country));
  }
}

class regTextField extends StatelessWidget {
  final String icon;
  final TextInputType type;
  final String title;
  final Function onTap;
  final TextEditingController controller;
  final bool isshow;

  const regTextField(
      {Key key,
      this.icon,
      this.title,
      this.onTap,
      this.controller,
      this.isshow = false,
      this.type = TextInputType.text})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    var iconContainer = Container(
      // margin: EdgeInsets.all(),
      height: 20,
      width: 60,
      // decoration: BoxDecoration(
      //   color: ThemeUtils().currentColorTheme.labelColorW,
      //   borderRadius: BorderRadius.circular(2),
      //   gradient: LinearGradient(
      //     begin: Alignment.topLeft,
      //     end: Alignment.bottomCenter,
      //     colors: [
      //       color2,
      //       color!,
      //     ],
      //     stops: [0.1, 0.8],
      //   ),
      // ),
      child: Text(
        icon,
        style: TextStyle(
          fontSize: 13,
          color: ThemeUtils().currentColorTheme.labelColorW,
        ),
      ),
    );

    Widget body = Row(
      children: [
        iconContainer,
        new SizedBox(
          child: new Container(
            // margin: EdgeInsets.fromLTRB(15, 5, 15, 5),
            color: ThemeUtils().currentColorTheme.contentBG,
            width: MediaQuery.of(context).size.width - 150,
            // height: 30,
            padding: EdgeInsets.fromLTRB(10, 0, 0, 0),
            alignment: Alignment.center,
            child: TextField(
              controller: controller,
              obscureText: isshow,
              keyboardType: type,
              maxLines: 1,
              decoration: InputDecoration(
                hintText: title,
                border: InputBorder.none,
                hintStyle: TextStyle(
                  fontSize: 12,
                  color: ThemeUtils().currentColorTheme.textGaryColor,
                ),
              ),
              style: TextStyle(
                fontSize: 12,
                color: ThemeUtils().currentColorTheme.textWithdrawColor,
              ),
            ),
          ),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
      ],
    );

    // body = Tapped(
    //   child: body,
    //   onTap: onTap,
    // );
    return Container(
      child: Container(
        padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
        // margin: EdgeInsets.fromLTRB(15, 5, 15, 5),
        color: ThemeUtils().currentColorTheme.contentBG,
        height: 50,
        child: body,
      ),
    );
  }
}

class regText extends StatelessWidget {
  final String des;
  final Image icon;
  final String title;
  final Function onTap;

  const regText({Key key, this.icon, this.title, this.onTap, this.des})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    var iconContainer = Container(
      // margin: EdgeInsets.all(),
      height: 20,
      width: 60,
      // decoration: BoxDecoration(
      //   color: ThemeUtils().currentColorTheme.labelColorW,
      //   borderRadius: BorderRadius.circular(2),
      //   gradient: LinearGradient(
      //     begin: Alignment.topLeft,
      //     end: Alignment.bottomCenter,
      //     colors: [
      //       color2,
      //       color!,
      //     ],
      //     stops: [0.1, 0.8],
      //   ),
      // ),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 13,
          color: ThemeUtils().currentColorTheme.labelColorW,
        ),
      ),
    );

    var leftIconContainer = Container(
      // margin: EdgeInsets.all(6),
      height: 13,
      width: 19,
      // decoration: BoxDecoration(
      //   color: ThemeUtils().currentColorTheme.labelColorW,
      //   borderRadius: BorderRadius.circular(2),
      //   gradient: LinearGradient(
      //     begin: Alignment.topLeft,
      //     end: Alignment.bottomCenter,
      //     colors: [
      //       color2,
      //       color!,
      //     ],
      //     stops: [0.1, 0.8],
      //   ),
      // ),
      child: icon,
    );

    Widget body = Row(
      children: [
        iconContainer,
        Container(
          alignment: Alignment.center,
          padding: EdgeInsets.only(left: 10),
          // height: 20,
          child: Text(
            des,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.dateGaryColor,
            ),
          ),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        leftIconContainer,
      ],
    );

    body = Tapped(
      child: body,
      onTap: onTap,
    );
    return Container(
      child: Container(
        // padding: EdgeInsets.all(12),
        padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
        color: ThemeUtils().currentColorTheme.contentBG,
        height: 50,
        child: body,
      ),
    );
  }
}
