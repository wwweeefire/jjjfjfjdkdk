// ignore_for_file: unused_import

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:heibai/net/api/Api.dart';
import 'package:heibai/net/api/app_api.dart';
import 'package:heibai/util/ThemeUtils.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:heibai/Classes/model/config.dart';
import 'package:tapped/tapped.dart'; //咨询
import 'package:fluttertoast/fluttertoast.dart';
import 'package:heibai/pages/login/RegisterView.dart';
import 'package:heibai/generated/l10n.dart';
// import 'package:heibai/Classes/routers/navigator_util.dart';
import 'package:heibai/pages/login/country.dart';
import 'package:heibai/pages/login/countries_json.dart';
import 'dart:convert';
import 'package:heibai/pages/login/countryView.dart';
import 'package:heibai/routers/Application.dart';
import 'package:heibai/routers/routes.dart';
import 'package:heibai/routers/navigator_util.dart';
import 'package:heibai/Classes/JCHub/JCHub.dart';
import 'package:heibai/util/DataUtils.dart';
import 'package:heibai/pages/localization_page.dart';
import 'package:heibai/pages/localthemepage.dart';

class LoginView extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return LoginViewState();
  }
}

//登录界面
class LoginViewState extends State<LoginView> {
  Config f = ConfigManager().config;

  bool loading = true;

  final usernameCtrl = TextEditingController(text: '');
  final passwordCtrl = TextEditingController(text: '');
  // 标记当前页面是否是我们自定义的回调页面
  // bool isLoadingCallbackPage = false;
  // 是否正在登录
  bool isOnLogin = false;
  Country ncountry;
  var imagepath;
// ValueNotifier是ValueListenableBuilder 需要传入的ValueListenable<T> 抽象类的实现 . 接收一个泛型.
  final ValueNotifier<String> new_counter =
      ValueNotifier<String>(S.current.DXZGJDQ);
  var Widgets = <Widget>[];

  @override
  // void initState() {
  //   super.initState();
  // }

  @override
  void initState() {
    super.initState();
  }

  Widget _builderWithValue(BuildContext context, String value, Widget child) {
    return regText(
      onTap: () async {
        // get_country();
        // c.launch(context);
        final result = await Navigator.of(context)
            .push(MaterialPageRoute(builder: (context) {
          return countryView(
            onSelected: (country) {
              ncountry = country;
              new_counter.value = ncountry.zh_name + '+' + ncountry.code;
            },
          );
        }));
      },
      des: '$value',
      title: S.current.GJDQ,
      icon: Image.asset(
        "images/wode/xyy@3x.png",
        width: 19,
        height: 13,
      ),
    );
  }

  void setStateIfMounted(f) {
    if (mounted) setState(f);
  }

  @override
  Widget build(BuildContext context) {
    void regrequest(Map<String, dynamic> params, BuildContext context) async {
      setStateIfMounted(() {
        isOnLogin = true;
      });
      ResultData resultData =
          await AppApi.getInstance().post_login(context, true, params);
      if (resultData.isSuccess()) {
        DataUtils.saveUserInfo(resultData.dataJson);
        // ConfigManager.

        NavigatorUtil.goToHomeRemovePage(context);
      } else {
        // setState(() {
        // isOnLogin = false;
        // });
        JCHub.showmsg(resultData.msg, context);
      }
    }

    var loginBtn = Builder(builder: (ctx) {
      return CommonButton(
          text: S.current.DL,
          color: ThemeUtils().currentColorTheme.labelColorY,
          onTap: () {
            // if (isOnLogin) return;
            // 拿到用户输入的账号密码
            String username = usernameCtrl.text.trim();
            String password = passwordCtrl.text.trim();
            if (username.isEmpty || password.isEmpty) {
              // Scaffold.of(ctx).showSnackBar(SnackBar(
              //   content: Text("账号和密码不能为空！"),
              // ));
              if (kIsWeb) {
                Fluttertoast.showToast(
                  msg: S.current.DZHMMBNWK,
                  toastLength: Toast.LENGTH_SHORT,
                  gravity: ToastGravity.CENTER,
                  webBgColor: "#e74c3c",
                  // textColor: Colors.black,
                  timeInSecForIosWeb: 5,
                );
              } else {
                Fluttertoast.showToast(
                    msg: S.current.DZHMMBNWK,
                    toastLength: Toast.LENGTH_SHORT,
                    gravity: ToastGravity.CENTER,
                    timeInSecForIosWeb: 1);
              }

              return;
            }
            if (f != null) {
              if (f.base.mobileRegister == 1) {
                if (ncountry == null) {
                  String msg = S.current.DQXZQH;
                  if (kIsWeb) {
                    Fluttertoast.showToast(
                      msg: msg,
                      toastLength: Toast.LENGTH_SHORT,
                      gravity: ToastGravity.CENTER,
                      webBgColor: "#e74c3c",
                      // textColor: Colors.black,
                      timeInSecForIosWeb: 5,
                    );
                  } else {
                    Fluttertoast.showToast(
                        msg: msg,
                        toastLength: Toast.LENGTH_SHORT,
                        gravity: ToastGravity.CENTER,
                        timeInSecForIosWeb: 1);
                  }

                  return;
                }
              }
            }

            Map<String, dynamic> params = {};

            if (ncountry != null) {
              params["country"] = ncountry.code;
            }

            params["password"] = password;

            params["username"] = username;

            regrequest(params, context);
            // 关闭键盘
            FocusScope.of(context).requestFocus(FocusNode());
            // 发送给webview，让webview登录后再取回token
            // autoLogin(username, password);
          });
    });
    var loadingView;
    // if (isOnLogin) {
    //   loadingView = Center(
    //       child: Padding(
    //     padding: const EdgeInsets.fromLTRB(0, 30, 0, 0),
    //     child: Column(
    //       crossAxisAlignment: CrossAxisAlignment.center,
    //       children: <Widget>[
    //         // CupertinoActivityIndicator(),
    //         Text("登录中，请稍等...")
    //       ],
    //     ),
    //   ));
    // } else {
    loadingView = Center();
    // }

    if (!isOnLogin) {
      String s;
      if (f == null) {
        s = Api.host;
      } else {
        s = ConfigManager().imageHost + f.base.appLogo;
      }
      final mediaQueryData = MediaQuery.of(context);

// 2.获取宽度和高度
      final screenWidth = mediaQueryData.size.width;
      Widget logo =
          Row(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
        Container(
            width: 160,
            height: 100,
            child: CachedNetworkImage(
                imageUrl: s,
                fit: BoxFit.cover,
                placeholder: (context, url) => CircularProgressIndicator(),
                errorWidget: (context, url, error) => Icon(Icons.error))),
      ]);

      Widgets.add(SizedBox(
        height: 50,
      ));
      Widgets.add(logo);
      Widgets.add(SizedBox(
        height: 10,
      ));

      // TODO: implement build

      if (f != null) {
        if (f.base.mobileRegister == 1) {
          Widgets.add(ValueListenableBuilder<String>(
            builder: _builderWithValue,
            valueListenable: new_counter,
          ));
          Widgets.add(SizedBox(
            height: 5,
          ));
          Widgets.add(iconText(
            icon: Image.asset(
              "images/login/_iphone@3x.png",
              width: 19,
              height: 13,
            ),
            title: S.current.SJH,
            controller: usernameCtrl,
            type: TextInputType.phone,
          ));
        } else {
          Widgets.add(iconText(
            icon: Image.asset(
              "images/login/_iphone@3x.png",
              width: 19,
              height: 13,
            ),
            title: S.current.DSRYHM,
            controller: usernameCtrl,
          ));
          ;
        }
        Widgets.add(SizedBox(
          height: 5,
        ));
        Widgets.add(iconText(
          icon: Image.asset(
            "images/login/login_lock@3x.png",
            width: 19,
            height: 13,
          ),
          title: S.current.QSRMM,
          type: TextInputType.visiblePassword,
          controller: passwordCtrl,
        ));
      }

      Widgets.add(SizedBox(
        height: 5,
      ));

      // Widgets.add(new inpuNameWiget());
      // Widgets.add(new ForgotPasswordButtonWiget());
      // Widgets.add(SizedBox(
      //   height: 30,
      // ));
      Widgets.add(loginBtn);
    }
    Widgets.add(Expanded(
        child: Column(
      children: <Widget>[
        Expanded(child: loadingView),
      ],
    )));
    Widget tbody = Container(
      padding: const EdgeInsets.all(28),
      child: Column(
        children: Widgets,
      ),
    );

    _regview() async {
      // 打开登录页并处理登录成功的回调
      final result = await Navigator.of(context)
          .push(MaterialPageRoute(builder: (context) {
        return RegisterView();
      }));
      // result为"refresh"代表登录成功
      if (result != null && result == "refresh") {
        // 刷新用户信息
        Navigator.pop(context, "refresh");
      }
      // navigator_util()

      // NavigatorUtil.goToLoginRemovePage(context);
    }

    Widget yesterdaIncome = Tapped(
        onTap: () {
          _regview();
        },
        child: Container(
          alignment: Alignment.center,
          child: RichText(
              text: TextSpan(
            text: S.current.HMZH + ',',
            style: TextStyle(
                color: ThemeUtils().currentColorTheme.textGaryColor,
                fontSize: 15),
            children: [
              TextSpan(
                text: S.current.ZWS,
                style: TextStyle(color: Colors.red, fontSize: 15),
              ),
            ],
          )),
        ));

    Widget body = Stack(
      children: [
        tbody,
        Positioned(left: 0, right: 0, bottom: 29, child: yesterdaIncome)
      ],
    );

    String userInfo =
        DataUtils.preferences.getString(DataUtils.SPchangeLanguage);

    if (userInfo == null) {
      userInfo = "zh";
    }
    ;

    Widget allviebody = Scaffold(
      backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
      resizeToAvoidBottomInset: false,
      body: body,
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
        ),
        // 如果没有设置这项， 二级页面 会默认是返回箭头  ， 有侧边栏的页面默认有图标（用来打开侧边栏）
        // automaticallyImplyLeading: true,
        // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
        title: ThemeUtils.sText(S.current.DL),
        centerTitle: true,
        //  actions: <Widget>[
        //     IconButton(
        //         icon: Icon(Icons.add_alarm),
        //         tooltip: 'Add Alarm',
        //         onPressed: () {
        //           // do nothing
        //         })
        //   ],   // 标题是否在居中

        actions: Api.istest == true
            ? <Widget>[
                TextButton(
                  child: Text("主题"),
                  onPressed: () async {
                    final result = await Navigator.of(context)
                        .push(MaterialPageRoute(builder: (context) {
                      return localthemepage();
                    }));
                  },
                ),
                IconButton(
                    icon: Image.asset(
                      "images/flag/" + userInfo + ".png",
                      width: 20,
                      height: 20,
                    ),

                    // tooltip: 'Add Alarm',
                    onPressed: () async {
                      final result = await Navigator.of(context)
                          .push(MaterialPageRoute(builder: (context) {
                        return LocalizetionPage();
                      }));
                      // do nothing
                    }),
              ]
            : <Widget>[
                IconButton(
                    icon: Image.asset(
                      "images/flag/" + userInfo + ".png",
                      width: 20,
                      height: 20,
                    ),

                    // tooltip: 'Add Alarm',
                    onPressed: () async {
                      final result = await Navigator.of(context)
                          .push(MaterialPageRoute(builder: (context) {
                        return LocalizetionPage();
                      }));
                      // do nothing
                    }),
              ],

        elevation: 0, // 导航栏Z轴的高度，默认是1  默认就是有高度 阴影的
        backgroundColor: ThemeUtils()
            .currentColorTheme
            .contentBG, // 导航栏的颜色  默认是 ThemeData 的颜色
//         flexibleSpace: FlexibleSpaceBar(title: Text("你号"),),//这个堆叠在工具栏上面  一般 appbar不用  主要用在 SliverAppBar上
//          brightness: Brightness.light, //状态栏的深度 有白色和黑色两种主题
//          titleSpacing: 10,//flexibleSpace 和 title 的距离  默认是重合的
//          toolbarOpacity: 0.5,// 导航栏透明度 默认是1 ，不包括flexibleSpace
//          bottomOpacity: 0.5,
      ),
    );

    return allviebody;
  }
}

//登录按钮
class loginButtonWiget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new SizedBox(
      height: 50,
      child: new Container(
          padding: EdgeInsets.fromLTRB(2, 15, 2, 15),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5),
            color: ThemeUtils().currentColorTheme.labelColorY,
          ),
          alignment: Alignment.center,
          child: Text(
            S.current.DL,
            textAlign: TextAlign.center,
            style: TextStyle(
                letterSpacing: 16,
                fontWeight: FontWeight.bold,
                color: ThemeUtils().currentColorTheme.labelColorW),
          )),
    );
  }
}

class CommonButton extends StatefulWidget {
  String text;
  GestureTapCallback onTap;
  Color color = ThemeUtils().currentColorTheme.labelColorY;

  // ignore: use_key_in_widget_constructors
  CommonButton({@required this.text, @required this.onTap, this.color});

  @override
  State<StatefulWidget> createState() => CommonButtonState();
}

class CommonButtonState extends State<CommonButton> {
  TextStyle textStyle = TextStyle(color: Colors.white, fontSize: 17);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        this.widget.onTap();
      },
      child: Container(
        height: 50,
        decoration: BoxDecoration(
            color: widget.color,
            // border: Border.all(color: const Color(0xffcccccc)),
            borderRadius: BorderRadius.all(Radius.circular(5))),
        child: Center(
          child: Text(
            this.widget.text,
            style: textStyle,
          ),
        ),
      ),
    );
  }
}

//忘记密码
class ForgotPasswordButtonWiget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new SizedBox(
      height: 20,
      child: new Container(
          padding: EdgeInsets.fromLTRB(0, 0, 48, 0),
          alignment: Alignment.centerRight,
          child: Text(
            '忘记密码？',
            textAlign: TextAlign.center,
            style: TextStyle(
                // fontWeight: FontWeight.bold,
                color: Color(0xFFF0B90B)),
          )),
    );
  }
}

class iconText extends StatelessWidget {
  final Image icon;

  final String title;
  final Function onTap;
  final TextInputType type;
  final TextEditingController controller;

  const iconText(
      {Key key,
      this.icon,
      this.title,
      this.onTap,
      this.controller,
      this.type = TextInputType.text})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    var iconContainer = Container(
      // margin: EdgeInsets.all(),
      height: 20,
      width: 20,
      // decoration: BoxDecoration(
      //   color: ThemeUtils().currentColorTheme.labelColorW,
      //   borderRadius: BorderRadius.circular(2),
      //   gradient: LinearGradient(
      //     begin: Alignment.topLeft,
      //     end: Alignment.bottomCenter,
      //     colors: [
      //       color2,
      //       color!,
      //     ],
      //     stops: [0.1, 0.8],
      //   ),
      // ),
      child: icon,
    );

    Widget body = Row(
      children: [
        iconContainer,
        new SizedBox(
          child: new Container(
            // margin: EdgeInsets.fromLTRB(15, 5, 15, 5),
            color: ThemeUtils().currentColorTheme.contentBG,
            width: MediaQuery.of(context).size.width - 150,
            // height: 30,
            padding: EdgeInsets.fromLTRB(10, 0, 0, 0),
            alignment: Alignment.center,

            child: TextField(
              obscureText: type == TextInputType.visiblePassword ? true : false,
              controller: controller,
              keyboardType: type,
              maxLines: 1,
              decoration: InputDecoration(
                hintText: title,
                border: InputBorder.none,
                hintStyle: TextStyle(
                  fontSize: 12,
                  color: ThemeUtils().currentColorTheme.textGaryColor,
                ),
              ),
              style: TextStyle(
                fontSize: 12,
                color: ThemeUtils().currentColorTheme.textWithdrawColor,
              ),
            ),
          ),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
      ],
    );

    // body = Tapped(
    //   child: body,
    //   onTap: onTap,
    // );
    return Container(
      child: Container(
        padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
        // margin: EdgeInsets.fromLTRB(15, 5, 15, 5),
        color: ThemeUtils().currentColorTheme.contentBG,
        height: 50,
        child: body,
      ),
    );
  }
}

class inpuNameWiget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new SizedBox(
      child: new Container(
        margin: EdgeInsets.fromLTRB(15, 5, 15, 5),
        color: ThemeUtils().currentColorTheme.contentBG,
        // width: 100,
        // height: 30,
        padding: EdgeInsets.fromLTRB(10, 5, 5, 5),
        alignment: Alignment.center,
        child: TextField(
          maxLines: 1,
          decoration: InputDecoration(
            hintText: '请输入姓名',
            border: InputBorder.none,
            hintStyle: TextStyle(
              fontSize: 12,
              color: ThemeUtils().currentColorTheme.textGaryColor,
            ),
          ),
          style: TextStyle(
            fontSize: 12,
            color: ThemeUtils().currentColorTheme.textWithdrawColor,
          ),
        ),
      ),
    );
  }
}
