import 'package:flutter/foundation.dart';

class Country {
  String zh_name;
  String code;
  // String dialCode;
  // String extra;

  Country({
    @required this.zh_name,
    @required this.code,
    // @required this.dialCode,
    // this.extra,
  });

  @override
  String toString() {
    return code;
  }

  Country.fromJson(Map<dynamic, dynamic> countryData) {
    zh_name = countryData['zh_name'];
    // code = countryData['ISO'];
    code = countryData['code'];
  }

  // String get flagUri => "assets/images/flags/${code.toLowerCase()}.png";
}
