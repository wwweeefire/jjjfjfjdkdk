import 'package:flutter/material.dart';
import 'package:heibai/generated/l10n.dart';
// TODO Implement this library.
import 'package:heibai/util/DataUtils.dart';
import 'package:heibai/util/ThemeUtils.dart';
// import 'package:flutter_search_bars/flutter_search_bars.dart';
import 'package:heibai/pages/login/country_picker.dart';
import 'package:heibai/pages/login/country.dart';
import 'package:heibai/pages/login/country_listview.dart';
import 'package:heibai/pages/login/countries_json.dart';
import 'package:heibai/net/api/Api.dart';
import 'package:heibai/net/api/app_api.dart';

typedef OnCountrySelectedCallback = Function(Country country);

class countryView extends StatefulWidget {
  final OnCountrySelectedCallback onSelected;

  const countryView({Key key, this.onSelected}) : super(key: key);
  @override
  State<StatefulWidget> createState() {
    return countryViewState(onSelected);
  }
}

class countryViewState extends State<countryView> {
  final OnCountrySelectedCallback onSelected;
  CountryListView clv;
  List list;

  countryViewState(this.onSelected);
  Widget build(BuildContext context) {
    Widget _get_country(BuildContext context) {
      if (list != null) {
        return CountryListView(
          showFlag: false,
          backgroundColor: ThemeUtils().currentColorTheme.labelColorW,
          countryJsonList: list,
          onSelected: (country) {
            onSelected(country);
            Navigator.pop(context);
          },
          itemTitleStyle: TextStyle(
            fontSize: 13,
            color: ThemeUtils().currentColorTheme.labelColorW,
          ),
          dialCodeStyle: TextStyle(
            fontSize: 13,
            color: ThemeUtils().currentColorTheme.labelColorW,
          ),
        );
      }
    }

    void get_country() async {
      if (list != null) {
        return;
      }
      ResultData resultData =
          await AppApi.getInstance().get_country(context, true);
      if (resultData.isSuccess()) {
        var yt = countryCodes;
        Map<dynamic, dynamic> countryData = resultData.data;
        var uu = countryData.putIfAbsent("list", () => (2)); //存在
        list = uu;
        //存在
        setState(() {});
      }
    }

    get_country();
    Widget allviebody = Scaffold(
      backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
      body: _get_country(context),
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
        ),
        // 如果没有设置这项， 二级页面 会默认是返回箭头  ， 有侧边栏的页面默认有图标（用来打开侧边栏）
        // automaticallyImplyLeading: true,
        // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
        title: ThemeUtils.sText(S.current.SZDQ),
        centerTitle: true,
        // actions: <Widget>[
        //   IconButton(
        //       icon: Icon(Icons.add_alarm),
        //       tooltip: 'Add Alarm',
        //       onPressed: () {
        //         final result = Navigator.of(context)
        //             .push(MaterialPageRoute(builder: (context) {
        //           return SetingViewPage();
        //         }));
        //         // do nothing
        //       })
        // ], // 标题是否在居中

        elevation: 0, // 导航栏Z轴的高度，默认是1  默认就是有高度 阴影的
        backgroundColor: ThemeUtils()
            .currentColorTheme
            .contentBG, // 导航栏的颜色  默认是 ThemeData 的颜色
//         flexibleSpace: FlexibleSpaceBar(title: Text("你号"),),//这个堆叠在工具栏上面  一般 appbar不用  主要用在 SliverAppBar上
//          brightness: Brightness.light, //状态栏的深度 有白色和黑色两种主题
//          titleSpacing: 10,//flexibleSpace 和 title 的距离  默认是重合的
//          toolbarOpacity: 0.5,// 导航栏透明度 默认是1 ，不包括flexibleSpace
//          bottomOpacity: 0.5,
      ),
    );
    return allviebody;
  }
}
