import 'package:flutter/material.dart';
import 'package:heibai/generated/l10n.dart';
import 'package:heibai/pages/userMsgRow.dart';
import 'package:heibai/pages/KChatPage.dart';
import 'package:heibai/pages/DeviceSearchPage.dart';
import 'package:heibai/util/ThemeUtils.dart';

import '../Classes/model/MCategory.dart';
import '../Classes/model/MCategoryList.dart';
import 'package:heibai/Classes/JCHub/JCHub.dart';
import 'package:heibai/net/api/Api.dart';
import 'package:heibai/net/api/app_api.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import '../Classes/model/homeListModel.dart';
import 'dart:math';
import '../Classes/model/zCategoryList.dart';
import 'package:heibai/pages/web_socket_utility.dart';
// import '../Classes/model/zCategoryList.dart';
import '../Classes/model/NProduct.dart';

class MarketzPageListView extends StatefulWidget {
  final MCategory model;

  final int index;

  const MarketzPageListView({Key key, this.model, this.index})
      : super(key: key);
  @override
  State<StatefulWidget> createState() {
    return MarketzPageListViewState(model, index);
  }
}

class MarketzPageListViewState extends State<MarketzPageListView> {
  final MCategory model;

  final int index;

  // //  List<MListElement> list;
  // List<MListElement> list = [];

  List<zListElement> Zlist = [];
  RefreshController _refreshController =
      RefreshController(initialRefresh: false);

  bool showLoading = true;
  int page = 1;

  MarketzPageListViewState(this.model, this.index);

  // void getdata() async {
  //   Map<String, dynamic> param = {};

  //   param["page"] = 1;
  //   param["pageSize"] = 15;
  //   // param["name"] = model.list[index].name;
  //   param["category"] = model.list[index].id;
  //   ResultData resultData =
  //       await AppApi.getInstance().get_product_page_list(context, false, param);
  //   if (resultData.isSuccess()) {
  //     list.remove;
  //     MCategoryList model = mCategoryListFromJson(resultData.dataJson);
  //     // nowmodel = model;
  //     // showLoading = false;
  //     list = model.list;

  //     setState(() {
  //       showLoading = false;
  //       // nowmodel = model;
  //       page++;
  //       list = model.list;
  //     });
  //   } else {
  //     setState(() {});
  //     JCHub.showmsg(resultData.msg, context);
  //   }
  // }

  void getzdata() async {
    Map<String, dynamic> param = {};

    ResultData resultData = await AppApi.getInstance()
        .get_member_optional_list(context, false, param);
    if (resultData.isSuccess()) {
      Zlist.remove;
      ZCategoryList model = zCategoryListFromJson(resultData.dataJson);

      showLoading = false;

      setStateIfMounted(() {
        showLoading = false;
        // // nowmodel = model;
        // // page++;
        // list = model.list;
        Zlist = model.list;
      });
    } else {
      //setState(() {});
      JCHub.showmsg(resultData.msg, context);
    }
  }

  void setStateIfMounted(f) {
    if (mounted) setState(f);
  }

  getdddata() async {
    WebSocketUtility().addListener(onMessage);

    // bool isf = true;
  }

  void onMessage(data) {
    NProduct ss = nProductFromJson(data);

    // print(data);
    chagemodel(ss);
  }

  _randomBit(int len, double intge) {
    String b = "1";
    for (int i = 0; i < len; i++) {
      b = b + "0";
    }
    int s = (intge * 2 * double.parse(b)).toInt();
    int u = (Random().nextInt(s));
    return (u - u / 2) / double.parse(b);
  }

  @override
  void dispose() {
    super.dispose();
    WebSocketUtility().removeListener(onMessage);
  }

  void chagemodel(NProduct model) {
    var index = -1;
    for (var i = 0; i < Zlist.length; i++) {
      zListElement ss = Zlist[i];
      if (model.code == ss.code) {
        index = i;
        // return;
      }
    }
    // int id;
    // String code;
    // String name;
    // double wave;
    // String openTime;
    // int weekendTrading;
    // double open;
    // double price;
    // double low;
    // double high;
    // double change;
    if (index >= 0) {
      zListElement oldmodel = Zlist[index];

      zListElement newmodel;

      if (model.price == oldmodel.price) {
        String wave = oldmodel.wave.toString();
        List<String> wavelist = wave.split(".");
        int size = wavelist.last.length;
        double b = _randomBit(size, oldmodel.wave);

        // double b = (Random().nextInt(100) - 50) / 100.0;
        String price = oldmodel.price.toString();

        List<String> s = price.split(".");
        int a = s.last.length;
        String rstr = b.toStringAsFixed(a);
        double r = double.parse(rstr);
        double newprices = model.price + r;

        String newpricesstr = newprices.toStringAsFixed(a);
        double newprice = double.parse(newpricesstr);
        // String name = oldmodel.name;
        newmodel = zListElement(
          id: oldmodel.id,
          code: model.code,
          open: model.open,
          name: oldmodel.name,
          wave: oldmodel.wave,
          openTime: oldmodel.openTime,
          weekendTrading: oldmodel.weekendTrading,
          price: newprice,
          low: model.low,
          high: model.high,
          change: oldmodel.change + r / oldmodel.open,
          vol: model.vol,
        );
      } else {
        newmodel = zListElement(
          id: oldmodel.id,
          code: model.code,
          open: model.open,
          name: oldmodel.name,
          wave: oldmodel.wave,
          openTime: oldmodel.openTime,
          weekendTrading: oldmodel.weekendTrading,
          price: model.price,
          low: model.low,
          high: model.high,
          change: model.change,
          vol: model.vol,
        );
      }

      setStateIfMounted(() {
        Zlist.fillRange(index, index + 1, newmodel);
        // datas = [];
        // showLoading = true;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    // if (model.list[index].id > 0) {
    //   getdata();
    // } else {
    getzdata();
    getdddata();
    // }

    //   if (SchedulerBinding.instance.schedulerPhase ==
    //   SchedulerPhase.persistentCallbacks) {
    // SchedulerBinding.instance.addPostFrameCallback((_) => onWidgetBuild());
  }

  void _onRefresh() async {
    // if (model.list[index].id > 0) {
    //   getdata();
    // } else {
    getzdata();
    // }

    // if failed,use refreshFailed()
    _refreshController.refreshCompleted();
  }

  void _onLoading() async {
    // monitor network fetch
    // await Future.delayed(Duration(milliseconds: 1000));
    // // if failed,use loadFailed(),if no data return,use LoadNodata()
    // // items.add((items.length+1).toString());
    // if (model.list[index].id > 0) {
    //   // getdata();
    //   Map<String, dynamic> param = {};
    //   param["page"] = page;
    //   param["pageSize"] = 15;
    //   // param["name"] = model.list[index].name;
    //   param["category"] = model.list[index].id;
    //   ResultData resultData = await AppApi.getInstance()
    //       .get_product_page_list(context, true, param);
    //   if (resultData.isSuccess()) {
    //     // List list = resultData.data;

    //     MCategoryList model = mCategoryListFromJson(resultData.dataJson);
    //     // nowmodel = model;
    //     // showLoading = false;
    //     list.addAll(model.list);

    //     if (page < model.page.total) {
    //       page++;
    //       _refreshController.loadComplete();
    //     } else {
    //       _refreshController.loadNoData();
    //     }

    //     setState(() {
    //       // showLoading = false;
    //       // nowmodel = model;
    //       list.addAll(model.list);
    //       //  list.addAll(model.list);
    //     });
    //   } else {
    //     JCHub.showmsg(resultData.msg, context);
    //     _refreshController.loadComplete();
    //     // tap();
    //   }
    //   if (mounted) setState(() {});
    // } else {
    _refreshController.loadNoData();
    // }
  }

  /// disappear
  // @override
  // void dispose() {
  //   super.dispose();

  //   /// release whatever you have consume
  // }

  Widget build(BuildContext context) {
    Color themeColor = ThemeUtils().currentColorTheme.currentColorTheme;
    Color contentBG = ThemeUtils().currentColorTheme.contentBG;
    var listView = ListView.builder(
      // shrinkWrap: true, //解决无限高度问题
      // physics: new NeverScrollableScrollPhysics(), //禁用滑动事件
      itemCount: Zlist.length == 0 ? 1 : Zlist.length + 2,
      itemBuilder: (context, i) => renderRow(i),
    );

    Widget allviebody = Scaffold(
      backgroundColor: themeColor,
      body: showLoading == true
          ? Text('')
          : SmartRefresher(
              header: WaterDropHeader(),
              footer: ClassicFooter(
                loadStyle: LoadStyle.ShowWhenLoading,
              ),
              enablePullDown: true,
              enablePullUp: true,
              // header: ClassicHeader(refreshStyle: RefreshStyle.Follow),
              // footer: tableHeader.footer,
              controller: _refreshController,
              onRefresh: _onRefresh,
              onLoading: _onLoading,
              child: listView,
            ),
    );

    return allviebody;
  }

  pushKChatPage(Product pro) async {
    // 打开登录页并处理登录成功的回调
    final result =
        await Navigator.of(context).push(MaterialPageRoute(builder: (context) {
      return KChatPage(
        title: pro.name,
        model: pro,
      );
    }));
  }

  renderRow(i) {
    if (Zlist.length == 0) {
      var rowitem = addWiget();

      return InkWell(
        child: rowitem,
        onTap: () async {
          final result = await Navigator.of(context)
              .push(MaterialPageRoute(builder: (context) {
            return DeviceSearchPage(
                // title: pro.name,
                // model: pro,
                );
          }));
        },
      );
    } else {
      if (i == 0) {
        return TitleMsgRow(
          title: S.current.SPMC,
          price: S.current.ZXJ,
          increase: S.current.ERZF,
        );
      }

      if (i < Zlist.length + 1) {
        i--;

        zListElement item = Zlist[i];

        var rowitem = UserMsgRow(
            title: item.name,
            price: item.price.toString(),
            increase: item.change.toStringAsFixed(2));
        return InkWell(
          child: rowitem,
          onTap: () {
            Product pro = Product(
                weekendTrading: item.weekendTrading,
                open: item.open.toDouble(),
                price: item.price.toDouble(),
                low: item.low.toDouble(),
                high: item.high.toDouble(),
                change: item.change.toDouble(),
                id: item.id,
                code: item.code,
                name: item.name,
                wave: item.wave,
                vol: item.vol,
                openTime: item.openTime);
            // pushKChatPage(pro);

            pushKChatPage(pro);
          },
        );
      } else if (i == Zlist.length + 1) {
        var rowitem = addWiget();

        return InkWell(
          child: rowitem,
          onTap: () async {
            final result = await Navigator.of(context)
                .push(MaterialPageRoute(builder: (context) {
              return DeviceSearchPage(
                  // title: pro.name,
                  // model: pro,
                  );
            }));
          },
        );
      }
    }
  }
}

class addWiget extends StatelessWidget {
  Widget build(BuildContext context) {
    final mediaQueryData = MediaQuery.of(context);

// 2.获取宽度和高度
    final screenWidth = mediaQueryData.size.width;
    var iconContainer = Container(
      // margin: EdgeInsets.all(),
      alignment: Alignment.center,
      height: 20,
      width: 20,

      child: Image.asset(
        "images/wode/tianjia@3x.png",
      ),
    );

    Widget body = Row(
      children: [
        Container(
          width: screenWidth / 2 - 40,
        ),
        iconContainer,
        Container(
          alignment: Alignment.center,
          padding: EdgeInsets.only(left: 10),
          // height: 20,
          child: Text(
            S.current.TJZX,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.dateGaryColor,
            ),
          ),
        ),
      ],
    );

    return Container(
      child: Container(
        margin: EdgeInsets.only(bottom: 1),
        // margin: EdgeInsets.fromLTRB(15, 5, 15, 5),
        // color: ThemeUtils().currentColorTheme.viewgaryBG,
        height: 44,
        child: body,
      ),
    );
  }
}
