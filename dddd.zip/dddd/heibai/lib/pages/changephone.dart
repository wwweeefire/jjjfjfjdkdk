import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:heibai/generated/l10n.dart';

import 'package:heibai/pages/Views/iconTextIcon.dart';
import 'package:heibai/util/ThemeUtils.dart';
import 'package:heibai/pages/Withdrawal/WithdDataInfo.dart';
import 'package:heibai/pages/Withdrawal/banklistview.dart';
import 'package:heibai/net/api/Api.dart';
import 'package:heibai/net/api/app_api.dart';
import 'package:heibai/Classes/model/Withdrawmethod.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:tapped/tapped.dart'; //咨询
import 'package:heibai/Classes/model/bankitemModel.dart';
import 'package:heibai/Classes/JCHub/JCHub.dart';
import 'package:heibai/pages/login/loginView.dart';

class changephone extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return changephoneState();
  }
}

class changephoneState extends State<changephone> {
  // Widget build(BuildContext context) {
  //
  //  Widget ad = Container();
  //   return ad;
  // }
  // bankListElement bank;
  // Withdrawmethod cmodel;
  final usernameCtrl = TextEditingController(text: '');
  // final bankcardCtrl = TextEditingController(text: '');
  // final bankznameCtrl = TextEditingController(text: '');

  // final usernameCtrl = TextEditingController(text: '');
  // final passwordCtrl = TextEditingController(text: '');

  bool showloading = true;
  // final ValueNotifier<String> new_counter = ValueNotifier<String>("请选择银行");
  // Widget _builderWithValue(BuildContext context, String value, Widget child) {
  //   return regText(
  //     onTap: () {
  //       // get_country();
  //       // c.launch(context);
  //       final result =
  //           Navigator.of(context).push(MaterialPageRoute(builder: (context) {
  //         return banklistview(
  //           onSelected: (country) {
  //             bank = country;
  //             new_counter.value = bank.bankName;
  //           },
  //         );
  //       }));
  //     },
  //     des: '$value',
  //     title: '银行名字',
  //     icon: Image.asset(
  //       "images/wode/xyy@3x.png",
  //       width: 19,
  //       height: 13,
  //     ),
  //   );
  // }

  Widget build(BuildContext context) {
    Widget btitle = Container(
      alignment: Alignment.centerLeft,
      margin: EdgeInsets.fromLTRB(15, 0, 0, 0),
      child: Text(
        S.current.SJH,
        style: TextStyle(
          fontSize: 15,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );
    Widget inpuBank = inpuBankNumberWiget(
      title: S.current.SRXGDSJH,
      hight: 40,
      type: TextInputType.text,
      Controller: usernameCtrl,
    );

    void post_member_update(params) async {
      // params["code"] = widget.model.code;

      ResultData resultData =
          await AppApi.getInstance().post_member_update(context, true, params);
      if (resultData.isSuccess()) {
        JCHub.showmsg(S.current.XGCG, context);
        Navigator.pop(context, "refresh");
      } else {
        JCHub.showmsg(resultData.msg, context);
      }
    }

    var loginBtn = Builder(builder: (ctx) {
      return CommonButton(
          text: S.current.XIUGAI,
          color: ThemeUtils().currentColorTheme.labelColorY,
          onTap: () {
            String username = usernameCtrl.text.trim();

            if (username.isEmpty) {
              JCHub.showmsg(S.current.QJCSJBNWK, context);
              return;
            }
            Map<String, dynamic> params = {};
            // params["mobile"] = bankzname;
            // params["password_confirm"] = bankcard;
            params["mobile"] = username;
            post_member_update(params);
            FocusScope.of(context).requestFocus(FocusNode());
          });
    });

    Widget listview = Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[
        SizedBox(
          height: 10,
        ),
        btitle,
        SizedBox(
          height: 5,
        ),
        inpuBank,
        SizedBox(
          height: 2,
        ),
        SizedBox(
          height: 2,
        ),
        loginBtn,
      ],
    );

    Widget body = Container(
      child: showloading == false ? Container() : listview,
    );

    Widget allviebody = Scaffold(
      backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
      body: body,
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
        ),
        // 如果没有设置这项， 二级页面 会默认是返回箭头  ， 有侧边栏的页面默认有图标（用来打开侧边栏）
        // automaticallyImplyLeading: true,
        // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
        title: ThemeUtils.sText(S.current.SJHM),
        centerTitle: true,
        //  actions: <Widget>[
        //     IconButton(
        //         icon: Icon(Icons.add_alarm),
        //         tooltip: 'Add Alarm',
        //         onPressed: () {
        //           // do nothing
        //         })
        //   ],   // 标题是否在居中

//          elevation: 0.1, // 导航栏Z轴的高度，默认是1  默认就是有高度 阴影的
        backgroundColor: ThemeUtils()
            .currentColorTheme
            .contentBG, // 导航栏的颜色  默认是 ThemeData 的颜色
//         flexibleSpace: FlexibleSpaceBar(title: Text("你号"),),//这个堆叠在工具栏上面  一般 appbar不用  主要用在 SliverAppBar上
//          brightness: Brightness.light, //状态栏的深度 有白色和黑色两种主题
//          titleSpacing: 10,//flexibleSpace 和 title 的距离  默认是重合的
//          toolbarOpacity: 0.5,// 导航栏透明度 默认是1 ，不包括flexibleSpace
//          bottomOpacity: 0.5,
      ),
    );
    return allviebody;
  }
}

class inpuBankNumberWiget extends StatelessWidget {
  final String title;
  final TextInputType type;
  final int hight;
  final TextEditingController Controller;

  const inpuBankNumberWiget(
      {Key key, this.title, this.type, this.hight, this.Controller})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    int he = hight;
    if (he == null) {
      he = 50;
    }
    // TODO: implement build
    return new SizedBox(
      child: new Container(
        height: he.toDouble(),
        padding: EdgeInsets.fromLTRB(10, 5, 5, 5),
        margin: EdgeInsets.fromLTRB(15, 5, 15, 5),
        color: ThemeUtils().currentColorTheme.contentBG,
        alignment: Alignment.center,
        child: TextField(
          keyboardType: type,
          maxLines: 1,
          controller: Controller,
          decoration: InputDecoration(
            hintText: title,
            border: InputBorder.none,
            hintStyle: TextStyle(
              fontSize: 12,
              color: ThemeUtils().currentColorTheme.textGaryColor,
            ),
          ),
          style: TextStyle(
            fontSize: 12,
            color: ThemeUtils().currentColorTheme.textWithdrawColor,
          ),
        ),
      ),
    );
  }
}

class regText extends StatelessWidget {
  final String des;
  final Image icon;
  final String title;
  final Function onTap;

  const regText({Key key, this.icon, this.title, this.onTap, this.des})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    var leftIconContainer = Container(
      // margin: EdgeInsets.all(6),
      height: 13,
      width: 19,
      // decoration: BoxDecoration(
      //   color: ThemeUtils().currentColorTheme.labelColorW,
      //   borderRadius: BorderRadius.circular(2),
      //   gradient: LinearGradient(
      //     begin: Alignment.topLeft,
      //     end: Alignment.bottomCenter,
      //     colors: [
      //       color2,
      //       color!,
      //     ],
      //     stops: [0.1, 0.8],
      //   ),
      // ),
      child: icon,
    );

    Widget body = Row(
      children: [
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.only(left: 10),
          // height: 20,
          child: Text(
            des,
            style: TextStyle(
              fontSize: 12,
              // fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.dateGaryColor,
            ),
          ),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        leftIconContainer,
      ],
    );

    body = Tapped(
      child: body,
      onTap: onTap,
    );
    return Container(
      child: Container(
        // padding: EdgeInsets.all(12),
        padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
        color: ThemeUtils().currentColorTheme.contentBG,
        height: 50,
        child: body,
      ),
    );
  }
}
