// TODO Implement this library
// .
import 'package:flutter/material.dart';
import 'package:heibai/generated/l10n.dart';
import 'package:heibai/pages/PositionRecordListView.dart';

import 'package:heibai/pages/PositionRecordoverListView.dart';
import 'package:heibai/util/ThemeUtils.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';

// TODO Implement this library.

class PositionRecordPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return PositionRecordPageState();
  }
}

class PositionRecordPageState extends State
    with SingleTickerProviderStateMixin {
  @override
  void initState() {
    super.initState();
  }

  int _tabIndex = 0;
  var _body;
  var pages;
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    var positionRecordPageState = PositionRecordPageState();

    //  pages = [];
    pages = [
      PositionRecordListView(),
      PositionRecordoverListView(),
    ];

    _body = IndexedStack(
      children: pages,
      index: _tabIndex,
    );
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
        ),
        automaticallyImplyLeading: true,
        // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
        title: ThemeUtils.sText(S.of(context).tab_Position_record),
        centerTitle: true,
        // 标题是否在居中
        // actions: <Widget>[
        //   IconButton(
        //       icon: Icon(Icons.add_alarm),
        //       tooltip: 'Add Alarm',
        //       onPressed: () {
        //         // do nothing
        //       })
        // ],

//          elevation: 0.1, // 导航栏Z轴的高度，默认是1  默认就是有高度 阴影的
        backgroundColor: ThemeUtils().currentColorTheme.contentBG,
      ),
      body: DefaultTabController(
        length: 2,
        child: Scaffold(
          backgroundColor: ThemeUtils().currentColorTheme.contentBG,
          appBar: TabBar(
            labelColor:
                ThemeUtils().currentColorTheme.labelColorY, // 选中的Widget颜色
            indicatorColor: ThemeUtils().currentColorTheme.labelColorY,
            labelStyle: new TextStyle(
                fontSize: 15.0), // 必须设置，设置 color 没用的，因为 labelColor 已经设置了
            unselectedLabelColor: ThemeUtils().currentColorTheme.labelColorW,
            unselectedLabelStyle: new TextStyle(fontSize: 15.0),

            tabs: <Widget>[
              Tab(
                text: S.of(context).CHMX,
              ),
              Tab(
                text: S.of(context).LSMX,
              )
            ],
            onTap: (index) {
              setState(() {
                _tabIndex = index;
              });
            },
          ),
          body: _body,
        ),
      ),
    );
    ;
  }
}
