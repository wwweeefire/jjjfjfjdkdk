import 'package:flutter/material.dart';
import 'package:heibai/generated/l10n.dart';
import 'package:heibai/util/ThemeUtils.dart';
import 'dart:io';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'dart:convert';
import '../Classes/model/helpListmodel.dart';
import 'package:tapped/tapped.dart'; //咨询
import 'package:heibai/pages/CommonWebPage.dart';
import 'package:heibai/pages/CommonAPPwebpage.dart';

import 'package:heibai/Classes/model/config.dart';
// import 'package:webviewx/webviewx.dart';
// import 'dart:html';
// import 'dart:ui' as ui;
// // import 'package:simp';
// // import 'package:flutter_fai_webview/flutter_fai_webview.dart';
// import 'package:webview_flutter/webview_flutter.dart';

class HelpCenterdespage extends StatefulWidget {
  final String htmlContent;
  final ListElement model;

  HelpCenterdespage({Key key, this.htmlContent, this.model}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return HelpCenterdespageState();
  }
}

class HelpCenterdespageState extends State<HelpCenterdespage> {
  void initState() {
    super.initState();
  }

  Size get screenSize => MediaQuery.of(context).size;
  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Widget titletext = Container(
      alignment: Alignment.centerLeft,
      child: Text(
        widget.model.title,
        style: TextStyle(
          fontSize: 18,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );
    Widget Expiredate = Container(
      alignment: Alignment.centerLeft,
      child: Text(
        widget.model.content,
        style: TextStyle(
          fontSize: 12,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );
    Widget topview = Container(
        margin: EdgeInsets.all(15),
        padding: EdgeInsets.all(6),
        color: ThemeUtils().currentColorTheme.contentBG,
        child: Column(children: <Widget>[
          SizedBox(
            height: 5,
          ),
          titletext,
          SizedBox(
            height: 20,
          ),
          Expiredate,
          SizedBox(
            height: 15,
          ),
        ]));

    var kfid = ConfigManager().config.kf[0].id;

    var userid = ConfigManager().user.id;
    Widget yesterdaIncome = Tapped(
        onTap: () async {
          var baidu = ConfigManager().config.kf[0].link;
          if (kIsWeb) {
            final result = await Navigator.of(context)
                .push(MaterialPageRoute(builder: (context) {
              return CommonWebPage(
                htmlContent: baidu + "?id=$kfid&uid=$userid",
                title: S.current.KF,
              );
            }));
          } else {
            final result = await Navigator.of(context)
                .push(MaterialPageRoute(builder: (context) {
              return CommonAPPwebpage(
                htmlContent: baidu + "?id=$kfid&uid=$userid",
                title: S.current.KF,
              );
            }));
          }
        },
        child: Container(
          alignment: Alignment.center,
          child: RichText(
              text: TextSpan(
            text: S.current.RRWFDJ,
            style: TextStyle(
                color: ThemeUtils().currentColorTheme.textGaryColor,
                fontSize: 12),
            children: [
              TextSpan(
                text: S.current.KF,
                style: TextStyle(color: Colors.red, fontSize: 12),
              ),
            ],
          )),
        ));

    Widget tbview = Container(
        // margin: EdgeInsets.all(15),

        child: Column(children: <Widget>[
      SizedBox(
        height: 5,
      ),
      topview,
      SizedBox(
        height: 5,
      ),
      yesterdaIncome,
    ]));

    return Scaffold(
      backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
      appBar: AppBar(
        backgroundColor: ThemeUtils().currentColorTheme.contentBG,
        title: ThemeUtils.sText(widget.model.title),
        iconTheme: IconThemeData(
          color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
        ),
      ),
      body: Container(
        // margin: EdgeInsets.only(bottom: 0),
        child: Container(
          // color: ,
          child: Center(
            child: Container(
              child: tbview,
            ),
          ),
        ),
      ),
    );
  }
}
