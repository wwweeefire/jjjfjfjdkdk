import 'package:flutter/material.dart';
import 'package:heibai/pages/userMsgRow.dart';
import 'dart:io';
import 'package:heibai/util/ThemeUtils.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:heibai/net/api/Api.dart';
import 'package:heibai/net/api/app_api.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import '../Classes/model/PositionRecordModel.dart';
import 'package:heibai/Classes/JCHub/JCHub.dart';
import 'package:heibai/generated/l10n.dart';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'dart:async';
import 'package:heibai/constants/events/changebuyEvent.dart';
import 'package:heibai/constants/Constants.dart';
import 'package:flutter/foundation.dart';

class PositionRecordListView extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return PositionRecordListViewState();
  }
}

class PositionRecordListViewState extends State<PositionRecordListView> {
  List<ListElement> list = [];
  bool showLoading = true;
  int page = 1;
  RefreshController _refreshController =
      RefreshController(initialRefresh: false);

  void get_order_page_list() async {
    Map<String, dynamic> params = {};

    params["page"] = 1;
    params["pageSize"] = 15;
    params["status"] = 0;

    ResultData resultData =
        await AppApi.getInstance().get_order_page_list(context, false, params);
    if (resultData.isSuccess()) {
      PositionRecordModel model =
          positionRecordModelFromJson(resultData.dataJson);
      list = model.list;
      page++;
      if (mounted)
        setState(() {
          if (list.length > 0) {
            list = model.list;
            showLoading = false;
          }
        });
    }
  }

  @override
  void initState() {
    super.initState();
    get_order_page_list();

    Constants.eventBus.on<changebuyEvent>().listen((event) {
      // 收到登录的消息，重新获取个人信息
      list = [];
      if (mounted) setState(() {});

      get_order_page_list();
    });
    //   if (SchedulerBinding.instance.schedulerPhase ==
    //   SchedulerPhase.persistentCallbacks) {
    // SchedulerBinding.instance.addPostFrameCallback((_) => onWidgetBuild());
  }

  Widget build(BuildContext context) {
    YYDialog.init(context);

    final mediaQueryData = MediaQuery.of(context);

// 2.获取宽度和高度
    final screenWidth = mediaQueryData.size.width;
    final screenHeight = mediaQueryData.size.height;

    final statusBarHeight = mediaQueryData.padding.top;
// 有刘海的屏幕:34 没有刘海的屏幕0
    double bottomHeight = 10.0;

    if (!kIsWeb) {
      bottomHeight = 10.0;
      if (Platform.isIOS) {
        bottomHeight = mediaQueryData.padding.bottom;
      }
    }

    Color themeColor = ThemeUtils().currentColorTheme.currentColorTheme;
    Color contentBG = ThemeUtils().currentColorTheme.contentBG;
    var listView = ListView.builder(
      // shrinkWrap: true, //解决无限高度问题
      // physics: new NeverScrollableScrollPhysics(), //禁用滑动事件
      itemCount: list.length,
      itemBuilder: (context, i) => renderRow(i),
    );

    Widget allviebody = Scaffold(
        backgroundColor: themeColor,
        body: Container(
          margin: EdgeInsets.only(bottom: bottomHeight),
          child: SmartRefresher(
            header: WaterDropHeader(),
            footer: ClassicFooter(
              loadStyle: LoadStyle.ShowWhenLoading,
            ),
            enablePullDown: true,
            enablePullUp: true,
            // header: ClassicHeader(refreshStyle: RefreshStyle.Follow),
            // footer: tableHeader.footer,
            controller: _refreshController,
            onRefresh: _onRefresh,
            onLoading: _onLoading,
            child: showLoading == true
                ? ListView(
                    children: [
                      Center(
                          child: Container(
                        child: Image.asset(
                          "images/wode/nulldata.png",
                        ),
                      ))
                    ],
                  )
                : listView,
          ),
        ));

    return allviebody;
  }

  void _onRefresh() async {
    get_order_page_list();

    // if failed,use refreshFailed()
    _refreshController.refreshCompleted();
  }

  void _onLoading() async {
    Map<String, dynamic> params = {};

    params["page"] = page;
    params["pageSize"] = 15;
    params["status"] = 0;

    ResultData resultData =
        await AppApi.getInstance().get_order_page_list(context, false, params);
    if (resultData.isSuccess()) {
      // List list = resultData.data;
      PositionRecordModel model =
          positionRecordModelFromJson(resultData.dataJson);
      // nowmodel = model;
      // showLoading = false;
      // list.addAll(model.list);

      if (page < model.page.total) {
        page++;
        _refreshController.loadComplete();
      } else {
        _refreshController.loadNoData();
      }

      setState(() {
        // showLoading = false;
        // nowmodel = model;
        list.addAll(model.list);
        //  list.addAll(model.list);
      });
    } else {
      JCHub.showmsg(resultData.msg, context);
      _refreshController.loadComplete();
      // tap();
    }
    if (mounted) setState(() {});
  }

  renderRow(i) {
    // if (i == 0) {
    //   return ItemTitleRow(
    //     title: '商品名称',
    //     price: '创建时间',
    //     increase: '成交明细',
    //     onther: '收益',
    //   );
    // }

    // i--;
    ListElement item = list[i];

    var rowitem = pritemView(
      item: item,
    );

    return InkWell(
      child: rowitem,
      onTap: () {},
    );
  }
}

// class pritemView extends StatelessWidget {

//     @override
//   State<StatefulWidget> createState() {
//     return payNumberlistViewState(model, index, tap);
//   }

// }

class pritemView extends StatefulWidget {
  final ListElement item;

  const pritemView({
    Key key,
    this.item,
  }) : super(key: key);
  @override
  State<StatefulWidget> createState() {
    return payNumberlistViewState(item);
  }
}

class payNumberlistViewState extends State<pritemView> {
  ListElement item;

  payNumberlistViewState(this.item);

  Timer _timer;
  var cucettime = 0;

  void _startTimer() {
    cucettime = item.seconds;

    final Duration duration = Duration(seconds: 1);

    cancelTimer();

    _timer = Timer.periodic(duration, (timer) {
      cucettime = cucettime - 1;
      if (this.mounted) {
        setState(() {});
      }
      // print('CountValue');
      // print(cucettime);
      if (cucettime <= 0) {
        cancelTimer();
        Constants.eventBus.fire(changebuyEvent());

        /// 等下写bus
      }
    });
  }

  void cancelTimer() {
    if (_timer != null) {
      _timer.cancel();
      _timer = null;
    }
  }

  @override
  void dispose() {
    cancelTimer();

    super.dispose();
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Constants.eventBus.on<changebuyEvent>().listen((event) {
      // 收到登录的消息，重新获取个人信息
      cancelTimer();
    });
    _startTimer();

    // getdata();
  }

  Widget build(BuildContext context) {
    final mediaQueryData = MediaQuery.of(context);

// 2.获取宽度和高度
    final screenWidth = mediaQueryData.size.width;
    Widget nametext = Row(
      children: [
        Container(
          alignment: Alignment.centerLeft,
          width: screenWidth / 2 - 40,
          child: Text(
            item.productName,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.labelColorW,
            ),
          ),
        ),
        // Expanded(
        //   child: Text(''), // 中间用Expanded控件
        // ),
        Container(
          alignment: Alignment.center,
          child: Text(
            item.chooseType == 1
                ? "↑" + S.current.BUYZ + ""
                : "↓" + S.current.MD + "",
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: item.chooseType == 1
                  ? ThemeUtils().currentColorTheme.numberRedColor
                  : ThemeUtils().currentColorTheme.textgreenColor,
            ),
          ),
        ),
      ],
    );
    Widget titletext = Container(
      alignment: Alignment.centerLeft,
      child: Text(
        item.payPrice.toString(),
        style: TextStyle(
          fontSize: 12,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.labelColorW,
        ),
      ),
    );
    var Time = DateTime.fromMillisecondsSinceEpoch(item.createTime * 1000);
    var aTime = Time.toLocal().toString().substring(0, 16);
    Widget buyAmounteText = Row(
      children: [
        Container(
          alignment: Alignment.center,
          child: Text(
            aTime.toString(),
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.labelColorW,
            ),
          ),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        Container(
          alignment: Alignment.center,
          padding: EdgeInsets.only(right: 10),
          child: Text(
            cucettime.toString() + "S",
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.numberRedColor,
            ),
          ),
        ),
        // Expanded(
        //   child: Container(
        //     width: 15,
        //   ), // 中间用Expanded控件
        // ),
      ],
    );

    Widget topview = Column(
      children: <Widget>[
        SizedBox(
          height: 5,
        ),
        nametext,
        SizedBox(
          height: 5,
        ),
        titletext,
        SizedBox(
          height: 5,
        ),
        buyAmounteText,
        SizedBox(
          height: 5,
        ),
        Divider(
          color: ThemeUtils().currentColorTheme.lineColor,
          height: 1.0,
        )
      ],
    );

    return Container(
        padding: EdgeInsets.only(left: 20, right: 20),
        height: 76,
        child: topview);
  }
}

showdialog() {}

YYDialog YYAlertDialogWithGravity({width, gravity, doubleButtonGravity, tap}) {
  YYDialog yyDialog = YYDialog().build()
    ..width = width
    ..gravity = gravity
    ..gravityAnimationEnable = true
    ..borderRadius = 4.0
    ..barrierDismissible = false
    ..widget(RecordContextView(tap: tap))
    ..backgroundColor = ThemeUtils().currentColorTheme.contentBG

    // ..doubleButton(
    //   padding: EdgeInsets.only(top: 20.0),
    //   gravity: doubleButtonGravity ?? Gravity.right,
    //   text1: "DISAGREE",
    //   color1: Colors.deepPurpleAccent,
    //   fontSize1: 14.0,
    //   text2: "AGREE",
    //   color2: Colors.deepPurpleAccent,
    //   fontSize2: 14.0,
    // )
    ..show();
  return yyDialog;
}

class RecordContextView extends StatelessWidget {
  final String title;
  final String price;
  final String increase;
  final String onther;
  final Function tap;
  const RecordContextView({
    Key key,
    this.title,
    this.price,
    this.increase,
    this.onther,
    this.tap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var leftIconContainer = InkWell(
        // margin: EdgeInsets.all(6),
        // alignment: Alignment.centerRight,
        onTap: () {
          tap();
        },
        child: Container(
          alignment: Alignment.centerRight,
          child: Image.asset(
            "images/wode/gunabi@3x.png",
            width: 15,
            height: 15,
          ),
        ));
    Widget titletext = Container(
      alignment: Alignment.center,
      child: Text(
        '欧元美元',
        style: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.labelColorW,
        ),
      ),
    );
    Widget nametext = Row(
      children: [
        Container(
          alignment: Alignment.center,
          child: Text(
            '欧元美元',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.labelColorW,
            ),
          ),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        Container(
          alignment: Alignment.center,
          child: Text(
            '↑买涨（100）',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.labelColorW,
            ),
          ),
        ),
      ],
    );
    Widget buyTitle = Container(
      alignment: Alignment.centerLeft,
      child: Text(
        '买入',
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textgreenColor,
        ),
      ),
    );

    Widget buyDateText = Container(
      alignment: Alignment.centerLeft,
      child: Text(
        '2021-11-25 12：12：12',
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.dateGaryColor,
        ),
      ),
    );

    Widget buyPriceText = Row(
      children: [
        Container(
          alignment: Alignment.center,
          child: Text(
            '买入价格',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.textGaryColor,
            ),
          ),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        Container(
          alignment: Alignment.center,
          child: Text(
            '↑1.1334',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.dateGaryColor,
            ),
          ),
        ),
      ],
    );

// 投资金额
    Widget buyAmounteText = Row(
      children: [
        Container(
          alignment: Alignment.center,
          child: Text(
            S.current.TZJE,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.textGaryColor,
            ),
          ),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        Container(
          alignment: Alignment.center,
          child: Text(
            '100',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.dateGaryColor,
            ),
          ),
        ),
      ],
    );

    /// 手续费
    Widget HandlingFree = Row(
      children: [
        Container(
          alignment: Alignment.center,
          child: Text(
            '手续费',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.textGaryColor,
            ),
          ),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        Container(
          alignment: Alignment.center,
          child: Text(
            '0.1%',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.dateGaryColor,
            ),
          ),
        ),
      ],
    );

    Widget ExpireDate = Row(
      children: [
        Container(
          alignment: Alignment.center,
          child: Text(
            S.current.DQSJ + '（s）',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.textGaryColor,
            ),
          ),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        Container(
          alignment: Alignment.center,
          child: Text(
            '0.1%',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.dateGaryColor,
            ),
          ),
        ),
      ],
    );

    Widget sellTitle = Container(
      alignment: Alignment.centerLeft,
      child: Text(
        '卖出',
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textgreenColor,
        ),
      ),
    );

    Widget shellDateText = Container(
      alignment: Alignment.centerLeft,
      child: Text(
        '2021-11-25 12：12：12',
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.dateGaryColor,
        ),
      ),
    );

    Widget shellPriceText = Row(
      children: [
        Container(
          alignment: Alignment.center,
          child: Text(
            '卖出价格',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.textGaryColor,
            ),
          ),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        Container(
          alignment: Alignment.center,
          child: Text(
            '↑1.1334',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.dateGaryColor,
            ),
          ),
        ),
      ],
    );

// 投资金额
    Widget shellAmounteText = Row(
      children: [
        Container(
          alignment: Alignment.center,
          child: Text(
            S.current.DSY + '(USDT)',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.textGaryColor,
            ),
          ),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        Container(
          alignment: Alignment.center,
          child: Text(
            '9.00',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.dateGaryColor,
            ),
          ),
        ),
      ],
    );

    Widget topview = Column(
      children: <Widget>[
        // SizedBox(
        //   height: 10,
        // ),
        leftIconContainer,
        SizedBox(
          height: 5,
        ),
        titletext,
        SizedBox(
          height: 13,
        ),
        nametext,
        SizedBox(
          height: 24,
        ),
        buyTitle,
        SizedBox(
          height: 5,
        ),
        buyDateText,
        SizedBox(
          height: 5,
        ),
        buyPriceText,
        SizedBox(
          height: 5,
        ),
        buyAmounteText,
        SizedBox(
          height: 5,
        ),
        HandlingFree,
        SizedBox(
          height: 5,
        ),
        ExpireDate,
        SizedBox(
          height: 57,
        ),
        sellTitle,
        SizedBox(
          height: 5,
        ),
        shellDateText,
        SizedBox(
          height: 5,
        ),
        shellPriceText,
        SizedBox(
          height: 5,
        ),
        shellAmounteText
      ],
    );
    return Container(
        padding: EdgeInsets.fromLTRB(40, 16, 30, 40), child: topview);
  }
}
