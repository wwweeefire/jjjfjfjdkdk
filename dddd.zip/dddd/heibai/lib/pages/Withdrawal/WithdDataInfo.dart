// import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:heibai/Classes/model/UserInfo.dart';
import 'package:heibai/Classes/model/banklistitem.dart';
import 'package:heibai/Classes/model/config.dart';
import 'package:heibai/generated/l10n.dart';
import 'package:heibai/pages/Withdrawal/Withdmethodadd.dart';
import 'package:heibai/Classes/model/banklistitem.dart';
import 'package:heibai/util/DataUtils.dart';
import 'package:heibai/pages/Views/iconTextIcon.dart';
import 'package:flutter/foundation.dart';
import 'package:heibai/pages/userMsgRow.dart';
import 'package:heibai/util/ThemeUtils.dart';
import 'package:flutter_multi_formatter/flutter_multi_formatter.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:heibai/net/api/Api.dart';
import 'package:heibai/net/api/app_api.dart';
import 'package:heibai/Classes/model/Withdrawmethod.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'dart:io';
import 'package:heibai/pages/login/loginView.dart';
import 'package:heibai/Classes/JCHub/JCHub.dart';
import 'package:heibai/constants/Constants.dart';
import 'package:heibai/constants/events/LoginEvent.dart';
// import 'package:common_utils/common_utils.dart';

// export 'package:common_utils/common_utils.dart';
// enum whithdType {
//   normal,
//   zfbType,
//   bankType,
//   usdtType,
//   uzfbType,
//   ubankType,
//   uusdtType
// }

class WithdDataInfo extends StatefulWidget {
  final ListElement model;

  const WithdDataInfo({Key key, this.model}) : super(key: key);

  @override
  State<StatefulWidget> createState() => WithdDataInfoState(model: this.model);
}

class WithdDataInfoState extends State<WithdDataInfo> {
  ListElement model;

  var titlename;

  var path;
  // var Widgets = <Widget>[];
  final moneyCtril = TextEditingController(text: '');

  final usernamCtril = TextEditingController(text: '');

  final banknameCtril = TextEditingController(text: '');

  final bnakidCtril = TextEditingController(text: '');
  final bankzhCtril = TextEditingController(text: '');
  final zfbnummberCtril = TextEditingController(text: '');
  final usdtadds = TextEditingController(text: '');

  final password = TextEditingController(text: '');

  nBankListElement banknamemodel;

  WithdDataInfoState({Key key, this.model});

  @override
  Widget build(BuildContext context) {
    YYDialog.init(context);
    final mediaQueryData = MediaQuery.of(context);
    Config user = ConfigManager().config;
// 2.获取宽度和高度
    final screenWidth = mediaQueryData.size.width;
    final screenHeight = mediaQueryData.size.height;

    final statusBarHeight = mediaQueryData.padding.top;
// 有刘海的屏幕:34 没有刘海的屏幕0
    double bottomHeight = 10.0;
    if (!kIsWeb) {
      if (Platform.isIOS) {
        bottomHeight = mediaQueryData.padding.bottom;
      }
    }

    titlename = model.name;
    path = ConfigManager().imageHost + model.icon;
    Widget bodyviw;
    // Widgets = <Widget>[];
    var pathicon;
    if (model.code == 'kf') {
      pathicon = "images/recharge/kfczPay@3x.png";
    } else if (model.code == 'bank') {
      pathicon = "images/recharge/bankPay@3x.png";
    } else if (model.code == 'usdt') {
      pathicon = "images/recharge/USDTPay@3x.png";
    } else if (model.code == 'payment') {
      pathicon = "images/recharge/ThirdPay@3x.png";
    } else if (model.code == 'alipay') {
      pathicon = "images/recharge/zfbPay@3x.png";
    }

    Widget titleview = Container(
      child: iconTextIcon(
        onTap: () {
          if (model.code == 'bank') {
            if (user.base.bindCard == 1) {
              YYPaylistDialogWithGravity(
                  gravity: Gravity.bottom,
                  width: 262 + bottomHeight,
                  // model: cmodel,
                  tap: (indx) {
                    banknamemodel = indx;

                    Navigator.pop(context);
                    // if (indx > 0) {
                    setState(() {});
                    // }
                  });
            }
          }
        },
        icon: CachedNetworkImage(
          imageUrl: ConfigManager().imageHost + path,
          fit: BoxFit.cover,
          placeholder: (context, url) => Image.asset(
            pathicon,
          ),
          errorWidget: (context, url, error) => Image.asset(
            pathicon,
          ),
        ),
        title: banknamemodel == null
            ? titlename
            : banknamemodel.bankName +
                "(" +
                banknamemodel.cardNumber.toString() +
                ")",
        rightImage: Image.asset(
          "images/wode/xyy@3x.png",
          width: 19,
          height: 13,
        ),
      ),
    );
    // Widgets.add(titleview);

    Widget textbody = Container(
      alignment: Alignment.centerLeft,
      padding: EdgeInsets.only(left: 10),
      // height: 20,
      child: Text(
        S.current.WithdrawalAmount,
        style: TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );

    Widget inputMoneyWiget = Container(
      padding: EdgeInsets.fromLTRB(10, 2, 8, 2),
      // decoration: BoxDecoration(
      //   borderRadius: BorderRadius.circular(30),
      //   color: ThemeUtils().currentColorTheme.labelColorW,
      // ),
      alignment: Alignment.center,
      child: TextFormField(
        maxLines: 1,
        controller: moneyCtril,
        keyboardType: TextInputType.number,
        // inputFormatters: [
        //   PosInputFormatter(),
        // ],
        decoration: InputDecoration(
          hintText: ConfigManager().config.base.symbolFlag,
          hintStyle: TextStyle(
            fontSize: 24,
            color: ThemeUtils().currentColorTheme.textWithdrawColor,
          ),
          border: InputBorder.none,
        ),
        style: TextStyle(
          fontSize: 24,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );

    Widget balance = Container(
      alignment: Alignment.centerLeft,
      padding: EdgeInsets.only(left: 10),
      // height: 20,
      child: Text(
        S.current.AvailableBalance +
            ConfigManager().config.base.symbolFlag +
            ConfigManager().user.balance.toString(),
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );

    Widget bodeView = Column(
      children: <Widget>[
        SizedBox(
          height: 10,
        ),
        textbody,
        SizedBox(
          height: 20,
        ),
        inputMoneyWiget,
        balance,
      ],
    );
    Widget inputMoney = Container(
      child: Container(
        // padding: EdgeInsets.all(12),
        margin: EdgeInsets.fromLTRB(15, 5, 15, 5),
        color: ThemeUtils().currentColorTheme.contentBG,
        // height: 44,
        child: bodeView,
      ),
    );

    Widget name = Container();
    Widget bankname = Container();
    Widget bannumber = Container();

    if (model.code == 'bank') {
      if (ConfigManager().config.base.bindCard == 0) {
        name = inpuBankNumberWiget(
          title: S.current.QSRXM,
          type: TextInputType.text,
          Controller: usernamCtril,
        );

        bankname = inpuBankNumberWiget(
          title: S.current.QSRYHKMC,
          type: TextInputType.text,
          Controller: banknameCtril,
        );

        bannumber = inpuBankNumberWiget(
          title: S.current.QSRYHKH,
          type: TextInputType.phone,
          Controller: bnakidCtril,
        );
      }
    } else if (model.code == 'alipay') {
      name = inpuBankNumberWiget(
        title: S.current.QSRXM,
        type: TextInputType.text,
        Controller: usernamCtril,
      );

      bannumber = inpuBankNumberWiget(
        title: S.current.RSRZFBZH,
        type: TextInputType.text,
        Controller: zfbnummberCtril,
      );
    } else if (model.code == "usdt") {
      name = inpuBankNumberWiget(
        title: S.current.QSRUSDTDZ,
        type: TextInputType.text,
        Controller: usdtadds,
      );
    }

    Widget passwor = inpuBankNumberWiget(
      title: S.current.QSRTXMM,
      type: TextInputType.number,
      Controller: password,
      ishow: true,
    );

    Widget des = describeTextView();

    // Widget ad = Container();
    // return a;
    Widget body = Container(
      margin: EdgeInsets.only(bottom: bottomHeight + 50),
      height: screenHeight - 50 - bottomHeight,
      child: Column(
        // padding: EdgeInsets.zero,
        // shrinkWrap: true,
        // physics: new NeverScrollableScrollPhysics(), //禁用滑动事件
        // physics: AlwaysScrollableScrollPhysics(
        //   parent: BouncingScrollPhysics(),
        // ),
        children: [
          titleview,
          inputMoney,
          name,
          bankname,
          bannumber,
          passwor,
          des
        ],
      ),
    );
    // body = Container(
    //   color: ThemeUtils().currentColorTheme.contentBG,
    //   // height: 44,
    //   child: Column(
    //     children: <Widget>[
    //       body,
    //     ],
    //   ),
    // );

    var loginBtn = Builder(builder: (ctx) {
      return CommonButton(
          text: S.current.submit,
          color: ThemeUtils().currentColorTheme.labelColorY,
          onTap: () {
            Map<String, dynamic> params = {};
            String passwor = password.text.trim();

            if (model.code == 'bank') {
              if (ConfigManager().config.base.bindCard == 0) {
                String username = usernamCtril.text.trim();
                String money = moneyCtril.text.trim();
                String bankname = banknameCtril.text.trim();
                String banknumber = bnakidCtril.text.trim();

                if (username.isEmpty ||
                    money.isEmpty ||
                    bankname.isEmpty ||
                    banknumber.isEmpty ||
                    passwor.isEmpty) {
                  JCHub.showmsg(S.current.QJCSJBNWK, context);
                  return;
                }
                params["bank_name"] = bankname;

                params["card_number"] = banknumber;
                params["method"] = model.id;

                params["real_name"] = username;
                params["total_amount"] = double.parse(money);

                params["withdraw_password"] = passwor;
                pushcomit(context, params);
              } else {
                String money = moneyCtril.text.trim();
                // String passwor = password.text.trim();

                if (banknamemodel == null) {
                  JCHub.showmsg(S.current.QXZYHK, context);
                  return;
                }
                if (money.isEmpty) {
                  JCHub.showmsg(S.current.QSRJR, context);
                  return;
                }
                if (passwor.isEmpty) {
                  JCHub.showmsg(S.current.QSRTXMM, context);
                  return;
                }

                params["bank_name"] = banknamemodel.bankName;
                params["id"] = banknamemodel.id;

                params["branch_bank"] = banknamemodel.branchBank;
                params["bank_phone"] = banknamemodel.bankPhone;
                params["card_number"] = banknamemodel.cardNumber;
                params["method"] = model.id;
                params["withdraw_password"] = passwor;
                params["real_name"] = banknamemodel.realName;
                params["total_amount"] = double.parse(money);
                ;
                pushcomit(context, params);
              }
            } else if (model.code == 'alipay') {
              String username = usernamCtril.text.trim();
              String money = moneyCtril.text.trim();
              String bankname = zfbnummberCtril.text.trim();
              if (username.isEmpty ||
                  money.isEmpty ||
                  bankname.isEmpty ||
                  passwor.isEmpty) {
                JCHub.showmsg(S.current.QSRTXMM, context);
                return;
              }

              //  params["bank_name"] = banknamemodel.bankName;
              //  params["bank_id"] = banknamemodel.bankId;

              params["card_number"] = bankname;
              // params["bank_phone"] = banknamemodel.bankPhone;
              params["method"] = model.id;
              params["withdraw_password"] = passwor;
              params["real_name"] = username;
              params["total_amount"] = double.parse(money);
              ;
              pushcomit(context, params);
            } else if (model.code == "usdt") {
              String money = moneyCtril.text.trim();
              String bankname = usdtadds.text.trim();
              if (money.isEmpty || bankname.isEmpty || passwor.isEmpty) {
                JCHub.showmsg(S.current.QJCSJBNWK, context);
                return;
              }

              params["card_number"] = bankname;
              // params["bank_phone"] = banknamemodel.bankPhone;
              params["method"] = model.id;
              params["withdraw_password"] = passwor;
              params["total_amount"] = double.parse(money);
              pushcomit(context, params);
            }
          });
    });

    bodyviw = Stack(
      children: [
        body,
        Positioned(left: 0, right: 0, bottom: bottomHeight, child: loginBtn)
      ],
    );

    Widget allviebody = Scaffold(
      backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
      resizeToAvoidBottomInset: false,
      body: bodyviw,
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
        ),
        // 如果没有设置这项， 二级页面 会默认是返回箭头  ， 有侧边栏的页面默认有图标（用来打开侧边栏）
        // automaticallyImplyLeading: true,
        // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
        title: ThemeUtils.sText(S.current.withdraw),
        centerTitle: true,

        backgroundColor: ThemeUtils()
            .currentColorTheme
            .contentBG, // 导航栏的颜色  默认是 ThemeData 的颜色
      ),
    );
    return allviebody;
  }
}

pushcomit(BuildContext context, Map<String, dynamic> params) async {
  ResultData resultData =
      await AppApi.getInstance().post_withdraw_create(context, true, params);
  if (resultData.isSuccess()) {
    //  DataUtils.saveUserInfo(resultData.dataJson);
    // ConfigManager.
    Constants.eventBus.fire(LoginEvent());
    Navigator.pop(context);
    JCHub.showmsg(S.current.Submittedsuccessfullywaitingforreview, context);
  } else {
    JCHub.showmsg(resultData.msg, context);
  }
}

class inpuBankNumberWiget extends StatelessWidget {
  final String title;
  final TextInputType type;
  final int hight;
  final TextEditingController Controller;

  final bool ishow;

  const inpuBankNumberWiget(
      {Key key,
      this.title,
      this.hight,
      this.Controller,
      this.ishow = false,
      this.type = TextInputType.text})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    int he = hight;
    if (he == null) {
      he = 50;
    }

    return Container(
      child: Container(
        padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
        margin: EdgeInsets.fromLTRB(15, 5, 15, 5),
        color: ThemeUtils().currentColorTheme.contentBG,
        height: 50,
        child: new SizedBox(
          child: new Container(
            height: he.toDouble(),
            color: ThemeUtils().currentColorTheme.contentBG,
            alignment: Alignment.center,
            child: TextField(
              obscureText: ishow,
              keyboardType: type,
              maxLines: 1,
              controller: Controller,
              decoration: InputDecoration(
                hintText: title,
                border: InputBorder.none,
                hintStyle: TextStyle(
                  fontSize: 12,
                  color: ThemeUtils().currentColorTheme.textGaryColor,
                ),
              ),
              style: TextStyle(
                fontSize: 12,
                color: ThemeUtils().currentColorTheme.textWithdrawColor,
              ),
            ),
          ),
        ),
      ),
    );
    // TODO: implement build
  }
}
// class inputMoneyWiget extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     // TODO: implement build
//     return new SizedBox(
//       child: new Container(
//         padding: EdgeInsets.fromLTRB(20, 2, 8, 2),
//         decoration: BoxDecoration(
//           borderRadius: BorderRadius.circular(30),
//           color: Colors.black12,
//         ),
//         alignment: Alignment.center,
//         child: TextField(
//           maxLines: 1,
//           decoration: InputDecoration(
//             hintText: '用户名',
//             border: InputBorder.none,
//           ),
//         ),
//       ),
//     );
//   }
// }

class describeTextView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Widget textbody = Container(
      alignment: Alignment.centerLeft,
      padding: EdgeInsets.fromLTRB(15, 2, 2, 2),
      // height: 20,
      child: Text(
        S.current.handlingfee +
            ConfigManager().config.funds.withdrawFee.toString() +
            '%',
        style: TextStyle(
          fontSize: 15,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );

    // Widget btext = Container(
    // alignment: Alignment.centerLeft,
    // padding: EdgeInsets.fromLTRB(15, 2, 2, 2),
    // height: 20,
    // child: Text(
    // '手续费:  0.00',
    // style: TextStyle(
    // fontSize: 15,
    // fontWeight: FontWeight.w900,
    // color: ThemeUtils().currentColorTheme.textWithdrawColor,
    // ),
    // ),
    // );

    Config user = ConfigManager().config;
    Widget text = Container(
      alignment: Alignment.centerLeft,
      padding: EdgeInsets.fromLTRB(15, 2, 2, 2),
      // height: 20,
      child: Text(
        S.current.withddes +
            "\n2." +
            S.current.DNBJEDSQ +
            user.funds.withdrawMinAmount.toString() +
            "\n3." +
            S.current.CJSJWMR +
            user.funds.withdrawStartTime +
            S.current.DZHI +
            user.funds.withdrawEndTime,
        style: TextStyle(
          fontSize: 12,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );

    Widget bodeView = Column(
      children: <Widget>[
        // SizedBox(
        //   height: 5,
        // ),
        textbody,
        // SizedBox(
        //   height: 5,
        // ),
        // btext,
        SizedBox(
          height: 10,
        ),
        text,
      ],
    );
    return Container(
      child: Container(
        // padding: EdgeInsets.all(12),
        // margin: EdgeInsets.fromLTRB(15, 5, 15, 5),
        // color: ThemeUtils().currentColorTheme.,
        // height: 44,
        child: bodeView,
      ),
    );
  }
}

YYDialog YYPaylistDialogWithGravity(
    {width, gravity, doubleButtonGravity, tap, model, shell}) {
  YYDialog yyDialog = YYDialog().build()
    // ..width = width
    ..height = width
    ..gravity = gravity
    ..gravityAnimationEnable = true
    // ..borderRadius = 4.0
    // ..barrierDismissible = false
    ..widget(rechargemethodView(
      tap: tap,
    ))
    // ..widget(CountdownClockPage())
    ..barrierColor = Colors.black.withOpacity(.7)
    ..backgroundColor = ThemeUtils().currentColorTheme.contentBG

    // ..doubleButton(
    //   padding: EdgeInsets.only(top: 20.0),
    //   gravity: doubleButtonGravity ?? Gravity.right,
    //   text1: "DISAGREE",
    //   color1: Colors.deepPurpleAccent,
    //   fontSize1: 14.0,
    //   text2: "AGREE",
    //   color2: Colors.deepPurpleAccent,
    //   fontSize2: 14.0,
    // )
    ..show();
  return yyDialog;
}

class rechargemethodView extends StatefulWidget {
  final Function tap;

  const rechargemethodView({
    Key key,
    this.tap,
  }) : super(key: key);
  @override
  State<StatefulWidget> createState() {
    // ignore: no_logic_in_create_state
    return rechargemethodViewState(tap);
  }
}

class rechargemethodViewState extends State<rechargemethodView> {
  Function tap;
  rechargemethodViewState(this.tap);

  @override
  Widget build(BuildContext context) {
    var index;

    var leftIconContainer = InkWell(
        // margin: EdgeInsets.all(6),
        // alignment: Alignment.centerRight,
        onTap: () {
          Navigator.pop(context);
        },
        child: Container(
          margin: EdgeInsets.only(right: 10),
          alignment: Alignment.centerRight,
          child: Image.asset(
            "images/wode/gunabi@3x.png",
            width: 15,
            height: 15,
          ),
        ));
    Widget titletext = Container(
      // alignment: Alignment.center,
      margin: EdgeInsets.only(left: 10),
      child: Text(
        S.current.Chooseabankcard,
        style: TextStyle(
          fontSize: 16,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );

    Widget body = Row(
      children: [
        titletext,
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        leftIconContainer,
      ],
    );

    Widget paynumberlistvie = Container(
      alignment: Alignment.topRight,
      height: 176,
      // color: Colors.red,
      child: wListView(
        tap: (index) {
          tap(index);
        },
      ),
    );

    Widget topview = Column(
      children: <Widget>[
        SizedBox(
          height: 5,
        ),
        body,
        // SizedBox(
        //   height: 5,
        // ),
        // titletext,
        SizedBox(
          height: 10,
        ),
        paynumberlistvie,

        // shellPriceText,
        // SizedBox(
        //   height: 5,
        // ),
        // shellAmounteText
      ],
    );
    return Container(
      // padding: EdgeInsets.only(left: 20, right: 20),

      child: MediaQuery.removePadding(
        context: context,
        removeTop: true,
        child: topview,
      ),
    );
  }
}

class wListView extends StatefulWidget {
  final Function tap;
  final int index;

  const wListView({Key key, this.index, this.tap}) : super(key: key);
  @override
  State<StatefulWidget> createState() {
    return wListViewState(index, tap);
  }
}

class wListViewState extends State<wListView> {
  final Function tap;
  final int index;

  List<nBankListElement> banklist = [];

  void get_member_bank_list() async {
    // params["status"] = 2;

    ResultData resultData = await AppApi.getInstance().get_member_bank_list(
      context,
      false,
    );
    if (resultData.isSuccess()) {
      Banklistitem model = banklistitemFromJson(resultData.dataJson);
      banklist = model.list;

      setState(() {
        banklist = model.list;
      });
    }
  }

  wListViewState(this.index, this.tap);
  var select = 0;

  @override
  void initState() {
    super.initState();

    get_member_bank_list();
    //   if (SchedulerBinding.instance.schedulerPhase ==
    //   SchedulerPhase.persistentCallbacks) {
    // SchedulerBinding.instance.addPostFrameCallback((_) => onWidgetBuild());
  }

  Widget build(BuildContext context) {
    var listView = ListView.builder(
      shrinkWrap: true, //解决无限高度问题
      // physics: new NeverScrollableScrollPhysics(), //禁用滑动事件
      itemCount: banklist.length == 0 ? 1 : banklist.length,
      scrollDirection: Axis.vertical,
      itemBuilder: (context, i) => renderRow(i),
    );

    return listView;
  }

  renderRow(i) {
    if (i < banklist.length) {
      nBankListElement model = banklist[i];
      var rowitem = wListRow(
        index: model.bankName + "(" + model.cardNumber.toString() + ")",
      );

      return InkWell(
        child: rowitem,
        onTap: () {
          tap(model);
        },
      );
    } else if (i == banklist.length) {
      var rowitem = addWiget();

      return InkWell(
        child: rowitem,
        onTap: () async {
          final result = await Navigator.of(context)
              .push(MaterialPageRoute(builder: (context) {
            return Withdmethodadd();
          }));
        },
      );
    }
    // Product pro = model.category[index].product[i];
  }
}

class addWiget extends StatelessWidget {
  Widget build(BuildContext context) {
    var iconContainer = Container(
      // margin: EdgeInsets.all(),
      height: 20,
      width: 20,

      child: Image.asset(
        "images/recharge/bankPay@3x.png",
      ),
    );

    Widget body = Row(
      children: [
        iconContainer,
        Container(
          alignment: Alignment.center,
          padding: EdgeInsets.only(left: 10),
          // height: 20,
          child: Text(
            S.current.Addabankcard,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.dateGaryColor,
            ),
          ),
        ),
      ],
    );

    return Container(
      child: Container(
        margin: EdgeInsets.only(bottom: 1),
        // margin: EdgeInsets.fromLTRB(15, 5, 15, 5),
        padding: EdgeInsets.fromLTRB(15, 0, 0, 0),
        color: ThemeUtils().currentColorTheme.viewgaryBG,
        height: 44,
        child: body,
      ),
    );
  }
}

class wListRow extends StatefulWidget {
  final String index;

  const wListRow({Key key, this.index}) : super(key: key);
  @override
  State<StatefulWidget> createState() {
    // ignore: no_logic_in_create_state
    return wListRowState();
  }
}

class wListRowState extends State<wListRow> {
  @override
  Widget build(BuildContext context) {
    var iconContainer = Container(
      // margin: EdgeInsets.all(),
      height: 20,
      width: 20,

      child: Image.asset(
        "images/recharge/bankPay@3x.png",
      ),
    );

    Widget body = Row(
      children: [
        iconContainer,
        Container(
          alignment: Alignment.center,
          padding: EdgeInsets.only(left: 10),
          // height: 20,
          child: Text(
            widget.index,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.dateGaryColor,
            ),
          ),
        ),
      ],
    );

    return Container(
      child: Container(
        margin: EdgeInsets.only(bottom: 1),
        padding: EdgeInsets.fromLTRB(15, 0, 0, 0),
        color: ThemeUtils().currentColorTheme.viewgaryBG,
        height: 44,
        child: body,
      ),
    );
  }
}
