import 'package:flutter/material.dart';
import 'package:heibai/generated/l10n.dart';
import 'package:heibai/pages/userMsgRow.dart';

import 'package:heibai/util/ThemeUtils.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:heibai/net/api/Api.dart';
import 'package:heibai/net/api/app_api.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
// import '../Classes/model/billModel.dart';
import 'package:heibai/Classes/model/bankitemModel.dart';

import 'package:heibai/Classes/JCHub/JCHub.dart';

typedef OnCountrySelectedCallback = Function(bankListElement bank);

class banklistview extends StatefulWidget {
  final OnCountrySelectedCallback onSelected;
  const banklistview({Key key, this.onSelected}) : super(key: key);
  @override
  State<StatefulWidget> createState() {
    return banklistviewState(onSelected);
  }
}

class banklistviewState extends State<banklistview> {
  final OnCountrySelectedCallback onSelected;
  banklistviewState(this.onSelected);
  List<bankListElement> list = [];
  bool showLoading = true;
  int page = 1;
  RefreshController _refreshController =
      RefreshController(initialRefresh: false);

  void get_message_page_list() async {
    Map<String, dynamic> params = {};

    // params["page"] = 1;
    // params["pageSize"] = 15;
    // params["status"] = 2;

    ResultData resultData =
        await AppApi.getInstance().get_bank_list(context, false, params);
    if (resultData.isSuccess()) {
      BankitemModel model = bankitemModelFromJson(resultData.dataJson);
      list = model.list;

      setState(() {
        showLoading = false;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    get_message_page_list();
    //   if (SchedulerBinding.instance.schedulerPhase ==
    //   SchedulerPhase.persistentCallbacks) {
    // SchedulerBinding.instance.addPostFrameCallback((_) => onWidgetBuild());
  }

  Widget build(BuildContext context) {
    Color themeColor = ThemeUtils().currentColorTheme.currentColorTheme;
    Color contentBG = ThemeUtils().currentColorTheme.contentBG;
    var listView = ListView.builder(
      // shrinkWrap: true, //解决无限高度问题
      // physics: new NeverScrollableScrollPhysics(), //禁用滑动事件
      itemCount: list.length,
      itemBuilder: (context, i) => renderRow(i),
    );

    Widget allviebody = Scaffold(
        appBar: AppBar(
          iconTheme: IconThemeData(
            color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
          ),
          automaticallyImplyLeading: true,
          // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
          title: ThemeUtils.sText(S.current.YHKLB),
          backgroundColor: ThemeUtils().currentColorTheme.contentBG,
        ),
        backgroundColor: themeColor,
        body: showLoading == true ? Text('') : listView);

    return allviebody;
  }

  renderRow(i) {
    bankListElement item = list[i];

    var rowitem = Container(
        alignment: Alignment.centerLeft,
        height: 44,
        margin: EdgeInsets.fromLTRB(15, 0, 15, 0),
        child: Text(
          item.bankName,
          style: TextStyle(
              color: ThemeUtils().currentColorTheme.textGaryColor,
              fontSize: 15),
        ));

    return InkWell(
      child: rowitem,
      onTap: () {
        onSelected(item);
        Navigator.pop(context);
      },
    );
  }
}
