import 'package:flutter/material.dart';
import 'package:heibai/generated/l10n.dart';

import 'package:heibai/pages/Views/iconTextIcon.dart';
import 'package:heibai/util/ThemeUtils.dart';
import 'package:heibai/pages/Withdrawal/WithdDataInfo.dart';
import 'package:heibai/net/api/Api.dart';
import 'package:heibai/net/api/app_api.dart';
import 'package:heibai/Classes/model/Withdrawmethod.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:heibai/Classes/model/config.dart';

class WithdrawalPlatformPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return WithdrawalPlatformPageState();
  }
}

class WithdrawalPlatformPageState extends State<WithdrawalPlatformPage> {
  // Widget build(BuildContext context) {
  //
  //  Widget ad = Container();
  //   return ad;
  // }

  Withdrawmethod cmodel;
  bool showloading = true;
  void get_config() async {
    Map<String, dynamic> param = {};
    ResultData resultData =
        await AppApi.getInstance().get_withdraw_method(context, true, param);
    if (resultData.isSuccess()) {
      Withdrawmethod model = withdrawmethodFromJson(resultData.dataJson);
      cmodel = model;

      showloading = false;

      setState(() {
        //
        cmodel = model;
        showloading = false;
      });
    }
  }

  Widget build(BuildContext context) {
    if (showloading) {
      get_config();
    }

    renderRow(i) {
      // Product pro = model.category[index].product[i];
      ListElement m = cmodel.list[i];
      var titlename = m.name;
      var path = ConfigManager().imageHost + m.icon;
      var pathicon;
      if (m.code == 'kf') {
        pathicon = "images/recharge/kfczPay@3x.png";
      } else if (m.code == 'bank') {
        pathicon = "images/recharge/bankPay@3x.png";
      } else if (m.code == 'usdt') {
        pathicon = "images/recharge/USDTPay@3x.png";
      } else if (m.code == 'payment') {
        pathicon = "images/recharge/ThirdPay@3x.png";
      } else if (m.code == 'alipay') {
        pathicon = "images/recharge/zfbPay@3x.png";
      }

      var rowitem = iconTextIcon(
        onTap: () async {
          final result = await Navigator.of(context)
              .push(MaterialPageRoute(builder: (context) {
            return WithdDataInfo(
              model: m,
            );
          }));
        },
        icon: CachedNetworkImage(
          imageUrl: path,
          fit: BoxFit.cover,
          placeholder: (context, url) => Image.asset(
            pathicon,
          ),
          errorWidget: (context, url, error) => Image.asset(
            pathicon,
          ),
        ),
        title: titlename,
        rightImage: Image.asset(
          "images/wode/xyy@3x.png",
          width: 19,
          height: 13,
        ),
      );

      return rowitem;
    }

    var listView = ListView.builder(
      shrinkWrap: true, //解决无限高度问题
      // physics: new NeverScrollableScrollPhysics(), //禁用滑动事件
      itemCount: cmodel == null ? 0 : cmodel.list.length,
      scrollDirection: Axis.vertical,
      itemBuilder: (context, i) => renderRow(i),
    );

    Widget body = Container(
      child: showloading == true ? Container() : listView,
    );

    Widget allviebody = Scaffold(
      backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
      body: body,
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
        ),
        // 如果没有设置这项， 二级页面 会默认是返回箭头  ， 有侧边栏的页面默认有图标（用来打开侧边栏）
        // automaticallyImplyLeading: true,
        // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
        title: ThemeUtils.sText(S.current.Withdrawalchannel),
        centerTitle: true,
        //  actions: <Widget>[
        //     IconButton(
        //         icon: Icon(Icons.add_alarm),
        //         tooltip: 'Add Alarm',
        //         onPressed: () {
        //           // do nothing
        //         })
        //   ],   // 标题是否在居中

//          elevation: 0.1, // 导航栏Z轴的高度，默认是1  默认就是有高度 阴影的
        backgroundColor: ThemeUtils()
            .currentColorTheme
            .contentBG, // 导航栏的颜色  默认是 ThemeData 的颜色
//         flexibleSpace: FlexibleSpaceBar(title: Text("你号"),),//这个堆叠在工具栏上面  一般 appbar不用  主要用在 SliverAppBar上
//          brightness: Brightness.light, //状态栏的深度 有白色和黑色两种主题
//          titleSpacing: 10,//flexibleSpace 和 title 的距离  默认是重合的
//          toolbarOpacity: 0.5,// 导航栏透明度 默认是1 ，不包括flexibleSpace
//          bottomOpacity: 0.5,
      ),
    );
    return allviebody;
  }
}
