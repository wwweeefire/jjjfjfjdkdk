import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:heibai/generated/l10n.dart';
import 'package:heibai/pages/Views/iconTextIcon.dart';
import 'package:heibai/util/ThemeUtils.dart';
import 'package:heibai/pages/Withdrawal/WithdDataInfo.dart';
import 'package:heibai/pages/Withdrawal/banklistview.dart';
import 'package:heibai/net/api/Api.dart';
import 'package:heibai/net/api/app_api.dart';
import 'package:heibai/Classes/model/Withdrawmethod.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:tapped/tapped.dart'; //咨询
import 'package:heibai/Classes/model/bankitemModel.dart';
import 'package:heibai/Classes/JCHub/JCHub.dart';
import 'package:heibai/pages/login/loginView.dart';

class Withdmethodadd extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return WithdmethodaddState();
  }
}

class WithdmethodaddState extends State<Withdmethodadd> {
  // Widget build(BuildContext context) {
  //
  //  Widget ad = Container();
  //   return ad;
  // }
  bankListElement bank;
  Withdrawmethod cmodel;
  final usernameCtrl = TextEditingController(text: '');
  final bankcardCtrl = TextEditingController(text: '');
  final bankznameCtrl = TextEditingController(text: '');
  final phoneCtrl = TextEditingController(text: '');
  // final usernameCtrl = TextEditingController(text: '');
  // final passwordCtrl = TextEditingController(text: '');

  bool showloading = true;
  final ValueNotifier<String> new_counter =
      ValueNotifier<String>(S.current.QXZYH);
  Widget _builderWithValue(BuildContext context, String value, Widget child) {
    return regText(
      onTap: () async {
        // get_country();
        // c.launch(context);
        final result = await Navigator.of(context)
            .push(MaterialPageRoute(builder: (context) {
          return banklistview(
            onSelected: (country) {
              bank = country;
              new_counter.value = bank.bankName;
            },
          );
        }));
      },
      des: '$value',
      title: S.current.YHMZ,
      icon: Image.asset(
        "images/wode/xyy@3x.png",
        width: 19,
        height: 13,
      ),
    );
  }

  Widget build(BuildContext context) {
    Widget btitle = Container(
      alignment: Alignment.centerLeft,
      margin: EdgeInsets.fromLTRB(15, 0, 0, 0),
      child: Text(
        S.current.XM,
        style: TextStyle(
          fontSize: 15,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );
    Widget inpuBank = inpuBankNumberWiget(
      title: S.current.QSRXM,
      hight: 40,
      type: TextInputType.text,
      Controller: usernameCtrl,
    );

    Widget bankname = Container(
      alignment: Alignment.centerLeft,
      margin: EdgeInsets.fromLTRB(15, 0, 0, 0),
      child: Text(
        S.current.YHMZ,
        style: TextStyle(
          fontSize: 15,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );
    // Widget inpuBankiname = ;
    Widget inpuBankiname = Container(
        alignment: Alignment.centerLeft,
        margin: EdgeInsets.fromLTRB(15, 0, 0, 15),
        child: ValueListenableBuilder<String>(
          builder: _builderWithValue,
          valueListenable: new_counter,
        ));

    Widget bankcard = Container(
      alignment: Alignment.centerLeft,
      margin: EdgeInsets.fromLTRB(15, 0, 0, 0),
      child: Text(
        S.current.YHZHKH,
        style: TextStyle(
          fontSize: 15,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );
    Widget inputbankcard = inpuBankNumberWiget(
      title: S.current.QRRYHZHKH,
      type: TextInputType.number,
      Controller: bankcardCtrl,
    );

    Widget bankzname = Container(
      alignment: Alignment.centerLeft,
      margin: EdgeInsets.fromLTRB(15, 0, 0, 0),
      child: Text(
        S.current.YHZH,
        style: TextStyle(
          fontSize: 15,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );
    Widget inputzbankname = inpuBankNumberWiget(
      title: S.current.QSRYHZH,
      type: TextInputType.text,
      Controller: bankznameCtrl,
    );

    Widget phoneCard = Container(
      alignment: Alignment.centerLeft,
      margin: EdgeInsets.fromLTRB(15, 0, 0, 0),
      child: Text(
        S.current.SJHM,
        style: TextStyle(
          fontSize: 15,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );
    Widget inputphone = inpuBankNumberWiget(
      title: S.current.QRRSJHM,
      hight: 40,
      type: TextInputType.phone,
      Controller: phoneCtrl,
    );

    void post_member_bank_create(params) async {
      // params["code"] = widget.model.code;

      ResultData resultData = await AppApi.getInstance()
          .post_member_bank_create(context, true, params);
      if (resultData.isSuccess()) {
        JCHub.showmsg(S.current.Submittedsuccessfullywaitingforreview, context);
        Navigator.pop(context);
      } else {
        JCHub.showmsg(resultData.msg, context);
      }
    }

    var loginBtn = Builder(builder: (ctx) {
      return CommonButton(
          text: S.current.submit,
          color: ThemeUtils().currentColorTheme.labelColorY,
          onTap: () {
            Map<String, dynamic> params = {};

            String username = usernameCtrl.text.trim();
            String bankcard = bankcardCtrl.text.trim();

            String bankzname = bankznameCtrl.text.trim();
            String phone = phoneCtrl.text.trim();

            if (username.isEmpty ||
                bankcard.isEmpty ||
                bankzname.isEmpty ||
                phone.isEmpty ||
                bank.bankName.isEmpty) {
              JCHub.showmsg(S.current.QJCSJBNWK, context);
              return;
            }
            params["bank_id"] = bank.id;
            params["bank_phone"] = phone;
            params["branch_bank"] = bankzname;
            params["card_number"] = bankcard;
            params["real_name"] = username;
            post_member_bank_create(params);
          });
    });

    Widget listview = Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[
        SizedBox(
          height: 10,
        ),
        btitle,
        SizedBox(
          height: 5,
        ),
        inpuBank,
        SizedBox(
          height: 2,
        ),
        bankname,
        SizedBox(
          height: 2,
        ),
        inpuBankiname,
        SizedBox(
          height: 2,
        ),
        bankcard,
        SizedBox(
          height: 2,
        ),
        inputbankcard,
        SizedBox(
          height: 2,
        ),
        bankzname,
        SizedBox(
          height: 2,
        ),
        inputzbankname,
        SizedBox(
          height: 2,
        ),
        phoneCard,
        SizedBox(
          height: 2,
        ),
        inputphone,
        SizedBox(
          height: 10,
        ),
        loginBtn,
      ],
    );

    Widget body = Container(
      child: showloading == false ? Container() : listview,
    );

    Widget allviebody = Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
      body: body,
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
        ),
        // 如果没有设置这项， 二级页面 会默认是返回箭头  ， 有侧边栏的页面默认有图标（用来打开侧边栏）
        // automaticallyImplyLeading: true,
        // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
        title: ThemeUtils.sText(S.current.BDYHK),
        centerTitle: true,
        //  actions: <Widget>[
        //     IconButton(
        //         icon: Icon(Icons.add_alarm),
        //         tooltip: 'Add Alarm',
        //         onPressed: () {
        //           // do nothing
        //         })
        //   ],   // 标题是否在居中

//          elevation: 0.1, // 导航栏Z轴的高度，默认是1  默认就是有高度 阴影的
        backgroundColor: ThemeUtils()
            .currentColorTheme
            .contentBG, // 导航栏的颜色  默认是 ThemeData 的颜色
//         flexibleSpace: FlexibleSpaceBar(title: Text("你号"),),//这个堆叠在工具栏上面  一般 appbar不用  主要用在 SliverAppBar上
//          brightness: Brightness.light, //状态栏的深度 有白色和黑色两种主题
//          titleSpacing: 10,//flexibleSpace 和 title 的距离  默认是重合的
//          toolbarOpacity: 0.5,// 导航栏透明度 默认是1 ，不包括flexibleSpace
//          bottomOpacity: 0.5,
      ),
    );
    return allviebody;
  }
}

class inpuBankNumberWiget extends StatelessWidget {
  final String title;
  final TextInputType type;
  final int hight;
  final TextEditingController Controller;

  final bool ishow;

  const inpuBankNumberWiget(
      {Key key,
      this.title,
      this.hight,
      this.Controller,
      this.ishow = false,
      this.type = TextInputType.text})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    int he = hight;
    if (he == null) {
      he = 50;
    }

    return Container(
      child: Container(
        padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
        margin: EdgeInsets.fromLTRB(15, 5, 15, 5),
        color: ThemeUtils().currentColorTheme.contentBG,
        height: 50,
        child: new SizedBox(
          child: new Container(
            height: he.toDouble(),
            color: ThemeUtils().currentColorTheme.contentBG,
            alignment: Alignment.center,
            child: TextField(
              obscureText: ishow,
              keyboardType: type,
              maxLines: 1,
              controller: Controller,
              decoration: InputDecoration(
                hintText: title,
                border: InputBorder.none,
                hintStyle: TextStyle(
                  fontSize: 12,
                  color: ThemeUtils().currentColorTheme.textGaryColor,
                ),
              ),
              style: TextStyle(
                fontSize: 12,
                color: ThemeUtils().currentColorTheme.textWithdrawColor,
              ),
            ),
          ),
        ),
      ),
    );
    // TODO: implement build
  }
}

class regText extends StatelessWidget {
  final String des;
  final Image icon;
  final String title;
  final Function onTap;

  const regText({Key key, this.icon, this.title, this.onTap, this.des})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    var leftIconContainer = Container(
      // margin: EdgeInsets.all(6),
      height: 13,
      width: 19,
      // decoration: BoxDecoration(
      //   color: ThemeUtils().currentColorTheme.labelColorW,
      //   borderRadius: BorderRadius.circular(2),
      //   gradient: LinearGradient(
      //     begin: Alignment.topLeft,
      //     end: Alignment.bottomCenter,
      //     colors: [
      //       color2,
      //       color!,
      //     ],
      //     stops: [0.1, 0.8],
      //   ),
      // ),
      child: icon,
    );

    Widget body = Row(
      children: [
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.only(left: 10),
          // height: 20,
          child: Text(
            des,
            style: TextStyle(
              fontSize: 12,
              // fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.dateGaryColor,
            ),
          ),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        leftIconContainer,
      ],
    );

    body = Tapped(
      child: body,
      onTap: onTap,
    );
    return Container(
      child: Container(
        // padding: EdgeInsets.all(12),
        padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
        color: ThemeUtils().currentColorTheme.contentBG,
        height: 50,
        child: body,
      ),
    );
  }
}
