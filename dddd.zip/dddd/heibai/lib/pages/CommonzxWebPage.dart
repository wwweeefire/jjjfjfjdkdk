import 'package:flutter/material.dart';
import 'package:heibai/util/ThemeUtils.dart';
import 'dart:io';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:heibai/generated/l10n.dart';
import 'package:webviewx/webviewx.dart';
import 'package:webview_flutter/webview_flutter.dart';

import 'package:heibai/pages/register_web_webview_stub.dart'
    if (dart.library.html) 'package:heibai/pages//register_web_webview.dart';
// import 'dart:html';
// import 'dart:ui' as ui;
// // import 'package:simp';
// // import 'package:flutter_fai_webview/flutter_fai_webview.dart';
// import 'package:webview_flutter/webview_flutter.dart';

class CommonzxWebPage extends StatefulWidget {
  final String htmlContent;
  final String title;

  CommonzxWebPage({Key key, this.htmlContent, this.title}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return NewListWebContentState();
  }
}

class NewListWebContentState extends State<CommonzxWebPage> {
  WebViewXController webviewController;

  void initState() {
    registerWebViewWebImplementation();
    super.initState();
  }

  Size get screenSize => MediaQuery.of(context).size;
  @override
  void dispose() {
    super.dispose();
    //webviewController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    void showSnackBar(String content, BuildContext context) {
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(
          SnackBar(
            content: Text(content),
            duration: const Duration(seconds: 1),
          ),
        );
    }

    Widget _buildWebViewX() {
      return WebViewX(
        key: const ValueKey('webviewx'),
        initialContent: widget.htmlContent,
        initialSourceType: SourceType.urlBypass,
        height: screenSize.height,
        width: screenSize.width,
        onWebViewCreated: (controller) => webviewController = controller,
        onPageStarted: (src) =>
            debugPrint('A new page has started loading: $src\n'),
        onPageFinished: (src) =>
            debugPrint('The page has finished loading: $src\n'),
        dartCallBacks: {
          DartCallback(
            name: 'TestDartCallback',
            callBack: (msg) => showSnackBar(msg.toString(), context),
          )
        },
        webSpecificParams: const WebSpecificParams(
          printDebugInfo: true,
        ),
        mobileSpecificParams: const MobileSpecificParams(
          androidEnableHybridComposition: true,
        ),
      );
    }

    return Scaffold(
      // backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
      appBar: AppBar(
        backgroundColor: ThemeUtils().currentColorTheme.contentBG,
        title: ThemeUtils.sText(widget.title),
      ),
      body: Container(
        // margin: EdgeInsets.only(bottom: 0),
        child: Container(
          // color: ,
          child: Center(
            child: Container(
              child: kIsWeb == true
                  ? WebView(
                      initialUrl: widget.htmlContent,
                    )
                  : _buildWebViewX(),
            ),
          ),
        ),
      ),
    );
  }
}
