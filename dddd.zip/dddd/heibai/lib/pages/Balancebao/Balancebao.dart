// import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:heibai/Classes/JCHub/JCHub.dart';
import 'package:heibai/generated/l10n.dart';

import 'package:heibai/pages/Views/iconTextIcon.dart';
import 'package:heibai/pages/userMsgRow.dart';
import 'package:heibai/util/ThemeUtils.dart';
import 'package:flutter_multi_formatter/flutter_multi_formatter.dart';
import 'package:heibai/net/api/Api.dart';
import 'package:heibai/net/api/app_api.dart';
import 'package:heibai/Classes/model/ybalanceModel.dart';
import 'package:flutter_custom_dialog/flutter_custom_dialog.dart';
import 'package:heibai/pages/login/loginView.dart';
import 'package:heibai/constants/events/LoginEvent.dart';
// import 'package:heibai/pages/login/loginView.dart';
import 'package:heibai/constants/Constants.dart';

class Balancebao extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return BalancebaoState();
  }
}

class BalancebaoState extends State<Balancebao> {
  YbalanceModel model;

  bool showloading = true;
  getdate() async {
    ResultData resultData =
        await AppApi.getInstance().get_invest(context, true);
    if (resultData.isSuccess()) {
      model = ybalanceModelFromJson(resultData.dataJson);

      setState(() {
        showloading = false;
      });
    } else {}
  }

  renderRow(i) {
    if (i == 0) {
    } else {}
    --i;
    if (i.isOdd) {
      return Divider(
        // color: Color(0xFF2B3139),
        height: 1,
      );
    }
    i = i ~/ 2;

    // }
    ListElement smodel = model.income.list[i];

    return InkWell(
      child: yitemlistView(
        model: smodel,
      ),
      onTap: () {
//        Navigator
//            .of(context)
//            .push(MaterialPageRoute(builder: (context) => CommonWebPage(title: "Test", url: "https://my.oschina.net/u/815261/blog")));
      },
    );
  }

  void initState() {
    super.initState();

    getdate();

    //   if (SchedulerBinding.instance.schedulerPhase ==
    //   SchedulerPhase.persistentCallbacks) {
    // SchedulerBinding.instance.addPostFrameCallback((_) => onWidgetBuild());
  }

  @override
  Widget build(BuildContext context) {
    YYDialog.init(context);
    var listView = ListView.builder(
      shrinkWrap: true, //解决无限高度问题
      physics: new NeverScrollableScrollPhysics(), //禁用滑动事件
      itemCount: model == null ? 0 : model.income.list.length * 2,

      // itemCount: 1 * 2,
      itemBuilder: (context, i) => renderRow(i),
    );

    Widget titletext = Container(
      alignment: Alignment.centerLeft,
      margin: EdgeInsets.only(left: 15, top: 5, right: 15),
      height: 44,
      child: Text(
        S.current.SYJL,
        style: TextStyle(
          fontSize: 15,
          // fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );
    Widget body = ListView(
      physics: BouncingScrollPhysics(
        parent: AlwaysScrollableScrollPhysics(),
      ),
      children: <Widget>[
        Container(
            // color: Colors.black,
            child: Column(
          children: <Widget>[
            SizedBox(
              height: 55,
            ),
            Container(
              margin: EdgeInsets.symmetric(horizontal: 15, vertical: 0),
              decoration: BoxDecoration(
                color: ThemeUtils().currentColorTheme.contentBG,
                border:
                    Border.all(color: ThemeUtils().currentColorTheme.contentBG),
                borderRadius: BorderRadius.circular(8),
              ),
              child: balanceTopView(
                model: model,
                onTap: () {
                  Navigator.pop(context);
                  getdate();
                },
              ),
            ),
            titletext,
            listView,
          ],
        )),
        // 头像与关注
        // Stack(
        //   // alignment: Alignment.centerLeft,
        //   children: <Widget>[avatar, topButtons],
        // ),
      ],
    );

    Widget ad = Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          colors: <Color>[
            Color(0xFF3A8EFF),
            Color(0xFF3A8EFF),
          ],
        ),
      ),
      child: Stack(alignment: Alignment.topCenter, children: <Widget>[
        Container(
          margin: EdgeInsets.only(top: 230),
          height: double.infinity,
          width: double.infinity,
          color: ThemeUtils().currentColorTheme.defaultColor,
        ),
        body,
      ]),
    );

    Widget allviebody = Scaffold(
      backgroundColor: ThemeUtils().currentColorTheme.defaultColor,
      body: showloading == true ? Container() : ad,
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: ThemeUtils().currentColorTheme.labelColorW, //修改颜色
        ),
        // 如果没有设置这项， 二级页面 会默认是返回箭头  ， 有侧边栏的页面默认有图标（用来打开侧边栏）
        // automaticallyImplyLeading: true,
        // 如果有 leading  这个不会管用 ； 如果没有leading ，当有侧边栏的时候， false：不会显示默认的图片，true 会显示 默认图片，并响应打开侧边栏的事件
        title: Text(S.current.YueBao),
        centerTitle: true,
        //  actions: <Widget>[
        //     IconButton(
        //         icon: Icon(Icons.add_alarm),
        //         tooltip: 'Add Alarm',
        //         onPressed: () {
        //           // do nothing
        //         })
        //   ],   // 标题是否在居中

        elevation: 0, // 导航栏Z轴的高度，默认是1  默认就是有高度 阴影的
        // backgroundColor: ThemeUtils().currentColorTheme.contentBG, // 导航栏的颜色  默认是 ThemeData 的颜色
//         flexibleSpace: FlexibleSpaceBar(title: Text("你号"),),//这个堆叠在工具栏上面  一般 appbar不用  主要用在 SliverAppBar上
//          brightness: Brightness.light, //状态栏的深度 有白色和黑色两种主题
//          titleSpacing: 10,//flexibleSpace 和 title 的距离  默认是重合的
//          toolbarOpacity: 0.5,// 导航栏透明度 默认是1 ，不包括flexibleSpace
//          bottomOpacity: 0.5,
      ),
    );
    return allviebody;
  }
}

class balanceTopView extends StatelessWidget {
  final String lumpSum;
  final String income;
  final String rate;
  final String yesterdaIncome;
  final YbalanceModel model;
  final Function onTap;

  const balanceTopView({
    Key key,
    this.lumpSum,
    this.income,
    this.rate,
    this.onTap,
    this.yesterdaIncome,
    this.model,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    //
    final mediaQueryData = MediaQuery.of(context);

// 2.获取宽度和高度
    final screenWidth = mediaQueryData.size.width;
    Widget titletext = Container(
      alignment: Alignment.center,
      // padding: EdgeInsets.fromLTRB(15, 2, 2, 2),
      height: 20,
      child: Text(
        S.current.ZJE,
        style: TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );

    Widget moneyText = Container(
      alignment: Alignment.center,
      // padding: EdgeInsets.fromLTRB(15, 2, 2, 2),
      height: 20,
      child: Text(
        model.member.balance.toString(),
        style: TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w900,
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
        ),
      ),
    );

    Widget yesterdaIncome = Container(
      alignment: Alignment.center,
      child: RichText(
          text: TextSpan(
        text: S.current.ZRSY,
        style: TextStyle(
            color: ThemeUtils().currentColorTheme.textGaryColor, fontSize: 12),
        children: [
          TextSpan(
            text: model.member.yesterdayIncome.toString(),
            style: TextStyle(color: Colors.red, fontSize: 12),
          ),
          TextSpan(
            text: '',
            style: TextStyle(
                color: ThemeUtils().currentColorTheme.textGaryColor,
                fontSize: 12),
          )
        ],
      )),
    );

    Widget leftView = Container(
      margin: EdgeInsets.fromLTRB(10, 5, 10, 5),
      // color: Colors.red,
      child: Column(
        children: [
          Container(
            alignment: Alignment.center,
            // padding: EdgeInsets.fromLTRB(15, 2, 2, 2),
            height: 20,
            child: Text(
              S.current.LJSY,
              style: TextStyle(
                fontSize: 15,
                // fontWeight: FontWeight.w900,
                color: ThemeUtils().currentColorTheme.textWithdrawColor,
              ),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Container(
            alignment: Alignment.center,
            // padding: EdgeInsets.fromLTRB(15, 2, 2, 2),
            height: 20,
            child: Text(
              model.member.totalIncome.toString(),
              style: TextStyle(
                fontSize: 15,
                // fontWeight: FontWeight.w900,
                color: ThemeUtils().currentColorTheme.textWithdrawColor,
              ),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          new SizedBox(
            child: InkWell(
              onTap: () {
                YYAlertDialogWithGravity(
                    width: screenWidth - 30,
                    gravity: Gravity.center,
                    inuput: 2,
                    tap: onTap);
              },
              child: new Container(
                  height: 44,
                  // padding: EdgeInsets.fromLTRB(15, 15, 15, 15),
                  // margin: EdgeInsets.fromLTRB(15, 5, 15, 5),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      // color: ThemeUtils().currentColorTheme.labelColorY,
                      // border: bo
                      border: Border.all(
                          color: ThemeUtils().currentColorTheme.labelColorY,
                          width: 1)),
                  alignment: Alignment.center,
                  child: Text(
                    S.current.ZC,
                    // textAlign: TextAlign.center,
                    style: TextStyle(
                        // letterSpacing: 20,
                        // fontWeight: FontWeight.bold,
                        color: ThemeUtils().currentColorTheme.labelColorY),
                  )),
            ),
          )
        ],
      ),
    );

    Widget rightView = Container(
      // color: Colors.yellow,
      margin: EdgeInsets.fromLTRB(10, 5, 10, 5),
      child: Column(
        children: [
          Container(
            alignment: Alignment.center,
            // padding: EdgeInsets.fromLTRB(15, 2, 2, 2),
            height: 20,
            child: Text(
              S.current.QRNH + '(%)',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w900,
                color: ThemeUtils().currentColorTheme.textWithdrawColor,
              ),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Container(
            alignment: Alignment.center,
            // padding: EdgeInsets.fromLTRB(15, 2, 2, 2),
            height: 20,
            child: Text(
              model.info.ratio.toString() + "%",
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w900,
                color: ThemeUtils().currentColorTheme.textWithdrawColor,
              ),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          new SizedBox(
              child: InkWell(
            onTap: () {
              YYAlertDialogWithGravity(
                  width: screenWidth - 30,
                  gravity: Gravity.center,
                  inuput: 1,
                  tap: onTap);
            },
            child: new Container(
                height: 44,
                //  padding: EdgeInsets.fromLTRB(15, 15, 15, 15),
                // margin: EdgeInsets.fromLTRB(15, 5, 15, 5),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  color: ThemeUtils().currentColorTheme.labelColorY,
                  // border: bo
                ),
                alignment: Alignment.center,
                child: Text(
                  S.current.ZR,
                  // textAlign: TextAlign.center,
                  style: TextStyle(
                      // letterSpacing: 20,
                      // fontWeight: FontWeight.bold,
                      color: Colors.white70),
                )),
          ))
        ],
      ),
    );

    Widget ontherview = Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      mainAxisSize: MainAxisSize.max,
      //交叉轴的布局方式，对于column来说就是水平方向的布局方式
      crossAxisAlignment: CrossAxisAlignment.center,
      //就是字child的垂直布局方向，向上还是向下
      verticalDirection: VerticalDirection.down,
      children: <Widget>[
        Expanded(flex: 1, child: leftView),
        Expanded(flex: 1, child: rightView)
      ],
    );
    Widget bodyview = Column(
      children: [
        SizedBox(
          height: 15,
        ),
        titletext,
        SizedBox(
          height: 5,
        ),
        moneyText,
        SizedBox(
          height: 11,
        ),
        yesterdaIncome,
        SizedBox(
          height: 11,
        ),
        ontherview
      ],
    );

    return Container(
      child: Container(
        height: 230,
        // margin: EdgeInsets.all(8),
        child: bodyview,
      ),
    );
  }
}

class yitemlistView extends StatelessWidget {
  final ListElement model;
  final Function onTap;
  const yitemlistView({
    Key key,
    this.onTap,
    this.model,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    var deviceData = MediaQuery.of(context); // 返回 MediaQueryData

    Widget toptext = Container(
      height: 21,
      width: 100,
      child: Text(
        S.current.DSY,
        overflow: TextOverflow.ellipsis,
        maxLines: 1,
        style: TextStyle(color: Color(0xFFE5EAF4), fontSize: 15),
        textAlign: TextAlign.left,
      ),
    );
    var Time = DateTime.fromMillisecondsSinceEpoch(model.createTime * 1000);
    var aTime = Time.toLocal().toString().substring(0, 16);
    Widget bottomtext = Container(
      height: 15,
      width: 100,
      child: Text(
        aTime.toString(),
        overflow: TextOverflow.ellipsis,
        maxLines: 1,
        style: TextStyle(
          color: Color(0xFF8898B3),
          fontSize: 12,
        ),
      ),
    );

    ;
    Widget textView = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        SizedBox(
          height: 5,
        ),
        toptext,
        SizedBox(
          height: 5,
        ),
        bottomtext,
        // SizedBox(
        //   height: 12,
        // ),
      ],
    );

    Widget rtoptext = Container(
      height: 21,
      width: 100,
      child: Text(
        model.income.toString(),
        overflow: TextOverflow.ellipsis,
        maxLines: 1,
        style: TextStyle(color: Color(0xFFE5EAF4), fontSize: 15),
        textAlign: TextAlign.right,
      ),
    );
    Widget rbottomtext = Container(
      height: 15,
      width: 100,
      child: Text(
        model.balance.toString(),
        overflow: TextOverflow.ellipsis,
        maxLines: 1,
        textAlign: TextAlign.right,
        style: TextStyle(
          color: Color(0xFF8898B3),
          fontSize: 12,
        ),
      ),
    );

    ;
    Widget rtextView = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        SizedBox(
          height: 5,
        ),
        rtoptext,
        SizedBox(
          height: 5,
        ),
        rbottomtext,
        // SizedBox(
        //   height: 12,
        // ),
      ],
    );

    Widget body = Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[
        textView,
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        rtextView,
      ],
    );

    return Center(
      child: Container(
        padding: EdgeInsets.only(left: 10, right: 10),

        height: 50,
        child: body,
        color: ThemeUtils().currentColorTheme.contentBG,
        // color: Colors.red,
      ),
    );
  }
}

YYDialog YYAlertDialogWithGravity(
    {width, gravity, doubleButtonGravity, tap, inuput}) {
  YYDialog yyDialog = YYDialog().build()
    ..width = width
    ..gravity = gravity
    ..gravityAnimationEnable = true
    ..borderRadius = 4.0
    ..barrierDismissible = false
    ..widget(textContextView(
      tap: tap,
      input: inuput,
    ))
    ..backgroundColor = ThemeUtils().currentColorTheme.contentBG

    // ..doubleButton(
    //   padding: EdgeInsets.only(top: 20.0),
    //   gravity: doubleButtonGravity ?? Gravity.right,
    //   text1: "DISAGREE",
    //   color1: Colors.deepPurpleAccent,
    //   fontSize1: 14.0,
    //   text2: "AGREE",
    //   color2: Colors.deepPurpleAccent,
    //   fontSize2: 14.0,
    // )
    ..show();
  return yyDialog;
}

class textContextView extends StatelessWidget {
  final String title;
  final String price;
  final String increase;
  final String onther;
  final int input;
  final Function tap;
  const textContextView({
    Key key,
    this.title,
    this.price,
    this.increase,
    this.onther,
    this.tap,
    this.input,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final passwordCtrl = TextEditingController(text: '');
    var leftIconContainer = InkWell(
        // margin: EdgeInsets.all(6),
        // alignment: Alignment.centerRight,
        onTap: () {
          tap();
        },
        child: Container(
          alignment: Alignment.centerRight,
          child: Image.asset(
            "images/wode/gunabi@3x.png",
            width: 15,
            height: 15,
          ),
        ));
    // Widget titletext = Container(
    //   alignment: Alignment.center,
    //   child: Text(
    //     '欧元美元',
    //     style: TextStyle(
    //       fontSize: 16,
    //       fontWeight: FontWeight.w900,
    //       color: ThemeUtils().currentColorTheme.labelColorW,
    //     ),
    //   ),
    // );

    Widget inpuBank = Container(
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5),
            // color: ThemeUtils().currentColorTheme.labelColorY,
            // border: bo
            border: Border.all(
                color: ThemeUtils().currentColorTheme.labelColorW, width: 1)),
        child: inpuBankNumberWiget(
          title: S.current.QSRJR,
          hight: 40,
          Controller: passwordCtrl,
          type: TextInputType.number,
        ));

    void get_product_optional() async {
      Map<String, dynamic> params = {};

      // params["code"] = widget.model.code;
      String username = passwordCtrl.text.trim();
      params["amount"] = double.parse(username);
      params["type"] = input;

      ResultData resultData = await AppApi.getInstance()
          .post_invest_transfer(context, true, params);
      if (resultData.isSuccess()) {
        Constants.eventBus.fire(LoginEvent());
        tap();
      } else {
        JCHub.showmsg(resultData.msg, context);
      }
    }

    var PositionBtn = Builder(builder: (ctx) {
      return CommonButton(
          text: S.current.submit,
          color: ThemeUtils().currentColorTheme.labelColorY,
          onTap: () {
            Map<String, dynamic> params = {};

            // if (ncountry != null) {
            String username = passwordCtrl.text.trim();
            if (username.length == 0) {
              return;
            }
            get_product_optional();

            // 关闭键盘
            FocusScope.of(context).requestFocus(FocusNode());
          });
    });

    Widget bview = Column(
      children: <Widget>[
        SizedBox(
          height: 20,
        ),
        leftIconContainer,
        SizedBox(
          height: 5,
        ),
        inpuBank,
        SizedBox(
          height: 10,
        ),
        PositionBtn,
        // SizedBox(
        //   height: 5,
        // ),
        // PositionBtn
      ],
    );

    return Container(
        height: 180,
        // padding: EdgeInsets.fromLTRB(40, 16, 30, 40),
        child: bview);
  }
}

class inpuBankNumberWiget extends StatelessWidget {
  final String title;
  final TextInputType type;
  final int hight;
  final TextEditingController Controller;

  final bool ishow;

  const inpuBankNumberWiget(
      {Key key,
      this.title,
      this.hight,
      this.Controller,
      this.ishow = false,
      this.type = TextInputType.text})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    int he = hight;
    if (he == null) {
      he = 50;
    }

    return Container(
      child: Container(
        padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
        margin: EdgeInsets.fromLTRB(15, 5, 15, 5),
        color: ThemeUtils().currentColorTheme.contentBG,
        height: 50,
        child: new SizedBox(
          child: new Container(
            height: he.toDouble(),
            color: ThemeUtils().currentColorTheme.contentBG,
            alignment: Alignment.center,
            child: TextField(
              obscureText: ishow,
              keyboardType: type,
              maxLines: 1,
              controller: Controller,
              decoration: InputDecoration(
                hintText: title,
                border: InputBorder.none,
                hintStyle: TextStyle(
                  fontSize: 12,
                  color: ThemeUtils().currentColorTheme.textGaryColor,
                ),
              ),
              style: TextStyle(
                fontSize: 12,
                color: ThemeUtils().currentColorTheme.textWithdrawColor,
              ),
            ),
          ),
        ),
      ),
    );
    // TODO: implement build
  }
}
