import 'package:flutter/material.dart';
import 'package:heibai/util/ThemeUtils.dart';
// TODO Implement this library.
import 'package:heibai/pages/WhomePageList.dart';
import 'package:tapped/tapped.dart';

class TopIconTextButton extends StatelessWidget {
  final Image icon;

  final String title;
  final Function onTap;

  const TopIconTextButton({
    Key key,
    this.icon,
    this.title,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var iconContainer = Container(
      margin: EdgeInsets.all(6),
      height: 22,
      width: 22,
      // decoration: BoxDecoration(
      //   color: ThemeUtils().currentColorTheme.labelColorW,
      //   borderRadius: BorderRadius.circular(2),
      //   gradient: LinearGradient(
      //     begin: Alignment.topLeft,
      //     end: Alignment.bottomCenter,
      //     colors: [
      //       color2,
      //       color!,
      //     ],
      //     stops: [0.1, 0.8],
      //   ),
      // ),
      child: icon,
    );
    Widget body = Column(
      children: <Widget>[
        iconContainer,
        Text(
          title,
          style: TextStyle(
            fontWeight: FontWeight.normal,
            fontSize: SysSize.small,
            color: ThemeUtils().currentColorTheme.labelColorW,
            inherit: true,
          ),
        )
      ],
    );
    body = Tapped(
      child: body,
      onTap: onTap,
    );
    return Expanded(
      child: Container(
        margin: EdgeInsets.all(8),
        child: body,
      ),
    );
  }
}
