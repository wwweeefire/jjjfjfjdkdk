import 'package:flutter/material.dart';
import 'package:heibai/util/ThemeUtils.dart';
// TODO Implement this library.
import 'package:heibai/pages/WhomePageList.dart';
import 'package:tapped/tapped.dart';

class iconTextIcon extends StatelessWidget {
  final Widget icon;
  final Image rightImage;
  final String title;
  final Function onTap;

  const iconTextIcon({
    Key key,
    this.icon,
    this.title,
    this.onTap,
    this.rightImage,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var iconContainer = Container(
      // margin: EdgeInsets.all(),
      height: 20,
      width: 20,
      // decoration: BoxDecoration(
      //   color: ThemeUtils().currentColorTheme.labelColorW,
      //   borderRadius: BorderRadius.circular(2),
      //   gradient: LinearGradient(
      //     begin: Alignment.topLeft,
      //     end: Alignment.bottomCenter,
      //     colors: [
      //       color2,
      //       color!,
      //     ],
      //     stops: [0.1, 0.8],
      //   ),
      // ),
      child: icon,
    );

    var leftIconContainer = Container(
      // margin: EdgeInsets.all(6),
      height: 13,
      width: 19,
      // decoration: BoxDecoration(
      //   color: ThemeUtils().currentColorTheme.labelColorW,
      //   borderRadius: BorderRadius.circular(2),
      //   gradient: LinearGradient(
      //     begin: Alignment.topLeft,
      //     end: Alignment.bottomCenter,
      //     colors: [
      //       color2,
      //       color!,
      //     ],
      //     stops: [0.1, 0.8],
      //   ),
      // ),
      child: rightImage,
    );

    Widget body = Row(
      children: [
        iconContainer,
        Container(
          alignment: Alignment.center,
          padding: EdgeInsets.only(left: 10),
          // height: 20,
          child: Text(
            title,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: ThemeUtils().currentColorTheme.dateGaryColor,
            ),
          ),
        ),
        Expanded(
          child: Text(''), // 中间用Expanded控件
        ),
        leftIconContainer,
      ],
    );

    body = Tapped(
      child: body,
      onTap: onTap,
    );
    return Container(
      child: Container(
        padding: EdgeInsets.all(12),
        margin: EdgeInsets.fromLTRB(15, 5, 15, 5),
        color: ThemeUtils().currentColorTheme.contentBG,
        height: 44,
        child: body,
      ),
    );
  }
}
