import 'package:heibai/Classes/style.dart';
import 'package:heibai/util/ThemeUtils.dart';
import 'package:flutter/material.dart';
import 'package:tapped/tapped.dart';

class UserMsgRow extends StatelessWidget {
  final String title;
  final String price;
  final String increase;

  const UserMsgRow({
    Key key,
    this.title,
    this.price,
    this.increase,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var list = <Widget>[
      Flex(
        direction: Axis.horizontal,
        children: <Widget>[
          Expanded(
            flex: 5,
            child: Container(
              // padding: EdgeInsets.zero,
              height: 45,
              // color: Colors.red,
              margin: EdgeInsets.symmetric(horizontal: 15, vertical: 0),
              alignment: Alignment.centerLeft,
              child: Text(
                title ?? '活动哈哈哈哈哈哈',
                maxLines: 1,
                style: TextStyle(
                  color: ThemeUtils().currentColorTheme.textWithdDDrawColor,
                  fontSize: 14,
                ),
                textAlign: TextAlign.left,
              ),
            ),
          ),
          Expanded(
            flex: 4,
            child: Container(
              // padding: EdgeInsets.zero,
              height: 45,
              alignment: Alignment.centerLeft,
              // color: Colors.yellow,
              child: Text(
                price ?? '1000000',
                maxLines: 1,
                style: TextStyle(
                  color: ThemeUtils().currentColorTheme.textWithdDDrawColor,
                  fontSize: 14,
                ),
                textAlign: TextAlign.left,
              ),
            ),
          ),
          Expanded(
            flex: 3,
            child: Container(
              alignment: Alignment.center,
              // padding: EdgeInsets.zero,
              height: 45,

              child: Text(
                increase + "%" ?? '+150%',
                maxLines: 1,
                style: TextStyle(
                  color: double.parse(increase) > 0
                      ? ThemeUtils().currentColorTheme.numberRedColor
                      : ThemeUtils().currentColorTheme.textgreenColor,
                  fontSize: 14,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ),
        ],
      ),
    ];
    var info = Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: list,
    );

    return Container(
      child: Container(
        // padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        child: Row(
          children: <Widget>[
            Expanded(child: info),
          ],
        ),
      ),
    );
  }
}

class TitleMsgRow extends StatelessWidget {
  final String title;
  final String price;
  final String increase;

  const TitleMsgRow({
    Key key,
    this.title,
    this.price,
    this.increase,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var list = <Widget>[
      Flex(
        direction: Axis.horizontal,
        children: <Widget>[
          Expanded(
            flex: 5,
            child: Container(
              // padding: EdgeInsets.zero,
              height: 30,
              // color: Colors.red,
              margin: EdgeInsets.symmetric(horizontal: 15, vertical: 0),
              alignment: Alignment.centerLeft,
              child: Text(
                title ?? '商品名称',
                style: TextStyle(
                  color: ThemeUtils().currentColorTheme.dateGaryColor,
                  fontSize: 12,
                ),
                textAlign: TextAlign.left,
              ),
            ),
          ),
          Expanded(
            flex: 4,
            child: Container(
              // padding: EdgeInsets.zero,
              height: 30,
              alignment: Alignment.centerLeft,
              // color: Colors.yellow,
              child: Text(
                price ?? '最新净值',
                style: TextStyle(
                  color: ThemeUtils().currentColorTheme.dateGaryColor,
                  fontSize: 12,
                ),
                textAlign: TextAlign.left,
              ),
            ),
          ),
          Expanded(
            flex: 3,
            child: Container(
              alignment: Alignment.center,
              // padding: EdgeInsets.zero,
              height: 30,

              child: Text(
                increase ?? '跌涨幅',
                style: TextStyle(
                  color: ThemeUtils().currentColorTheme.dateGaryColor,
                  fontSize: 12,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ),
        ],
      ),
    ];
    var info = Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: list,
    );

    return Container(
      child: Container(
        // padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        child: Row(
          children: <Widget>[
            Expanded(child: info),
          ],
        ),
      ),
    );
  }
}

class ItmeRow extends StatelessWidget {
  final String title;
  final String price;
  final String increase;
  final String onther;
  final Function onTap;
  const ItmeRow(
      {Key key, this.title, this.price, this.increase, this.onther, this.onTap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    var list = <Widget>[
      Flex(
        direction: Axis.horizontal,
        children: <Widget>[
          Expanded(
            flex: 5,
            child: Container(
              // padding: EdgeInsets.zero,
              height: 45,
              // color: Colors.red,
              margin: EdgeInsets.symmetric(horizontal: 15, vertical: 0),
              alignment: Alignment.centerLeft,
              child: Text(
                title ?? '活动哈',
                style: TextStyle(
                  color: ThemeUtils().currentColorTheme.textWithdDDrawColor,
                  fontSize: 14,
                ),
                textAlign: TextAlign.left,
              ),
            ),
          ),
          Expanded(
            flex: 4,
            child: Container(
              // padding: EdgeInsets.zero,
              height: 45,
              alignment: Alignment.centerLeft,
              // color: Colors.yellow,
              child: Text(
                price ?? '1000000',
                style: TextStyle(
                  color: ThemeUtils().currentColorTheme.textWithdDDrawColor,
                  fontSize: 14,
                ),
                textAlign: TextAlign.left,
              ),
            ),
          ),
          Expanded(
            flex: 4,
            child: Container(
              alignment: Alignment.centerLeft,
              height: 45,
              child: Text(
                increase ?? '+150%',
                style: TextStyle(
                  color: ThemeUtils().currentColorTheme.textWithdDDrawColor,
                  fontSize: 14,
                ),
                textAlign: TextAlign.left,
              ),
            ),
          ),
          Expanded(
            flex: 3,
            child: Container(
              alignment: Alignment.centerRight,
              // padding: EdgeInsets.zero,
              padding: EdgeInsets.only(right: 15),
              height: 45,

              child: Text(
                onther ?? '明细',
                style: TextStyle(
                  color: ThemeUtils().currentColorTheme.textWithdDDrawColor,
                  fontSize: 14,
                ),
                textAlign: TextAlign.right,
              ),
            ),
          ),
        ],
      ),
    ];
    var info = Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: list,
    );
    var body = Tapped(
      child: Container(
        // padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        child: Row(
          children: <Widget>[
            Expanded(child: info),
          ],
        ),
      ),
      onTap: onTap,
    );
    return Container(
      child: body,
    );
  }
}

class ItemTitleRow extends StatelessWidget {
  final String title;
  final String price;
  final String increase;
  final String onther;
  const ItemTitleRow({
    Key key,
    this.title,
    this.price,
    this.increase,
    this.onther,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var list = <Widget>[
      Flex(
        direction: Axis.horizontal,
        children: <Widget>[
          Expanded(
            flex: 5,
            child: Container(
              // padding: EdgeInsets.zero,
              height: 30,
              // color: Colors.red,
              margin: EdgeInsets.symmetric(horizontal: 15, vertical: 0),
              alignment: Alignment.centerLeft,
              child: Text(
                title ?? '商品名称',
                style: TextStyle(
                  color: ThemeUtils().currentColorTheme.dateGaryColor,
                  fontSize: 12,
                ),
                textAlign: TextAlign.left,
              ),
            ),
          ),
          Expanded(
            flex: 4,
            child: Container(
              // padding: EdgeInsets.zero,
              height: 30,
              alignment: Alignment.centerLeft,
              // color: Colors.yellow,
              child: Text(
                price ?? '最新净值',
                style: TextStyle(
                  color: ThemeUtils().currentColorTheme.dateGaryColor,
                  fontSize: 12,
                ),
                textAlign: TextAlign.left,
              ),
            ),
          ),
          Expanded(
            flex: 4,
            child: Container(
              // padding: EdgeInsets.zero,
              height: 30,
              alignment: Alignment.centerLeft,
              // color: Colors.yellow,
              child: Text(
                onther ?? '最新净值',
                style: TextStyle(
                  color: ThemeUtils().currentColorTheme.dateGaryColor,
                  fontSize: 12,
                ),
                textAlign: TextAlign.left,
              ),
            ),
          ),
          Expanded(
            flex: 3,
            child: Container(
              alignment: Alignment.center,
              // padding: EdgeInsets.zero,
              height: 30,

              child: Text(
                increase ?? '跌涨幅',
                style: TextStyle(
                  color: ThemeUtils().currentColorTheme.dateGaryColor,
                  fontSize: 12,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ),
        ],
      ),
    ];
    var info = Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: list,
    );

    return Container(
      child: Container(
        // padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        child: Row(
          children: <Widget>[
            Expanded(child: info),
          ],
        ),
      ),
    );
  }
}
