import 'package:flutter/material.dart';
import 'package:heibai/util/baseThemeData.dart';

class defaultThemeData extends baseThemeData {
// 默认主题色
  List<Color> kminetopColor = <Color>[
    Color(0xFFFCD535),
    Color(0xFFFCD535),
  ];
  Color defaultColor = const Color(0xFF0B0E10);
  Color kminenavColor = const Color(0xFFFCD535);

  // // 可选的主题色
  //  List<Color> supportColors = [defaultColor];

  // 当前的主题色
  Color currentColorTheme = const Color(0xFF0B0E10);

  Color tabbarColor = const Color(0xFF232C3D);
  Color tabbarSColor = const Color(0xFFFCD535);

// 字体黄色
  Color labelColorY = const Color(0xFFF0B90B);
//字体白色
  Color labelColorW = const Color(0xFFFFFFFF);
  // 字体灰色
  Color labelColorG = const Color(0xFF999999);
  //view颜色
  Color contentBG = const Color(0xFF181A20);

  Color viewgaryBG = const Color(0xFF2B3139);

//我的界面的字体
  Color nameLabelTextColor = const Color(0xFFF9F2F2);
  Color integralLabelTextColor = const Color(0xFFF3E6E6);

  // 涨跌
  Color textgreenColor = const Color(0xFF0ECB81);

  Color numberRedColor = const Color(0xFFF6465D);

  Color textRedColor = const Color(0xFFF6465D);
  Color dateGaryColor = const Color(0xFF848E9C);
  Color textGaryColor = const Color(0xFFB7BDC6);
  Color textWithdrawColor = const Color(0xFFEAECEF);

  Color textWithdDDrawColor = const Color(0xFF8898B3);
  Color textWithdkkkwColor = const Color(0xFFE5EAF4);
  Color lineColor = const Color(0xFF2B3139);
}
