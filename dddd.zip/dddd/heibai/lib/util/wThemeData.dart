import 'package:flutter/material.dart';
import 'package:heibai/util/baseThemeData.dart';

class wThemeData extends baseThemeData {
  Color defaultColor = const Color(0xFFF5F5F5);
  Color kminenavColor = const Color(0xFFFCD535);
  // 可选的主题色
  //  List<Color> supportColors = [defaultColor];

  // 当前的主题色
  Color currentColorTheme = const Color(0xFFF5F5F5);

  Color tabbarColor = const Color(0xFFFFFFFF);
  Color tabbarSColor = const Color(0xFFFCD535);

// 字体黄色
  Color labelColorY = const Color(0xFFF0B90B);
//字体白色
  Color labelColorW = const Color(0xFF333333);
  // 字体灰色
  Color labelColorG = const Color(0xFF333333);
  //view颜色
  Color contentBG = const Color(0xFFFFFFFF);

  Color viewgaryBG = const Color(0xFFF5F5F5);

//我的界面的字体
  Color nameLabelTextColor = const Color(0xFF333333);
  Color integralLabelTextColor = const Color(0xFF333333);

  // 涨跌
  Color textgreenColor = const Color(0xFF0ECB81);

  Color numberRedColor = const Color(0xFFF6465D);

  Color textRedColor = const Color(0xFFF6465D);
  Color dateGaryColor = const Color(0xFF848E9C);
  Color textGaryColor = const Color(0xFF333333);
  Color textWithdrawColor = const Color(0xFF333333);
  Color textWithdDDrawColor = const Color(0xFF333333);
  Color textWithdkkkwColor = const Color(0xFF333333);

  Color lineColor = const Color(0xFFECECEC);

  // Color lineColor = const Color(0xFFECECEC);
  Text sText(String) {
    return Text(
      String,
      style: TextStyle(color: textWithdrawColor, fontSize: 15),
    );
  }
}
