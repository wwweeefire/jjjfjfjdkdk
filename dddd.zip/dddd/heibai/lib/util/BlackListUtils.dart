
import 'dart:async';

// 黑名单工具类，用于在本地操作黑名单
class BlackListUtils {
  static final String spBlackList = "blackList";

  // 将对象数组转化为整型数组
  static List<int> convert(List objList) {
    if (objList == null || objList.isEmpty) {
      // ignore: deprecated_member_use
      return <int>[];
    }
    List<int> intList = [];
    for (var obj in objList) {
      intList.add(obj['authorid']);
    }
    return intList;
  }

  // 字符串转化为整型数组
  static List<int> _str2intList(String str) {
    if (str != null && str.length > 0) {
      List<String> list = str.split(",");
      if (list != null && list.isNotEmpty) {
        List<int> intList = [];
        for (String s in list) {
          intList.add(int.parse(s));
        }
        return intList;
      }
    }
    return null;
  }

  // 整型数组转化为字符串
  static String _intList2Str(List<int> list) {
    if (list == null || list.isEmpty) {
      return null;
    }
    StringBuffer sb = StringBuffer();
    for (int id in list) {
      sb.write("$id,");
    }
    String result = sb.toString();
    return result.substring(0, result.length - 1);
  }

  
}
