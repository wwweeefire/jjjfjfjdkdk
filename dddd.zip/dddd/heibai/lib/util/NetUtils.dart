// ignore_for_file: unnecessary_string_interpolations
library basicnetservice;

import "package:http/http.dart" as http;

import 'package:flutter/services.dart' show rootBundle;
export 'package:heibai/net/service/net_service.dart';
import 'dart:io';
import 'package:heibai/net/api/Api.dart';
import 'package:flutter/widgets.dart';
// import 'package:heibai/net/service/net_service.dart';
import 'package:heibai/net/service/net_service.dart';

import 'package:heibai/net/widget/dialog_param.dart';
import 'package:heibai/net/widget/loading_dialog.dart';

// export 'result_data.dart';
import 'dart:convert';

import 'dart:io';

import 'package:dio/dio.dart';
import 'package:heibai/net/api/net_config.dart';
// import 'result_data.dart';
// import 'dio_instance.dart';
import 'package:flutter/material.dart';
import 'package:http_parser/http_parser.dart';

// import 'app_net_service.dart';

// import 'app_net_service.dart';
class NetUtils {
// Future<List<Anchor>> getAnchors() async {
//     //1. 读取json文件
//     String jsonString = await rootBundle.loadString("assets/test.json");

//     //2.转成List或Map类型
//     final jsonResult = json.decode(jsonString);

//     //遍历List，并且转成Anchor对象放到另一个List中
//     List<Anchor> anchors = new List();
//     for(Map<String,dynamic> map in jsonResult) {
//       anchors.add(Anchor.withMap(map));
//     }

//     return anchors;
//   }

  Future<Anchor> getAnchors() async {
    ;

    //遍历List，并且转成Anchor对象放到另一个List中
  }

  static Future<String> get(String url, {Map<String, String> params}) async {
    if (params != null && params.isNotEmpty) {
      // 如果参数不为空，则将参数拼接到URL后面
      StringBuffer sb = StringBuffer("?");
      params.forEach((key, value) {
        sb.write("$key" + "=" + "$value" + "&");
      });
      String paramStr = sb.toString();
      paramStr = paramStr.substring(0, paramStr.length - 1);
      url += paramStr;
    }
    http.Response res = await http.get(
      Uri.parse(url),
    );
    return res.body;
  }

  // post请求
  static Future<String> post(String url, {Map<String, String> params}) async {
    http.Response res = await http.post(Uri.parse(url), body: params);
    return res.body;
  }
}

class Anchor {
  List domain;

  Anchor({
    this.domain,
  });

  Anchor.withMap(Map<String, dynamic> parseMap) {
    this.domain = parseMap["domain"];
  }

  // @override
  // String toString() {
  //   return "$nickName - $roomName : $imageUrl";
  // }
}
