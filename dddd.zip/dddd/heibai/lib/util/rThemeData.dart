import 'package:flutter/material.dart';
import 'package:heibai/util/baseThemeData.dart';

class rThemeData extends baseThemeData {
  List<Color> kminetopColor = <Color>[
    Color(0xFFFD3E83),
    Color(0xFFFD3E83),
  ];
  Color defaultColor = const Color(0xFFF5F5F5);

  //  List<Color> supportColors = [defaultColor];

  Color kminenavColor = const Color(0xFFFD3E83);
  // 当前的主题色
  Color currentColorTheme = Color(0xFFF5F5F5);

  Color tabbarColor = const Color(0xFFFFFFFF);
  Color tabbarSColor = const Color(0xFFFD3E83);

// 字体黄色
  Color labelColorY = const Color(0xFFF02B2B);
//字体白色
  Color labelColorW = const Color(0xFF333333);
  // 字体灰色
  Color labelColorG = const Color(0xFF333333);
  //view颜色
  Color contentBG = const Color(0xFFFFFFFF);

  Color viewgaryBG = const Color(0xFFF5F5F5);

//我的界面的字体
  Color nameLabelTextColor = const Color(0xFF333333);
  Color integralLabelTextColor = const Color(0xFF333333);

  // 涨跌
  Color textgreenColor = const Color(0xFF0ECB81);

  Color numberRedColor = const Color(0xFFF6465D);

  Color textRedColor = const Color(0xFFF6465D);
  Color dateGaryColor = const Color(0xFF848E9C);
  Color textGaryColor = const Color(0xFF333333);
  Color textWithdrawColor = const Color(0xFF333333);
  Color textWithdDDrawColor = const Color(0xFF333333);
  Color textWithdkkkwColor = const Color(0xFF333333);

  Color lineColor = const Color(0xFFECECEC);
}
