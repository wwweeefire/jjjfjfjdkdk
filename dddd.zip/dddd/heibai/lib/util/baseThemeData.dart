import 'package:flutter/material.dart';

class baseThemeData {
  List<Color> kminetopColor = <Color>[
    Color(0xFFFCD535),
    Color(0xFFFCD535),
  ];
  Color defaultColor;
  Color kminenavColor;

  // // 可选的主题色
  //  List<Color> supportColors = [defaultColor];

  // 当前的主题色
  Color currentColorTheme;

  Color tabbarColor;
  Color tabbarSColor;

// 字体黄色
  Color labelColorY;
//字体白色
  Color labelColorW;
  // 字体灰色
  Color labelColorG;
  //view颜色
  Color contentBG;

  Color viewgaryBG;

//我的界面的字体
  Color nameLabelTextColor;
  Color integralLabelTextColor;

  // 涨跌
  Color textgreenColor;

  Color numberRedColor;

  Color textRedColor;
  Color dateGaryColor;
  Color textGaryColor;
  Color textWithdrawColor;

  Color textWithdDDrawColor;
  Color textWithdkkkwColor;
  Color lineColor;
}
