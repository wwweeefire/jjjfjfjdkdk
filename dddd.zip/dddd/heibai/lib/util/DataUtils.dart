// ignore: file_names, import_of_legacy_library_into_null_safe
// ignore_for_file: constant_identifier_names, import_of_legacy_library_into_null_safe

import 'package:shared_preferences/shared_preferences.dart';
import 'dart:async';
import '../Classes/model/UserInfo.dart';
import 'package:heibai/Classes/model/config.dart';
import 'package:heibai/util/ThemeUtils.dart';

class DataUtils {
  // ignore: constant_identifier_names
  // static const String SP_AC_TOKEN = "accessToken";
  // // ignore: constant_identifier_names
  // static const String SP_RE_TOKEN = "refreshToken";
  static const String SP_UID = "uid";
  static const String SP_AC_TOKEN = "accessToken";
  // static const String SP_IS_LOGIN = "isLogin";
  // static const String SP_EXPIRES_IN = "expiresIn";
  // static const String SP_TOKEN_TYPE = "tokenType";

  // static const String SP_USER_NAME = "name";
  // static const String SP_USER_ID = "id";
  // static const String SP_USER_LOC = "location";
  // static const String SP_USER_GENDER = "gender";
  // static const String SP_USER_AVATAR = "avatar";
  // static const String SP_USER_EMAIL = "email";
  // static const String SP_USER_URL = "url";
  static const String SP_IS_LOGIN = "isLogin";
  static const String SP_COLOR_THEME_INDEX = "colorThemeIndex";

  static const String SP_SEARCH = "SP_SEARCH";

  static const String SPchangeLanguage = "SPchangeLanguage";

  static const String SPchangeTheme = "SPchangeTheme";

  static const String SPHost = "SPHost";

  static get avatar => null;

  static SharedPreferences preferences;

  static Future<void> getSharedPreferences() async {
    if (preferences == null) {
      preferences = await SharedPreferences.getInstance();
    } else {
      return;
    }
  }

  // 清除登录信息
  static clearLoginInfo() async {
    SharedPreferences sp = await SharedPreferences.getInstance();
    await sp.setString(SP_UID, "");
    await sp.setBool(SP_IS_LOGIN, false);
    await sp.setString(SP_AC_TOKEN, "");
    ConfigManager().user = UserInfo();
  }

  // 保存用户个人信息
  static Future<UserInfo> saveUserInfo(String data) async {
    if (data != null) {
      SharedPreferences sp = await SharedPreferences.getInstance();

      await sp.setString(SP_UID, data);
      await sp.setBool(SP_IS_LOGIN, true);

      UserInfo userInfo = userInfoFromJson(data);
      String accessToken = userInfo.token;
      await sp.setString(SP_AC_TOKEN, accessToken);
      ConfigManager().user = userInfo;
      return userInfo;
    } else {
      ConfigManager().user = UserInfo();
    }

    return null;
  }

  // 获取用户信息
  static Future<UserInfo> getUserInfo() async {
    SharedPreferences sp = await SharedPreferences.getInstance();

    bool isLogin = await sp.getBool(SP_IS_LOGIN);
    if (isLogin == null || !isLogin) {
      return null;
    }
    String name = sp.getString(SP_UID);

    UserInfo userInfo = userInfoFromJson(name);
    ConfigManager().user = userInfo;

    return userInfo;
  }

  // 是否登录
  static Future<bool> isLogin() async {
    SharedPreferences sp = await SharedPreferences.getInstance();
    bool b = sp.getBool(SP_IS_LOGIN);
    return b != null && b;
  }

  // 获取accesstoken
  static Future<String> getAccessToken() async {
    SharedPreferences sp = await SharedPreferences.getInstance();
    return sp.getString(SP_AC_TOKEN);
  }

  // 设置选择的主题色
  static setColorTheme(int colorThemeIndex) async {
    SharedPreferences sp = await SharedPreferences.getInstance();
    sp.setInt(SP_COLOR_THEME_INDEX, colorThemeIndex);
  }

  static Future<int> getColorThemeIndex() async {
    SharedPreferences sp = await SharedPreferences.getInstance();
    return sp.getInt(SP_COLOR_THEME_INDEX);
  }

  static setsearch(List<String> hisArray) async {
    SharedPreferences sp = await SharedPreferences.getInstance();
    // sp.setInt(SP_COLOR_THEME_INDEX, colorThemeIndex);

    sp.setStringList(SP_SEARCH, hisArray);
  }

  static Future<List<String>> getsearch() async {
    SharedPreferences sp = await SharedPreferences.getInstance();
    return sp.getStringList(SP_SEARCH);
  }

  static changeLanguage(String hisArray) async {
    SharedPreferences sp = await DataUtils.preferences;
    // sp.setInt(SP_COLOR_THEME_INDEX, colorThemeIndex);
    sp.setString(SPchangeLanguage, hisArray);
  }

  static Future<String> getchangeLanguage() async {
    SharedPreferences sp = await DataUtils.preferences;

    sp ??= await SharedPreferences.getInstance();

    String df = sp.getString(SPchangeLanguage);
    if (df == null) {
      df = "zh";
      DataUtils.changeLanguage(df);
      ConfigManager().code = df;
    }
    return df;
  }

  static changehost(String hisArray) async {
    SharedPreferences sp = await DataUtils.preferences;
    // sp.setInt(SP_COLOR_THEME_INDEX, colorThemeIndex);
    sp.setString(SPHost, hisArray);
  }

  static Future<String> getchangehost() async {
    SharedPreferences sp = await DataUtils.preferences;

    sp ??= await SharedPreferences.getInstance();

    String df = sp.getString(SPHost);
    if (df == null) {}
    return df;
  }

  static changetheme(String hisArray) async {
    SharedPreferences sp = await DataUtils.preferences;
    // sp.setInt(SP_COLOR_THEME_INDEX, colorThemeIndex);
    sp.setString(SPchangeTheme, hisArray);

    int a = ThemeUtilsString.supportSting.indexOf(hisArray);
    ThemeUtils().currentColorTheme = ThemeUtils.supportColors[a];
  }

  static Future<String> getchangetheme() async {
    SharedPreferences sp = await DataUtils.preferences;

    sp ??= await SharedPreferences.getInstance();

    String df = sp.getString(SPchangeTheme);
    if (df == null) {
      df = ThemeUtilsString.supportSting[0];
      DataUtils.changetheme(df);
      ThemeUtils().currentColorTheme = ThemeUtils.supportColors[0];
    } else {
      int a = ThemeUtilsString.supportSting.indexOf(df);
      ThemeUtils().currentColorTheme = ThemeUtils.supportColors[a];
    }
    return df;
  }

  /// hideNumber
  // static String hideNumber(
  //   String phoneNo,
  // ) {
  //   int start = 4;
  //   int end = 7;
  //   if (phoneNo.length > 4) {
  //     end = phoneNo.length - 4;
  //   }
  //   String replacement = '****';
  //   return phoneNo.replaceRange(start, end, replacement);
  // }

  // static String hidephoneNumber(String phoneNo,
  //     {int start = 4, int end = 6, String replacement = '****'}) {
  //   return phoneNo.replaceRange(start, end, replacement);
  // }

  static String getLanguage() {
    String userInfo =
        DataUtils.preferences.getString(DataUtils.SPchangeLanguage);
    if (userInfo == "zh") {
      return "中文";
    } else if (userInfo == "en") {
      return "English";
    } else if (userInfo == "zh_hk") {
      return "繁体字";
    }
  }
}
