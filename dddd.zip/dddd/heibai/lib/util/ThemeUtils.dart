import 'package:flutter/material.dart';
import 'package:heibai/util/baseThemeData.dart';
import 'package:heibai/util/defaultThemeData.dart';

import 'package:heibai/util/gThemeData.dart';

import 'package:heibai/util/rThemeData.dart';
import 'package:heibai/util/wThemeData.dart';
// import 'package:pull_to_refresh/pull_to_refresh.dart';

class ThemeUtilsString {
// ignore: non_constant_identifier_names
  // static List <String> = ["默认","白色","蓝色","红色"];

  static const List<String> supportSting = ["默认", "白色", "蓝色", "红色"];
}

class ThemeUtils {
  static baseThemeData defaultTheme = defaultThemeData();
  static baseThemeData gTheme = gThemeData();

  static baseThemeData rTheme = rThemeData();
  static baseThemeData wTheme = wThemeData();

  static List<baseThemeData> supportColors = [
    defaultTheme,
    wTheme,
    gTheme,
    rTheme,
  ];

  baseThemeData currentColorTheme;
  static final ThemeUtils _dioManager = ThemeUtils._instance();

  /// *********************************** 构造函数 ***********************************

  /// [DioManager]私有的 自定义命名式构造方法, Ps:instance不是关键字, 可随意命名
  /// 加 _ 表示该命名式构造函数为[DioManager]私有, 外部是不可调用的,
  /// 从而确保该命名式构造函数的使用, 仅可用来创建 _dioManager 这个静态的final实例对象
  ThemeUtils._instance() {}

  /// 工厂化的主构造函数 - 返回私有的实例对象
  /// 返回的就是唯一的实例 _dioManager
  factory ThemeUtils() {
    return _dioManager;
  }

  static Text sText(String) {
    return Text(
      String,
      style: TextStyle(
          color: ThemeUtils().currentColorTheme.textWithdrawColor,
          fontSize: 15),
    );
  }
  // // 当前的主题色
  // static baseThemeData currentColorTheme = ;

//   白金
//   static const int = 1;
//   static const Color defaultColor = const Color(0xFFF5F5F5);
//   static const Color kminenavColor = const Color(0xFFFCD535);
//   // 可选的主题色

//   static const Color tabbarColor = const Color(0xFFFFFFFF);
//   static const Color tabbarSColor = const Color(0xFFFCD535);

// // 字体黄色
//   static const Color labelColorY = const Color(0xFFF0B90B);
// //字体白色
//   static const Color labelColorW = const Color(0xFF333333);
//   // 字体灰色
//   static const Color labelColorG = const Color(0xFF333333);
//   //view颜色
//   static const Color contentBG = const Color(0xFFFFFFFF);

//   static const Color viewgaryBG = const Color(0xFFF5F5F5);

// //我的界面的字体
//   static const Color nameLabelTextColor = const Color(0xFF333333);
//   static const Color integralLabelTextColor = const Color(0xFF333333);

//   // 涨跌
//   static const Color textgreenColor = const Color(0xFF0ECB81);

//   static const Color numberRedColor = const Color(0xFFF6465D);

//   static const Color textRedColor = const Color(0xFFF6465D);
//   static const Color dateGaryColor = const Color(0xFF848E9C);
//   static const Color textGaryColor = const Color(0xFF333333);
//   static const Color textWithdrawColor = const Color(0xFF333333);
//   static const Color textWithdDDrawColor = const Color(0xFF333333);
//   static const Color textWithdkkkwColor = const Color(0xFF333333);

//   static const Color lineColor = const Color(0xFFECECEC);

  //红色

//   static const List<Color> kminetopColor = <Color>[
//     Color(0xFFFD3E83),
//     Color(0xFFFD3E83),
//   ];
//   static const Color defaultColor = const Color(0xFFF5F5F5);

//   // 可选的主题色
//   static const List<Color> supportColors = [defaultColor];

//   static const Color kminenavColor = const Color(0xFFFD3E83);
//   // 当前的主题色
//   static Color currentColorTheme = defaultColor;

//   static const Color tabbarColor = const Color(0xFFFFFFFF);
//   static const Color tabbarSColor = const Color(0xFFFD3E83);

// // 字体黄色
//   static const Color labelColorY = const Color(0xFFF02B2B);
// //字体白色
//   static const Color labelColorW = const Color(0xFF333333);
//   // 字体灰色
//   static const Color labelColorG = const Color(0xFF333333);
//   //view颜色
//   static const Color contentBG = const Color(0xFFFFFFFF);

//   static const Color viewgaryBG = const Color(0xFFF5F5F5);

// //我的界面的字体
//   static const Color nameLabelTextColor = const Color(0xFF333333);
//   static const Color integralLabelTextColor = const Color(0xFF333333);

//   // 涨跌
//   static const Color textgreenColor = const Color(0xFF0ECB81);

//   static const Color numberRedColor = const Color(0xFFF6465D);

//   static const Color textRedColor = const Color(0xFFF6465D);
//   static const Color dateGaryColor = const Color(0xFF848E9C);
//   static const Color textGaryColor = const Color(0xFF333333);
//   static const Color textWithdrawColor = const Color(0xFF333333);
//   static const Color textWithdDDrawColor = const Color(0xFF333333);
//   static const Color textWithdkkkwColor = const Color(0xFF333333);

//   static const Color lineColor = const Color(0xFFECECEC);

  //蓝色

//   static const List<Color> kminetopColor = <Color>[
//     Color(0xFF3A8EFF),
//     Color(0xFF3A8EFF),
//   ];
//   static const Color defaultColor = const Color(0xFFF5F5F5);

//   // 可选的主题色
//   static const List<Color> supportColors = [defaultColor];

//   static const Color kminenavColor = const Color(0xFF3A8EFF);
//   // 当前的主题色
//   static Color currentColorTheme = defaultColor;

//   static const Color tabbarColor = const Color(0xFFFFFFFF);
//   static const Color tabbarSColor = const Color(0xFF3A8EFF);

// // 字体黄色
//   static const Color labelColorY = const Color(0xFF3A8EFF);
// //字体白色
//   static const Color labelColorW = const Color(0xFF333333);
//   // 字体灰色
//   static const Color labelColorG = const Color(0xFF333333);
//   //view颜色
//   static const Color contentBG = const Color(0xFFFFFFFF);

//   static const Color viewgaryBG = const Color(0xFFF5F5F5);

// //我的界面的字体
//   static const Color nameLabelTextColor = const Color(0xFF333333);
//   static const Color integralLabelTextColor = const Color(0xFF333333);

//   // 涨跌
//   static const Color textgreenColor = const Color(0xFF0ECB81);

//   static const Color numberRedColor = const Color(0xFFF6465D);

//   static const Color textRedColor = const Color(0xFFF6465D);
//   static const Color dateGaryColor = const Color(0xFF848E9C);
//   static const Color textGaryColor = const Color(0xFF333333);
//   static const Color textWithdrawColor = const Color(0xFF333333);
//   static const Color textWithdDDrawColor = const Color(0xFF333333);
//   static const Color textWithdkkkwColor = const Color(0xFF333333);

//   static const Color lineColor = const Color(0xFFECECEC);

}

class StandardTextStyle {
  static Size boundingTextSize(String text, TextStyle style,
      {int maxLines = 2 ^ 31, double maxWidth = double.infinity}) {
    if (text == null || text.isEmpty) {
      return Size.zero;
    }
    final TextPainter textPainter = TextPainter(
        textDirection: TextDirection.ltr,
        text: TextSpan(text: text, style: style),
        maxLines: maxLines)
      ..layout(maxWidth: maxWidth);
    return textPainter.size;
  }

  static TextStyle big = TextStyle(
    fontWeight: FontWeight.w600,
    fontSize: SysSize.big,
    inherit: true,
    color: ThemeUtils().currentColorTheme.labelColorW,
  );
  static const TextStyle bigWithOpacity = const TextStyle(
    color: const Color.fromRGBO(0xff, 0xff, 0xff, .66),
    fontWeight: FontWeight.w600,
    fontSize: SysSize.big,
    inherit: true,
  );
  static TextStyle normalW = TextStyle(
    fontWeight: FontWeight.w600,
    fontSize: SysSize.normal,
    color: ThemeUtils().currentColorTheme.labelColorW,
    inherit: true,
  );
  static TextStyle normal = TextStyle(
    fontWeight: FontWeight.normal,
    fontSize: SysSize.normal,
    color: ThemeUtils().currentColorTheme.labelColorW,
    inherit: true,
  );
  static const TextStyle normalWithOpacity = const TextStyle(
    color: const Color.fromRGBO(0xff, 0xff, 0xff, .66),
    fontWeight: FontWeight.normal,
    fontSize: SysSize.normal,
    inherit: true,
  );
  static TextStyle small = TextStyle(
    fontWeight: FontWeight.normal,
    fontSize: SysSize.small,
    color: ThemeUtils().currentColorTheme.labelColorW,
    inherit: true,
  );
  static const TextStyle smallWithOpacity = const TextStyle(
    color: const Color.fromRGBO(0xff, 0xff, 0xff, .66),
    fontWeight: FontWeight.normal,
    fontSize: SysSize.small,
    inherit: true,
  );
}

class SysSize {
  static const double avatar = 56;
  // static const double iconBig = 40;
  static const double iconNormal = 24;
  // static const double big = 18;
  // static const double normal = 16;
  // static const double small = 12;
  static const double iconBig = 40;
  static const double big = 16;
  static const double normal = 14;
  static const double small = 12;
}

class nullimage {
  //= CustomHeader(
  //   builder: (context, mode) {
  //     Widget body;
  //     if (mode == RefreshStatus.idle) {
  //       body = Text("上拉加载",
  //           style: TextStyle(color: ThemeUtils.labelColorG, fontSize: 15));
  //     } else if (mode == RefreshStatus.refreshing) {
  //       body = Container(
  //         // color: ThemeUtils.labelColorW,
  //         child: CircularProgressIndicator(),
  //       );
  //     } else if (mode == RefreshStatus.canRefresh) {
  //       body = Text("可以松手了",
  //           style: TextStyle(color: ThemeUtils.labelColorG, fontSize: 15));
  //     } else if (mode == RefreshStatus.completed) {
  //       body = Text("刷新成功!",
  //           style: TextStyle(color: ThemeUtils.labelColorG, fontSize: 15));
  //     } else {
  //       body = Text("刷新失败!",
  //           style: TextStyle(color: ThemeUtils.labelColorG, fontSize: 15));
  //     }
  //     return Container(
  //       height: 44.0,
  //       child: Center(child: body),
  //     );
  //   },
  // );

  // static Widget footer = CustomFooter(
  //   builder: (BuildContext context, LoadStatus mode) {
  //     Widget body;
  //     if (mode == LoadStatus.idle) {
  //       body = Text("上拉加载",
  //           style: TextStyle(color: ThemeUtils.labelColorG, fontSize: 15));
  //     } else if (mode == LoadStatus.loading) {
  //       body = Container(
  //         // color: ThemeUtils.labelColorW,
  //         child: CircularProgressIndicator(),
  //       );
  //     } else if (mode == LoadStatus.failed) {
  //       body = Text(
  //         "加载失败！点击重试！",
  //         style: TextStyle(color: ThemeUtils.labelColorG, fontSize: 15),
  //       );
  //     } else if (mode == LoadStatus.canLoading) {
  //       body = Text("松手,加载更多!",
  //           style: TextStyle(color: ThemeUtils.labelColorG, fontSize: 15));
  //     } else {
  //       body = Text("没有更多数据了!",
  //           style: TextStyle(color: ThemeUtils.labelColorG, fontSize: 15));
  //     }
  //     return Container(
  //       height: 44.0,
  //       child: Center(child: body),
  //     );
  //   },
  // );
}
