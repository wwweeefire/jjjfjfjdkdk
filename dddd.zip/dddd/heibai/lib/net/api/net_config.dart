class NetConfig {
  static const DEBUG = false;
}
