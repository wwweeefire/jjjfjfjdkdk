library basicnetservice;

export 'package:heibai/net/service/net_service.dart';
import 'dart:io';
import 'package:heibai/net/api/Api.dart';
import 'package:flutter/widgets.dart';
// import 'package:heibai/net/service/net_service.dart';
import 'package:heibai/net/service/net_service.dart';

import 'package:heibai/net/widget/dialog_param.dart';
import 'package:heibai/net/widget/loading_dialog.dart';
import 'dart:typed_data';
import 'app_net_service.dart';

class AppApi extends AppNetService {
  /// 获取天气的接口
  // static const String _GET_WEATHER = "/";
  // static const String _SIGN_UP = "/signup";
  // static const String _SIGN_IN = "/signin";
  static const String _GET_USER_MINE = "/get_user_mine";
  static const String _UPLOAD_USER_ICON = "/upload_photo";

  static const String _UPLOAD_IMAGE = "/upload/image";
  // static const String _UPDATE_USER = "/update_user";

  static AppApi _instance = AppApi();

  static AppApi getInstance() {
    if (_instance == null) {
      _instance = AppApi();
    }
    return _instance;
  }

  Future<ResultData> get_config(BuildContext context, bool showProgress) async {
    Map<String, dynamic> param = {};

    ///?app=weather.future&weaid=1&&appkey=10003&sign=b59bc3ef6191eb9f747dd4e83c99f2a4&format=json
    // param["app"] = "weather.future";
    // param["weaid"] = "1";
    // param["appkey"] = "10003";
    // param["sign"] = "b59bc3ef6191eb9f747dd4e83c99f2a4";
    // param["format"] = "json";
    ResultData resultData = await get(Api.getConfig,
        params: param, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> get_country(
      BuildContext context, bool showProgress) async {
    Map<String, dynamic> param = {};

    ResultData resultData = await get(Api.getcountry,
        params: param, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> get_product_page_list(BuildContext context,
      bool showProgress, Map<String, dynamic> params) async {
    // Map<String, dynamic> param = {};

    ResultData resultData = await get(Api.get_product_page_list,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> get_member_optional_list(BuildContext context,
      bool showProgress, Map<String, dynamic> params) async {
    // Map<String, dynamic> param = {};

    ResultData resultData = await get(Api.get_member_optional_list,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> get_product_optional(BuildContext context,
      bool showProgress, Map<String, dynamic> params) async {
    // Map<String, dynamic> param = {};

    ResultData resultData = await get(Api.get_product_optional,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> get_recharge_method_info(BuildContext context,
      bool showProgress, Map<String, dynamic> params) async {
    // Map<String, dynamic> param = {};

    ResultData resultData = await get(Api.get_recharge_method_info,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> get_member_info(
      BuildContext context, bool showProgress) async {
    Map<String, dynamic> param = {};

    ResultData resultData = await get(Api.get_member_info,
        params: param, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> get_product_list(
      BuildContext context, bool showProgress) async {
    Map<String, dynamic> param = {};

    ResultData resultData = await get(Api.get_product_list,
        params: param, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> get_index(BuildContext context, bool showProgress) async {
    Map<String, dynamic> param = {};

    ResultData resultData = await get(Api.get_index,
        params: param, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> get_product_category(
      BuildContext context, bool showProgress) async {
    Map<String, dynamic> param = {};

    ResultData resultData = await get(Api.get_product_category,
        params: param, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> get_member_bank_list(
      BuildContext context, bool showProgress) async {
    Map<String, dynamic> param = {};

    ResultData resultData = await get(Api.get_member_bank_list,
        params: param, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> get_invest(BuildContext context, bool showProgress) async {
    Map<String, dynamic> param = {};

    ResultData resultData = await get(Api.get_invest,
        params: param, context: context, showLoad: showProgress);
    return resultData;
  }

  // 注册
  Future<ResultData> regrequest(BuildContext context, bool showProgress,
      Map<String, dynamic> params) async {
    ResultData resultData = await post(Api.getregister,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> post_login(BuildContext context, bool showProgress,
      Map<String, dynamic> params) async {
    ResultData resultData = await post(Api.post_login,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> post_recharge_create(BuildContext context,
      bool showProgress, Map<String, dynamic> params) async {
    ResultData resultData = await post(Api.post_recharge_create,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> post_logout(BuildContext context, bool showProgress,
      Map<String, dynamic> params) async {
    ResultData resultData = await post(Api.post_logout,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> post_member_optional_create(BuildContext context,
      bool showProgress, Map<String, dynamic> params) async {
    ResultData resultData = await post(Api.post_member_optional_create,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> post_product_buy(BuildContext context, bool showProgress,
      Map<String, dynamic> params) async {
    ResultData resultData = await post(Api.post_product_buy,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> post_member_bank_create(BuildContext context,
      bool showProgress, Map<String, dynamic> params) async {
    ResultData resultData = await post(Api.post_member_bank_create,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> post_member_password(BuildContext context,
      bool showProgress, Map<String, dynamic> params) async {
    ResultData resultData = await post(Api.post_member_password,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> post_member_pay_password(BuildContext context,
      bool showProgress, Map<String, dynamic> params) async {
    ResultData resultData = await post(Api.post_member_pay_password,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> post_member_update(BuildContext context, bool showProgress,
      Map<String, dynamic> params) async {
    ResultData resultData = await post(Api.post_member_update,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> post_member_verified(BuildContext context,
      bool showProgress, Map<String, dynamic> params) async {
    ResultData resultData = await post(Api.post_member_verified,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> post_withdraw_create(BuildContext context,
      bool showProgress, Map<String, dynamic> params) async {
    ResultData resultData = await post(Api.post_withdraw_create,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> post_invest_transfer(BuildContext context,
      bool showProgress, Map<String, dynamic> params) async {
    ResultData resultData = await post(Api.post_invest_transfer,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> post_member_optional_remove(BuildContext context,
      bool showProgress, Map<String, dynamic> params) async {
    ResultData resultData = await post(Api.post_member_optional_remove,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> get_product_kline(BuildContext context, bool showProgress,
      Map<String, dynamic> params) async {
    ResultData resultData = await get(Api.get_product_kline,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> get_order_page_list(BuildContext context,
      bool showProgress, Map<String, dynamic> params) async {
    ResultData resultData = await get(Api.get_order_page_list,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> get_trade_page_list(BuildContext context,
      bool showProgress, Map<String, dynamic> params) async {
    ResultData resultData = await get(Api.get_trade_page_list,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> get_recharge_page_list(BuildContext context,
      bool showProgress, Map<String, dynamic> params) async {
    ResultData resultData = await get(Api.get_recharge_page_list,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> get_withdraw_page_list(BuildContext context,
      bool showProgress, Map<String, dynamic> params) async {
    ResultData resultData = await get(Api.get_withdraw_page_list,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> get_product_option(BuildContext context, bool showProgress,
      Map<String, dynamic> params) async {
    ResultData resultData = await get(Api.get_product_option,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> get_message_page_list(BuildContext context,
      bool showProgress, Map<String, dynamic> params) async {
    ResultData resultData = await get(Api.get_message_page_list,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> get_member_level_list(BuildContext context,
      bool showProgress, Map<String, dynamic> params) async {
    ResultData resultData = await get(Api.get_member_level_list,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> get_help_list(BuildContext context, bool showProgress,
      Map<String, dynamic> params) async {
    ResultData resultData = await get(Api.get_help_list,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> get_bank_list(BuildContext context, bool showProgress,
      Map<String, dynamic> params) async {
    ResultData resultData = await get(Api.get_bank_list,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> get_notice_page_list(BuildContext context,
      bool showProgress, Map<String, dynamic> params) async {
    ResultData resultData = await get(Api.get_notice_page_list,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> get_helpcenter_list(BuildContext context,
      bool showProgress, Map<String, dynamic> params) async {
    ResultData resultData = await get(Api.get_helpcenter_list,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> getConnect(BuildContext context, bool showProgress,
      Map<String, dynamic> params) async {
    ResultData resultData = await get(Api.getConnect,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> get_news_page_list(BuildContext context, bool showProgress,
      Map<String, dynamic> params) async {
    ResultData resultData = await get(Api.get_news_page_list,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> get_recharge_method(BuildContext context,
      bool showProgress, Map<String, dynamic> params) async {
    ResultData resultData = await get(Api.get_recharge_method,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  Future<ResultData> get_withdraw_method(BuildContext context,
      bool showProgress, Map<String, dynamic> params) async {
    ResultData resultData = await get(Api.get_withdraw_method,
        params: params, context: context, showLoad: showProgress);
    return resultData;
  }

  /// 上传头像接口
  Future<ResultData> uploadUserIcon(
    BuildContext context,
    File file,
    List<int> byets,
  ) async {
    // 开始进度
    ShowParam showParam =
        new ShowParam(barrierDismissible: true, showBackground: true);
    showParam.text = "正在...";
    LoadingDialogUtil.showTextLoadingDialog(context, showParam);
    String fileName = file.path.substring(file.path.lastIndexOf("/") + 1);
    // print("filename: $fileName");
    List<int> bytes = await file.readAsBytes();
    ResultData resultData =
        await upLoad(file, fileName, byets, _UPLOAD_USER_ICON, params: {});
    showParam.pop();
    // 结束进度
    resultData.toast();
    return resultData;
  }

  /// 上传头像接口
  Future<ResultData> uploadimage(
      BuildContext context, File file, List<int> byets) async {
    // 开始进度
    ShowParam showParam =
        new ShowParam(barrierDismissible: true, showBackground: true);
    showParam.text = "正在上传...";
    LoadingDialogUtil.showTextLoadingDialog(context, showParam);
    String fileName = file.path.substring(file.path.lastIndexOf("/") + 1);

    ResultData resultData =
        await upLoad(file, fileName, byets, _UPLOAD_IMAGE, params: {});
    showParam.pop();
    // 结束进度
    resultData.toast();
    return resultData;
  }
}
