class Api {
  static final bool istest = false;
  static final String action = '/api/v1';
  static final String githubhoust =
      "https://dengyun2022.coding.net/p/domain/d/domain/git/raw/ctolmax/conf.json";

  // static final String host = "http://192.168.132.45:8000/api/v1";

  // static final String imagehost = "http://192.168.132.45:8000";

  // static final String SOCKET_URL = 'ws://192.168.132.45:8000/api/v1/websocket';

  static final String host = "https://finance.33456.plus";
  static final String imagehost = "https://finance.33456.plus/";

  static final String SOCKET_URL = 'wss://finance.33456.plus/api/v1/websocket';

  // static final String host = "https://ooshanghai.top/api/v1";
  // static final String imagehost = "https://ooshanghai.top/";

  // static final String SOCKET_URL = 'wss://ooshanghai.top/api/v1/websocket';

  // 配置列表
  static final String getConfig = "/config";

  static final String getcountry = "/country/list";

  static final String getregister = "/register";

  static final String post_login = "/login";
  static final String get_member_info = "/member/info";

  static final String get_index = "/index";

  static final String get_product_list = "/product/list";

  static final String get_product_kline = "/product/kline";

  static final String get_product_option = "/product/option";
  static final String get_news_page_list = "/news/page_list";
  static final String get_recharge_method = "/recharge/method";

  static final String get_withdraw_method = "/withdraw/method";

  static final String get_product_category = "/product/category";

  static final String get_product_page_list = "/product/page_list";
  static final String get_member_optional_list = "/member_optional/list";

  static final String get_recharge_method_info = "/recharge/method_info";
  static final String post_recharge_create = "/recharge/create";

  static final String get_invest = "/invest";

  static final String post_logout = "/logout";

  static final String get_product_optional = "/product/optional";

  static final String post_member_optional_create = "/member_optional/create";

  static final String post_member_optional_remove = "/member_optional/remove";

  static final String post_product_buy = "/product/buy";

  static final String get_order_page_list = "/order/page_list";

  static final String get_trade_page_list = "/trade/page_list";

  static final String get_recharge_page_list = "/recharge/page_list";

  static final String post_invest_transfer = "/invest/transfer";

  static final String get_withdraw_page_list = "/withdraw/page_list";

  static final String post_withdraw_create = "/withdraw/create";

  static final String get_message_page_list = "/message/page_list";

  static final String get_help_list = "/help/list?category=1";

  static final String get_helpcenter_list = "/help/list?category=2";

  static final String get_bank_list = "/bank/list";

  static final String post_member_bank_create = "/member_bank/create";

  static final String post_member_password = "/member/password";

  static final String post_member_pay_password = "/member/pay_password";

  static final String post_member_verified = "/member/verified";

  static final String post_member_update = "/member/update";

  static final String get_member_bank_list = "/member_bank/list";

  static final String getConnect = "/getConnect";

  static final String get_notice_page_list = "/notice/page_list";

  static final String get_member_level_list = "/member_level/list";

  // // 资讯详情
  // static final String newsDetail = host + "/action/openapi/news_detail";

  // // 动弹列表
  // static final String tweetsList = host + "/action/openapi/tweet_list";

  // // 评论列表
  // static final String commentList = host + "/action/openapi/comment_list";

  // // 评论回复
  // static final String commentReply = host + "/action/openapi/comment_reply";

  // // 获取用户信息
  // static final String userInfo = host + "/action/openapi/user";

  // // 发布动弹
  // static final String pubTweet = host + "/action/openapi/tweet_pub";

  // // 添加到小黑屋
  // static final String addToBlack = "http://osc.yubo.me/black/add";

  // // 查询小黑屋
  // static final String queryBlack = "http://osc.yubo.me/black/query";

  // // 从小黑屋中删除
  // static final String deleteBlack = "http://osc.yubo.me/black/delete";

  // // 开源活动
  // static final String eventList = "http://osc.yubo.me/events/";
}
