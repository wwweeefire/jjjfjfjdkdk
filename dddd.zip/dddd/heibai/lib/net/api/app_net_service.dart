library basicnetservice;

export 'package:heibai/net/service/net_service.dart';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:heibai/Classes/model/config.dart';
import 'package:heibai/net/api/Api.dart';
import 'package:heibai/net/service/net_service.dart';
import 'package:heibai/net/widget/dialog_param.dart';
import 'package:heibai/net/widget/loading_dialog.dart';
import 'package:heibai/routers/navigator_util.dart';
import 'package:heibai/util/DataUtils.dart';
import 'package:heibai/pages/web_socket_utility.dart';

class AppNetService extends NetService {
  AppNetService();

  @override
  request(String url,
      {Method method,
      Map<String, dynamic> params,
      var file,
      List<int> sbyets,
      String fileName,
      String fileSavePath,
      BuildContext context,
      bool showLoad = false}) async {
    /// 传参进行统一处理, 加上基本参数
    Map<String, dynamic> basicParam = await getBasicParam();
    // basicParam["timeStamp"] =
    //     (new DateTime.now().millisecondsSinceEpoch ~/ 1000).toString();
    if (params != null) {
      basicParam.addAll(params);
    }
    ShowParam showParam = new ShowParam(
        show: showLoad, barrierDismissible: false, showBackground: false);
    LoadingDialogUtil.showLoadingDialog(context, showParam);
    ResultData resultData = await super.request(url,
        method: method,
        params: basicParam,
        file: file,
        sbyets: sbyets,
        fileName: fileName,
        fileSavePath: fileSavePath);
    showParam.pop();

    /// 当apiToken 过期或者错误时的提示码
    if (resultData.code == 10000) {
      // 退出登录并跳转到登录界面
      // App.navigateTo(context, QuRoutes.ROUTE_MINE_LOGIN, clearStack: true);
      DataUtils.clearLoginInfo();
      NavigatorUtil.goToLoginRemovePage(context);
      WebSocketUtility().closeSocket();
    }
    if (10001 == resultData.code) {
      // DataUtils.clearLoginInfo();
      // NavigatorUtil.goToLoginRemovePage(context);
      // WebSocketUtility().closeSocket();
      // 退出登录并跳转到登录界面

    }
    if (resultData.msg == "网络连接失败") {}
    // if (resultData.result == false) {
    //   showParam.judgeNeedPop(context);
    // }

    return resultData;
  }

  @override
  getBasicUrl() {
    return ConfigManager().host + Api.action;
  }

  @override
  getHeaders() async {
    // TODO: implement getHeaders
    Map<String, dynamic> headers = {};

    if (ConfigManager().code != null) {
      headers["lang"] = ConfigManager().code;
      headers["Access-Control-Allow-Origin"] = "*";
      // headers["lang"] = "1";
    }
    if (ConfigManager().user != null) {
      headers["token"] = ConfigManager().user.token;

      // headers["lang"] = "1";
    }

    return headers;
  }

  Future<Map<String, dynamic>> getBasicParam() async {
    Map<String, dynamic> basicParam = {};
    // basicParam["agent"] = Platform.isAndroid ? "android" : "ios";
    return basicParam;
  }
}
