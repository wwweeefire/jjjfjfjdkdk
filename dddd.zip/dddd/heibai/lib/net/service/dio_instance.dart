import 'dart:io';

import 'package:dio/dio.dart';

class DioInstance {
  static const String CONTENT_TYPE_PRIMARY = "application";
  static const String CONTENT_TYPE_FORM =
      "x-www-form-urlencoded"; // MediaType.parse("application/json; charset=UTF-8");
  static const String CONTENT_TYPE_JSON = "json";
  static const String CONTENT_CHART_SET = 'utf-8';

  static Dio _instance;

  static Dio createInstance() {
    if (_instance == null) {
      var contentType2 = ContentType(CONTENT_TYPE_PRIMARY, CONTENT_TYPE_JSON,
          charset: CONTENT_CHART_SET);
      BaseOptions options = BaseOptions(
        // 15s 超时时间
        connectTimeout: 30000,
        receiveTimeout: 30000,
        responseType: ResponseType.plain,
        // contentType:
        //     "application/json; charset=utf-8; application/x-www-form-urlencoded;multipart/form-data"
        // // contentType: contentType2,
      );
      _instance = new Dio(options);
    }
    return _instance;
  }
}
