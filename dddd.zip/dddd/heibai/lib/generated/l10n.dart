// GENERATED CODE - DO NOT MODIFY BY HAND
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'intl/messages_all.dart';

// **************************************************************************
// Generator: Flutter Intl IDE plugin
// Made by Localizely
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, lines_longer_than_80_chars
// ignore_for_file: join_return_with_assignment, prefer_final_in_for_each
// ignore_for_file: avoid_redundant_argument_values

class S {
  S();
  
  static S current;
  
  static const AppLocalizationDelegate delegate =
    AppLocalizationDelegate();

  static Future<S> load(Locale locale) {
    final name = (locale.countryCode?.isEmpty ?? false) ? locale.languageCode : locale.toString();
    final localeName = Intl.canonicalizedLocale(name); 
    return initializeMessages(localeName).then((_) {
      Intl.defaultLocale = localeName;
      S.current = S();
      
      return S.current;
    });
  } 

  static S of(BuildContext context) {
    return Localizations.of<S>(context, S);
  }

  /// `Home`
  String get tab_home {
    return Intl.message(
      'Home',
      name: 'tab_home',
      desc: '',
      args: [],
    );
  }

  /// `market`
  String get tab_market {
    return Intl.message(
      'market',
      name: 'tab_market',
      desc: '',
      args: [],
    );
  }

  /// `Record`
  String get tab_Position_record {
    return Intl.message(
      'Record',
      name: 'tab_Position_record',
      desc: '',
      args: [],
    );
  }

  /// `Information`
  String get tab_consult {
    return Intl.message(
      'Information',
      name: 'tab_consult',
      desc: '',
      args: [],
    );
  }

  /// `Mine`
  String get tab_mine {
    return Intl.message(
      'Mine',
      name: 'tab_mine',
      desc: '',
      args: [],
    );
  }

  /// `Generate`
  String get generate {
    return Intl.message(
      'Generate',
      name: 'generate',
      desc: '',
      args: [],
    );
  }

  /// `switch language`
  String get changeLanguage {
    return Intl.message(
      'switch language',
      name: 'changeLanguage',
      desc: '',
      args: [],
    );
  }

  /// `invite friends`
  String get invitefriends {
    return Intl.message(
      'invite friends',
      name: 'invitefriends',
      desc: '',
      args: [],
    );
  }

  /// `Help Center`
  String get HelpCenter {
    return Intl.message(
      'Help Center',
      name: 'HelpCenter',
      desc: '',
      args: [],
    );
  }

  /// `about us`
  String get aboutus {
    return Intl.message(
      'about us',
      name: 'aboutus',
      desc: '',
      args: [],
    );
  }

  /// `Recharge record`
  String get Rechargerecord {
    return Intl.message(
      'Recharge record',
      name: 'Rechargerecord',
      desc: '',
      args: [],
    );
  }

  /// `Withdrawals record`
  String get Withdrawalsrecord {
    return Intl.message(
      'Withdrawals record',
      name: 'Withdrawalsrecord',
      desc: '',
      args: [],
    );
  }

  /// `Order history`
  String get Orderhistory {
    return Intl.message(
      'Order history',
      name: 'Orderhistory',
      desc: '',
      args: [],
    );
  }

  /// `recharge`
  String get recharge {
    return Intl.message(
      'recharge',
      name: 'recharge',
      desc: '',
      args: [],
    );
  }

  /// `withdraw`
  String get withdraw {
    return Intl.message(
      'withdraw',
      name: 'withdraw',
      desc: '',
      args: [],
    );
  }

  /// `Yu'e Bao`
  String get YueBao {
    return Intl.message(
      'Yu\'e Bao',
      name: 'YueBao',
      desc: '',
      args: [],
    );
  }

  /// `bill`
  String get bill {
    return Intl.message(
      'bill',
      name: 'bill',
      desc: '',
      args: [],
    );
  }

  /// `credit points:`
  String get Reputationpoints {
    return Intl.message(
      'credit points:',
      name: 'Reputationpoints',
      desc: '',
      args: [],
    );
  }

  /// `Click on the avatar to log in`
  String get Clickontheavatartologin {
    return Intl.message(
      'Click on the avatar to log in',
      name: 'Clickontheavatartologin',
      desc: '',
      args: [],
    );
  }

  /// `Recharge channel`
  String get Rechargemethod {
    return Intl.message(
      'Recharge channel',
      name: 'Rechargemethod',
      desc: '',
      args: [],
    );
  }

  /// `Recharge amount`
  String get Rechargeamount {
    return Intl.message(
      'Recharge amount',
      name: 'Rechargeamount',
      desc: '',
      args: [],
    );
  }

  /// `Amount cannot be empty`
  String get Amountcannotbeempty {
    return Intl.message(
      'Amount cannot be empty',
      name: 'Amountcannotbeempty',
      desc: '',
      args: [],
    );
  }

  /// `bank card recharge`
  String get bankcardrecharge {
    return Intl.message(
      'bank card recharge',
      name: 'bankcardrecharge',
      desc: '',
      args: [],
    );
  }

  /// `bank card information`
  String get bankcardinformation {
    return Intl.message(
      'bank card information',
      name: 'bankcardinformation',
      desc: '',
      args: [],
    );
  }

  /// `Payee Name: `
  String get PayeeName {
    return Intl.message(
      'Payee Name: ',
      name: 'PayeeName',
      desc: '',
      args: [],
    );
  }

  /// `bank card name: `
  String get bankcardname {
    return Intl.message(
      'bank card name: ',
      name: 'bankcardname',
      desc: '',
      args: [],
    );
  }

  /// `Bank card number: `
  String get Bankcardnumber {
    return Intl.message(
      'Bank card number: ',
      name: 'Bankcardnumber',
      desc: '',
      args: [],
    );
  }

  /// `Upload transfer voucher`
  String get Uploadtransfervoucher {
    return Intl.message(
      'Upload transfer voucher',
      name: 'Uploadtransfervoucher',
      desc: '',
      args: [],
    );
  }

  /// `submit`
  String get submit {
    return Intl.message(
      'submit',
      name: 'submit',
      desc: '',
      args: [],
    );
  }

  /// `Alipay information`
  String get Alipaynformation {
    return Intl.message(
      'Alipay information',
      name: 'Alipaynformation',
      desc: '',
      args: [],
    );
  }

  /// `Alipayaccount name: `
  String get Alipayaccount {
    return Intl.message(
      'Alipayaccount name: ',
      name: 'Alipayaccount',
      desc: '',
      args: [],
    );
  }

  /// `Alipay receipt code: `
  String get Alipayreceiptcode {
    return Intl.message(
      'Alipay receipt code: ',
      name: 'Alipayreceiptcode',
      desc: '',
      args: [],
    );
  }

  /// `USDT information`
  String get USDTinformation {
    return Intl.message(
      'USDT information',
      name: 'USDTinformation',
      desc: '',
      args: [],
    );
  }

  /// `USDT address: `
  String get USDTaddress {
    return Intl.message(
      'USDT address: ',
      name: 'USDTaddress',
      desc: '',
      args: [],
    );
  }

  /// `USDT receipt code: `
  String get USDTcode {
    return Intl.message(
      'USDT receipt code: ',
      name: 'USDTcode',
      desc: '',
      args: [],
    );
  }

  /// `Long press to save the QR code`
  String get LongpresstosavetheQRcode {
    return Intl.message(
      'Long press to save the QR code',
      name: 'LongpresstosavetheQRcode',
      desc: '',
      args: [],
    );
  }

  /// `upload certificate`
  String get uploadcertificate {
    return Intl.message(
      'upload certificate',
      name: 'uploadcertificate',
      desc: '',
      args: [],
    );
  }

  /// `Please enter the card number`
  String get Pleaseenterthecardnumber {
    return Intl.message(
      'Please enter the card number',
      name: 'Pleaseenterthecardnumber',
      desc: '',
      args: [],
    );
  }

  /// `Please enter address`
  String get Pleaseenteraddress {
    return Intl.message(
      'Please enter address',
      name: 'Pleaseenteraddress',
      desc: '',
      args: [],
    );
  }

  /// `Submitted successfully, waiting for review`
  String get Submittedsuccessfullywaitingforreview {
    return Intl.message(
      'Submitted successfully, waiting for review',
      name: 'Submittedsuccessfullywaitingforreview',
      desc: '',
      args: [],
    );
  }

  /// `Withdrawal channel`
  String get Withdrawalchannel {
    return Intl.message(
      'Withdrawal channel',
      name: 'Withdrawalchannel',
      desc: '',
      args: [],
    );
  }

  /// `Withdrawal Amount`
  String get WithdrawalAmount {
    return Intl.message(
      'Withdrawal Amount',
      name: 'WithdrawalAmount',
      desc: '',
      args: [],
    );
  }

  /// `AvailableBalance`
  String get AvailableBalance {
    return Intl.message(
      'AvailableBalance',
      name: 'AvailableBalance',
      desc: '',
      args: [],
    );
  }

  /// `handlingfee`
  String get handlingfee {
    return Intl.message(
      'handlingfee',
      name: 'handlingfee',
      desc: '',
      args: [],
    );
  }

  /// `'1. Please fill in your bank card information and withdrawal password correctly before withdrawing money `
  String get withddes {
    return Intl.message(
      '\'1. Please fill in your bank card information and withdrawal password correctly before withdrawing money ',
      name: 'withddes',
      desc: '',
      args: [],
    );
  }

  /// `Choosea bankcard`
  String get Chooseabankcard {
    return Intl.message(
      'Choosea bankcard',
      name: 'Chooseabankcard',
      desc: '',
      args: [],
    );
  }

  /// `Add a bank card`
  String get Addabankcard {
    return Intl.message(
      'Add a bank card',
      name: 'Addabankcard',
      desc: '',
      args: [],
    );
  }

  /// `Please type in your name`
  String get QSRXM {
    return Intl.message(
      'Please type in your name',
      name: 'QSRXM',
      desc: '',
      args: [],
    );
  }

  /// `Please enter bank name`
  String get QSRYHKMC {
    return Intl.message(
      'Please enter bank name',
      name: 'QSRYHKMC',
      desc: '',
      args: [],
    );
  }

  /// `Please enter bank card number`
  String get QSRYHKH {
    return Intl.message(
      'Please enter bank card number',
      name: 'QSRYHKH',
      desc: '',
      args: [],
    );
  }

  /// `Please enter your Alipay account`
  String get RSRZFBZH {
    return Intl.message(
      'Please enter your Alipay account',
      name: 'RSRZFBZH',
      desc: '',
      args: [],
    );
  }

  /// `Please enter USDT address`
  String get QSRUSDTDZ {
    return Intl.message(
      'Please enter USDT address',
      name: 'QSRUSDTDZ',
      desc: '',
      args: [],
    );
  }

  /// `Please enter the withdrawal password`
  String get QSRTXMM {
    return Intl.message(
      'Please enter the withdrawal password',
      name: 'QSRTXMM',
      desc: '',
      args: [],
    );
  }

  /// `Please check that the data cannot be empty`
  String get QJCSJBNWK {
    return Intl.message(
      'Please check that the data cannot be empty',
      name: 'QJCSJBNWK',
      desc: '',
      args: [],
    );
  }

  /// `Please select a bank card`
  String get QXZYHK {
    return Intl.message(
      'Please select a bank card',
      name: 'QXZYHK',
      desc: '',
      args: [],
    );
  }

  /// `Please enter the amount`
  String get QSRJR {
    return Intl.message(
      'Please enter the amount',
      name: 'QSRJR',
      desc: '',
      args: [],
    );
  }

  /// `Name`
  String get XM {
    return Intl.message(
      'Name',
      name: 'XM',
      desc: '',
      args: [],
    );
  }

  /// `bank name`
  String get YHMZ {
    return Intl.message(
      'bank name',
      name: 'YHMZ',
      desc: '',
      args: [],
    );
  }

  /// `Bank account/card number`
  String get YHZHKH {
    return Intl.message(
      'Bank account/card number',
      name: 'YHZHKH',
      desc: '',
      args: [],
    );
  }

  /// `Bank Branch`
  String get YHZH {
    return Intl.message(
      'Bank Branch',
      name: 'YHZH',
      desc: '',
      args: [],
    );
  }

  /// `mobile phone number`
  String get SJHM {
    return Intl.message(
      'mobile phone number',
      name: 'SJHM',
      desc: '',
      args: [],
    );
  }

  /// `Please enter bank account number`
  String get QRRYHZHKH {
    return Intl.message(
      'Please enter bank account number',
      name: 'QRRYHZHKH',
      desc: '',
      args: [],
    );
  }

  /// `Please enter bank branch`
  String get QSRYHZH {
    return Intl.message(
      'Please enter bank branch',
      name: 'QSRYHZH',
      desc: '',
      args: [],
    );
  }

  /// `Please enter the phone number`
  String get QRRSJHM {
    return Intl.message(
      'Please enter the phone number',
      name: 'QRRSJHM',
      desc: '',
      args: [],
    );
  }

  /// `Bind bank card`
  String get BDYHK {
    return Intl.message(
      'Bind bank card',
      name: 'BDYHK',
      desc: '',
      args: [],
    );
  }

  /// `Search currency`
  String get SSBZGPJJ {
    return Intl.message(
      'Search currency',
      name: 'SSBZGPJJ',
      desc: '',
      args: [],
    );
  }

  /// `search history`
  String get SSLS {
    return Intl.message(
      'search history',
      name: 'SSLS',
      desc: '',
      args: [],
    );
  }

  /// `No data`
  String get ZWSJ {
    return Intl.message(
      'No data',
      name: 'ZWSJ',
      desc: '',
      args: [],
    );
  }

  /// `Yu'e Bao`
  String get YEB {
    return Intl.message(
      'Yu\'e Bao',
      name: 'YEB',
      desc: '',
      args: [],
    );
  }

  /// `lump sum`
  String get ZJE {
    return Intl.message(
      'lump sum',
      name: 'ZJE',
      desc: '',
      args: [],
    );
  }

  /// `cumulative income`
  String get LJSY {
    return Intl.message(
      'cumulative income',
      name: 'LJSY',
      desc: '',
      args: [],
    );
  }

  /// `7-day annualization`
  String get QRNH {
    return Intl.message(
      '7-day annualization',
      name: 'QRNH',
      desc: '',
      args: [],
    );
  }

  /// `transfer out`
  String get ZC {
    return Intl.message(
      'transfer out',
      name: 'ZC',
      desc: '',
      args: [],
    );
  }

  /// `transfer in`
  String get ZR {
    return Intl.message(
      'transfer in',
      name: 'ZR',
      desc: '',
      args: [],
    );
  }

  /// `Earnings record`
  String get SYJL {
    return Intl.message(
      'Earnings record',
      name: 'SYJL',
      desc: '',
      args: [],
    );
  }

  /// `Personal information`
  String get GRXX {
    return Intl.message(
      'Personal information',
      name: 'GRXX',
      desc: '',
      args: [],
    );
  }

  /// `payment method`
  String get SKFS {
    return Intl.message(
      'payment method',
      name: 'SKFS',
      desc: '',
      args: [],
    );
  }

  /// `Bank card`
  String get YHK {
    return Intl.message(
      'Bank card',
      name: 'YHK',
      desc: '',
      args: [],
    );
  }

  /// `Change the withdrawal password`
  String get XGTXMM {
    return Intl.message(
      'Change the withdrawal password',
      name: 'XGTXMM',
      desc: '',
      args: [],
    );
  }

  /// `change Password`
  String get XGMM {
    return Intl.message(
      'change Password',
      name: 'XGMM',
      desc: '',
      args: [],
    );
  }

  /// `Enter old password`
  String get SRJMM {
    return Intl.message(
      'Enter old password',
      name: 'SRJMM',
      desc: '',
      args: [],
    );
  }

  /// `Please enter old password`
  String get QSRJMM {
    return Intl.message(
      'Please enter old password',
      name: 'QSRJMM',
      desc: '',
      args: [],
    );
  }

  /// `new password`
  String get XMM {
    return Intl.message(
      'new password',
      name: 'XMM',
      desc: '',
      args: [],
    );
  }

  /// `Please enter a new password`
  String get QSRXMM {
    return Intl.message(
      'Please enter a new password',
      name: 'QSRXMM',
      desc: '',
      args: [],
    );
  }

  /// `Confirm the new password`
  String get QRXMM {
    return Intl.message(
      'Confirm the new password',
      name: 'QRXMM',
      desc: '',
      args: [],
    );
  }

  /// `Confirm the new password again`
  String get ZCQRXMM {
    return Intl.message(
      'Confirm the new password again',
      name: 'ZCQRXMM',
      desc: '',
      args: [],
    );
  }

  /// `Avatar`
  String get TX {
    return Intl.message(
      'Avatar',
      name: 'TX',
      desc: '',
      args: [],
    );
  }

  /// `name`
  String get MZ {
    return Intl.message(
      'name',
      name: 'MZ',
      desc: '',
      args: [],
    );
  }

  /// `grade`
  String get DJ {
    return Intl.message(
      'grade',
      name: 'DJ',
      desc: '',
      args: [],
    );
  }

  /// `Phone number`
  String get SJH {
    return Intl.message(
      'Phone number',
      name: 'SJH',
      desc: '',
      args: [],
    );
  }

  /// `Enter the modified phone number`
  String get SRXGDSJH {
    return Intl.message(
      'Enter the modified phone number',
      name: 'SRXGDSJH',
      desc: '',
      args: [],
    );
  }

  /// `Position details`
  String get CHMX {
    return Intl.message(
      'Position details',
      name: 'CHMX',
      desc: '',
      args: [],
    );
  }

  /// `Historical details`
  String get LSMX {
    return Intl.message(
      'Historical details',
      name: 'LSMX',
      desc: '',
      args: [],
    );
  }

  /// `position`
  String get CHIC {
    return Intl.message(
      'position',
      name: 'CHIC',
      desc: '',
      args: [],
    );
  }

  /// `buy up`
  String get BUYZ {
    return Intl.message(
      'buy up',
      name: 'BUYZ',
      desc: '',
      args: [],
    );
  }

  /// `buy down`
  String get MD {
    return Intl.message(
      'buy down',
      name: 'MD',
      desc: '',
      args: [],
    );
  }

  /// `More`
  String get GD {
    return Intl.message(
      'More',
      name: 'GD',
      desc: '',
      args: [],
    );
  }

  /// `optional`
  String get ZX {
    return Intl.message(
      'optional',
      name: 'ZX',
      desc: '',
      args: [],
    );
  }

  /// `Add optional`
  String get TJZX {
    return Intl.message(
      'Add optional',
      name: 'TJZX',
      desc: '',
      args: [],
    );
  }

  /// `Please enter password`
  String get QSRMM {
    return Intl.message(
      'Please enter password',
      name: 'QSRMM',
      desc: '',
      args: [],
    );
  }

  /// `no account yet`
  String get HMZH {
    return Intl.message(
      'no account yet',
      name: 'HMZH',
      desc: '',
      args: [],
    );
  }

  /// `Sign up now`
  String get ZWS {
    return Intl.message(
      'Sign up now',
      name: 'ZWS',
      desc: '',
      args: [],
    );
  }

  /// `Log in`
  String get DL {
    return Intl.message(
      'Log in',
      name: 'DL',
      desc: '',
      args: [],
    );
  }

  /// `register`
  String get XZC {
    return Intl.message(
      'register',
      name: 'XZC',
      desc: '',
      args: [],
    );
  }

  /// `country / region`
  String get GJDQ {
    return Intl.message(
      'country / region',
      name: 'GJDQ',
      desc: '',
      args: [],
    );
  }

  /// `password`
  String get MM {
    return Intl.message(
      'password',
      name: 'MM',
      desc: '',
      args: [],
    );
  }

  /// `Withdrawal password`
  String get THXM {
    return Intl.message(
      'Withdrawal password',
      name: 'THXM',
      desc: '',
      args: [],
    );
  }

  /// `Confirm Password`
  String get QRMM {
    return Intl.message(
      'Confirm Password',
      name: 'QRMM',
      desc: '',
      args: [],
    );
  }

  /// `Referral code`
  String get TJM {
    return Intl.message(
      'Referral code',
      name: 'TJM',
      desc: '',
      args: [],
    );
  }

  /// `set region`
  String get SZDQ {
    return Intl.message(
      'set region',
      name: 'SZDQ',
      desc: '',
      args: [],
    );
  }

  /// `A friend invited you to join`
  String get DHYYQJR {
    return Intl.message(
      'A friend invited you to join',
      name: 'DHYYQJR',
      desc: '',
      args: [],
    );
  }

  /// `Invitation code`
  String get DYQM {
    return Intl.message(
      'Invitation code',
      name: 'DYQM',
      desc: '',
      args: [],
    );
  }

  /// `Copy the invitation code`
  String get FZYQM {
    return Intl.message(
      'Copy the invitation code',
      name: 'FZYQM',
      desc: '',
      args: [],
    );
  }

  /// `Copy to clipboard`
  String get DFZDJQB {
    return Intl.message(
      'Copy to clipboard',
      name: 'DFZDJQB',
      desc: '',
      args: [],
    );
  }

  /// `has been copied successfully`
  String get YJFZCG {
    return Intl.message(
      'has been copied successfully',
      name: 'YJFZCG',
      desc: '',
      args: [],
    );
  }

  /// `invite friends`
  String get DYQHY {
    return Intl.message(
      'invite friends',
      name: 'DYQHY',
      desc: '',
      args: [],
    );
  }

  /// `Please select an area code!`
  String get DQXZQH {
    return Intl.message(
      'Please select an area code!',
      name: 'DQXZQH',
      desc: '',
      args: [],
    );
  }

  /// `The account number and password cannot be empty!`
  String get DZHMMBNWK {
    return Intl.message(
      'The account number and password cannot be empty!',
      name: 'DZHMMBNWK',
      desc: '',
      args: [],
    );
  }

  /// `Please select a country`
  String get DXZGJDQ {
    return Intl.message(
      'Please select a country',
      name: 'DXZGJDQ',
      desc: '',
      args: [],
    );
  }

  /// `please enter user name`
  String get DSRYHM {
    return Intl.message(
      'please enter user name',
      name: 'DSRYHM',
      desc: '',
      args: [],
    );
  }

  /// `The phone number cannot be empty!`
  String get SJHBNWK {
    return Intl.message(
      'The phone number cannot be empty!',
      name: 'SJHBNWK',
      desc: '',
      args: [],
    );
  }

  /// `Username can not be empty`
  String get YHMBNWK {
    return Intl.message(
      'Username can not be empty',
      name: 'YHMBNWK',
      desc: '',
      args: [],
    );
  }

  /// `password can not be blank!`
  String get MMBNWK {
    return Intl.message(
      'password can not be blank!',
      name: 'MMBNWK',
      desc: '',
      args: [],
    );
  }

  /// `confirm password can not be blank!`
  String get QRMMBNWK {
    return Intl.message(
      'confirm password can not be blank!',
      name: 'QRMMBNWK',
      desc: '',
      args: [],
    );
  }

  /// `Withdrawal password cannot be empty!`
  String get TXMMBNWK {
    return Intl.message(
      'Withdrawal password cannot be empty!',
      name: 'TXMMBNWK',
      desc: '',
      args: [],
    );
  }

  /// `as your login account`
  String get ZWNDDLZH {
    return Intl.message(
      'as your login account',
      name: 'ZWNDDLZH',
      desc: '',
      args: [],
    );
  }

  /// `username`
  String get DYHM {
    return Intl.message(
      'username',
      name: 'DYHM',
      desc: '',
      args: [],
    );
  }

  /// `Please enter the password again`
  String get QZSRMM {
    return Intl.message(
      'Please enter the password again',
      name: 'QZSRMM',
      desc: '',
      args: [],
    );
  }

  /// `Please enter a 6-digit withdrawal password`
  String get SQSRTXMM {
    return Intl.message(
      'Please enter a 6-digit withdrawal password',
      name: 'SQSRTXMM',
      desc: '',
      args: [],
    );
  }

  /// `Please fill in the referral code`
  String get QTXTJM {
    return Intl.message(
      'Please fill in the referral code',
      name: 'QTXTJM',
      desc: '',
      args: [],
    );
  }

  /// `Station letter`
  String get ZNX {
    return Intl.message(
      'Station letter',
      name: 'ZNX',
      desc: '',
      args: [],
    );
  }

  /// `set up`
  String get SETING {
    return Intl.message(
      'set up',
      name: 'SETING',
      desc: '',
      args: [],
    );
  }

  /// `Service`
  String get KF {
    return Intl.message(
      'Service',
      name: 'KF',
      desc: '',
      args: [],
    );
  }

  /// `Still can't solve click`
  String get RRWFDJ {
    return Intl.message(
      'Still can\'t solve click',
      name: 'RRWFDJ',
      desc: '',
      args: [],
    );
  }

  /// `product name`
  String get SPMC {
    return Intl.message(
      'product name',
      name: 'SPMC',
      desc: '',
      args: [],
    );
  }

  /// `Latest price`
  String get ZXJ {
    return Intl.message(
      'Latest price',
      name: 'ZXJ',
      desc: '',
      args: [],
    );
  }

  /// `24 hour increase`
  String get ERZF {
    return Intl.message(
      '24 hour increase',
      name: 'ERZF',
      desc: '',
      args: [],
    );
  }

  /// `Highest`
  String get DZG {
    return Intl.message(
      'Highest',
      name: 'DZG',
      desc: '',
      args: [],
    );
  }

  /// `lowest`
  String get DZD {
    return Intl.message(
      'lowest',
      name: 'DZD',
      desc: '',
      args: [],
    );
  }

  /// `24 hour volume`
  String get ESCJL {
    return Intl.message(
      '24 hour volume',
      name: 'ESCJL',
      desc: '',
      args: [],
    );
  }

  /// `current price`
  String get DXJ {
    return Intl.message(
      'current price',
      name: 'DXJ',
      desc: '',
      args: [],
    );
  }

  /// `direction`
  String get DFX {
    return Intl.message(
      'direction',
      name: 'DFX',
      desc: '',
      args: [],
    );
  }

  /// `strike price`
  String get DZXJ {
    return Intl.message(
      'strike price',
      name: 'DZXJ',
      desc: '',
      args: [],
    );
  }

  /// `expected profits`
  String get YQSY {
    return Intl.message(
      'expected profits',
      name: 'YQSY',
      desc: '',
      args: [],
    );
  }

  /// `closure`
  String get DGB {
    return Intl.message(
      'closure',
      name: 'DGB',
      desc: '',
      args: [],
    );
  }

  /// `Order Confirmation`
  String get DDQR {
    return Intl.message(
      'Order Confirmation',
      name: 'DDQR',
      desc: '',
      args: [],
    );
  }

  /// `Expire date`
  String get DQSJ {
    return Intl.message(
      'Expire date',
      name: 'DQSJ',
      desc: '',
      args: [],
    );
  }

  /// `investment amount`
  String get TZJE {
    return Intl.message(
      'investment amount',
      name: 'TZJE',
      desc: '',
      args: [],
    );
  }

  /// `Handling fee:`
  String get SXF {
    return Intl.message(
      'Handling fee:',
      name: 'SXF',
      desc: '',
      args: [],
    );
  }

  /// `name`
  String get DMC {
    return Intl.message(
      'name',
      name: 'DMC',
      desc: '',
      args: [],
    );
  }

  /// `Build a position`
  String get DJC {
    return Intl.message(
      'Build a position',
      name: 'DJC',
      desc: '',
      args: [],
    );
  }

  /// `expected profits:`
  String get DYQSY {
    return Intl.message(
      'expected profits:',
      name: 'DYQSY',
      desc: '',
      args: [],
    );
  }

  /// `income`
  String get DSY {
    return Intl.message(
      'income',
      name: 'DSY',
      desc: '',
      args: [],
    );
  }

  /// `15 points`
  String get DSWF {
    return Intl.message(
      '15 points',
      name: 'DSWF',
      desc: '',
      args: [],
    );
  }

  /// `day line`
  String get DRX {
    return Intl.message(
      'day line',
      name: 'DRX',
      desc: '',
      args: [],
    );
  }

  /// `1 point`
  String get DONEF {
    return Intl.message(
      '1 point',
      name: 'DONEF',
      desc: '',
      args: [],
    );
  }

  /// `5 points`
  String get DFF {
    return Intl.message(
      '5 points',
      name: 'DFF',
      desc: '',
      args: [],
    );
  }

  /// `30 points`
  String get DSSF {
    return Intl.message(
      '30 points',
      name: 'DSSF',
      desc: '',
      args: [],
    );
  }

  /// `main image`
  String get ZZT {
    return Intl.message(
      'main image',
      name: 'ZZT',
      desc: '',
      args: [],
    );
  }

  /// `yesterday's earnings`
  String get ZRSY {
    return Intl.message(
      'yesterday\'s earnings',
      name: 'ZRSY',
      desc: '',
      args: [],
    );
  }

  /// `sign out`
  String get LOGOUT {
    return Intl.message(
      'sign out',
      name: 'LOGOUT',
      desc: '',
      args: [],
    );
  }

  /// `Notice`
  String get DTZ {
    return Intl.message(
      'Notice',
      name: 'DTZ',
      desc: '',
      args: [],
    );
  }

  /// `amount`
  String get DJR {
    return Intl.message(
      'amount',
      name: 'DJR',
      desc: '',
      args: [],
    );
  }

  /// `balance`
  String get DYE {
    return Intl.message(
      'balance',
      name: 'DYE',
      desc: '',
      args: [],
    );
  }

  /// `time`
  String get DFS {
    return Intl.message(
      'time',
      name: 'DFS',
      desc: '',
      args: [],
    );
  }

  /// `1 hour`
  String get DONEXS {
    return Intl.message(
      '1 hour',
      name: 'DONEXS',
      desc: '',
      args: [],
    );
  }

  /// `Minimum single withdrawal amount`
  String get DNBJEDSQ {
    return Intl.message(
      'Minimum single withdrawal amount',
      name: 'DNBJEDSQ',
      desc: '',
      args: [],
    );
  }

  /// `money`
  String get DNYQ {
    return Intl.message(
      'money',
      name: 'DNYQ',
      desc: '',
      args: [],
    );
  }

  /// `Withdrawal time is daily`
  String get CJSJWMR {
    return Intl.message(
      'Withdrawal time is daily',
      name: 'CJSJWMR',
      desc: '',
      args: [],
    );
  }

  /// `arrive`
  String get DZHI {
    return Intl.message(
      'arrive',
      name: 'DZHI',
      desc: '',
      args: [],
    );
  }

  /// `Support bank cards, Alipay, wechat, etc. easy and fast`
  String get ZCYHKMORE {
    return Intl.message(
      'Support bank cards, Alipay, wechat, etc. easy and fast',
      name: 'ZCYHKMORE',
      desc: '',
      args: [],
    );
  }

  /// `Quick recharge`
  String get KJCZ {
    return Intl.message(
      'Quick recharge',
      name: 'KJCZ',
      desc: '',
      args: [],
    );
  }

  /// `selling price`
  String get DMCJG {
    return Intl.message(
      'selling price',
      name: 'DMCJG',
      desc: '',
      args: [],
    );
  }

  /// `sell`
  String get DMCA {
    return Intl.message(
      'sell',
      name: 'DMCA',
      desc: '',
      args: [],
    );
  }

  /// `buy price`
  String get DMRJG {
    return Intl.message(
      'buy price',
      name: 'DMRJG',
      desc: '',
      args: [],
    );
  }

  /// `buy`
  String get DMRA {
    return Intl.message(
      'buy',
      name: 'DMRA',
      desc: '',
      args: [],
    );
  }

  /// `network connection failed`
  String get WLLJSB {
    return Intl.message(
      'network connection failed',
      name: 'WLLJSB',
      desc: '',
      args: [],
    );
  }

  /// `hint`
  String get WLTS {
    return Intl.message(
      'hint',
      name: 'WLTS',
      desc: '',
      args: [],
    );
  }

  /// `Retry`
  String get WLCS {
    return Intl.message(
      'Retry',
      name: 'WLCS',
      desc: '',
      args: [],
    );
  }

  /// `settlement time`
  String get JSSJ {
    return Intl.message(
      'settlement time',
      name: 'JSSJ',
      desc: '',
      args: [],
    );
  }

  /// `Verified`
  String get Verified {
    return Intl.message(
      'Verified',
      name: 'Verified',
      desc: '',
      args: [],
    );
  }

  /// `actual name`
  String get ZSXM {
    return Intl.message(
      'actual name',
      name: 'ZSXM',
      desc: '',
      args: [],
    );
  }

  /// `identity number`
  String get SFZH {
    return Intl.message(
      'identity number',
      name: 'SFZH',
      desc: '',
      args: [],
    );
  }

  /// `Please enter identification number`
  String get QSRSFZH {
    return Intl.message(
      'Please enter identification number',
      name: 'QSRSFZH',
      desc: '',
      args: [],
    );
  }

  /// `please enter your real name`
  String get QSRZSXM {
    return Intl.message(
      'please enter your real name',
      name: 'QSRZSXM',
      desc: '',
      args: [],
    );
  }

  /// `Are you sure you want to clear？`
  String get QCLTJL {
    return Intl.message(
      'Are you sure you want to clear？',
      name: 'QCLTJL',
      desc: '',
      args: [],
    );
  }

  /// `Cancel`
  String get DCQX {
    return Intl.message(
      'Cancel',
      name: 'DCQX',
      desc: '',
      args: [],
    );
  }

  /// `Sure`
  String get DQD {
    return Intl.message(
      'Sure',
      name: 'DQD',
      desc: '',
      args: [],
    );
  }

  /// `2 different passwords`
  String get TECMMBYY {
    return Intl.message(
      '2 different passwords',
      name: 'TECMMBYY',
      desc: '',
      args: [],
    );
  }

  /// `Change payment password`
  String get XIUGZFMM {
    return Intl.message(
      'Change payment password',
      name: 'XIUGZFMM',
      desc: '',
      args: [],
    );
  }

  /// `Change`
  String get XIUGAI {
    return Intl.message(
      'Change',
      name: 'XIUGAI',
      desc: '',
      args: [],
    );
  }

  /// `Successfully modified`
  String get XGCG {
    return Intl.message(
      'Successfully modified',
      name: 'XGCG',
      desc: '',
      args: [],
    );
  }

  /// `Modify login password`
  String get XGDLMM {
    return Intl.message(
      'Modify login password',
      name: 'XGDLMM',
      desc: '',
      args: [],
    );
  }

  /// `ID photo cannot be empty`
  String get SFZZPBNWK {
    return Intl.message(
      'ID photo cannot be empty',
      name: 'SFZZPBNWK',
      desc: '',
      args: [],
    );
  }

  /// `Please upload the front and back of your ID card`
  String get QSCSFZZFM {
    return Intl.message(
      'Please upload the front and back of your ID card',
      name: 'QSCSFZZFM',
      desc: '',
      args: [],
    );
  }

  /// `Avatar face`
  String get XTM {
    return Intl.message(
      'Avatar face',
      name: 'XTM',
      desc: '',
      args: [],
    );
  }

  /// `Upload your ID photo face`
  String get QSCNDTXM {
    return Intl.message(
      'Upload your ID photo face',
      name: 'QSCNDTXM',
      desc: '',
      args: [],
    );
  }

  /// `back`
  String get DBM {
    return Intl.message(
      'back',
      name: 'DBM',
      desc: '',
      args: [],
    );
  }

  /// `Upload the back of your ID`
  String get QSSCNDBM {
    return Intl.message(
      'Upload the back of your ID',
      name: 'QSSCNDBM',
      desc: '',
      args: [],
    );
  }

  /// `List of bank cards`
  String get YHKLB {
    return Intl.message(
      'List of bank cards',
      name: 'YHKLB',
      desc: '',
      args: [],
    );
  }

  /// `Details`
  String get QXIANQING {
    return Intl.message(
      'Details',
      name: 'QXIANQING',
      desc: '',
      args: [],
    );
  }

  /// `Web page`
  String get QWANGYE {
    return Intl.message(
      'Web page',
      name: 'QWANGYE',
      desc: '',
      args: [],
    );
  }

  /// `see more`
  String get CKGD {
    return Intl.message(
      'see more',
      name: 'CKGD',
      desc: '',
      args: [],
    );
  }

  /// `under review`
  String get SHZ {
    return Intl.message(
      'under review',
      name: 'SHZ',
      desc: '',
      args: [],
    );
  }

  /// `Review succeeded`
  String get SHCG {
    return Intl.message(
      'Review succeeded',
      name: 'SHCG',
      desc: '',
      args: [],
    );
  }

  /// `Audit failure`
  String get SHSB {
    return Intl.message(
      'Audit failure',
      name: 'SHSB',
      desc: '',
      args: [],
    );
  }

  /// `Please select a bank`
  String get QXZYH {
    return Intl.message(
      'Please select a bank',
      name: 'QXZYH',
      desc: '',
      args: [],
    );
  }
}

class AppLocalizationDelegate extends LocalizationsDelegate<S> {
  const AppLocalizationDelegate();

  List<Locale> get supportedLocales {
    return const <Locale>[
      Locale.fromSubtags(languageCode: 'en'),
      Locale.fromSubtags(languageCode: 'ja', countryCode: 'JP'),
      Locale.fromSubtags(languageCode: 'vi', countryCode: 'VN'),
      Locale.fromSubtags(languageCode: 'zh'),
      Locale.fromSubtags(languageCode: 'zh', countryCode: 'TW'),
    ];
  }

  @override
  bool isSupported(Locale locale) => _isSupported(locale);
  @override
  Future<S> load(Locale locale) => S.load(locale);
  @override
  bool shouldReload(AppLocalizationDelegate old) => false;

  bool _isSupported(Locale locale) {
    if (locale != null) {
      for (var supportedLocale in supportedLocales) {
        if (supportedLocale.languageCode == locale.languageCode) {
          return true;
        }
      }
    }
    return false;
  }
}