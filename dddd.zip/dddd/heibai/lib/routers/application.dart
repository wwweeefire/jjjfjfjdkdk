import 'package:fluro/fluro.dart';
// import 'package:flutter/cupertino.dart';

class Application {
  static FluroRouter router;
}
