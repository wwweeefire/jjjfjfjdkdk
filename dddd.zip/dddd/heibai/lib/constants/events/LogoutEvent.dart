
class LogoutEvent {

}