class LoginEvent {}
