
class SlideEvent {
  int index;
  SlideEvent(this.index);
}