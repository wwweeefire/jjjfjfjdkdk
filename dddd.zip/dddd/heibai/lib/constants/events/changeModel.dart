import '/Classes/model/homeListModel.dart';

class changeModel {
  Product model;

  changeModel(this.model);
}
