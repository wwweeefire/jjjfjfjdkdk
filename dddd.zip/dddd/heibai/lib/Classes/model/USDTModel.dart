// To parse this JSON data, do
//
//     final usdtModel = usdtModelFromJson(jsonString);

import 'dart:convert';

List<UsdtModel> usdtModelFromJson(String str) => List<UsdtModel>.from(json.decode(str).map((x) => UsdtModel.fromJson(x)));

String usdtModelToJson(List<UsdtModel> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class UsdtModel {
    UsdtModel({
        this.address,
        this.id,
        this.proto,
    });

    String address;
    int id;
    int proto;

    factory UsdtModel.fromJson(Map<String, dynamic> json) => UsdtModel(
        address: json["address"],
        id: json["id"],
        proto: json["proto"],
    );

    Map<String, dynamic> toJson() => {
        "address": address,
        "id": id,
        "proto": proto,
    };
}
