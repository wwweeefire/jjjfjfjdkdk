// To parse this JSON data, do
//
//     final rechargeallrecordModel = rechargeallrecordModelFromJson(jsonString);

import 'dart:convert';

RechargeallrecordModel rechargeallrecordModelFromJson(String str) =>
    RechargeallrecordModel.fromJson(json.decode(str));

String rechargeallrecordModelToJson(RechargeallrecordModel data) =>
    json.encode(data.toJson());

class RechargeallrecordModel {
  RechargeallrecordModel({
    this.list,
    this.page,
  });

  List<ListElement> list;
  Page page;

  factory RechargeallrecordModel.fromJson(Map<String, dynamic> json) =>
      RechargeallrecordModel(
        list: List<ListElement>.from(
            json["list"].map((x) => ListElement.fromJson(x))),
        page: Page.fromJson(json["page"]),
      );

  Map<String, dynamic> toJson() => {
        "list": List<dynamic>.from(list.map((x) => x.toJson())),
        "page": page.toJson(),
      };
}

class ListElement {
  ListElement({
    this.id,
    this.orderSn,
    this.type,
    this.typeName,
    this.amount,
    this.totalamount,
    this.remarks,
    this.from,
    this.to,
    this.voucher,
    this.status,
    this.updateTime,
    this.createTime,
  });

  int id;
  String orderSn;
  int type;
  String typeName;
  double amount;
  double totalamount;
  String remarks;
  String from;
  String to;
  String voucher;
  int status;
  int updateTime;
  int createTime;

  factory ListElement.fromJson(Map<String, dynamic> json) => ListElement(
        id: json["id"],
        orderSn: json["order_sn"],
        type: json["type"],
        typeName: json["type_name"],
        amount: json["amount"].toDouble(),
        totalamount: json["total_amount"] == null
            ? null
            : json["total_amount"].toDouble(),
        remarks: json["remarks"],
        from: json["from"],
        to: json["to"],
        voucher: json["voucher"],
        status: json["status"],
        updateTime: json["update_time"],
        createTime: json["create_time"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "order_sn": orderSn,
        "type": type,
        "type_name": typeName,
        "amount": amount,
        "real_amount": totalamount,
        "remarks": remarks,
        "from": from,
        "to": to,
        "voucher": voucher,
        "status": status,
        "update_time": updateTime,
        "create_time": createTime,
      };
}

class Page {
  Page({
    this.page,
    this.pageSize,
    this.record,
    this.total,
  });

  int page;
  int pageSize;
  int record;
  int total;

  factory Page.fromJson(Map<String, dynamic> json) => Page(
        page: json["page"],
        pageSize: json["page_size"],
        record: json["record"],
        total: json["total"],
      );

  Map<String, dynamic> toJson() => {
        "page": page,
        "page_size": pageSize,
        "record": record,
        "total": total,
      };
}
