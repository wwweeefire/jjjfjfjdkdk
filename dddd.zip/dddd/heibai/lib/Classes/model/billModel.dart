// To parse this JSON data, do
//
//     final biilModel = biilModelFromJson(jsonString);

import 'dart:convert';

BiilModel biilModelFromJson(String str) => BiilModel.fromJson(json.decode(str));

String biilModelToJson(BiilModel data) => json.encode(data.toJson());

class BiilModel {
  BiilModel({
    this.list,
    this.page,
  });

  List<ListElement> list;
  Page page;

  factory BiilModel.fromJson(Map<String, dynamic> json) => BiilModel(
        list: List<ListElement>.from(
            json["list"].map((x) => ListElement.fromJson(x))),
        page: Page.fromJson(json["page"]),
      );

  Map<String, dynamic> toJson() => {
        "list": List<dynamic>.from(list.map((x) => x.toJson())),
        "page": page.toJson(),
      };
}

class ListElement {
  ListElement({
    this.after,
    this.amount,
    this.before,
    this.createTime,
    this.id,
    this.typeName,
  });

  double after;
  double amount;
  double before;
  int createTime;
  int id;
  String typeName;

  factory ListElement.fromJson(Map<String, dynamic> json) => ListElement(
        after: json["after"],
        amount: json["amount"],
        before: json["before"],
        createTime: json["create_time"],
        id: json["id"],
        typeName: json["type_name"],
      );

  Map<String, dynamic> toJson() => {
        "after": after,
        "amount": amount,
        "before": before,
        "create_time": createTime,
        "id": id,
        "type_name": typeName,
      };
}

class Page {
  Page({
    this.page,
    this.pageSize,
    this.record,
    this.total,
  });

  int page;
  int pageSize;
  int record;
  int total;

  factory Page.fromJson(Map<String, dynamic> json) => Page(
        page: json["page"],
        pageSize: json["page_size"],
        record: json["record"],
        total: json["total"],
      );

  Map<String, dynamic> toJson() => {
        "page": page,
        "page_size": pageSize,
        "record": record,
        "total": total,
      };
}
