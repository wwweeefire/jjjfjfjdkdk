// To parse this JSON data, do
//
//     final nProduct = nProductFromJson(jsonString);

import 'dart:convert';

NProduct nProductFromJson(String str) => NProduct.fromJson(json.decode(str));

String nProductToJson(NProduct data) => json.encode(data.toJson());

class NProduct {
  NProduct({
    this.id,
    this.code,
    this.open,
    this.close,
    this.price,
    this.high,
    this.low,
    this.vol,
    this.change,
    this.createTime,
    this.updateTime,
  });

  int id;
  String code;
  double open;
  double close;
  double price;
  double high;
  double low;
  int vol;
  double change;
  int createTime;
  int updateTime;

  factory NProduct.fromJson(Map<String, dynamic> json) => NProduct(
        id: json["ID"],
        code: json["Code"],
        open: json["Open"].toDouble(),
        close: json["Close"].toDouble(),
        price: json["Price"].toDouble(),
        high: json["High"].toDouble(),
        low: json["Low"].toDouble(),
        vol: json["Vol"],
        change: json["Change"].toDouble(),
        createTime: json["CreateTime"],
        updateTime: json["UpdateTime"],
      );

  Map<String, dynamic> toJson() => {
        "ID": id,
        "Code": code,
        "Open": open,
        "Close": close,
        "Price": price,
        "High": high,
        "Low": low,
        "Vol": vol,
        "Change": change,
        "CreateTime": createTime,
        "UpdateTime": updateTime,
      };
}
