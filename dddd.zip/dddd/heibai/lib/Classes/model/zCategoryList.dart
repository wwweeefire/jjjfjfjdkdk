// To parse this JSON data, do
//
//     final zCategoryList = zCategoryListFromJson(jsonString);

import 'dart:convert';

ZCategoryList zCategoryListFromJson(String str) =>
    ZCategoryList.fromJson(json.decode(str));

String zCategoryListToJson(ZCategoryList data) => json.encode(data.toJson());

class ZCategoryList {
  ZCategoryList({
    this.list,
  });

  List<zListElement> list;

  factory ZCategoryList.fromJson(Map<String, dynamic> json) => ZCategoryList(
        list: List<zListElement>.from(
            json["list"].map((x) => zListElement.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "list": List<dynamic>.from(list.map((x) => x.toJson())),
      };
}

class zListElement {
  zListElement({
    this.id,
    this.code,
    this.name,
    this.wave,
    this.openTime,
    this.weekendTrading,
    this.open,
    this.price,
    this.low,
    this.high,
    this.change,
    this.vol,
  });

  int id;
  String code;
  String name;
  double wave;
  String openTime;
  int weekendTrading;
  double open;
  double price;
  double low;
  double high;
  double change;
  int vol;

  factory zListElement.fromJson(Map<String, dynamic> json) => zListElement(
        id: json["id"],
        code: json["code"],
        name: json["name"],
        wave: json["wave"].toDouble(),
        openTime: json["open_time"],
        weekendTrading: json["weekend_trading"],
        open: json["open"].toDouble(),
        price: json["price"].toDouble(),
        low: json["low"].toDouble(),
        high: json["high"].toDouble(),
        change: json["change"].toDouble(),
        vol: json["vol"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "code": code,
        "name": name,
        "wave": wave,
        "open_time": openTime,
        "weekend_trading": weekendTrading,
        "open": open,
        "price": price,
        "low": low,
        "high": high,
        "change": change,
        "vol": vol,
      };
}
