// To parse this JSON data, do
//
//     final level = levelFromJson(jsonString);

import 'dart:convert';

Level levelFromJson(String str) => Level.fromJson(json.decode(str));

String levelToJson(Level data) => json.encode(data.toJson());

class Level {
  Level({
    this.list,
  });

  List<ListElement> list;

  factory Level.fromJson(Map<String, dynamic> json) => Level(
        list: List<ListElement>.from(
            json["list"].map((x) => ListElement.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "list": List<dynamic>.from(list.map((x) => x.toJson())),
      };
}

class ListElement {
  ListElement({
    this.id,
    this.img,
    this.name,
  });

  int id;
  String img;
  String name;

  factory ListElement.fromJson(Map<String, dynamic> json) => ListElement(
        id: json["id"],
        img: json["img"],
        name: json["name"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "img": img,
        "name": name,
      };
}
