import 'dart:convert';

Productoption productoptionFromJson(String str) =>
    Productoption.fromJson(json.decode(str));

String productoptionToJson(Productoption data) => json.encode(data.toJson());

class Productoption {
  Productoption({
    this.interval,
    this.ratio,
    this.quick,
    this.fee,
  });

  List<int> interval;
  List<int> ratio;
  List<int> quick;
  int fee;

  factory Productoption.fromJson(Map<String, dynamic> json) => Productoption(
        interval: List<int>.from(json["interval"].map((x) => x)),
        ratio: List<int>.from(json["ratio"].map((x) => x)),
        quick: List<int>.from(json["quick"].map((x) => x)),
        fee: json["fee"],
      );

  Map<String, dynamic> toJson() => {
        "interval": List<dynamic>.from(interval.map((x) => x)),
        "ratio": List<dynamic>.from(ratio.map((x) => x)),
        "quick": List<dynamic>.from(quick.map((x) => x)),
        "fee": fee,
      };
}
