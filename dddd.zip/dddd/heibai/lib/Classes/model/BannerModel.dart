// To parse this JSON data, do
//
//     final bannerModel = bannerModelFromJson(jsonString);

import 'dart:convert';

BannerModel bannerModelFromJson(String str) =>
    BannerModel.fromJson(json.decode(str));

String bannerModelToJson(BannerModel data) => json.encode(data.toJson());

class BannerModel {
  BannerModel({
    this.banner,
    this.notice,
  });

  List<Banner> banner;
  Notice notice;

  factory BannerModel.fromJson(Map<String, dynamic> json) => BannerModel(
        banner: json["banner"] == null
            ? null
            : List<Banner>.from(json["banner"].map((x) => Banner.fromJson(x))),
        notice: Notice.fromJson(json["notice"]),
      );

  Map<String, dynamic> toJson() => {
        "banner": List<dynamic>.from(banner.map((x) => x.toJson())),
        "notice": notice.toJson(),
      };
}

class Banner {
  Banner({
    this.image,
    this.link,
  });

  String image;
  String link;

  factory Banner.fromJson(Map<String, dynamic> json) => Banner(
        image: json["image"],
        link: json["link"],
      );

  Map<String, dynamic> toJson() => {
        "image": image,
        "link": link,
      };
}

class Notice {
  Notice({
    this.pop,
    this.roll,
  });

  Pop pop;
  Pop roll;

  factory Notice.fromJson(Map<String, dynamic> json) => Notice(
        pop: json["pop"] == null ? null : Pop.fromJson(json["pop"]),
        roll: json["roll"] == null ? null : Pop.fromJson(json["roll"]),
      );

  Map<String, dynamic> toJson() => {
        "pop": pop.toJson(),
        "roll": roll.toJson(),
      };
}

class Pop {
  Pop({
    this.id,
    this.title,
    this.intro,
    this.content,
    this.lang,
    this.createTime,
  });

  int id;
  String title;
  String intro;
  String content;
  String lang;
  int createTime;

  factory Pop.fromJson(Map<String, dynamic> json) => Pop(
        id: json["id"],
        title: json["title"],
        intro: json["intro"],
        content: json["content"],
        lang: json["lang"],
        createTime: json["create_time"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "intro": intro,
        "content": content,
        "lang": lang,
        "create_time": createTime,
      };
}
