

import 'dart:convert';

List<ThirdParty> thirdPartyFromJson(String str) => List<ThirdParty>.from(json.decode(str).map((x) => ThirdParty.fromJson(x)));

String thirdPartyToJson(List<ThirdParty> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class ThirdParty {
    ThirdParty({
        this.icon,
        this.id,
        this.max,
        this.min,
        this.name,
    });

    String icon;
    int id;
    int max;
    int min;
    String name;

    factory ThirdParty.fromJson(Map<String, dynamic> json) => ThirdParty(
        icon: json["icon"],
        id: json["id"],
        max: json["max"],
        min: json["min"],
        name: json["name"],
    );

    Map<String, dynamic> toJson() => {
        "icon": icon,
        "id": id,
        "max": max,
        "min": min,
        "name": name,
    };
}
