// To parse this JSON data, do
//
//     final homeListModel = homeListModelFromJson(jsonString);

import 'dart:convert';

HomeListModel homeListModelFromJson(String str) =>
    HomeListModel.fromJson(json.decode(str));

String homeListModelToJson(HomeListModel data) => json.encode(data.toJson());

class HomeListModel {
  HomeListModel({
    this.category,
  });

  List<Category> category;

  factory HomeListModel.fromJson(Map<String, dynamic> json) => HomeListModel(
        category: List<Category>.from(
            json["category"].map((x) => Category.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "category": List<dynamic>.from(category.map((x) => x.toJson())),
      };
}

class Category {
  Category({
    this.id,
    this.name,
    this.product,
  });

  int id;
  String name;
  List<Product> product;

  factory Category.fromJson(Map<String, dynamic> json) => Category(
        id: json["id"],
        name: json["name"],
        product:
            List<Product>.from(json["product"].map((x) => Product.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "product": List<dynamic>.from(product.map((x) => x.toJson())),
      };
}

class Product {
  Product({
    this.id,
    this.code,
    this.name,
    this.wave,
    this.openTime,
    this.weekendTrading,
    this.open,
    this.price,
    this.low,
    this.high,
    this.change,
    this.vol,
  });

  int id;
  String code;
  String name;
  double wave;
  String openTime;
  int weekendTrading;
  double open;
  double price;
  double low;
  double high;
  double change;
  int vol;

  factory Product.fromJson(Map<String, dynamic> json) => Product(
        id: json["id"],
        code: json["code"],
        name: json["name"],
        wave: json["wave"].toDouble(),
        openTime: json["open_time"],
        weekendTrading: json["weekend_trading"],
        open: json["open"].toDouble(),
        price: json["price"].toDouble(),
        low: json["low"].toDouble(),
        high: json["high"].toDouble(),
        change: json["change"].toDouble(),
        vol: json["vol"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "code": code,
        "name": name,
        "wave": wave,
        "open_time": openTime,
        "weekend_trading": weekendTrading,
        "open": open,
        "price": price,
        "low": low,
        "high": high,
        "change": change,
        "vol": vol,
      };
}
