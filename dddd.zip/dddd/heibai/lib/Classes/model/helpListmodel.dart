// To parse this JSON data, do
//
//     final helpListmodel = helpListmodelFromJson(jsonString);

import 'dart:convert';

HelpListmodel helpListmodelFromJson(String str) =>
    HelpListmodel.fromJson(json.decode(str));

String helpListmodelToJson(HelpListmodel data) => json.encode(data.toJson());

class HelpListmodel {
  HelpListmodel({
    this.list,
  });

  List<ListElement> list;

  factory HelpListmodel.fromJson(Map<String, dynamic> json) => HelpListmodel(
        list: List<ListElement>.from(
            json["list"].map((x) => ListElement.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "list": List<dynamic>.from(list.map((x) => x.toJson())),
      };
}

class ListElement {
  ListElement({
    this.id,
    this.title,
    this.content,
    this.createTime,
  });

  int id;
  String title;
  String content;
  int createTime;

  factory ListElement.fromJson(Map<String, dynamic> json) => ListElement(
        id: json["id"],
        title: json["title"],
        content: json["content"],
        createTime: json["create_time"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "content": content,
        "create_time": createTime,
      };
}
