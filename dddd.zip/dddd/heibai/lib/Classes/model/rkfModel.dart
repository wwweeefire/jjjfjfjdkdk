// To parse this JSON data, do
//
//     final rkfModel = rkfModelFromJson(jsonString);

import 'dart:convert';

List<RkfModel> rkfModelFromJson(String str) =>
    List<RkfModel>.from(json.decode(str).map((x) => RkfModel.fromJson(x)));

String rkfModelToJson(List<RkfModel> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class RkfModel {
  RkfModel({
    this.endTime,
    this.id,
    this.link,
    this.name,
    this.startTime,
  });

  String endTime;
  int id;
  String link;
  String name;
  String startTime;

  factory RkfModel.fromJson(Map<String, dynamic> json) => RkfModel(
        endTime: json["end_time"],
        id: json["id"],
        link: json["link"],
        name: json["name"],
        startTime: json["start_time"],
      );

  Map<String, dynamic> toJson() => {
        "end_time": endTime,
        "id": id,
        "link": link,
        "name": name,
        "start_time": startTime,
      };
}
