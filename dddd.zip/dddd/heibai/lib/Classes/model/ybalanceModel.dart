// To parse this JSON data, do
//
//     final ybalanceModel = ybalanceModelFromJson(jsonString);

import 'dart:convert';

YbalanceModel ybalanceModelFromJson(String str) =>
    YbalanceModel.fromJson(json.decode(str));

String ybalanceModelToJson(YbalanceModel data) => json.encode(data.toJson());

class YbalanceModel {
  YbalanceModel({
    this.income,
    this.info,
    this.member,
  });

  Income income;
  Info info;
  Member member;

  factory YbalanceModel.fromJson(Map<String, dynamic> json) => YbalanceModel(
        income: Income.fromJson(json["income"]),
        info: Info.fromJson(json["info"]),
        member: Member.fromJson(json["member"]),
      );

  Map<String, dynamic> toJson() => {
        "income": income.toJson(),
        "info": info.toJson(),
        "member": member.toJson(),
      };
}

class Income {
  Income({
    this.list,
    this.page,
  });

  List<ListElement> list;
  Page page;

  factory Income.fromJson(Map<String, dynamic> json) => Income(
        list: List<ListElement>.from(
            json["list"].map((x) => ListElement.fromJson(x))),
        page: Page.fromJson(json["page"]),
      );

  Map<String, dynamic> toJson() => {
        "list": List<dynamic>.from(list.map((x) => x.toJson())),
        "page": page.toJson(),
      };
}

class ListElement {
  ListElement({
    this.balance,
    this.createTime,
    this.income,
  });

  double balance;
  int createTime;
  double income;

  factory ListElement.fromJson(Map<String, dynamic> json) => ListElement(
        balance: json["balance"].toDouble(),
        createTime: json["create_time"],
        income: json["income"].toDouble(),
      );

  Map<String, dynamic> toJson() => {
        "balance": balance,
        "create_time": createTime,
        "income": income,
      };
}

class Page {
  Page({
    this.page,
    this.pageSize,
    this.record,
    this.total,
  });

  int page;
  int pageSize;
  int record;
  int total;

  factory Page.fromJson(Map<String, dynamic> json) => Page(
        page: json["page"],
        pageSize: json["page_size"],
        record: json["record"],
        total: json["total"],
      );

  Map<String, dynamic> toJson() => {
        "page": page,
        "page_size": pageSize,
        "record": record,
        "total": total,
      };
}

class Info {
  Info({
    this.description,
    this.freezeDay,
    this.incomeInterval,
    this.name,
    this.ratio,
    this.status,
  });

  String description;
  int freezeDay;
  int incomeInterval;
  String name;
  int ratio;
  int status;

  factory Info.fromJson(Map<String, dynamic> json) => Info(
        description: json["description"],
        freezeDay: json["freeze_day"],
        incomeInterval: json["income_interval"],
        name: json["name"],
        ratio: json["ratio"],
        status: json["status"],
      );

  Map<String, dynamic> toJson() => {
        "description": description,
        "freeze_day": freezeDay,
        "income_interval": incomeInterval,
        "name": name,
        "ratio": ratio,
        "status": status,
      };
}

class Member {
  Member({
    this.balance,
    this.totalIncome,
    this.yesterdayIncome,
  });

  double balance;
  double totalIncome;
  double yesterdayIncome;

  factory Member.fromJson(Map<String, dynamic> json) => Member(
        balance: json["balance"].toDouble(),
        totalIncome: json["total_income"].toDouble(),
        yesterdayIncome: json["yesterday_income"].toDouble(),
      );

  Map<String, dynamic> toJson() => {
        "balance": balance,
        "total_income": totalIncome,
        "yesterday_income": yesterdayIncome,
      };
}
