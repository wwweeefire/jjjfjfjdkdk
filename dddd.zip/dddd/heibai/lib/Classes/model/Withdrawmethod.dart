// To parse this JSON data, do
//
//     final withdrawmethod = withdrawmethodFromJson(jsonString);

import 'dart:convert';

Withdrawmethod withdrawmethodFromJson(String str) =>
    Withdrawmethod.fromJson(json.decode(str));

String withdrawmethodToJson(Withdrawmethod data) => json.encode(data.toJson());

class Withdrawmethod {
  Withdrawmethod({
    this.list,
  });

  List<ListElement> list;

  factory Withdrawmethod.fromJson(Map<String, dynamic> json) => Withdrawmethod(
        list: List<ListElement>.from(
            json["list"].map((x) => ListElement.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "list": List<dynamic>.from(list.map((x) => x.toJson())),
      };
}

class ListElement {
  ListElement({
    this.id,
    this.name,
    this.code,
    this.icon,
    this.fee,
  });

  int id;
  String name;
  String code;
  String icon;
  double fee;

  factory ListElement.fromJson(Map<String, dynamic> json) => ListElement(
        id: json["id"],
        name: json["name"],
        code: json["code"],
        icon: json["icon"],
        fee: json["fee"].toDouble(),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "code": code,
        "icon": icon,
        "fee": fee,
      };
}
