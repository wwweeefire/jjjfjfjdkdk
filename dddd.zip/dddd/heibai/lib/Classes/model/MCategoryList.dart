// To parse this JSON data, do
//
//     final mCategoryList = mCategoryListFromJson(jsonString);

import 'dart:convert';

MCategoryList mCategoryListFromJson(String str) =>
    MCategoryList.fromJson(json.decode(str));

String mCategoryListToJson(MCategoryList data) => json.encode(data.toJson());

class MCategoryList {
  MCategoryList({
    this.list,
    this.page,
  });

  List<MListElement> list;
  Page page;

  factory MCategoryList.fromJson(Map<String, dynamic> json) => MCategoryList(
        list: List<MListElement>.from(
            json["list"].map((x) => MListElement.fromJson(x))),
        page: Page.fromJson(json["page"]),
      );

  Map<String, dynamic> toJson() => {
        "list": List<dynamic>.from(list.map((x) => x.toJson())),
        "page": page.toJson(),
      };
}

class MListElement {
  MListElement({
    this.change,
    this.code,
    this.high,
    this.id,
    this.low,
    this.name,
    this.open,
    this.openTime,
    this.price,
    this.vol,
    this.wave,
    this.weekendTrading,
  });

  double change;
  String code;
  double high;
  int id;
  double low;
  String name;
  double open;
  String openTime;
  double price;
  int vol;
  double wave;
  int weekendTrading;

  factory MListElement.fromJson(Map<String, dynamic> json) => MListElement(
        change: json["change"].toDouble(),
        code: json["code"],
        high: json["high"].toDouble(),
        id: json["id"],
        low: json["low"].toDouble(),
        name: json["name"],
        open: json["open"].toDouble(),
        openTime: json["open_time"],
        price: json["price"].toDouble(),
        vol: json["vol"],
        wave: json["wave"].toDouble(),
        weekendTrading: json["weekend_trading"],
      );

  Map<String, dynamic> toJson() => {
        "change": change,
        "code": code,
        "high": high,
        "id": id,
        "low": low,
        "name": name,
        "open": open,
        "open_time": openTime,
        "price": price,
        "vol": vol,
        "wave": wave,
        "weekend_trading": weekendTrading,
      };
}

class Page {
  Page({
    this.page,
    this.pageSize,
    this.record,
    this.total,
  });

  int page;
  int pageSize;
  int record;
  int total;

  factory Page.fromJson(Map<String, dynamic> json) => Page(
        page: json["page"],
        pageSize: json["page_size"],
        record: json["record"],
        total: json["total"],
      );

  Map<String, dynamic> toJson() => {
        "page": page,
        "page_size": pageSize,
        "record": record,
        "total": total,
      };
}
