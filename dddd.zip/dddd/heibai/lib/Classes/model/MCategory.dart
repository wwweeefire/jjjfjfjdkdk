// To parse this JSON data, do
//
//     final mCategory = mCategoryFromJson(jsonString);

import 'dart:convert';

MCategory mCategoryFromJson(String str) => MCategory.fromJson(json.decode(str));

String mCategoryToJson(MCategory data) => json.encode(data.toJson());

class MCategory {
  MCategory({
    this.list,
  });

  List<ListElement> list;

  factory MCategory.fromJson(Map<String, dynamic> json) => MCategory(
        list: List<ListElement>.from(
            json["list"].map((x) => ListElement.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "list": List<dynamic>.from(list.map((x) => x.toJson())),
      };
}

class ListElement {
  ListElement({
    this.id,
    this.name,
  });

  int id;
  String name;

  factory ListElement.fromJson(Map<String, dynamic> json) => ListElement(
        id: json["id"],
        name: json["name"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
      };
}
