// To parse this JSON data, do
//
//     final newListModel = newListModelFromJson(jsonString);

import 'dart:convert';

NewListModel newListModelFromJson(String str) =>
    NewListModel.fromJson(json.decode(str));

String newListModelToJson(NewListModel data) => json.encode(data.toJson());

class NewListModel {
  NewListModel({
    this.list,
    this.page,
  });

  List<ListElement> list;
  Page page;

  factory NewListModel.fromJson(Map<String, dynamic> json) => NewListModel(
        list: List<ListElement>.from(
            json["list"].map((x) => ListElement.fromJson(x))),
        page: Page.fromJson(json["page"]),
      );

  Map<String, dynamic> toJson() => {
        "list": List<dynamic>.from(list.map((x) => x.toJson())),
        "page": page.toJson(),
      };
}

class ListElement {
  ListElement({
    this.id,
    this.title,
    this.content,
    this.sort,
    this.intro,
    this.cover,
    this.createTime,
    this.updateTime,
  });

  int id;
  String title;
  String content;
  int sort;
  String intro;
  String cover;
  int createTime;
  int updateTime;

  factory ListElement.fromJson(Map<String, dynamic> json) => ListElement(
        id: json["id"],
        title: json["title"],
        content: json["content"],
        sort: json["sort"],
        intro: json["intro"],
        cover: json["cover"],
        createTime: json["create_time"],
        updateTime: json["update_time"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "content": content,
        "sort": sort,
        "intro": intro,
        "cover": cover,
        "create_time": createTime,
        "update_time": updateTime,
      };
}

class Page {
  Page({
    this.page,
    this.pageSize,
    this.record,
    this.total,
  });

  int page;
  int pageSize;
  int record;
  int total;

  factory Page.fromJson(Map<String, dynamic> json) => Page(
        page: json["page"],
        pageSize: json["page_size"],
        record: json["record"],
        total: json["total"],
      );

  Map<String, dynamic> toJson() => {
        "page": page,
        "page_size": pageSize,
        "record": record,
        "total": total,
      };
}
