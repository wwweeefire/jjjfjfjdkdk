// To parse this JSON data, do
//
//     final zfbParty = zfbPartyFromJson(jsonString);

import 'dart:convert';

List<ZfbParty> zfbPartyFromJson(String str) =>
    List<ZfbParty>.from(json.decode(str).map((x) => ZfbParty.fromJson(x)));

String zfbPartyToJson(List<ZfbParty> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class ZfbParty {
  ZfbParty({
    this.account,
    this.id,
    this.realName,
  });

  String account;
  int id;
  String realName;

  factory ZfbParty.fromJson(Map<String, dynamic> json) => ZfbParty(
        account: json["account"],
        id: json["id"],
        realName: json["real_name"],
      );

  Map<String, dynamic> toJson() => {
        "account": account,
        "id": id,
        "real_name": realName,
      };
}
