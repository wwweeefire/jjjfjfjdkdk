// To parse this JSON data, do
//
//     final banklistitem = banklistitemFromJson(jsonString);

import 'dart:convert';

Banklistitem banklistitemFromJson(String str) =>
    Banklistitem.fromJson(json.decode(str));

String banklistitemToJson(Banklistitem data) => json.encode(data.toJson());

class Banklistitem {
  Banklistitem({
    this.list,
  });

  List<nBankListElement> list;

  factory Banklistitem.fromJson(Map<String, dynamic> json) => Banklistitem(
        list: List<nBankListElement>.from(
            json["list"].map((x) => nBankListElement.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "list": List<dynamic>.from(list.map((x) => x.toJson())),
      };
}

class nBankListElement {
  nBankListElement({
    this.id,
    this.bankId,
    this.bankName,
    this.cardNumber,
    this.province,
    this.city,
    this.branchBank,
    this.realName,
    this.idNumber,
    this.bankPhone,
    this.isDefault,
  });

  int id;
  int bankId;
  String bankName;
  String cardNumber;
  String province;
  String city;
  String branchBank;
  String realName;
  String idNumber;
  String bankPhone;
  int isDefault;

  factory nBankListElement.fromJson(Map<String, dynamic> json) =>
      nBankListElement(
        id: json["id"],
        bankId: json["bank_id"],
        bankName: json["bank_name"],
        cardNumber: json["card_number"],
        province: json["province"],
        city: json["city"],
        branchBank: json["branch_bank"],
        realName: json["real_name"],
        idNumber: json["id_number"],
        bankPhone: json["bank_phone"],
        isDefault: json["is_default"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "bank_id": bankId,
        "bank_name": bankName,
        "card_number": cardNumber,
        "province": province,
        "city": city,
        "branch_bank": branchBank,
        "real_name": realName,
        "id_number": idNumber,
        "bank_phone": bankPhone,
        "is_default": isDefault,
      };
}
