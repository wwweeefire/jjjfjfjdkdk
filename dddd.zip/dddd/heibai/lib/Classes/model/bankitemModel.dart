// To parse this JSON data, do
//
//     final bankitemModel = bankitemModelFromJson(jsonString);

import 'dart:convert';

BankitemModel bankitemModelFromJson(String str) =>
    BankitemModel.fromJson(json.decode(str));

String bankitemModelToJson(BankitemModel data) => json.encode(data.toJson());

class BankitemModel {
  BankitemModel({
    this.list,
  });

  List<bankListElement> list;

  factory BankitemModel.fromJson(Map<String, dynamic> json) => BankitemModel(
        list: List<bankListElement>.from(
            json["list"].map((x) => bankListElement.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "list": List<dynamic>.from(list.map((x) => x.toJson())),
      };
}

class bankListElement {
  bankListElement({
    this.bankName,
    this.id,
  });

  String bankName;
  int id;

  factory bankListElement.fromJson(Map<String, dynamic> json) =>
      bankListElement(
        bankName: json["bank_name"],
        id: json["id"],
      );

  Map<String, dynamic> toJson() => {
        "bank_name": bankName,
        "id": id,
      };
}
