// To parse this JSON data, do
//
//     final noticelistmodel = noticelistmodelFromJson(jsonString);

import 'dart:convert';

Noticelistmodel noticelistmodelFromJson(String str) =>
    Noticelistmodel.fromJson(json.decode(str));

String noticelistmodelToJson(Noticelistmodel data) =>
    json.encode(data.toJson());

class Noticelistmodel {
  Noticelistmodel({
    this.list,
    this.page,
  });

  List<ListElement> list;
  Page page;

  factory Noticelistmodel.fromJson(Map<String, dynamic> json) =>
      Noticelistmodel(
        list: List<ListElement>.from(
            json["list"].map((x) => ListElement.fromJson(x))),
        page: Page.fromJson(json["page"]),
      );

  Map<String, dynamic> toJson() => {
        "list": List<dynamic>.from(list.map((x) => x.toJson())),
        "page": page.toJson(),
      };
}

class ListElement {
  ListElement({
    this.id,
    this.title,
    this.content,
    this.createTime,
  });

  int id;
  String title;
  String content;
  int createTime;

  factory ListElement.fromJson(Map<String, dynamic> json) => ListElement(
        id: json["id"],
        title: json["title"],
        content: json["content"],
        createTime: json["create_time"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "content": content,
        "create_time": createTime,
      };
}

class Page {
  Page({
    this.page,
    this.pageSize,
    this.record,
    this.total,
  });

  int page;
  int pageSize;
  int record;
  int total;

  factory Page.fromJson(Map<String, dynamic> json) => Page(
        page: json["page"],
        pageSize: json["page_size"],
        record: json["record"],
        total: json["total"],
      );

  Map<String, dynamic> toJson() => {
        "page": page,
        "page_size": pageSize,
        "record": record,
        "total": total,
      };
}
