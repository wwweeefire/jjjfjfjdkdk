// To parse this JSON data, do
//
//     final rechargemethod = rechargemethodFromJson(jsonString);

import 'dart:convert';

Rechargemethod rechargemethodFromJson(String str) =>
    Rechargemethod.fromJson(json.decode(str));

String rechargemethodToJson(Rechargemethod data) => json.encode(data.toJson());

class Rechargemethod {
  Rechargemethod({
    this.list,
  });

  List<ListElement> list;

  factory Rechargemethod.fromJson(Map<String, dynamic> json) => Rechargemethod(
        list: List<ListElement>.from(
            json["list"].map((x) => ListElement.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "list": List<dynamic>.from(list.map((x) => x.toJson())),
      };
}

class ListElement {
  ListElement({
    this.id,
    this.name,
    this.code,
    this.icon,
  });

  int id;
  String name;
  String code;
  String icon;

  factory ListElement.fromJson(Map<String, dynamic> json) => ListElement(
        id: json["id"],
        name: json["name"],
        code: json["code"],
        icon: json["icon"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "code": code,
        "icon": icon,
      };
}
