// To parse this JSON data, do
//
//     final bankDes = bankDesFromJson(jsonString);

import 'dart:convert';

List<BankDes> bankDesFromJson(String str) =>
    List<BankDes>.from(json.decode(str).map((x) => BankDes.fromJson(x)));

String bankDesToJson(List<BankDes> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class BankDes {
  BankDes({
    this.bankName,
    this.branchBank,
    this.cardNumber,
    this.id,
    this.realName,
  });

  String bankName;
  String branchBank;
  String cardNumber;
  int id;
  String realName;

  factory BankDes.fromJson(Map<String, dynamic> json) => BankDes(
        bankName: json["bank_name"],
        branchBank: json["branch_bank"],
        cardNumber: json["card_number"],
        id: json["id"],
        realName: json["real_name"],
      );

  Map<String, dynamic> toJson() => {
        "bank_name": bankName,
        "branch_bank": branchBank,
        "card_number": cardNumber,
        "id": id,
        "real_name": realName,
      };
}
