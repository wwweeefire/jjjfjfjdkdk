// To parse this JSON data, do
//
//     final Config = ConfigFromJson(jsonString);

import 'dart:convert';
import 'package:heibai/Classes/model/UserInfo.dart';

import 'package:heibai/Classes/model/level.dart';

Config ConfigFromJson(String str) => Config.fromJson(json.decode(str));

String ConfigToJson(Config data) => json.encode(data.toJson());

class ConfigManager {
  /// *********************************** 实例变量 ***********************************

  Config config;
  UserInfo user;
  Level level;
  bool isshown = true;

  String code = "zh";

  String host = '';
  String imageHost = '';

  String scockHost;

  // String dioManageID;
  /// [DioManager]持有的 - 静态的final实例对象, 并进行初始化
  static final ConfigManager _dioManager = ConfigManager._instance();

  /// *********************************** 构造函数 ***********************************

  /// [DioManager]私有的 自定义命名式构造方法, Ps:instance不是关键字, 可随意命名
  /// 加 _ 表示该命名式构造函数为[DioManager]私有, 外部是不可调用的,
  /// 从而确保该命名式构造函数的使用, 仅可用来创建 _dioManager 这个静态的final实例对象
  ConfigManager._instance() {}

  /// 工厂化的主构造函数 - 返回私有的实例对象
  /// 返回的就是唯一的实例 _dioManager
  factory ConfigManager() {
    return _dioManager;
  }

  /// *********************************** 实例方法 ***********************************

}

class Config {
  Config({
    this.base,
    this.funds,
    this.kf,
    this.lang,
  });

  Base base;
  Funds funds;
  List<Kf> kf;
  List<Lang> lang;

  factory Config.fromJson(Map<String, dynamic> json) => Config(
        base: Base.fromJson(json["base"]),
        funds: Funds.fromJson(json["funds"]),
        kf: List<Kf>.from(json["kf"].map((x) => Kf.fromJson(x))),
        lang: List<Lang>.from(json["lang"].map((x) => Lang.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "base": base.toJson(),
        "funds": funds.toJson(),
        "kf": List<dynamic>.from(kf.map((x) => x.toJson())),
        "lang": List<dynamic>.from(lang.map((x) => x.toJson())),
      };
}

class Base {
  Base({
    this.appName,
    this.appLogo,
    this.allowRegister,
    this.mobileRegister,
    this.mustInviteCode,
    this.showInviteCode,
    this.autoUpgrade,
    this.bindCard,
    this.bankCardTotal,
    this.editBankCard,
    this.symbolName,
    this.symbolIcon,
    this.symbolFlag,
    this.symbolUsdt,
    this.remoteNews,
    this.remoteLink,
  });

  String appName;
  String appLogo;
  int allowRegister;
  int mobileRegister;
  int mustInviteCode;
  int showInviteCode;
  int autoUpgrade;
  int bindCard;
  int bankCardTotal;
  int editBankCard;
  String symbolName;
  String symbolIcon;
  String symbolFlag;
  double symbolUsdt;
  int remoteNews;
  String remoteLink;

  factory Base.fromJson(Map<String, dynamic> json) => Base(
        appName: json["app_name"],
        appLogo: json["app_logo"],
        allowRegister: json["allow_register"],
        mobileRegister: json["mobile_register"],
        mustInviteCode: json["must_invite_code"],
        showInviteCode: json["show_invite_code"],
        autoUpgrade: json["auto_upgrade"],
        bindCard: json["bind_card"],
        bankCardTotal: json["bank_card_total"],
        editBankCard: json["edit_bank_card"],
        symbolName: json["symbol_name"],
        symbolIcon: json["symbol_icon"],
        symbolFlag: json["symbol_flag"],
        symbolUsdt: json["symbol_usdt"].toDouble(),
        remoteNews: json["remote_news"],
        remoteLink: json["remote_link"],
      );

  Map<String, dynamic> toJson() => {
        "app_name": appName,
        "app_logo": appLogo,
        "allow_register": allowRegister,
        "mobile_register": mobileRegister,
        "must_invite_code": mustInviteCode,
        "show_invite_code": showInviteCode,
        "auto_upgrade": autoUpgrade,
        "bind_card": bindCard,
        "bank_card_total": bankCardTotal,
        "edit_bank_card": editBankCard,
        "symbol_name": symbolName,
        "symbol_icon": symbolIcon,
        "symbol_flag": symbolFlag,
        "symbol_usdt": symbolUsdt,
        "remote_news": remoteNews,
        "remote_link": remoteLink,
      };
}

class Funds {
  Funds({
    this.rechargeStartTime,
    this.rechargeEndTime,
    this.rechargeMinAmount,
    this.rechargeMaxAmount,
    this.rechargeFee,
    this.rechargeQuickAmount,
    this.withdrawStartTime,
    this.withdrawEndTime,
    this.mustPassword,
    this.passwordFreeze,
    this.withdrawMinAmount,
    this.withdrawMaxAmount,
    this.withdrawFee,
    this.productFee,
    this.productQuickAmount,
    this.kfRecharge,
  });

  String rechargeStartTime;
  String rechargeEndTime;
  int rechargeMinAmount;
  int rechargeMaxAmount;
  int rechargeFee;
  String rechargeQuickAmount;
  String withdrawStartTime;
  String withdrawEndTime;
  int mustPassword;
  int passwordFreeze;
  int withdrawMinAmount;
  int withdrawMaxAmount;
  int withdrawFee;
  int productFee;
  String productQuickAmount;
  int kfRecharge;

  factory Funds.fromJson(Map<String, dynamic> json) => Funds(
        rechargeStartTime: json["recharge_start_time"],
        rechargeEndTime: json["recharge_end_time"],
        rechargeMinAmount: json["recharge_min_amount"],
        rechargeMaxAmount: json["recharge_max_amount"],
        rechargeFee: json["recharge_fee"],
        rechargeQuickAmount: json["recharge_quick_amount"],
        withdrawStartTime: json["withdraw_start_time"],
        withdrawEndTime: json["withdraw_end_time"],
        mustPassword: json["must_password"],
        passwordFreeze: json["password_freeze"],
        withdrawMinAmount: json["withdraw_min_amount"],
        withdrawMaxAmount: json["withdraw_max_amount"],
        withdrawFee: json["withdraw_fee"],
        productFee: json["product_fee"],
        productQuickAmount: json["product_quick_amount"],
        kfRecharge: json["kf_recharge"],
      );

  Map<String, dynamic> toJson() => {
        "recharge_start_time": rechargeStartTime,
        "recharge_end_time": rechargeEndTime,
        "recharge_min_amount": rechargeMinAmount,
        "recharge_max_amount": rechargeMaxAmount,
        "recharge_fee": rechargeFee,
        "recharge_quick_amount": rechargeQuickAmount,
        "withdraw_start_time": withdrawStartTime,
        "withdraw_end_time": withdrawEndTime,
        "must_password": mustPassword,
        "password_freeze": passwordFreeze,
        "withdraw_min_amount": withdrawMinAmount,
        "withdraw_max_amount": withdrawMaxAmount,
        "withdraw_fee": withdrawFee,
        "product_fee": productFee,
        "product_quick_amount": productQuickAmount,
        "kf_recharge": kfRecharge,
      };
}

class Kf {
  Kf({
    this.id,
    this.name,
    this.startTime,
    this.endTime,
    this.link,
  });

  int id;
  String name;
  String startTime;
  String endTime;
  String link;

  factory Kf.fromJson(Map<String, dynamic> json) => Kf(
        id: json["id"],
        name: json["name"],
        startTime: json["start_time"],
        endTime: json["end_time"],
        link: json["link"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "start_time": startTime,
        "end_time": endTime,
        "link": link,
      };
}

class Lang {
  Lang({
    this.id,
    this.name,
    this.code,
    this.icon,
    this.isDefault,
  });

  int id;
  String name;
  String code;
  String icon;
  int isDefault;

  factory Lang.fromJson(Map<String, dynamic> json) => Lang(
        id: json["id"],
        name: json["name"],
        code: json["code"],
        icon: json["icon"],
        isDefault: json["is_default"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "code": code,
        "icon": icon,
        "is_default": isDefault,
      };
}
