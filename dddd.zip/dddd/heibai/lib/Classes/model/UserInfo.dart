// To parse this JSON data, do
//
//     final userInfo = userInfoFromJson(jsonString);

import 'dart:convert';
import 'package:heibai/Classes/model/level.dart';
import 'package:heibai/Classes/model/config.dart';
import 'package:heibai/util/DataUtils.dart';

UserInfo userInfoFromJson(String str) => UserInfo.fromJson(json.decode(str));

String userInfoToJson(UserInfo data) => json.encode(data.toJson());

class UserInfo {
  UserInfo({
    this.id,
    this.username,
    this.balance,
    this.parentId,
    this.isReal,
    this.realName,
    this.investFreeze,
    this.investAmount,
    this.investIncome,
    this.avatar,
    this.status,
    this.fundsStatus,
    this.level,
    this.score,
    this.lastLoginTime,
    this.lastLoginIp,
    this.regTime,
    this.hasWithdrawPassword,
    this.registerIp,
    this.token,
    this.nickname,
    this.mobile,
    this.email,
    this.qq,
    this.wechat,
    this.inviteCode,
  });

  int id;
  String username;
  double balance;
  int parentId;
  int isReal;
  String realName;
  double investFreeze;
  double investAmount;
  double investIncome;
  String avatar;
  int status;
  int fundsStatus;
  int level;
  int score;
  int lastLoginTime;
  String lastLoginIp;
  int regTime;
  int hasWithdrawPassword;
  String registerIp;
  String token;
  String nickname;
  String mobile;
  String email;
  String qq;
  String wechat;
  String inviteCode;

  factory UserInfo.fromJson(Map<String, dynamic> json) => UserInfo(
        id: json["id"],
        username: json["username"],
        balance: json["balance"].toDouble(),
        parentId: json["parent_id"],
        isReal: json["is_real"],
        realName: json["real_name"],
        investFreeze: json["invest_freeze"].toDouble(),
        investAmount: json["invest_amount"].toDouble(),
        investIncome: json["invest_income"].toDouble(),
        avatar: json["avatar"],
        status: json["status"],
        fundsStatus: json["funds_status"],
        level: json["level"],
        score: json["score"],
        lastLoginTime: json["last_login_time"],
        lastLoginIp: json["last_login_ip"],
        regTime: json["reg_time"],
        hasWithdrawPassword: json["has_withdraw_password"],
        registerIp: json["register_ip"],
        token: json["token"],
        nickname: json["nickname"],
        mobile: json["mobile"],
        email: json["email"],
        qq: json["qq"],
        wechat: json["wechat"],
        inviteCode: json["invite_code"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "username": username,
        "balance": balance,
        "parent_id": parentId,
        "is_real": isReal,
        "real_name": realName,
        "invest_freeze": investFreeze,
        "invest_amount": investAmount,
        "invest_income": investIncome,
        "avatar": avatar,
        "status": status,
        "funds_status": fundsStatus,
        "level": level,
        "score": score,
        "last_login_time": lastLoginTime,
        "last_login_ip": lastLoginIp,
        "reg_time": regTime,
        "has_withdraw_password": hasWithdrawPassword,
        "register_ip": registerIp,
        "token": token,
        "nickname": nickname,
        "mobile": mobile,
        "email": email,
        "qq": qq,
        "wechat": wechat,
        "invite_code": inviteCode,
      };
  String getis_real() {
    String path = null;

    if (this.isReal == 1) {
      path = "images/wode/mine_ certification@3x.png";
      return path;
    }
    if (this.isReal == 2) {
      path = "images/wode/mine_ certified@3x.png";
      return path;
    }
    if (this.isReal == 0 || this.isReal == 3) {
      path = "images/wode/mine_not_certified@3x.png";
      return path;
    }
    //  if (this.isReal == 0) {
    //   path = "";
    // }
    return null;
  }

  String getlevel() {
    String path = null;
    int graden = this.level;
    Level model = ConfigManager().level;
    if (model == null) {
      return path;
    } else {
      ListElement cu;
      for (ListElement item in model.list) {
        if (item.id == graden) {
          cu = item;
          break;
        }
      }
      if (cu != null) {
        path = cu.img;
      }
      return path;
    }
  }

  String getlevelname() {
    String path = "";
    int graden = this.level;
    Level model = ConfigManager().level;
    if (model == null) {
      return path;
    } else {
      ListElement cu;
      for (ListElement item in model.list) {
        if (item.id == graden) {
          cu = item;
          break;
        }
      }
      if (cu != null) {
        path = cu.name;
      }
      return path;
    }
  }

  String getusername() {
    Config f = ConfigManager().config;

    String path = this.username;
    // if (f != null) {
    //   if (f.base.mobileRegister == 1) {
    //     if (path == this.mobile && path.length > 7) {
    //       path = DataUtils.hidephoneNumber(path);
    //     }
    //   }
    // }
    return path;
  }

  String getphone() {
    Config f = ConfigManager().config;

    String path = this.mobile;
    // if (f != null && path.length > 7) {
    //   // if (f.base.mobileRegister == 1) {
    //   path = DataUtils.hidephoneNumber(path);
    //   // }
    // }
    return path;
  }
}
