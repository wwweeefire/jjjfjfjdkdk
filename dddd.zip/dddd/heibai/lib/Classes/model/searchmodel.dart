// To parse this JSON data, do
//
//     final searchmodel = searchmodelFromJson(jsonString);

import 'dart:convert';

Searchmodel searchmodelFromJson(String str) =>
    Searchmodel.fromJson(json.decode(str));

String searchmodelToJson(Searchmodel data) => json.encode(data.toJson());

class Searchmodel {
  Searchmodel({
    this.list,
    this.page,
  });

  List<ListElement> list;
  Page page;

  factory Searchmodel.fromJson(Map<String, dynamic> json) => Searchmodel(
        list: List<ListElement>.from(
            json["list"].map((x) => ListElement.fromJson(x))),
        page: Page.fromJson(json["page"]),
      );

  Map<String, dynamic> toJson() => {
        "list": List<dynamic>.from(list.map((x) => x.toJson())),
        "page": page.toJson(),
      };
}

class ListElement {
  ListElement({
    this.id,
    this.code,
    this.name,
    this.wave,
    this.openTime,
    this.weekendTrading,
    this.open,
    this.price,
    this.low,
    this.high,
    this.change,
    this.vol,
  });

  int id;
  String code;
  String name;
  double wave;
  String openTime;
  int weekendTrading;
  double open;
  double price;
  double low;
  double high;
  double change;
  int vol;

  factory ListElement.fromJson(Map<String, dynamic> json) => ListElement(
        id: json["id"],
        code: json["code"],
        name: json["name"],
        wave: json["wave"].toDouble(),
        openTime: json["open_time"],
        weekendTrading: json["weekend_trading"],
        open: json["open"].toDouble(),
        price: json["price"].toDouble(),
        low: json["low"].toDouble(),
        high: json["high"].toDouble(),
        change: json["change"].toDouble(),
        vol: json["vol"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "code": code,
        "name": name,
        "wave": wave,
        "open_time": openTime,
        "weekend_trading": weekendTrading,
        "open": open,
        "price": price,
        "low": low,
        "high": high,
        "change": change,
        "vol": vol,
      };
}

class Page {
  Page({
    this.page,
    this.pageSize,
    this.record,
    this.total,
  });

  int page;
  int pageSize;
  int record;
  int total;

  factory Page.fromJson(Map<String, dynamic> json) => Page(
        page: json["page"],
        pageSize: json["page_size"],
        record: json["record"],
        total: json["total"],
      );

  Map<String, dynamic> toJson() => {
        "page": page,
        "page_size": pageSize,
        "record": record,
        "total": total,
      };
}
