// To parse this JSON data, do
//
//     final positionRecordModel = positionRecordModelFromJson(jsonString);

import 'dart:convert';

PositionRecordModel positionRecordModelFromJson(String str) =>
    PositionRecordModel.fromJson(json.decode(str));

String positionRecordModelToJson(PositionRecordModel data) =>
    json.encode(data.toJson());

class PositionRecordModel {
  PositionRecordModel({
    this.list,
    this.page,
  });

  List<ListElement> list;
  Page page;

  factory PositionRecordModel.fromJson(Map<String, dynamic> json) =>
      PositionRecordModel(
        list: List<ListElement>.from(
            json["list"].map((x) => ListElement.fromJson(x))),
        page: Page.fromJson(json["page"]),
      );

  Map<String, dynamic> toJson() => {
        "list": List<dynamic>.from(list.map((x) => x.toJson())),
        "page": page.toJson(),
      };
}

class ListElement {
  ListElement({
    this.oid,
    this.pid,
    this.productName,
    this.chooseType,
    this.payMoney,
    this.drawMoney,
    this.payPrice,
    this.drawPrice,
    this.wave,
    this.createTime,
    this.drawTime,
    this.seconds,
  });

  int oid;
  int pid;
  String productName;
  int chooseType;
  int payMoney;
  double drawMoney;
  double payPrice;
  double drawPrice;
  double wave;
  int createTime;
  int drawTime;
  int seconds;

  factory ListElement.fromJson(Map<String, dynamic> json) => ListElement(
        oid: json["oid"],
        pid: json["pid"],
        productName: json["product_name"],
        chooseType: json["choose_type"],
        payMoney: json["pay_money"],
        drawMoney: json["draw_money"].toDouble(),
        payPrice: json["pay_price"].toDouble(),
        drawPrice: json["draw_price"].toDouble(),
        wave: json["wave"].toDouble(),
        createTime: json["create_time"],
        drawTime: json["draw_time"],
        seconds: json["seconds"],
      );

  Map<String, dynamic> toJson() => {
        "oid": oid,
        "pid": pid,
        "product_name": productName,
        "choose_type": chooseType,
        "pay_money": payMoney,
        "draw_money": drawMoney,
        "pay_price": payPrice,
        "draw_price": drawPrice,
        "wave": wave,
        "create_time": createTime,
        "draw_time": drawTime,
        "seconds": seconds,
      };
}

class Page {
  Page({
    this.page,
    this.pageSize,
    this.record,
    this.total,
  });

  int page;
  int pageSize;
  int record;
  int total;

  factory Page.fromJson(Map<String, dynamic> json) => Page(
        page: json["page"],
        pageSize: json["page_size"],
        record: json["record"],
        total: json["total"],
      );

  Map<String, dynamic> toJson() => {
        "page": page,
        "page_size": pageSize,
        "record": record,
        "total": total,
      };
}
