import 'dart:html';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';

import 'package:flutter/material.dart';
import 'package:heibai/constants/events/chageIndex.dart';
import 'dart:convert';
import 'constants/Constants.dart';
import 'constants/events/ChangeThemeEvent.dart';
import 'package:fluro/fluro.dart';
import 'package:heibai/util/DataUtils.dart';
import 'package:heibai/util/ThemeUtils.dart';
import 'package:heibai/util/NetUtils.dart';
import 'package:heibai/net/api/Api.dart';
import 'package:heibai/routers/navigator_util.dart';
import 'package:heibai/generated/l10n.dart';
import 'package:heibai/Classes/model/level.dart';
//import 'package:flutter_osc/util/DataUtils.dart';
//import 'package:flutter_osc/util/ThemeUtils.dart';
import 'pages/NewsListPage.dart'; //咨询
import 'pages/MarketPage.dart'; // 市场
import 'pages/PositionRecordPage.dart'; //记录
import 'pages/MyInfoPage.dart'; //我的信息

import 'pages/CommonzxWebPage.dart'; //我的信息

import 'pages/HomePage.dart'; //首页
import 'package:flutter_localizations/flutter_localizations.dart';
// import 'pages/login/loginView.dart';
import 'Classes/model/config.dart'; //咨询
import 'package:heibai/net/api/app_api.dart';
// import 'package:heibai/net/api/bean/weather_bean.dart';
// import 'package:fluttertoast/fluttertoast.dart';

import 'package:heibai/routers/Application.dart';
import 'package:heibai/routers/routes.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
// import 'package:heibai/util/DataUtils.dart';
import '../Classes/model/UserInfo.dart';
import 'package:heibai/pages/web_socket_utility.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:heibai/constants/events/LoginEvent.dart';

class _AppSetting {
  _AppSetting();

  Null Function(Locale locale) changeLocale;
  Locale _locale;
}

void main() {
  runApp(MyApp());
}

RouteObserver<PageRoute> routeObserver = RouteObserver<PageRoute>();

class MyApp extends StatefulWidget {
  @override
  MyAppState createState() => MyAppState();
}

class MyAppState extends State<MyApp> with WidgetsBindingObserver {
  bool isHttp = true;
  static _AppSetting setting = _AppSetting();

  // MyAppState() {
  //   queryBlackList();
  // }

  queryBlackList() async {
    DataUtils.getSharedPreferences();

    DataUtils.getchangehost().then((String userInfo) {
      if (userInfo != null) {
        ConfigManager().host = userInfo;
        ConfigManager().imageHost = userInfo;

        // ConfigManager().scockHost =
        String ee = ConfigManager().host;

        List<String> s = ee.split("//");

        ConfigManager().scockHost = "wss://" + s.last + "/api/v1/websocket";

        setState(() {
          isHttp = true;
        });
      } else {
        NetUtils.get(Api.githubhoust).then((data) {
          // Navigator.of(context).pop();
          if (data != null) {
            final jsonResult = json.decode(data);

            Anchor aa = Anchor.withMap(jsonResult);

            ConfigManager().host = aa.domain.first;
            ConfigManager().imageHost = aa.domain.first;
            String ee = ConfigManager().host;
            List<String> s = ee.split("//");

            ConfigManager().scockHost = "wss://" + s.last + "/api/v1/websocket";
            DataUtils.changehost(aa.domain.first);
            setState(() {
              isHttp = true;
            });
          } else {
            ConfigManager().host = Api.host;
            ConfigManager().imageHost = Api.imagehost;
            ConfigManager().scockHost = Api.SOCKET_URL;

            setState(() {
              isHttp = true;
            });
          }
        }).catchError((e) {
          ConfigManager().host = Api.host;
          ConfigManager().imageHost = Api.imagehost;

          ConfigManager().scockHost = Api.SOCKET_URL;
          setState(() {
            isHttp = true;
          });
        });
      }
    });
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this); //添加观察者
    setting.changeLocale = (Locale locale) {
      setState(() {
        setting._locale = locale;
      });
    };

    DataUtils.getSharedPreferences();

    DataUtils.getchangetheme();

    if (kIsWeb) {
      // wss://ooshanghai.vip/api/v1/websocket
      String host = window.location.origin;

      // String host = "https://ctolmax.vip/";
      List<String> s = host.split("//");

      ConfigManager().scockHost = "wss://" + s.last + "/api/v1/websocket";
      ConfigManager().imageHost = host;
      ConfigManager().host = host;
    }
  }

  @override
  void dispose() {
    super.dispose();
    // print('YM--------dispose');
    WidgetsBinding.instance.removeObserver(this); //添加观察者
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    switch (state) {
      case AppLifecycleState.inactive:
        //  应用程序处于闲置状态并且没有收到用户的输入事件。
        print("进入后台");
        //注意这个状态，在切换到后台时候会触发，所以流程应该是先冻结窗口，然后停止UI

        break;
      case AppLifecycleState.paused:
//      应用程序处于不可见状态

        break;
      case AppLifecycleState.resumed:
        {
          print("进入前台");
          SocketStatus dd = WebSocketUtility().socketStatus;
          if (dd == SocketStatus.SocketStatusClosed || dd == null) {
            getConnect();
          }
        }

        break;
      case AppLifecycleState.detached:
        //当前页面即将退出

        break;
    }
  }

  void getConnect() async {
    Map<String, dynamic> params = {};

    // // params["code"] = widget.model.code;

    // params["pid"] = widget.model.id;

    ResultData resultData =
        await AppApi.getInstance().getConnect(context, false, params);
    if (resultData.isSuccess()) {
      String id = resultData.data;

      WebSocketUtility().initWebSocket(
          onOpen: () {
            WebSocketUtility().initHeartBeat();
          },
          onMessage: (data) {
            // print(data);
          },
          onError: (e) {
            print(e);
          },
          id: id);
      // bool isf = true;

    }
  }

  @override
  Widget build(BuildContext context) {
    //-----------------路由主要代码start
    final router = FluroRouter();
    Routes.configureRoutes(router);
    Application.router = router;

    //-----------------路由主要代码end

//  _tabIndex = widget.tabIndex == null ? 0 : widget.tabIndex;

    return RefreshConfiguration(
      // DataUtils.changeLanguage().then((String userInfo) {
      //
      // });

      headerBuilder: () =>
          WaterDropHeader(), // 配置默认头部指示器,假如你每个页面的头部指示器都一样的话,你需要设置这个
      footerBuilder: () => ClassicFooter(), // 配置默认底部指示器
      // headerTriggerDistance: 80.0, // 头部触发刷新的越界距离
      //  springDescription:SpringDescription(stiffness: 170, damping: 16, mass: 1.9),         // 自定义回弹动画,三个属性值意义请查询flutter api
      // maxOverScrollExtent: 100, //头部最大可以拖动的范围,如果发生冲出视图范围区域,请设置这个属性
      maxUnderScrollExtent: 0, // 底部最大可以拖动的范围
      enableScrollWhenRefreshCompleted:
          true, //这个属性不兼容PageView和TabBarView,如果你特别需要TabBarView左右滑动,你需要把它设置为true
      enableLoadingWhenFailed: true, //在加载失败的状态下,用户仍然可以通过手势上拉来触发加载更多
      hideFooterWhenNotFull: false, // Viewport不满一屏时,禁用上拉加载更多功能
      enableBallisticLoad: true, // 可以通过惯性滑动触发加载更多

      child: MaterialApp(
        title: 'LMAX Global Trading',
        navigatorObservers: [routeObserver],
        builder: (context, child) => Scaffold(
          resizeToAvoidBottomInset: false,
          body: GestureDetector(
            onTap: () {
              FocusScopeNode currentFocus = FocusScope.of(context);
              if (!currentFocus.hasPrimaryFocus &&
                  currentFocus.focusedChild != null) {
                FocusManager.instance.primaryFocus.unfocus();
              }
            },
            child: child,
          ),
        ),
        localizationsDelegates: const [
          S.delegate,
          GlobalMaterialLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate
        ],
        // 讲zh设置为第一项,没有适配语言时，英语为首选项
        supportedLocales: S.delegate.supportedLocales,

        localeResolutionCallback: (Locale locale, Iterable supportedLocales) {
          var result = supportedLocales
              .where((element) => element.countryCode == locale.countryCode);
          if (result.isNotEmpty) {
            return locale;
          }
          return Locale('zh');
        },
        locale: setting._locale,
        // title: 'fluro',
        // locale: Locale('zh', 'CN'),
        // -----------------路由主要代码start
        onGenerateRoute: Application.router.generator,
        //-----------------路由主要代码end
        debugShowCheckedModeBanner: false,
        // theme: ThemeData(
        //   brightness: Brightness.light,
        //   primaryColor: Color.fromARGB(255, 78, 79, 95),
        // ),
        home: isHttp == true ? MyOSCClient() : Container(),
      ),
    );
  }
}

class MyOSCClient extends StatefulWidget {
  final int tabIndex;

  const MyOSCClient({Key key, this.tabIndex}) : super(key: key);

  @override
  State<StatefulWidget> createState() => MyOSCClientState(tabIndex);
}

showLoginDialog(context) {
  showDialog(
      context: context,
      builder: (BuildContext ctx) {
        return AlertDialog(
          title: Text(S.current.WLTS),
          content: Text(S.current.WLLJSB),
          actions: <Widget>[
            FlatButton(
              child: Text(
                S.current.WLCS,
                style: TextStyle(color: Colors.blue),
              ),
              onPressed: () {
                NavigatorUtil.goToHomeRemovePage(context);
              },
            )
          ],
        );
      });
}

class MyOSCClientState extends State<MyOSCClient> {
  final int tabIndex;
  // RecordContextView({
  //   Key key,
  //   this.tap,

  //   this.model,
  // })

  MyOSCClientState(this.tabIndex);

  var appBarTitles = [];
  TextStyle tabTextStyleNormal =
      TextStyle(color: ThemeUtils().currentColorTheme.dateGaryColor);
  TextStyle tabTextStyleSelected =
      TextStyle(color: ThemeUtils().currentColorTheme.tabbarSColor);

  Color themeColor = ThemeUtils().currentColorTheme.defaultColor;
  int _tabIndex = 0;
  var _body;
  // ignore: prefer_typing_uninitialized_variables
  var tabImages = [];

  // ignore: prefer_typing_uninitialized_variables
  var pages = [];
  bool isloading = true;

  Image getTabImage(path) {
    return Image.asset(path, width: 20.0, height: 20.0);
  }

  void get_config() async {
    ResultData resultData =
        await AppApi.getInstance().get_config(context, true);
    if (resultData.isSuccess()) {
      ConfigManager().config = ConfigFromJson(resultData.dataJson);
      appBarTitles = [
        S.of(context).tab_home,
        S.of(context).tab_market,
        S.of(context).tab_Position_record,
        S.of(context).tab_consult,
        S.of(context).tab_mine
      ];
      pages = <Widget>[
        HomePage(),
        MarketPage(),
        PositionRecordPage(),
        ConfigManager().config.base.remoteNews == 1
            ? CommonzxWebPage(
                title: S.current.tab_consult,
                htmlContent: ConfigManager().config.base.remoteLink)
            : NewsListPage(),
        MyInfoPage()
        // LoginView()
      ];
      tabImages = [
        [
          getTabImage('images/tabaricon/iocn_sy_no@3x.png'),
          getTabImage('images/tabaricon/iocn_sy_yes@3x.png')
        ],
        [
          getTabImage('images/tabaricon/iocn_sc_no@3x.png'),
          getTabImage('images/tabaricon/iocn_sc_yes@3x.png')
        ],
        [
          getTabImage('images/tabaricon/iocn_ccjl_no@3x.png'),
          getTabImage('images/tabaricon/iocn_ccjl_yes@3x.png')
        ],
        [
          getTabImage('images/tabaricon/iocn_zx_no@3x.png'),
          getTabImage("images/tabaricon/iocn_zx_yes@3x.png")
        ],
        [
          getTabImage('images/tabaricon/iocn_wd_no@3x.png'),
          getTabImage('images/tabaricon/iocn_wd_yes@3x.png')
        ]
      ];
      setState(() {
        isloading = false;
      });
    } else {
      // setState(() {
      //   isloading = true;
      // });
      showLoginDialog(context);
    }
  }

  void get_member_level_list() async {
    Map<String, dynamic> params = {};
    ResultData resultData = await AppApi.getInstance()
        .get_member_level_list(context, false, params);
    if (resultData.isSuccess()) {
      Level model = levelFromJson(resultData.dataJson);
      ConfigManager().level = model;

      // setState(() {
      //   isloading = false;
      // });
    } else {
      // setState(() {
      //   isloading = false;
      // });
    }
  }

  void getConnect() async {
    Map<String, dynamic> params = {};

    // // params["code"] = widget.model.code;

    // params["pid"] = widget.model.id;

    ResultData resultData =
        await AppApi.getInstance().getConnect(context, false, params);
    if (resultData.isSuccess()) {
      String id = resultData.data;

      WebSocketUtility().initWebSocket(
          onOpen: () {
            WebSocketUtility().initHeartBeat();
          },
          onMessage: (data) {
            // print(data);
          },
          onError: (e) {
            print(e);
          },
          id: id);
      // bool isf = true;

    }
  }

  @override
  void initState() {
    super.initState();

    get_member_level_list();

    DataUtils.getUserInfo().then((UserInfo userInfo) {
      if (userInfo != null) {
        SocketStatus dd = WebSocketUtility().socketStatus;
        if (dd == SocketStatus.SocketStatusClosed || dd == null) {
          getConnect();
        }
      } else {
        // NavigatorUtil.goToLoginRemovePage(context);
      }
    });

    get_config();

    DataUtils.getchangeLanguage().then((String userInfo) {
      if (userInfo == null) {
        ConfigManager().code = "zh";
        DataUtils.changeLanguage("zh");
      } else {
        ConfigManager().code = userInfo;
      }
      if (ConfigManager().code == "zh") S.load(Locale('zh', 'CN'));
      if (ConfigManager().code == "en") S.load(Locale('en', 'US'));
      if (ConfigManager().code == "zh_hk") S.load(Locale('zh', 'TW'));
    });

    _tabIndex = widget.tabIndex == null ? 0 : widget.tabIndex;
    Constants.eventBus.on<chageIndex>().listen((event) {
      setState(() {
        _tabIndex = event.index;
      });
    });
  }

  TextStyle getTabTextStyle(int curIndex) {
    if (curIndex == _tabIndex) {
      return tabTextStyleSelected;
    }
    return tabTextStyleNormal;
  }

  Image getTabIcon(int curIndex) {
    if (tabImages.length > 0) {
      if (curIndex == _tabIndex) {
        return tabImages[curIndex][1];
      }
      return tabImages[curIndex][0];
    }
    return Image();
  }

  Text getTabTitle(int curIndex) {
    if (tabImages.length > 0) {
      return Text(appBarTitles[curIndex], style: getTabTextStyle(curIndex));
    } else {
      return Text("");
    }
  }

  @override
  Widget build(BuildContext context) {
    final mediaQueryData = MediaQuery.of(context);

// 2.获取宽度和高度
    final screenWidth = mediaQueryData.size.width;

    if (pages.length > 0) {
      if (_tabIndex > 0) {
        ConfigManager m = ConfigManager();
        ConfigManager().isshown = false;
      }
      _body = IndexedStack(
        children: pages,
        index: _tabIndex,
      );
    }

    return isloading == true
        ? Scaffold(
            // appBar: AppBar(
            //     backgroundColor: Colors.black26, //设置appBar的背景色
            //     title: Text(appBarTitles[_tabIndex],
            //         style: TextStyle(color: ThemeUtils.labelColorW)),
            //     iconTheme: IconThemeData(color: ThemeUtils.labelColorW)),
            body: Container(
              color: ThemeUtils().currentColorTheme.labelColorW,
              child: Center(
                  child: InkWell(
                      onTap: () {},
                      child: Container(
                        alignment: Alignment.center,
                        child: Image.asset(
                          'images/wode/LaunchImage.png',
                          width: screenWidth,
                          height: screenWidth,
                          fit: BoxFit.cover,
                        ),
                      ))),
            ),
            drawer: null)
        : Scaffold(
            // appBar: AppBar(
            //     backgroundColor: Colors.black26, //设置appBar的背景色
            //     title: Text(appBarTitles[_tabIndex],
            //         style: TextStyle(color: ThemeUtils.labelColorW)),
            //     iconTheme: IconThemeData(color: ThemeUtils.labelColorW)),
            body: isloading == true
                ? InkWell(
                    onTap: () {},
                    child: Container(
                      alignment: Alignment.center,
                      child: Image.asset(
                        'images/wode/LaunchImage.png',
                        width: screenWidth,
                        height: screenWidth,
                        fit: BoxFit.cover,
                      ),
                    ))
                : _body,
            bottomNavigationBar: isloading == false
                ? CupertinoTabBar(
                    backgroundColor: ThemeUtils().currentColorTheme.tabbarColor,
                    items: <BottomNavigationBarItem>[
                      BottomNavigationBarItem(
                          icon: getTabIcon(0), title: getTabTitle(0)),
                      BottomNavigationBarItem(
                          icon: getTabIcon(1), title: getTabTitle(1)),
                      BottomNavigationBarItem(
                          icon: getTabIcon(2), title: getTabTitle(2)),
                      BottomNavigationBarItem(
                          icon: getTabIcon(3), title: getTabTitle(3)),
                      BottomNavigationBarItem(
                          icon: getTabIcon(4), title: getTabTitle(4)),
                    ],
                    currentIndex: _tabIndex,
                    onTap: (index) {
                      setState(() {
                        _tabIndex = index;
                      });
                      if (index == 4) {
                        Constants.eventBus.fire(LoginEvent());
                      }
                    },
                  )
                : CupertinoTabBar(),
            drawer: null);
  }
}
